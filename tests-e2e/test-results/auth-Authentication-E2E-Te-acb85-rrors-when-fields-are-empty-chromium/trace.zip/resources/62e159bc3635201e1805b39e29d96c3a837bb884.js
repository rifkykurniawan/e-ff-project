import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/transactions/TransactionForm.tsx");const useEffect = __vite__cjsImport2_react["useEffect"]; const useRef = __vite__cjsImport2_react["useRef"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=0a9b0578";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=9dd4f110";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=513be775";
import { transactionSchema, transactionTypes } from "/src/types/transactions.ts";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/features/transactions/TransactionForm.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
var _s = $RefreshSig$();
export function TransactionForm({ accounts, categories, onSubmit, isSubmitting, defaultType, initialData }) {
	_s();
	const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm({
		resolver: zodResolver(transactionSchema),
		defaultValues: {
			description: initialData?.description || "",
			amount: initialData?.amount !== undefined ? initialData.amount : undefined,
			type: initialData?.type || defaultType || "Expense",
			date: initialData?.date || new Date().toISOString().split("T")[0],
			source_account_id: initialData?.source_account_id || "",
			destination_account_id: initialData?.destination_account_id || "",
			category_id: initialData?.category_id || "",
			notes: initialData?.notes || ""
		}
	});
	const selectedType = watch("type");
	const isFirstMountRef = useRef(true);
	// Reset fields when type changes to satisfy validation rules
	useEffect(() => {
		if (isFirstMountRef.current) {
			isFirstMountRef.current = false;
			return;
		}
		if (selectedType === "Income") {
			setValue("source_account_id", null);
			setValue("category_id", categories.find((c) => c.type === "Income")?.id || "");
		} else if (selectedType === "Expense") {
			setValue("destination_account_id", null);
			setValue("category_id", categories.find((c) => c.type === "Expense")?.id || "");
		} else if (selectedType === "Transfer") {
			setValue("category_id", null);
		}
	}, [
		selectedType,
		setValue,
		categories
	]);
	// Filter categories by transaction type
	const filteredCategories = categories.filter((cat) => cat.type === selectedType);
	return /* @__PURE__ */ _jsxDEV("form", {
		onSubmit: handleSubmit(onSubmit),
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("label", {
					className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
					children: "Type"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex gap-2",
					children: transactionTypes.map((t) => /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						"data-testid": `transaction-type-${t.toLowerCase()}-button`,
						onClick: () => setValue("type", t, { shouldValidate: true }),
						className: `flex-1 py-2 text-sm font-medium rounded-lg border transition-all ${selectedType === t ? "bg-emerald-600 text-white border-emerald-600 shadow-sm" : "bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-50 dark:hover:bg-zinc-800"}`,
						children: t
					}, t, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 9
				}, this),
				errors.type && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-xs text-red-500",
					children: errors.type.message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 25
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("label", {
					className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
					children: "Description"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					type: "text",
					...register("description"),
					"data-testid": "transaction-description-input",
					placeholder: "e.g., Weekly groceries, Salary deposit",
					className: `w-full rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.description ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 9
				}, this),
				errors.description && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-xs text-red-500",
					children: errors.description.message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 102,
					columnNumber: 32
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("label", {
					className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
					children: "Amount"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 107,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "relative",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "absolute inset-y-0 left-0 flex items-center pl-3 text-zinc-500 sm:text-sm",
						children: "Rp"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "number",
						...register("amount"),
						"data-testid": "transaction-amount-input",
						placeholder: "0",
						className: `w-full rounded-lg border bg-white dark:bg-zinc-900 pl-9 pr-3 py-2 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.amount ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 9
				}, this),
				errors.amount && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-xs text-red-500",
					children: errors.amount.message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 27
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("label", {
					className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
					children: "Date"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 129,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					type: "date",
					...register("date"),
					"data-testid": "transaction-date-input",
					className: `w-full rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.date ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 132,
					columnNumber: 9
				}, this),
				errors.date && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-xs text-red-500",
					children: errors.date.message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 140,
					columnNumber: 25
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 128,
				columnNumber: 7
			}, this),
			(selectedType === "Expense" || selectedType === "Transfer") && /* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("label", {
					className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
					children: "Source Account"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 146,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "relative",
					children: [/* @__PURE__ */ _jsxDEV("select", {
						...register("source_account_id"),
						"data-testid": "transaction-source-account-select",
						className: `w-full appearance-none rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 pr-10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.source_account_id ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`,
						children: [/* @__PURE__ */ _jsxDEV("option", {
							value: "",
							children: "Select source account..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 157,
							columnNumber: 15
						}, this), accounts.map((acc) => /* @__PURE__ */ _jsxDEV("option", {
							value: acc.id,
							children: [
								acc.name,
								" (Rp ",
								acc.balance.toLocaleString(),
								")"
							]
						}, acc.id, true, {
							fileName: _jsxFileName,
							lineNumber: 159,
							columnNumber: 17
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-zinc-500",
						children: /* @__PURE__ */ _jsxDEV("svg", {
							className: "h-4 w-4",
							fill: "none",
							stroke: "currentColor",
							viewBox: "0 0 24 24",
							xmlns: "http://www.w3.org/2000/svg",
							children: /* @__PURE__ */ _jsxDEV("path", {
								strokeLinecap: "round",
								strokeLinejoin: "round",
								strokeWidth: "2",
								d: "M19 9l-7 7-7-7"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 166,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 165,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 164,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 149,
					columnNumber: 11
				}, this),
				errors.source_account_id && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-xs text-red-500",
					children: errors.source_account_id.message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 170,
					columnNumber: 40
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 145,
				columnNumber: 9
			}, this),
			(selectedType === "Income" || selectedType === "Transfer") && /* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("label", {
					className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
					children: "Destination Account"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 177,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "relative",
					children: [/* @__PURE__ */ _jsxDEV("select", {
						...register("destination_account_id"),
						"data-testid": "transaction-destination-account-select",
						className: `w-full appearance-none rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 pr-10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.destination_account_id ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`,
						children: [/* @__PURE__ */ _jsxDEV("option", {
							value: "",
							children: "Select destination account..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 188,
							columnNumber: 15
						}, this), accounts.map((acc) => /* @__PURE__ */ _jsxDEV("option", {
							value: acc.id,
							children: [
								acc.name,
								" (Rp ",
								acc.balance.toLocaleString(),
								")"
							]
						}, acc.id, true, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 17
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 181,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-zinc-500",
						children: /* @__PURE__ */ _jsxDEV("svg", {
							className: "h-4 w-4",
							fill: "none",
							stroke: "currentColor",
							viewBox: "0 0 24 24",
							xmlns: "http://www.w3.org/2000/svg",
							children: /* @__PURE__ */ _jsxDEV("path", {
								strokeLinecap: "round",
								strokeLinejoin: "round",
								strokeWidth: "2",
								d: "M19 9l-7 7-7-7"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 197,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 195,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 180,
					columnNumber: 11
				}, this),
				errors.destination_account_id && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-xs text-red-500",
					children: errors.destination_account_id.message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 201,
					columnNumber: 45
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 176,
				columnNumber: 9
			}, this),
			selectedType !== "Transfer" && /* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("label", {
					className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
					children: "Category"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 208,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "relative",
					children: [/* @__PURE__ */ _jsxDEV("select", {
						...register("category_id"),
						"data-testid": "transaction-category-select",
						className: `w-full appearance-none rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 pr-10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.category_id ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`,
						children: [/* @__PURE__ */ _jsxDEV("option", {
							value: "",
							children: "Select category..."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 219,
							columnNumber: 15
						}, this), filteredCategories.map((cat) => /* @__PURE__ */ _jsxDEV("option", {
							value: cat.id,
							children: cat.name
						}, cat.id, false, {
							fileName: _jsxFileName,
							lineNumber: 221,
							columnNumber: 17
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 212,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-zinc-500",
						children: /* @__PURE__ */ _jsxDEV("svg", {
							className: "h-4 w-4",
							fill: "none",
							stroke: "currentColor",
							viewBox: "0 0 24 24",
							xmlns: "http://www.w3.org/2000/svg",
							children: /* @__PURE__ */ _jsxDEV("path", {
								strokeLinecap: "round",
								strokeLinejoin: "round",
								strokeWidth: "2",
								d: "M19 9l-7 7-7-7"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 228,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 227,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 226,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 211,
					columnNumber: 11
				}, this),
				errors.category_id && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-xs text-red-500",
					children: errors.category_id.message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 232,
					columnNumber: 34
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 207,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
				className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
				children: "Notes (Optional)"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 238,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("textarea", {
				...register("notes"),
				"data-testid": "transaction-notes-textarea",
				placeholder: "Add extra details...",
				rows: 3,
				className: "w-full rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-3 py-2 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 241,
				columnNumber: 9
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 237,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "pt-4 flex justify-end",
				children: /* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: isSubmitting,
					"data-testid": "transaction-submit-button",
					className: "w-full sm:w-auto rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 disabled:opacity-50 transition-colors",
					children: isSubmitting ? "Logging..." : "Log Transaction"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 252,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 251,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 62,
		columnNumber: 5
	}, this);
}
_s(TransactionForm, "eNiql0LFlFtbXFurZ6eTOqwmhqA=", false, function() {
	return [useForm];
});
_c = TransactionForm;
var _c;
$RefreshReg$(_c, "TransactionForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/transactions/TransactionForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/features/transactions/TransactionForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/features/transactions/TransactionForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/features/transactions/TransactionForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsV0FBVyxjQUFjO0FBQ2xDLFNBQVMsbUJBQW1CLHdCQUErQzs7OztBQWEzRSxPQUFPLFNBQVMsZ0JBQWdCLEVBQUUsVUFBVSxZQUFZLFVBQVUsY0FBYyxhQUFhLGVBQXFDOztDQUNoSSxNQUFNLEVBQ0osVUFDQSxjQUNBLE9BQ0EsVUFDQSxXQUFXLEVBQUUsYUFDWCxRQUEwQjtFQUM1QixVQUFVLFlBQVksaUJBQWlCO0VBQ3ZDLGVBQWU7R0FDYixhQUFhLGFBQWEsZUFBZTtHQUN6QyxRQUFRLGFBQWEsV0FBVyxZQUFZLFlBQVksU0FBVTtHQUNsRSxNQUFNLGFBQWEsUUFBUSxlQUFlO0dBQzFDLE1BQU0sYUFBYSxRQUFRLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztHQUMvRCxtQkFBbUIsYUFBYSxxQkFBcUI7R0FDckQsd0JBQXdCLGFBQWEsMEJBQTBCO0dBQy9ELGFBQWEsYUFBYSxlQUFlO0dBQ3pDLE9BQU8sYUFBYSxTQUFTO0VBQy9CO0NBQ0YsQ0FBQztDQUVELE1BQU0sZUFBZSxNQUFNLE1BQU07Q0FDakMsTUFBTSxrQkFBa0IsT0FBTyxJQUFJOztDQUduQyxnQkFBZ0I7RUFDZCxJQUFJLGdCQUFnQixTQUFTO0dBQzNCLGdCQUFnQixVQUFVO0dBQzFCO0VBQ0Y7RUFDQSxJQUFJLGlCQUFpQixVQUFVO0dBQzdCLFNBQVMscUJBQXFCLElBQUk7R0FDbEMsU0FBUyxlQUFlLFdBQVcsTUFBSyxNQUFLLEVBQUUsU0FBUyxRQUFRLENBQUMsRUFBRSxNQUFNLEVBQUU7RUFDN0UsT0FBTyxJQUFJLGlCQUFpQixXQUFXO0dBQ3JDLFNBQVMsMEJBQTBCLElBQUk7R0FDdkMsU0FBUyxlQUFlLFdBQVcsTUFBSyxNQUFLLEVBQUUsU0FBUyxTQUFTLENBQUMsRUFBRSxNQUFNLEVBQUU7RUFDOUUsT0FBTyxJQUFJLGlCQUFpQixZQUFZO0dBQ3RDLFNBQVMsZUFBZSxJQUFJO0VBQzlCO0NBQ0YsR0FBRztFQUFDO0VBQWM7RUFBVTtDQUFVLENBQUM7O0NBR3ZDLE1BQU0scUJBQXFCLFdBQVcsUUFBUSxRQUFRLElBQUksU0FBUyxZQUFZO0NBRS9FLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFVBQVUsYUFBYSxRQUFRO0VBQUcsV0FBVTtZQUFsRDtHQUVFLHdCQUFDLE9BQUQ7SUFDRSx3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUFrRTtJQUU1RTs7Ozs7SUFDUCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLGlCQUFpQixLQUFLLE1BQ3JCLHdCQUFDLFVBQUQ7TUFFRSxNQUFLO01BQ0wsZUFBYSxvQkFBb0IsRUFBRSxZQUFZLEVBQUU7TUFDakQsZUFBZSxTQUFTLFFBQVEsR0FBRyxFQUFFLGdCQUFnQixLQUFLLENBQUM7TUFDM0QsV0FBVyxvRUFDVCxpQkFBaUIsSUFDYiwyREFDQTtnQkFHTDtLQUNLLEdBWEQ7Ozs7WUFXQyxDQUNUO0lBQ0U7Ozs7O0lBQ0osT0FBTyxRQUFRLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQTZCLE9BQU8sS0FBSztJQUFXOzs7OztHQUM5RTs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQ0Usd0JBQUMsU0FBRDtLQUFPLFdBQVU7ZUFBa0U7SUFFNUU7Ozs7O0lBQ1Asd0JBQUMsU0FBRDtLQUNFLE1BQUs7S0FDTCxHQUFJLFNBQVMsYUFBYTtLQUMxQixlQUFZO0tBQ1osYUFBWTtLQUNaLFdBQVcscUxBQ1QsT0FBTyxjQUFjLHdDQUF3QztJQUVoRTs7Ozs7SUFDQSxPQUFPLGVBQWUsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBNkIsT0FBTyxZQUFZO0lBQVc7Ozs7O0dBQzVGOzs7OztHQUdMLHdCQUFDLE9BQUQ7SUFDRSx3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUFrRTtJQUU1RTs7Ozs7SUFDUCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQTRFO0tBRXRGOzs7O2VBQ04sd0JBQUMsU0FBRDtNQUNFLE1BQUs7TUFDTCxHQUFJLFNBQVMsUUFBUTtNQUNyQixlQUFZO01BQ1osYUFBWTtNQUNaLFdBQVcsMExBQ1QsT0FBTyxTQUFTLHdDQUF3QztLQUUzRDs7OzthQUNFOzs7Ozs7SUFDSixPQUFPLFVBQVUsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBNkIsT0FBTyxPQUFPO0lBQVc7Ozs7O0dBQ2xGOzs7OztHQUdMLHdCQUFDLE9BQUQ7SUFDRSx3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUFrRTtJQUU1RTs7Ozs7SUFDUCx3QkFBQyxTQUFEO0tBQ0UsTUFBSztLQUNMLEdBQUksU0FBUyxNQUFNO0tBQ25CLGVBQVk7S0FDWixXQUFXLGdLQUNULE9BQU8sT0FBTyx3Q0FBd0M7SUFFekQ7Ozs7O0lBQ0EsT0FBTyxRQUFRLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQTZCLE9BQU8sS0FBSztJQUFXOzs7OztHQUM5RTs7Ozs7SUFHSCxpQkFBaUIsYUFBYSxpQkFBaUIsZUFDL0Msd0JBQUMsT0FBRDtJQUNFLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWtFO0lBRTVFOzs7OztJQUNQLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFEO01BQ0UsR0FBSSxTQUFTLG1CQUFtQjtNQUNoQyxlQUFZO01BQ1osV0FBVyxzTEFDVCxPQUFPLG9CQUFvQix3Q0FBd0M7Z0JBSnZFLENBT0Usd0JBQUMsVUFBRDtPQUFRLE9BQU07aUJBQUc7TUFBZ0M7Ozs7Z0JBQ2hELFNBQVMsS0FBSyxRQUNiLHdCQUFDLFVBQUQ7T0FBcUIsT0FBTyxJQUFJO2lCQUFoQztRQUNHLElBQUk7UUFBSztRQUFNLElBQUksUUFBUSxlQUFlO1FBQUU7T0FDdkM7U0FGSyxJQUFJOzs7O2FBRVQsQ0FDVCxDQUNLOzs7OztlQUNSLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQVUsTUFBSztPQUFPLFFBQU87T0FBZSxTQUFRO09BQVksT0FBTTtpQkFDbkYsd0JBQUMsUUFBRDtRQUFNLGVBQWM7UUFBUSxnQkFBZTtRQUFRLGFBQVk7UUFBSSxHQUFFO09BQXVCOzs7OztNQUN6Rjs7Ozs7S0FDRjs7OzthQUNGOzs7Ozs7SUFDSixPQUFPLHFCQUFxQix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUE2QixPQUFPLGtCQUFrQjtJQUFXOzs7OztHQUN4Rzs7Ozs7SUFJTCxpQkFBaUIsWUFBWSxpQkFBaUIsZUFDOUMsd0JBQUMsT0FBRDtJQUNFLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWtFO0lBRTVFOzs7OztJQUNQLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFEO01BQ0UsR0FBSSxTQUFTLHdCQUF3QjtNQUNyQyxlQUFZO01BQ1osV0FBVyxzTEFDVCxPQUFPLHlCQUF5Qix3Q0FBd0M7Z0JBSjVFLENBT0Usd0JBQUMsVUFBRDtPQUFRLE9BQU07aUJBQUc7TUFBcUM7Ozs7Z0JBQ3JELFNBQVMsS0FBSyxRQUNiLHdCQUFDLFVBQUQ7T0FBcUIsT0FBTyxJQUFJO2lCQUFoQztRQUNHLElBQUk7UUFBSztRQUFNLElBQUksUUFBUSxlQUFlO1FBQUU7T0FDdkM7U0FGSyxJQUFJOzs7O2FBRVQsQ0FDVCxDQUNLOzs7OztlQUNSLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQVUsTUFBSztPQUFPLFFBQU87T0FBZSxTQUFRO09BQVksT0FBTTtpQkFDbkYsd0JBQUMsUUFBRDtRQUFNLGVBQWM7UUFBUSxnQkFBZTtRQUFRLGFBQVk7UUFBSSxHQUFFO09BQXVCOzs7OztNQUN6Rjs7Ozs7S0FDRjs7OzthQUNGOzs7Ozs7SUFDSixPQUFPLDBCQUEwQix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUE2QixPQUFPLHVCQUF1QjtJQUFXOzs7OztHQUNsSDs7Ozs7R0FJTixpQkFBaUIsY0FDaEIsd0JBQUMsT0FBRDtJQUNFLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWtFO0lBRTVFOzs7OztJQUNQLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFEO01BQ0UsR0FBSSxTQUFTLGFBQWE7TUFDMUIsZUFBWTtNQUNaLFdBQVcsc0xBQ1QsT0FBTyxjQUFjLHdDQUF3QztnQkFKakUsQ0FPRSx3QkFBQyxVQUFEO09BQVEsT0FBTTtpQkFBRztNQUEwQjs7OztnQkFDMUMsbUJBQW1CLEtBQUssUUFDdkIsd0JBQUMsVUFBRDtPQUFxQixPQUFPLElBQUk7aUJBQzdCLElBQUk7TUFDQyxHQUZLLElBQUk7Ozs7YUFFVCxDQUNULENBQ0s7Ozs7O2VBQ1Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7T0FBVSxNQUFLO09BQU8sUUFBTztPQUFlLFNBQVE7T0FBWSxPQUFNO2lCQUNuRix3QkFBQyxRQUFEO1FBQU0sZUFBYztRQUFRLGdCQUFlO1FBQVEsYUFBWTtRQUFJLEdBQUU7T0FBdUI7Ozs7O01BQ3pGOzs7OztLQUNGOzs7O2FBQ0Y7Ozs7OztJQUNKLE9BQU8sZUFBZSx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUE2QixPQUFPLFlBQVk7SUFBVzs7Ozs7R0FDNUY7Ozs7O0dBSVAsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7SUFBTyxXQUFVO2NBQWtFO0dBRTVFOzs7O2FBQ1Asd0JBQUMsWUFBRDtJQUNFLEdBQUksU0FBUyxPQUFPO0lBQ3BCLGVBQVk7SUFDWixhQUFZO0lBQ1osTUFBTTtJQUNOLFdBQVU7R0FDWDs7OztXQUNFOzs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxVQUFVO0tBQ1YsZUFBWTtLQUNaLFdBQVU7ZUFFVCxlQUFlLGVBQWU7SUFDekI7Ozs7O0dBQ0w7Ozs7O0VBQ0Q7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlRyYW5zYWN0aW9uRm9ybS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gXCJyZWFjdC1ob29rLWZvcm1cIjtcbmltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSBcIkBob29rZm9ybS9yZXNvbHZlcnMvem9kXCI7XG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdHJhbnNhY3Rpb25TY2hlbWEsIHRyYW5zYWN0aW9uVHlwZXMsIHR5cGUgVHJhbnNhY3Rpb25JbnB1dCB9IGZyb20gXCIuLi8uLi90eXBlcy90cmFuc2FjdGlvbnNcIjtcbmltcG9ydCB0eXBlIHsgQWNjb3VudCB9IGZyb20gXCIuLi8uLi90eXBlcy9hY2NvdW50c1wiO1xuaW1wb3J0IHR5cGUgeyBDYXRlZ29yeSB9IGZyb20gXCIuLi8uLi90eXBlcy9jYXRlZ29yaWVzXCI7XG5cbmludGVyZmFjZSBUcmFuc2FjdGlvbkZvcm1Qcm9wcyB7XG4gIGFjY291bnRzOiBBY2NvdW50W107XG4gIGNhdGVnb3JpZXM6IENhdGVnb3J5W107XG4gIG9uU3VibWl0OiAoZGF0YTogVHJhbnNhY3Rpb25JbnB1dCkgPT4gUHJvbWlzZTx2b2lkPjtcbiAgaXNTdWJtaXR0aW5nPzogYm9vbGVhbjtcbiAgZGVmYXVsdFR5cGU/OiBcIkluY29tZVwiIHwgXCJFeHBlbnNlXCIgfCBcIlRyYW5zZmVyXCI7XG4gIGluaXRpYWxEYXRhPzogUGFydGlhbDxUcmFuc2FjdGlvbklucHV0Pjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFRyYW5zYWN0aW9uRm9ybSh7IGFjY291bnRzLCBjYXRlZ29yaWVzLCBvblN1Ym1pdCwgaXNTdWJtaXR0aW5nLCBkZWZhdWx0VHlwZSwgaW5pdGlhbERhdGEgfTogVHJhbnNhY3Rpb25Gb3JtUHJvcHMpIHtcbiAgY29uc3Qge1xuICAgIHJlZ2lzdGVyLFxuICAgIGhhbmRsZVN1Ym1pdCxcbiAgICB3YXRjaCxcbiAgICBzZXRWYWx1ZSxcbiAgICBmb3JtU3RhdGU6IHsgZXJyb3JzIH0sXG4gIH0gPSB1c2VGb3JtPFRyYW5zYWN0aW9uSW5wdXQ+KHtcbiAgICByZXNvbHZlcjogem9kUmVzb2x2ZXIodHJhbnNhY3Rpb25TY2hlbWEpIGFzIGFueSxcbiAgICBkZWZhdWx0VmFsdWVzOiB7XG4gICAgICBkZXNjcmlwdGlvbjogaW5pdGlhbERhdGE/LmRlc2NyaXB0aW9uIHx8IFwiXCIsXG4gICAgICBhbW91bnQ6IGluaXRpYWxEYXRhPy5hbW91bnQgIT09IHVuZGVmaW5lZCA/IGluaXRpYWxEYXRhLmFtb3VudCA6ICh1bmRlZmluZWQgYXMgYW55KSxcbiAgICAgIHR5cGU6IGluaXRpYWxEYXRhPy50eXBlIHx8IGRlZmF1bHRUeXBlIHx8IFwiRXhwZW5zZVwiLFxuICAgICAgZGF0ZTogaW5pdGlhbERhdGE/LmRhdGUgfHwgbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXSxcbiAgICAgIHNvdXJjZV9hY2NvdW50X2lkOiBpbml0aWFsRGF0YT8uc291cmNlX2FjY291bnRfaWQgfHwgXCJcIixcbiAgICAgIGRlc3RpbmF0aW9uX2FjY291bnRfaWQ6IGluaXRpYWxEYXRhPy5kZXN0aW5hdGlvbl9hY2NvdW50X2lkIHx8IFwiXCIsXG4gICAgICBjYXRlZ29yeV9pZDogaW5pdGlhbERhdGE/LmNhdGVnb3J5X2lkIHx8IFwiXCIsXG4gICAgICBub3RlczogaW5pdGlhbERhdGE/Lm5vdGVzIHx8IFwiXCIsXG4gICAgfSxcbiAgfSk7XG5cbiAgY29uc3Qgc2VsZWN0ZWRUeXBlID0gd2F0Y2goXCJ0eXBlXCIpO1xuICBjb25zdCBpc0ZpcnN0TW91bnRSZWYgPSB1c2VSZWYodHJ1ZSk7XG5cbiAgLy8gUmVzZXQgZmllbGRzIHdoZW4gdHlwZSBjaGFuZ2VzIHRvIHNhdGlzZnkgdmFsaWRhdGlvbiBydWxlc1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc0ZpcnN0TW91bnRSZWYuY3VycmVudCkge1xuICAgICAgaXNGaXJzdE1vdW50UmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHNlbGVjdGVkVHlwZSA9PT0gXCJJbmNvbWVcIikge1xuICAgICAgc2V0VmFsdWUoXCJzb3VyY2VfYWNjb3VudF9pZFwiLCBudWxsKTtcbiAgICAgIHNldFZhbHVlKFwiY2F0ZWdvcnlfaWRcIiwgY2F0ZWdvcmllcy5maW5kKGMgPT4gYy50eXBlID09PSBcIkluY29tZVwiKT8uaWQgfHwgXCJcIik7XG4gICAgfSBlbHNlIGlmIChzZWxlY3RlZFR5cGUgPT09IFwiRXhwZW5zZVwiKSB7XG4gICAgICBzZXRWYWx1ZShcImRlc3RpbmF0aW9uX2FjY291bnRfaWRcIiwgbnVsbCk7XG4gICAgICBzZXRWYWx1ZShcImNhdGVnb3J5X2lkXCIsIGNhdGVnb3JpZXMuZmluZChjID0+IGMudHlwZSA9PT0gXCJFeHBlbnNlXCIpPy5pZCB8fCBcIlwiKTtcbiAgICB9IGVsc2UgaWYgKHNlbGVjdGVkVHlwZSA9PT0gXCJUcmFuc2ZlclwiKSB7XG4gICAgICBzZXRWYWx1ZShcImNhdGVnb3J5X2lkXCIsIG51bGwpO1xuICAgIH1cbiAgfSwgW3NlbGVjdGVkVHlwZSwgc2V0VmFsdWUsIGNhdGVnb3JpZXNdKTtcblxuICAvLyBGaWx0ZXIgY2F0ZWdvcmllcyBieSB0cmFuc2FjdGlvbiB0eXBlXG4gIGNvbnN0IGZpbHRlcmVkQ2F0ZWdvcmllcyA9IGNhdGVnb3JpZXMuZmlsdGVyKChjYXQpID0+IGNhdC50eXBlID09PSBzZWxlY3RlZFR5cGUpO1xuXG4gIHJldHVybiAoXG4gICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChvblN1Ym1pdCl9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgey8qIFRyYW5zYWN0aW9uIFR5cGUgKi99XG4gICAgICA8ZGl2PlxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXppbmMtNzAwIGRhcms6dGV4dC16aW5jLTMwMCBtYi0xXCI+XG4gICAgICAgICAgVHlwZVxuICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICB7dHJhbnNhY3Rpb25UeXBlcy5tYXAoKHQpID0+IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAga2V5PXt0fVxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9e2B0cmFuc2FjdGlvbi10eXBlLSR7dC50b0xvd2VyQ2FzZSgpfS1idXR0b25gfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWYWx1ZShcInR5cGVcIiwgdCwgeyBzaG91bGRWYWxpZGF0ZTogdHJ1ZSB9KX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleC0xIHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSByb3VuZGVkLWxnIGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgIHNlbGVjdGVkVHlwZSA9PT0gdFxuICAgICAgICAgICAgICAgICAgPyBcImJnLWVtZXJhbGQtNjAwIHRleHQtd2hpdGUgYm9yZGVyLWVtZXJhbGQtNjAwIHNoYWRvdy1zbVwiXG4gICAgICAgICAgICAgICAgICA6IFwiYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAgdGV4dC16aW5jLTcwMCBkYXJrOnRleHQtemluYy0zMDAgaG92ZXI6YmctemluYy01MCBkYXJrOmhvdmVyOmJnLXppbmMtODAwXCJcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHt0fVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgICB7ZXJyb3JzLnR5cGUgJiYgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTUwMFwiPntlcnJvcnMudHlwZS5tZXNzYWdlfTwvcD59XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIERlc2NyaXB0aW9uICovfVxuICAgICAgPGRpdj5cbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC16aW5jLTcwMCBkYXJrOnRleHQtemluYy0zMDAgbWItMVwiPlxuICAgICAgICAgIERlc2NyaXB0aW9uXG4gICAgICAgIDwvbGFiZWw+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJkZXNjcmlwdGlvblwiKX1cbiAgICAgICAgICBkYXRhLXRlc3RpZD1cInRyYW5zYWN0aW9uLWRlc2NyaXB0aW9uLWlucHV0XCJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4sIFdlZWtseSBncm9jZXJpZXMsIFNhbGFyeSBkZXBvc2l0XCJcbiAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCBweC0zIHB5LTIgdGV4dC1zbSB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci16aW5jLTQwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAvMjAgJHtcbiAgICAgICAgICAgIGVycm9ycy5kZXNjcmlwdGlvbiA/IFwiYm9yZGVyLXJlZC01MDAgZm9jdXM6Ym9yZGVyLXJlZC01MDBcIiA6IFwiYm9yZGVyLXppbmMtMzAwIGRhcms6Ym9yZGVyLXppbmMtNzAwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgfWB9XG4gICAgICAgIC8+XG4gICAgICAgIHtlcnJvcnMuZGVzY3JpcHRpb24gJiYgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTUwMFwiPntlcnJvcnMuZGVzY3JpcHRpb24ubWVzc2FnZX08L3A+fVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBBbW91bnQgKi99XG4gICAgICA8ZGl2PlxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXppbmMtNzAwIGRhcms6dGV4dC16aW5jLTMwMCBtYi0xXCI+XG4gICAgICAgICAgQW1vdW50XG4gICAgICAgIDwvbGFiZWw+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgbGVmdC0wIGZsZXggaXRlbXMtY2VudGVyIHBsLTMgdGV4dC16aW5jLTUwMCBzbTp0ZXh0LXNtXCI+XG4gICAgICAgICAgICBScFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiYW1vdW50XCIpfVxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJ0cmFuc2FjdGlvbi1hbW91bnQtaW5wdXRcIlxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHBsLTkgcHItMyBweS0yIHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgcGxhY2Vob2xkZXItemluYy00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwICR7XG4gICAgICAgICAgICAgIGVycm9ycy5hbW91bnQgPyBcImJvcmRlci1yZWQtNTAwIGZvY3VzOmJvcmRlci1yZWQtNTAwXCIgOiBcImJvcmRlci16aW5jLTMwMCBkYXJrOmJvcmRlci16aW5jLTcwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIHtlcnJvcnMuYW1vdW50ICYmIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDBcIj57ZXJyb3JzLmFtb3VudC5tZXNzYWdlfTwvcD59XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIERhdGUgKi99XG4gICAgICA8ZGl2PlxuICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXppbmMtNzAwIGRhcms6dGV4dC16aW5jLTMwMCBtYi0xXCI+XG4gICAgICAgICAgRGF0ZVxuICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgey4uLnJlZ2lzdGVyKFwiZGF0ZVwiKX1cbiAgICAgICAgICBkYXRhLXRlc3RpZD1cInRyYW5zYWN0aW9uLWRhdGUtaW5wdXRcIlxuICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHB4LTMgcHktMiB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCAke1xuICAgICAgICAgICAgZXJyb3JzLmRhdGUgPyBcImJvcmRlci1yZWQtNTAwIGZvY3VzOmJvcmRlci1yZWQtNTAwXCIgOiBcImJvcmRlci16aW5jLTMwMCBkYXJrOmJvcmRlci16aW5jLTcwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgIH1gfVxuICAgICAgICAvPlxuICAgICAgICB7ZXJyb3JzLmRhdGUgJiYgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTUwMFwiPntlcnJvcnMuZGF0ZS5tZXNzYWdlfTwvcD59XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFNvdXJjZSBBY2NvdW50IChFeHBlbnNlIC8gVHJhbnNmZXIpICovfVxuICAgICAgeyhzZWxlY3RlZFR5cGUgPT09IFwiRXhwZW5zZVwiIHx8IHNlbGVjdGVkVHlwZSA9PT0gXCJUcmFuc2ZlclwiKSAmJiAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC16aW5jLTcwMCBkYXJrOnRleHQtemluYy0zMDAgbWItMVwiPlxuICAgICAgICAgICAgU291cmNlIEFjY291bnRcbiAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwic291cmNlX2FjY291bnRfaWRcIil9XG4gICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwidHJhbnNhY3Rpb24tc291cmNlLWFjY291bnQtc2VsZWN0XCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIGFwcGVhcmFuY2Utbm9uZSByb3VuZGVkLWxnIGJvcmRlciBiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHB4LTMgcHktMiBwci0xMCB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCAke1xuICAgICAgICAgICAgICAgIGVycm9ycy5zb3VyY2VfYWNjb3VudF9pZCA/IFwiYm9yZGVyLXJlZC01MDAgZm9jdXM6Ym9yZGVyLXJlZC01MDBcIiA6IFwiYm9yZGVyLXppbmMtMzAwIGRhcms6Ym9yZGVyLXppbmMtNzAwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IHNvdXJjZSBhY2NvdW50Li4uPC9vcHRpb24+XG4gICAgICAgICAgICAgIHthY2NvdW50cy5tYXAoKGFjYykgPT4gKFxuICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXthY2MuaWR9IHZhbHVlPXthY2MuaWR9PlxuICAgICAgICAgICAgICAgICAge2FjYy5uYW1lfSAoUnAge2FjYy5iYWxhbmNlLnRvTG9jYWxlU3RyaW5nKCl9KVxuICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIGluc2V0LXktMCByaWdodC0wIGZsZXggaXRlbXMtY2VudGVyIHB4LTMgdGV4dC16aW5jLTUwMFwiPlxuICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cImgtNCB3LTRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XG4gICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTkgOWwtNyA3LTctN1wiPjwvcGF0aD5cbiAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICB7ZXJyb3JzLnNvdXJjZV9hY2NvdW50X2lkICYmIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDBcIj57ZXJyb3JzLnNvdXJjZV9hY2NvdW50X2lkLm1lc3NhZ2V9PC9wPn1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogRGVzdGluYXRpb24gQWNjb3VudCAoSW5jb21lIC8gVHJhbnNmZXIpICovfVxuICAgICAgeyhzZWxlY3RlZFR5cGUgPT09IFwiSW5jb21lXCIgfHwgc2VsZWN0ZWRUeXBlID09PSBcIlRyYW5zZmVyXCIpICYmIChcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXppbmMtNzAwIGRhcms6dGV4dC16aW5jLTMwMCBtYi0xXCI+XG4gICAgICAgICAgICBEZXN0aW5hdGlvbiBBY2NvdW50XG4gICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImRlc3RpbmF0aW9uX2FjY291bnRfaWRcIil9XG4gICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwidHJhbnNhY3Rpb24tZGVzdGluYXRpb24tYWNjb3VudC1zZWxlY3RcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgYXBwZWFyYW5jZS1ub25lIHJvdW5kZWQtbGcgYm9yZGVyIGJnLXdoaXRlIGRhcms6YmctemluYy05MDAgcHgtMyBweS0yIHByLTEwIHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwICR7XG4gICAgICAgICAgICAgICAgZXJyb3JzLmRlc3RpbmF0aW9uX2FjY291bnRfaWQgPyBcImJvcmRlci1yZWQtNTAwIGZvY3VzOmJvcmRlci1yZWQtNTAwXCIgOiBcImJvcmRlci16aW5jLTMwMCBkYXJrOmJvcmRlci16aW5jLTcwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBkZXN0aW5hdGlvbiBhY2NvdW50Li4uPC9vcHRpb24+XG4gICAgICAgICAgICAgIHthY2NvdW50cy5tYXAoKGFjYykgPT4gKFxuICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXthY2MuaWR9IHZhbHVlPXthY2MuaWR9PlxuICAgICAgICAgICAgICAgICAge2FjYy5uYW1lfSAoUnAge2FjYy5iYWxhbmNlLnRvTG9jYWxlU3RyaW5nKCl9KVxuICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIGluc2V0LXktMCByaWdodC0wIGZsZXggaXRlbXMtY2VudGVyIHB4LTMgdGV4dC16aW5jLTUwMFwiPlxuICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cImgtNCB3LTRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XG4gICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTkgOWwtNyA3LTctN1wiPjwvcGF0aD5cbiAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICB7ZXJyb3JzLmRlc3RpbmF0aW9uX2FjY291bnRfaWQgJiYgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTUwMFwiPntlcnJvcnMuZGVzdGluYXRpb25fYWNjb3VudF9pZC5tZXNzYWdlfTwvcD59XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIENhdGVnb3J5IChJbmNvbWUgLyBFeHBlbnNlKSAqL31cbiAgICAgIHtzZWxlY3RlZFR5cGUgIT09IFwiVHJhbnNmZXJcIiAmJiAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC16aW5jLTcwMCBkYXJrOnRleHQtemluYy0zMDAgbWItMVwiPlxuICAgICAgICAgICAgQ2F0ZWdvcnlcbiAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiY2F0ZWdvcnlfaWRcIil9XG4gICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwidHJhbnNhY3Rpb24tY2F0ZWdvcnktc2VsZWN0XCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIGFwcGVhcmFuY2Utbm9uZSByb3VuZGVkLWxnIGJvcmRlciBiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHB4LTMgcHktMiBwci0xMCB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCAke1xuICAgICAgICAgICAgICAgIGVycm9ycy5jYXRlZ29yeV9pZCA/IFwiYm9yZGVyLXJlZC01MDAgZm9jdXM6Ym9yZGVyLXJlZC01MDBcIiA6IFwiYm9yZGVyLXppbmMtMzAwIGRhcms6Ym9yZGVyLXppbmMtNzAwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IGNhdGVnb3J5Li4uPC9vcHRpb24+XG4gICAgICAgICAgICAgIHtmaWx0ZXJlZENhdGVnb3JpZXMubWFwKChjYXQpID0+IChcbiAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Y2F0LmlkfSB2YWx1ZT17Y2F0LmlkfT5cbiAgICAgICAgICAgICAgICAgIHtjYXQubmFtZX1cbiAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSBpbnNldC15LTAgcmlnaHQtMCBmbGV4IGl0ZW1zLWNlbnRlciBweC0zIHRleHQtemluYy01MDBcIj5cbiAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJoLTQgdy00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTE5IDlsLTcgNy03LTdcIj48L3BhdGg+XG4gICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAge2Vycm9ycy5jYXRlZ29yeV9pZCAmJiA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1yZWQtNTAwXCI+e2Vycm9ycy5jYXRlZ29yeV9pZC5tZXNzYWdlfTwvcD59XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIE5vdGVzICovfVxuICAgICAgPGRpdj5cbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC16aW5jLTcwMCBkYXJrOnRleHQtemluYy0zMDAgbWItMVwiPlxuICAgICAgICAgIE5vdGVzIChPcHRpb25hbClcbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgey4uLnJlZ2lzdGVyKFwibm90ZXNcIil9XG4gICAgICAgICAgZGF0YS10ZXN0aWQ9XCJ0cmFuc2FjdGlvbi1ub3Rlcy10ZXh0YXJlYVwiXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJBZGQgZXh0cmEgZGV0YWlscy4uLlwiXG4gICAgICAgICAgcm93cz17M31cbiAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXppbmMtMzAwIGRhcms6Ym9yZGVyLXppbmMtNzAwIGJnLXdoaXRlIGRhcms6YmctemluYy05MDAgcHgtMyBweS0yIHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgcGxhY2Vob2xkZXItemluYy00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFN1Ym1pdCBCdXR0b24gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ31cbiAgICAgICAgICBkYXRhLXRlc3RpZD1cInRyYW5zYWN0aW9uLXN1Ym1pdC1idXR0b25cIlxuICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gcm91bmRlZC1sZyBiZy1lbWVyYWxkLTYwMCBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGhvdmVyOmJnLWVtZXJhbGQtNzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMCBmb2N1czpyaW5nLW9mZnNldC0yIGRpc2FibGVkOm9wYWNpdHktNTAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICA+XG4gICAgICAgICAge2lzU3VibWl0dGluZyA/IFwiTG9nZ2luZy4uLlwiIDogXCJMb2cgVHJhbnNhY3Rpb25cIn1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Zvcm0+XG4gICk7XG59XG4iXX0=