import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/BudgetsPage.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=513be775";
import { Edit2, PieChart, Info, AlertTriangle } from "/node_modules/.vite/deps/lucide-react.js?v=7df35618";
import { useBudgets } from "/src/hooks/useBudgets.ts";
import { useCategories } from "/src/hooks/useCategories.ts";
import { useTransactions } from "/src/hooks/useTransactions.ts";
import { Modal } from "/src/components/Modal.tsx";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=0a9b0578";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=9dd4f110";
import { budgetSchema } from "/src/types/budgets.ts";
import { useOutletContext } from "/node_modules/.vite/deps/react-router-dom.js?v=63710477";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/BudgetsPage.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
var _s = $RefreshSig$();
export function BudgetsPage() {
	_s();
	const currentDate = new Date();
	const [selectedYear, setSelectedYear] = useState(currentDate.getFullYear());
	const [selectedMonth, setSelectedMonth] = useState(currentDate.getMonth() + 1);
	const [editingBudget, setEditingBudget] = useState(null);
	const { showBalances } = useOutletContext();
	const formatAmount = (val) => {
		return showBalances ? `Rp ${val.toLocaleString()}` : "Rp ••••••";
	};
	const formatRemaining = (val) => {
		if (!showBalances) return "Rp ••••••";
		return `${val < 0 ? "-" : ""}Rp ${Math.abs(val).toLocaleString()}`;
	};
	const { categories } = useCategories();
	const { budgets, isLoading: isBudgetsLoading, createBudget, updateBudget } = useBudgets(selectedYear, selectedMonth);
	// Define date range for transactions query
	const startDate = `${selectedYear}-${String(selectedMonth).padStart(2, "0")}-01`;
	const lastDay = new Date(selectedYear, selectedMonth, 0).getDate();
	const endDate = `${selectedYear}-${String(selectedMonth).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`;
	const { transactions, isLoading: isTransactionsLoading } = useTransactions({
		startDate,
		endDate,
		type: "Expense"
	});
	const expenseCategories = categories.filter((c) => c.type === "Expense").sort((a, b) => a.name.localeCompare(b.name));
	// Sum actual spending per category
	const actualSpendingMap = expenseCategories.reduce((acc, cat) => {
		const total = transactions.filter((t) => t.category_id === cat.id && t.type === "Expense").reduce((sum, t) => sum + Number(t.amount), 0);
		acc[cat.id] = total;
		return acc;
	}, {});
	// React Hook Form for Set/Edit Budget Modal
	const { register, handleSubmit, formState: { errors }, reset } = useForm({
		resolver: zodResolver(budgetSchema),
		defaultValues: {
			category_id: "",
			year: selectedYear,
			month: selectedMonth,
			planned_amount: 0
		}
	});
	const handleOpenEdit = (categoryId, categoryName) => {
		const existing = budgets.find((b) => b.category_id === categoryId);
		setEditingBudget({
			categoryId,
			categoryName,
			budget: existing
		});
		reset({
			category_id: categoryId,
			year: selectedYear,
			month: selectedMonth,
			planned_amount: existing ? existing.planned_amount : 0
		});
	};
	const handleCloseEdit = () => {
		setEditingBudget(null);
	};
	const onFormSubmit = async (data) => {
		try {
			if (editingBudget?.budget) {
				await updateBudget({
					id: editingBudget.budget.id,
					input: { planned_amount: data.planned_amount }
				});
			} else {
				await createBudget(data);
			}
			handleCloseEdit();
		} catch (err) {
			console.error(err);
			alert(err.message || "Failed to save budget.");
		}
	};
	const months = [
		{
			value: 1,
			label: "January"
		},
		{
			value: 2,
			label: "February"
		},
		{
			value: 3,
			label: "March"
		},
		{
			value: 4,
			label: "April"
		},
		{
			value: 5,
			label: "May"
		},
		{
			value: 6,
			label: "June"
		},
		{
			value: 7,
			label: "July"
		},
		{
			value: 8,
			label: "August"
		},
		{
			value: 9,
			label: "September"
		},
		{
			value: 10,
			label: "October"
		},
		{
			value: 11,
			label: "November"
		},
		{
			value: 12,
			label: "December"
		}
	];
	const years = Array.from({ length: 5 }, (_, i) => currentDate.getFullYear() - 2 + i);
	const totalPlanned = budgets.reduce((sum, b) => sum + Number(b.planned_amount), 0);
	const totalActual = Object.values(actualSpendingMap).reduce((sum, val) => sum + val, 0);
	const totalRemaining = totalPlanned - totalActual;
	const isLoading = isBudgetsLoading || isTransactionsLoading;
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-2xl font-bold text-zinc-900 dark:text-white tracking-tight flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV(PieChart, { className: "h-6 w-6 text-emerald-500" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 137,
					columnNumber: 13
				}, this), "Monthly Budget"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 136,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-zinc-500 dark:text-zinc-400 mt-1",
				children: "Set monthly category spending limits and monitor actual payouts."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 140,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 135,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex gap-2 w-full sm:w-auto",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "relative flex-1 sm:flex-initial",
					children: [/* @__PURE__ */ _jsxDEV("select", {
						value: selectedMonth,
						onChange: (e) => setSelectedMonth(Number(e.target.value)),
						"data-testid": "month-select",
						className: "w-full appearance-none rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 px-3 py-2 pr-10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
						children: months.map((m) => /* @__PURE__ */ _jsxDEV("option", {
							value: m.value,
							children: m.label
						}, m.value, false, {
							fileName: _jsxFileName,
							lineNumber: 154,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 147,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-zinc-500",
						children: /* @__PURE__ */ _jsxDEV("svg", {
							className: "h-4 w-4",
							fill: "none",
							stroke: "currentColor",
							viewBox: "0 0 24 24",
							xmlns: "http://www.w3.org/2000/svg",
							children: /* @__PURE__ */ _jsxDEV("path", {
								strokeLinecap: "round",
								strokeLinejoin: "round",
								strokeWidth: "2",
								d: "M19 9l-7 7-7-7"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 159,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 158,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 157,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 146,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative flex-1 sm:flex-initial",
					children: [/* @__PURE__ */ _jsxDEV("select", {
						value: selectedYear,
						onChange: (e) => setSelectedYear(Number(e.target.value)),
						"data-testid": "year-select",
						className: "w-full appearance-none rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 px-3 py-2 pr-10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
						children: years.map((y) => /* @__PURE__ */ _jsxDEV("option", {
							value: y,
							children: y
						}, y, false, {
							fileName: _jsxFileName,
							lineNumber: 173,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 166,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-zinc-500",
						children: /* @__PURE__ */ _jsxDEV("svg", {
							className: "h-4 w-4",
							fill: "none",
							stroke: "currentColor",
							viewBox: "0 0 24 24",
							xmlns: "http://www.w3.org/2000/svg",
							children: /* @__PURE__ */ _jsxDEV("path", {
								strokeLinecap: "round",
								strokeLinejoin: "round",
								strokeWidth: "2",
								d: "M19 9l-7 7-7-7"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 178,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 176,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 165,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 144,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 134,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-1 md:grid-cols-3 gap-4 mb-8",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "text-zinc-500 dark:text-zinc-400 text-xs font-semibold uppercase tracking-wider",
						children: "Total Planned Budget"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 188,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "text-2xl font-bold text-zinc-900 dark:text-white mt-1",
						children: formatAmount(totalPlanned)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 187,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "text-zinc-500 dark:text-zinc-400 text-xs font-semibold uppercase tracking-wider",
						children: "Total Spent"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 192,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "text-2xl font-bold text-red-500 mt-1",
						children: formatAmount(totalActual)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 193,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 191,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "text-zinc-500 dark:text-zinc-400 text-xs font-semibold uppercase tracking-wider",
						children: "Remaining Budget"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 196,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: `text-2xl font-bold mt-1 ${totalRemaining < 0 ? "text-red-500" : "text-emerald-500"}`,
						children: formatRemaining(totalRemaining)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 197,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 195,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 186,
			columnNumber: 7
		}, this),
		isLoading ? /* @__PURE__ */ _jsxDEV("div", {
			className: "flex h-64 items-center justify-center text-zinc-500",
			children: "Loading budget sheet..."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 205,
			columnNumber: 9
		}, this) : expenseCategories.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 p-12 text-center",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-zinc-100 dark:bg-zinc-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4",
					children: /* @__PURE__ */ _jsxDEV(Info, { className: "h-8 w-8 text-zinc-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 209,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 208,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-lg font-semibold text-zinc-900 dark:text-white mb-2",
					children: "No Expense Categories Found"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 211,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-zinc-500 dark:text-zinc-400 max-w-sm mx-auto",
					children: "Please define some expense categories on the Categories page first to schedule monthly budgets."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 212,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 207,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden",
			children: /* @__PURE__ */ _jsxDEV("table", {
				className: "w-full text-left border-collapse",
				children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
					className: "border-b border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/50",
					children: [
						/* @__PURE__ */ _jsxDEV("th", {
							className: "p-4 text-xs font-semibold text-zinc-500 uppercase",
							children: "Category"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 221,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "p-4 text-xs font-semibold text-zinc-500 uppercase text-right",
							children: "Planned Limit"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 222,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "p-4 text-xs font-semibold text-zinc-500 uppercase text-right",
							children: "Actual Spent"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 223,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "p-4 text-xs font-semibold text-zinc-500 uppercase text-right",
							children: "Remaining Balance"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 224,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "p-4 text-xs font-semibold text-zinc-500 uppercase",
							children: "Progress Status"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 225,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", {
							className: "p-4 text-xs font-semibold text-zinc-500 uppercase text-center",
							children: "Action"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 226,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 220,
					columnNumber: 15
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 219,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("tbody", {
					className: "divide-y divide-zinc-100 dark:divide-zinc-800",
					children: expenseCategories.map((cat) => {
						const existingBudget = budgets.find((b) => b.category_id === cat.id);
						const planned = existingBudget ? Number(existingBudget.planned_amount) : 0;
						const actual = actualSpendingMap[cat.id] || 0;
						const remaining = planned - actual;
						// Progress calculations
						const progressPercentage = planned > 0 ? Math.min(actual / planned * 100, 100) : 0;
						const isOverBudget = remaining < 0;
						return /* @__PURE__ */ _jsxDEV("tr", {
							className: "hover:bg-zinc-50 dark:hover:bg-zinc-800/20 transition-colors",
							children: [
								/* @__PURE__ */ _jsxDEV("td", {
									className: "p-4 text-sm font-semibold text-zinc-900 dark:text-white align-top",
									children: cat.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 243,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "p-4 text-sm text-zinc-900 dark:text-zinc-300 text-right font-medium align-top",
									children: existingBudget ? formatAmount(planned) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-zinc-400 dark:text-zinc-600 italic",
										children: "Not set"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 250,
										columnNumber: 25
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 248,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "p-4 text-sm text-zinc-900 dark:text-zinc-300 text-right font-medium align-top",
									children: formatAmount(actual)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 255,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: `p-4 text-sm text-right font-semibold align-top ${isOverBudget ? "text-red-500" : "text-zinc-900 dark:text-zinc-300"}`,
									children: formatRemaining(remaining)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 260,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "p-4 align-top",
									children: planned > 0 ? /* @__PURE__ */ _jsxDEV("div", {
										className: "w-full max-w-xs",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex justify-between text-sm mb-1",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-zinc-500",
												children: [progressPercentage.toFixed(0), "% used"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 269,
												columnNumber: 29
											}, this), isOverBudget && /* @__PURE__ */ _jsxDEV("span", {
												className: "text-red-500 flex items-center gap-0.5 font-medium",
												children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "h-3.5 w-3.5" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 272,
													columnNumber: 33
												}, this), "Overspent!"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 271,
												columnNumber: 31
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 268,
											columnNumber: 27
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "w-full bg-zinc-200 dark:bg-zinc-800 h-2 rounded-full overflow-hidden",
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: `h-full rounded-full transition-all duration-300 ${isOverBudget ? "bg-red-500" : "bg-emerald-500"}`,
												style: { width: `${progressPercentage}%` }
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 278,
												columnNumber: 29
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 277,
											columnNumber: 27
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 267,
										columnNumber: 25
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-sm text-zinc-400 dark:text-zinc-600",
										children: "No budget planned"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 287,
										columnNumber: 25
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 265,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "p-4 text-center align-top",
									children: /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => handleOpenEdit(cat.id, cat.name),
										"data-testid": `edit-budget-button-${cat.name.toLowerCase().replace(/\s+/g, "-")}`,
										className: "p-1.5 text-zinc-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-500/10 rounded-md transition-colors inline-flex",
										children: /* @__PURE__ */ _jsxDEV(Edit2, { className: "h-4 w-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 298,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 293,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 292,
									columnNumber: 21
								}, this)
							]
						}, cat.id, true, {
							fileName: _jsxFileName,
							lineNumber: 241,
							columnNumber: 19
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 229,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 218,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 217,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(Modal, {
			isOpen: editingBudget !== null,
			onClose: handleCloseEdit,
			title: `${editingBudget?.budget ? "Edit" : "Set"} Budget for ${editingBudget?.categoryName}`,
			children: /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit(onFormSubmit),
				className: "space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
						children: "Planned Budget Amount (Rp)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 317,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "number",
						...register("planned_amount"),
						"data-testid": "planned-amount-input",
						className: `w-full rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.planned_amount ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 320,
						columnNumber: 13
					}, this),
					errors.planned_amount && /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-1 text-xs text-red-500",
						children: errors.planned_amount.message
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 328,
						columnNumber: 39
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 316,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "pt-4 flex justify-end",
					children: /* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						"data-testid": "budget-submit-button",
						className: "w-full sm:w-auto rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 transition-colors",
						children: "Save Budget"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 332,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 331,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 315,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 310,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 132,
		columnNumber: 5
	}, this);
}
_s(BudgetsPage, "r8OOQdCV2ioq9phNvVpgz+4/j+E=", false, function() {
	return [
		useOutletContext,
		useCategories,
		useBudgets,
		useTransactions,
		useForm
	];
});
_c = BudgetsPage;
var _c;
$RefreshReg$(_c, "BudgetsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/BudgetsPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/BudgetsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/BudgetsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/BudgetsPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxPQUFPLFVBQVUsTUFBTSxxQkFBcUI7QUFDckQsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsZUFBZTtBQUN4QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLG9CQUFtRDtBQUM1RCxTQUFTLHdCQUF3Qjs7OztBQUVqQyxPQUFPLFNBQVMsY0FBYzs7Q0FDNUIsTUFBTSxjQUFjLElBQUksS0FBSztDQUM3QixNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxZQUFZLFlBQVksQ0FBQztDQUMxRSxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxZQUFZLFNBQVMsSUFBSSxDQUFDO0NBQzdFLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUErRSxJQUFJO0NBQzdILE1BQU0sRUFBRSxpQkFBaUIsaUJBQTRDO0NBRXJFLE1BQU0sZ0JBQWdCLFFBQWdCO0VBQ3BDLE9BQU8sZUFBZSxNQUFNLElBQUksZUFBZSxNQUFNO0NBQ3ZEO0NBRUEsTUFBTSxtQkFBbUIsUUFBZ0I7RUFDdkMsSUFBSSxDQUFDLGNBQWMsT0FBTztFQUMxQixPQUFPLEdBQUcsTUFBTSxJQUFJLE1BQU0sR0FBRyxLQUFLLEtBQUssSUFBSSxHQUFHLENBQUMsQ0FBQyxlQUFlO0NBQ2pFO0NBRUEsTUFBTSxFQUFFLGVBQWUsY0FBYztDQUNyQyxNQUFNLEVBQUUsU0FBUyxXQUFXLGtCQUFrQixjQUFjLGlCQUFpQixXQUFXLGNBQWMsYUFBYTs7Q0FHbkgsTUFBTSxZQUFZLEdBQUcsYUFBYSxHQUFHLE9BQU8sYUFBYSxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUcsRUFBRTtDQUM1RSxNQUFNLFVBQVUsSUFBSSxLQUFLLGNBQWMsZUFBZSxDQUFDLENBQUMsQ0FBQyxRQUFRO0NBQ2pFLE1BQU0sVUFBVSxHQUFHLGFBQWEsR0FBRyxPQUFPLGFBQWEsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLEVBQUUsR0FBRyxPQUFPLE9BQU8sQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0NBRTVHLE1BQU0sRUFBRSxjQUFjLFdBQVcsMEJBQTBCLGdCQUFnQjtFQUN6RTtFQUNBO0VBQ0EsTUFBTTtDQUNSLENBQUM7Q0FFRCxNQUFNLG9CQUFvQixXQUN2QixRQUFPLE1BQUssRUFBRSxTQUFTLFNBQVMsQ0FBQyxDQUNqQyxNQUFNLEdBQUcsTUFBTSxFQUFFLEtBQUssY0FBYyxFQUFFLElBQUksQ0FBQzs7Q0FHOUMsTUFBTSxvQkFBb0Isa0JBQWtCLFFBQVEsS0FBSyxRQUFRO0VBQy9ELE1BQU0sUUFBUSxhQUNYLFFBQU8sTUFBSyxFQUFFLGdCQUFnQixJQUFJLE1BQU0sRUFBRSxTQUFTLFNBQVMsQ0FBQyxDQUM3RCxRQUFRLEtBQUssTUFBTSxNQUFNLE9BQU8sRUFBRSxNQUFNLEdBQUcsQ0FBQztFQUMvQyxJQUFJLElBQUksTUFBTTtFQUNkLE9BQU87Q0FDVCxHQUFHLENBQUMsQ0FBMkI7O0NBRy9CLE1BQU0sRUFDSixVQUNBLGNBQ0EsV0FBVyxFQUFFLFVBQ2IsVUFDRSxRQUFxQjtFQUN2QixVQUFVLFlBQVksWUFBWTtFQUNsQyxlQUFlO0dBQ2IsYUFBYTtHQUNiLE1BQU07R0FDTixPQUFPO0dBQ1AsZ0JBQWdCO0VBQ2xCO0NBQ0YsQ0FBQztDQUVELE1BQU0sa0JBQWtCLFlBQW9CLGlCQUF5QjtFQUNuRSxNQUFNLFdBQVcsUUFBUSxNQUFLLE1BQUssRUFBRSxnQkFBZ0IsVUFBVTtFQUMvRCxpQkFBaUI7R0FDZjtHQUNBO0dBQ0EsUUFBUTtFQUNWLENBQUM7RUFFRCxNQUFNO0dBQ0osYUFBYTtHQUNiLE1BQU07R0FDTixPQUFPO0dBQ1AsZ0JBQWdCLFdBQVcsU0FBUyxpQkFBaUI7RUFDdkQsQ0FBQztDQUNIO0NBRUEsTUFBTSx3QkFBd0I7RUFDNUIsaUJBQWlCLElBQUk7Q0FDdkI7Q0FFQSxNQUFNLGVBQWUsT0FBTyxTQUFzQjtFQUNoRCxJQUFJO0dBQ0YsSUFBSSxlQUFlLFFBQVE7SUFDekIsTUFBTSxhQUFhO0tBQ2pCLElBQUksY0FBYyxPQUFPO0tBQ3pCLE9BQU8sRUFBRSxnQkFBZ0IsS0FBSyxlQUFlO0lBQy9DLENBQUM7R0FDSCxPQUFPO0lBQ0wsTUFBTSxhQUFhLElBQUk7R0FDekI7R0FDQSxnQkFBZ0I7RUFDbEIsU0FBUyxLQUFVO0dBQ2pCLFFBQVEsTUFBTSxHQUFHO0dBQ2pCLE1BQU0sSUFBSSxXQUFXLHdCQUF3QjtFQUMvQztDQUNGO0NBRUEsTUFBTSxTQUFTO0VBQ2I7R0FBRSxPQUFPO0dBQUcsT0FBTztFQUFVO0VBQzdCO0dBQUUsT0FBTztHQUFHLE9BQU87RUFBVztFQUM5QjtHQUFFLE9BQU87R0FBRyxPQUFPO0VBQVE7RUFDM0I7R0FBRSxPQUFPO0dBQUcsT0FBTztFQUFRO0VBQzNCO0dBQUUsT0FBTztHQUFHLE9BQU87RUFBTTtFQUN6QjtHQUFFLE9BQU87R0FBRyxPQUFPO0VBQU87RUFDMUI7R0FBRSxPQUFPO0dBQUcsT0FBTztFQUFPO0VBQzFCO0dBQUUsT0FBTztHQUFHLE9BQU87RUFBUztFQUM1QjtHQUFFLE9BQU87R0FBRyxPQUFPO0VBQVk7RUFDL0I7R0FBRSxPQUFPO0dBQUksT0FBTztFQUFVO0VBQzlCO0dBQUUsT0FBTztHQUFJLE9BQU87RUFBVztFQUMvQjtHQUFFLE9BQU87R0FBSSxPQUFPO0VBQVc7Q0FDakM7Q0FFQSxNQUFNLFFBQVEsTUFBTSxLQUFLLEVBQUUsUUFBUSxFQUFFLElBQUksR0FBRyxNQUFNLFlBQVksWUFBWSxJQUFJLElBQUksQ0FBQztDQUVuRixNQUFNLGVBQWUsUUFBUSxRQUFRLEtBQUssTUFBTSxNQUFNLE9BQU8sRUFBRSxjQUFjLEdBQUcsQ0FBQztDQUNqRixNQUFNLGNBQWMsT0FBTyxPQUFPLGlCQUFpQixDQUFDLENBQUMsUUFBUSxLQUFLLFFBQVEsTUFBTSxLQUFLLENBQUM7Q0FDdEYsTUFBTSxpQkFBaUIsZUFBZTtDQUV0QyxNQUFNLFlBQVksb0JBQW9CO0NBRXRDLE9BQ0Usd0JBQUMsT0FBRDtFQUVFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBZCxDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLDJCQUE0Qjs7OztjQUFDLGdCQUUvQzs7Ozs7YUFDSix3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUF3QztHQUFtRTs7OztXQUNySDs7OzthQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLE9BQU87TUFDUCxXQUFXLE1BQU0saUJBQWlCLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQztNQUN4RCxlQUFZO01BQ1osV0FBVTtnQkFFVCxPQUFPLEtBQUksTUFDVix3QkFBQyxVQUFEO09BQXNCLE9BQU8sRUFBRTtpQkFBUSxFQUFFO01BQWMsR0FBMUMsRUFBRTs7OzthQUF3QyxDQUN4RDtLQUNLOzs7O2VBQ1Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7T0FBVSxNQUFLO09BQU8sUUFBTztPQUFlLFNBQVE7T0FBWSxPQUFNO2lCQUNuRix3QkFBQyxRQUFEO1FBQU0sZUFBYztRQUFRLGdCQUFlO1FBQVEsYUFBWTtRQUFJLEdBQUU7T0FBdUI7Ozs7O01BQ3pGOzs7OztLQUNGOzs7O2FBQ0Y7Ozs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQ7TUFDRSxPQUFPO01BQ1AsV0FBVyxNQUFNLGdCQUFnQixPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7TUFDdkQsZUFBWTtNQUNaLFdBQVU7Z0JBRVQsTUFBTSxLQUFJLE1BQ1Qsd0JBQUMsVUFBRDtPQUFnQixPQUFPO2lCQUFJO01BQVUsR0FBeEI7Ozs7YUFBd0IsQ0FDdEM7S0FDSzs7OztlQUNSLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQVUsTUFBSztPQUFPLFFBQU87T0FBZSxTQUFRO09BQVksT0FBTTtpQkFDbkYsd0JBQUMsUUFBRDtRQUFNLGVBQWM7UUFBUSxnQkFBZTtRQUFRLGFBQVk7UUFBSSxHQUFFO09BQXVCOzs7OztNQUN6Rjs7Ozs7S0FDRjs7OzthQUNGOzs7OztZQUNGOzs7OztXQUNGOzs7Ozs7RUFHTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFrRjtLQUF5Qjs7OztlQUMxSCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBeUQsYUFBYSxZQUFZO0tBQU87Ozs7YUFDckc7Ozs7OztJQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBa0Y7S0FBZ0I7Ozs7ZUFDakgsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQXdDLGFBQWEsV0FBVztLQUFPOzs7O2FBQ25GOzs7Ozs7SUFDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWtGO0tBQXFCOzs7O2VBQ3RILHdCQUFDLE9BQUQ7TUFBSyxXQUFXLDJCQUEyQixpQkFBaUIsSUFBSSxpQkFBaUI7Z0JBQzlFLGdCQUFnQixjQUFjO0tBQzVCOzs7O2FBQ0Y7Ozs7OztHQUNGOzs7Ozs7RUFHSixZQUNDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQXNEO0VBQTRCOzs7O2FBQy9GLGtCQUFrQixXQUFXLElBQy9CLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE1BQUQsRUFBTSxXQUFVLHdCQUF5Qjs7Ozs7SUFDdEM7Ozs7O0lBQ0wsd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBMkQ7SUFBK0I7Ozs7O0lBQ3hHLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQW9EO0lBRTlEOzs7OztHQUNBOzs7OzthQUVMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsU0FBRDtJQUFPLFdBQVU7Y0FBakIsQ0FDRSx3QkFBQyxTQUFELFlBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZDtNQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFvRDtNQUFZOzs7OztNQUM5RSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBK0Q7TUFBaUI7Ozs7O01BQzlGLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUErRDtNQUFnQjs7Ozs7TUFDN0Ysd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQStEO01BQXFCOzs7OztNQUNsRyx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBb0Q7TUFBbUI7Ozs7O01BQ3JGLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFnRTtNQUFVOzs7OztLQUN0Rjs7Ozs7YUFDQzs7OztjQUNQLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQ2Qsa0JBQWtCLEtBQUssUUFBUTtNQUM5QixNQUFNLGlCQUFpQixRQUFRLE1BQUssTUFBSyxFQUFFLGdCQUFnQixJQUFJLEVBQUU7TUFDakUsTUFBTSxVQUFVLGlCQUFpQixPQUFPLGVBQWUsY0FBYyxJQUFJO01BQ3pFLE1BQU0sU0FBUyxrQkFBa0IsSUFBSSxPQUFPO01BQzVDLE1BQU0sWUFBWSxVQUFVOztNQUc1QixNQUFNLHFCQUFxQixVQUFVLElBQUksS0FBSyxJQUFLLFNBQVMsVUFBVyxLQUFLLEdBQUcsSUFBSTtNQUNuRixNQUFNLGVBQWUsWUFBWTtNQUVqQyxPQUNFLHdCQUFDLE1BQUQ7T0FBaUIsV0FBVTtpQkFBM0I7UUFFRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWCxJQUFJO1FBQ0g7Ozs7O1FBR0osd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsaUJBQWlCLGFBQWEsT0FBTyxJQUNwQyx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBMEM7U0FBYTs7Ozs7UUFFdkU7Ozs7O1FBR0osd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsYUFBYSxNQUFNO1FBQ2xCOzs7OztRQUdKLHdCQUFDLE1BQUQ7U0FBSSxXQUFXLGtEQUFrRCxlQUFlLGlCQUFpQjttQkFDOUYsZ0JBQWdCLFNBQVM7UUFDeEI7Ozs7O1FBR0osd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsVUFBVSxJQUNULHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEIsQ0FBaUMsbUJBQW1CLFFBQVEsQ0FBQyxHQUFFLFFBQVk7Ozs7O3FCQUMxRSxnQkFDQyx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEIsQ0FDRSx3QkFBQyxlQUFELEVBQWUsV0FBVSxjQUFlOzs7O3NCQUFDLFlBRXJDOzs7OzttQkFFTDs7Ozs7b0JBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ2Isd0JBQUMsT0FBRDtZQUNFLFdBQVcsbURBQ1QsZUFBZSxlQUFlO1lBRWhDLE9BQU8sRUFBRSxPQUFPLEdBQUcsbUJBQW1CLEdBQUc7V0FDMUM7Ozs7O1VBQ0U7Ozs7a0JBQ0Y7Ozs7O29CQUVMLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEyQztTQUF1Qjs7Ozs7UUFFbEY7Ozs7O1FBR0osd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1osd0JBQUMsVUFBRDtVQUNFLGVBQWUsZUFBZSxJQUFJLElBQUksSUFBSSxJQUFJO1VBQzlDLGVBQWEsc0JBQXNCLElBQUksS0FBSyxZQUFZLENBQUMsQ0FBQyxRQUFRLFFBQVEsR0FBRztVQUM3RSxXQUFVO29CQUVWLHdCQUFDLE9BQUQsRUFBTyxXQUFVLFVBQVc7Ozs7O1NBQ3RCOzs7OztRQUNOOzs7OztPQUNGO1NBNURLLElBQUk7Ozs7YUE0RFQ7S0FFUixDQUFDO0lBQ0k7Ozs7WUFDRjs7Ozs7O0VBQ0o7Ozs7O0VBSVAsd0JBQUMsT0FBRDtHQUNFLFFBQVEsa0JBQWtCO0dBQzFCLFNBQVM7R0FDVCxPQUFPLEdBQUcsZUFBZSxTQUFTLFNBQVMsTUFBTSxjQUFjLGVBQWU7YUFFOUUsd0JBQUMsUUFBRDtJQUFNLFVBQVUsYUFBYSxZQUFZO0lBQUcsV0FBVTtjQUF0RCxDQUNFLHdCQUFDLE9BQUQ7S0FDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBa0U7S0FFNUU7Ozs7O0tBQ1Asd0JBQUMsU0FBRDtNQUNFLE1BQUs7TUFDTCxHQUFJLFNBQVMsZ0JBQWdCO01BQzdCLGVBQVk7TUFDWixXQUFXLGdLQUNULE9BQU8saUJBQWlCLHdDQUF3QztLQUVuRTs7Ozs7S0FDQSxPQUFPLGtCQUFrQix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBNkIsT0FBTyxlQUFlO0tBQVc7Ozs7O0lBQ2xHOzs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLGVBQVk7TUFDWixXQUFVO2dCQUNYO0tBRU87Ozs7O0lBQ0w7Ozs7WUFDRDs7Ozs7O0VBQ0Q7Ozs7O0NBQ0o7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQnVkZ2V0c1BhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBFZGl0MiwgUGllQ2hhcnQsIEluZm8sIEFsZXJ0VHJpYW5nbGUgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyB1c2VCdWRnZXRzIH0gZnJvbSBcIi4uL2hvb2tzL3VzZUJ1ZGdldHNcIjtcbmltcG9ydCB7IHVzZUNhdGVnb3JpZXMgfSBmcm9tIFwiLi4vaG9va3MvdXNlQ2F0ZWdvcmllc1wiO1xuaW1wb3J0IHsgdXNlVHJhbnNhY3Rpb25zIH0gZnJvbSBcIi4uL2hvb2tzL3VzZVRyYW5zYWN0aW9uc1wiO1xuaW1wb3J0IHsgTW9kYWwgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9Nb2RhbFwiO1xuaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gXCJyZWFjdC1ob29rLWZvcm1cIjtcbmltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSBcIkBob29rZm9ybS9yZXNvbHZlcnMvem9kXCI7XG5pbXBvcnQgeyBidWRnZXRTY2hlbWEsIHR5cGUgQnVkZ2V0SW5wdXQsIHR5cGUgQnVkZ2V0IH0gZnJvbSBcIi4uL3R5cGVzL2J1ZGdldHNcIjtcbmltcG9ydCB7IHVzZU91dGxldENvbnRleHQgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuXG5leHBvcnQgZnVuY3Rpb24gQnVkZ2V0c1BhZ2UoKSB7XG4gIGNvbnN0IGN1cnJlbnREYXRlID0gbmV3IERhdGUoKTtcbiAgY29uc3QgW3NlbGVjdGVkWWVhciwgc2V0U2VsZWN0ZWRZZWFyXSA9IHVzZVN0YXRlKGN1cnJlbnREYXRlLmdldEZ1bGxZZWFyKCkpO1xuICBjb25zdCBbc2VsZWN0ZWRNb250aCwgc2V0U2VsZWN0ZWRNb250aF0gPSB1c2VTdGF0ZShjdXJyZW50RGF0ZS5nZXRNb250aCgpICsgMSk7XG4gIGNvbnN0IFtlZGl0aW5nQnVkZ2V0LCBzZXRFZGl0aW5nQnVkZ2V0XSA9IHVzZVN0YXRlPHsgY2F0ZWdvcnlJZDogc3RyaW5nOyBjYXRlZ29yeU5hbWU6IHN0cmluZzsgYnVkZ2V0PzogQnVkZ2V0IH0gfCBudWxsPihudWxsKTtcbiAgY29uc3QgeyBzaG93QmFsYW5jZXMgfSA9IHVzZU91dGxldENvbnRleHQ8eyBzaG93QmFsYW5jZXM6IGJvb2xlYW4gfT4oKTtcblxuICBjb25zdCBmb3JtYXRBbW91bnQgPSAodmFsOiBudW1iZXIpID0+IHtcbiAgICByZXR1cm4gc2hvd0JhbGFuY2VzID8gYFJwICR7dmFsLnRvTG9jYWxlU3RyaW5nKCl9YCA6IFwiUnAg4oCi4oCi4oCi4oCi4oCi4oCiXCI7XG4gIH07XG5cbiAgY29uc3QgZm9ybWF0UmVtYWluaW5nID0gKHZhbDogbnVtYmVyKSA9PiB7XG4gICAgaWYgKCFzaG93QmFsYW5jZXMpIHJldHVybiBcIlJwIOKAouKAouKAouKAouKAouKAolwiO1xuICAgIHJldHVybiBgJHt2YWwgPCAwID8gXCItXCIgOiBcIlwifVJwICR7TWF0aC5hYnModmFsKS50b0xvY2FsZVN0cmluZygpfWA7XG4gIH07XG5cbiAgY29uc3QgeyBjYXRlZ29yaWVzIH0gPSB1c2VDYXRlZ29yaWVzKCk7XG4gIGNvbnN0IHsgYnVkZ2V0cywgaXNMb2FkaW5nOiBpc0J1ZGdldHNMb2FkaW5nLCBjcmVhdGVCdWRnZXQsIHVwZGF0ZUJ1ZGdldCB9ID0gdXNlQnVkZ2V0cyhzZWxlY3RlZFllYXIsIHNlbGVjdGVkTW9udGgpO1xuXG4gIC8vIERlZmluZSBkYXRlIHJhbmdlIGZvciB0cmFuc2FjdGlvbnMgcXVlcnlcbiAgY29uc3Qgc3RhcnREYXRlID0gYCR7c2VsZWN0ZWRZZWFyfS0ke1N0cmluZyhzZWxlY3RlZE1vbnRoKS5wYWRTdGFydCgyLCBcIjBcIil9LTAxYDtcbiAgY29uc3QgbGFzdERheSA9IG5ldyBEYXRlKHNlbGVjdGVkWWVhciwgc2VsZWN0ZWRNb250aCwgMCkuZ2V0RGF0ZSgpO1xuICBjb25zdCBlbmREYXRlID0gYCR7c2VsZWN0ZWRZZWFyfS0ke1N0cmluZyhzZWxlY3RlZE1vbnRoKS5wYWRTdGFydCgyLCBcIjBcIil9LSR7U3RyaW5nKGxhc3REYXkpLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xuXG4gIGNvbnN0IHsgdHJhbnNhY3Rpb25zLCBpc0xvYWRpbmc6IGlzVHJhbnNhY3Rpb25zTG9hZGluZyB9ID0gdXNlVHJhbnNhY3Rpb25zKHtcbiAgICBzdGFydERhdGUsXG4gICAgZW5kRGF0ZSxcbiAgICB0eXBlOiBcIkV4cGVuc2VcIlxuICB9KTtcblxuICBjb25zdCBleHBlbnNlQ2F0ZWdvcmllcyA9IGNhdGVnb3JpZXNcbiAgICAuZmlsdGVyKGMgPT4gYy50eXBlID09PSBcIkV4cGVuc2VcIilcbiAgICAuc29ydCgoYSwgYikgPT4gYS5uYW1lLmxvY2FsZUNvbXBhcmUoYi5uYW1lKSk7XG5cbiAgLy8gU3VtIGFjdHVhbCBzcGVuZGluZyBwZXIgY2F0ZWdvcnlcbiAgY29uc3QgYWN0dWFsU3BlbmRpbmdNYXAgPSBleHBlbnNlQ2F0ZWdvcmllcy5yZWR1Y2UoKGFjYywgY2F0KSA9PiB7XG4gICAgY29uc3QgdG90YWwgPSB0cmFuc2FjdGlvbnNcbiAgICAgIC5maWx0ZXIodCA9PiB0LmNhdGVnb3J5X2lkID09PSBjYXQuaWQgJiYgdC50eXBlID09PSBcIkV4cGVuc2VcIilcbiAgICAgIC5yZWR1Y2UoKHN1bSwgdCkgPT4gc3VtICsgTnVtYmVyKHQuYW1vdW50KSwgMCk7XG4gICAgYWNjW2NhdC5pZF0gPSB0b3RhbDtcbiAgICByZXR1cm4gYWNjO1xuICB9LCB7fSBhcyBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+KTtcblxuICAvLyBSZWFjdCBIb29rIEZvcm0gZm9yIFNldC9FZGl0IEJ1ZGdldCBNb2RhbFxuICBjb25zdCB7XG4gICAgcmVnaXN0ZXIsXG4gICAgaGFuZGxlU3VibWl0LFxuICAgIGZvcm1TdGF0ZTogeyBlcnJvcnMgfSxcbiAgICByZXNldFxuICB9ID0gdXNlRm9ybTxCdWRnZXRJbnB1dD4oe1xuICAgIHJlc29sdmVyOiB6b2RSZXNvbHZlcihidWRnZXRTY2hlbWEpIGFzIGFueSxcbiAgICBkZWZhdWx0VmFsdWVzOiB7XG4gICAgICBjYXRlZ29yeV9pZDogXCJcIixcbiAgICAgIHllYXI6IHNlbGVjdGVkWWVhcixcbiAgICAgIG1vbnRoOiBzZWxlY3RlZE1vbnRoLFxuICAgICAgcGxhbm5lZF9hbW91bnQ6IDAsXG4gICAgfVxuICB9KTtcblxuICBjb25zdCBoYW5kbGVPcGVuRWRpdCA9IChjYXRlZ29yeUlkOiBzdHJpbmcsIGNhdGVnb3J5TmFtZTogc3RyaW5nKSA9PiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBidWRnZXRzLmZpbmQoYiA9PiBiLmNhdGVnb3J5X2lkID09PSBjYXRlZ29yeUlkKTtcbiAgICBzZXRFZGl0aW5nQnVkZ2V0KHtcbiAgICAgIGNhdGVnb3J5SWQsXG4gICAgICBjYXRlZ29yeU5hbWUsXG4gICAgICBidWRnZXQ6IGV4aXN0aW5nXG4gICAgfSk7XG4gICAgXG4gICAgcmVzZXQoe1xuICAgICAgY2F0ZWdvcnlfaWQ6IGNhdGVnb3J5SWQsXG4gICAgICB5ZWFyOiBzZWxlY3RlZFllYXIsXG4gICAgICBtb250aDogc2VsZWN0ZWRNb250aCxcbiAgICAgIHBsYW5uZWRfYW1vdW50OiBleGlzdGluZyA/IGV4aXN0aW5nLnBsYW5uZWRfYW1vdW50IDogMCxcbiAgICB9KTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVDbG9zZUVkaXQgPSAoKSA9PiB7XG4gICAgc2V0RWRpdGluZ0J1ZGdldChudWxsKTtcbiAgfTtcblxuICBjb25zdCBvbkZvcm1TdWJtaXQgPSBhc3luYyAoZGF0YTogQnVkZ2V0SW5wdXQpID0+IHtcbiAgICB0cnkge1xuICAgICAgaWYgKGVkaXRpbmdCdWRnZXQ/LmJ1ZGdldCkge1xuICAgICAgICBhd2FpdCB1cGRhdGVCdWRnZXQoe1xuICAgICAgICAgIGlkOiBlZGl0aW5nQnVkZ2V0LmJ1ZGdldC5pZCxcbiAgICAgICAgICBpbnB1dDogeyBwbGFubmVkX2Ftb3VudDogZGF0YS5wbGFubmVkX2Ftb3VudCB9XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXdhaXQgY3JlYXRlQnVkZ2V0KGRhdGEpO1xuICAgICAgfVxuICAgICAgaGFuZGxlQ2xvc2VFZGl0KCk7XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICAgIGFsZXJ0KGVyci5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIHNhdmUgYnVkZ2V0LlwiKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgbW9udGhzID0gW1xuICAgIHsgdmFsdWU6IDEsIGxhYmVsOiBcIkphbnVhcnlcIiB9LFxuICAgIHsgdmFsdWU6IDIsIGxhYmVsOiBcIkZlYnJ1YXJ5XCIgfSxcbiAgICB7IHZhbHVlOiAzLCBsYWJlbDogXCJNYXJjaFwiIH0sXG4gICAgeyB2YWx1ZTogNCwgbGFiZWw6IFwiQXByaWxcIiB9LFxuICAgIHsgdmFsdWU6IDUsIGxhYmVsOiBcIk1heVwiIH0sXG4gICAgeyB2YWx1ZTogNiwgbGFiZWw6IFwiSnVuZVwiIH0sXG4gICAgeyB2YWx1ZTogNywgbGFiZWw6IFwiSnVseVwiIH0sXG4gICAgeyB2YWx1ZTogOCwgbGFiZWw6IFwiQXVndXN0XCIgfSxcbiAgICB7IHZhbHVlOiA5LCBsYWJlbDogXCJTZXB0ZW1iZXJcIiB9LFxuICAgIHsgdmFsdWU6IDEwLCBsYWJlbDogXCJPY3RvYmVyXCIgfSxcbiAgICB7IHZhbHVlOiAxMSwgbGFiZWw6IFwiTm92ZW1iZXJcIiB9LFxuICAgIHsgdmFsdWU6IDEyLCBsYWJlbDogXCJEZWNlbWJlclwiIH0sXG4gIF07XG5cbiAgY29uc3QgeWVhcnMgPSBBcnJheS5mcm9tKHsgbGVuZ3RoOiA1IH0sIChfLCBpKSA9PiBjdXJyZW50RGF0ZS5nZXRGdWxsWWVhcigpIC0gMiArIGkpO1xuXG4gIGNvbnN0IHRvdGFsUGxhbm5lZCA9IGJ1ZGdldHMucmVkdWNlKChzdW0sIGIpID0+IHN1bSArIE51bWJlcihiLnBsYW5uZWRfYW1vdW50KSwgMCk7XG4gIGNvbnN0IHRvdGFsQWN0dWFsID0gT2JqZWN0LnZhbHVlcyhhY3R1YWxTcGVuZGluZ01hcCkucmVkdWNlKChzdW0sIHZhbCkgPT4gc3VtICsgdmFsLCAwKTtcbiAgY29uc3QgdG90YWxSZW1haW5pbmcgPSB0b3RhbFBsYW5uZWQgLSB0b3RhbEFjdHVhbDtcblxuICBjb25zdCBpc0xvYWRpbmcgPSBpc0J1ZGdldHNMb2FkaW5nIHx8IGlzVHJhbnNhY3Rpb25zTG9hZGluZztcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICB7LyogSGVhZGVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBzbTppdGVtcy1jZW50ZXIgbWItOCBnYXAtNFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxQaWVDaGFydCBjbGFzc05hbWU9XCJoLTYgdy02IHRleHQtZW1lcmFsZC01MDBcIiAvPlxuICAgICAgICAgICAgTW9udGhseSBCdWRnZXRcbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtemluYy01MDAgZGFyazp0ZXh0LXppbmMtNDAwIG10LTFcIj5TZXQgbW9udGhseSBjYXRlZ29yeSBzcGVuZGluZyBsaW1pdHMgYW5kIG1vbml0b3IgYWN0dWFsIHBheW91dHMuPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBNb250aC9ZZWFyIHNlbGVjdG9ycyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yIHctZnVsbCBzbTp3LWF1dG9cIj5cbiAgICAgICAgICB7LyogTW9udGggU2VsZWN0ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleC0xIHNtOmZsZXgtaW5pdGlhbFwiPlxuICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRNb250aH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZE1vbnRoKE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cIm1vbnRoLXNlbGVjdFwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhcHBlYXJhbmNlLW5vbmUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwIGJnLXdoaXRlIGRhcms6YmctemluYy05MDAgcHgtMyBweS0yIHByLTEwIHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHttb250aHMubWFwKG0gPT4gKFxuICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXttLnZhbHVlfSB2YWx1ZT17bS52YWx1ZX0+e20ubGFiZWx9PC9vcHRpb24+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBvaW50ZXItZXZlbnRzLW5vbmUgYWJzb2x1dGUgaW5zZXQteS0wIHJpZ2h0LTAgZmxleCBpdGVtcy1jZW50ZXIgcHgtMyB0ZXh0LXppbmMtNTAwXCI+XG4gICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwiaC00IHctNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cbiAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xOSA5bC03IDctNy03XCI+PC9wYXRoPlxuICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFllYXIgU2VsZWN0ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleC0xIHNtOmZsZXgtaW5pdGlhbFwiPlxuICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRZZWFyfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkWWVhcihOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJ5ZWFyLXNlbGVjdFwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhcHBlYXJhbmNlLW5vbmUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwIGJnLXdoaXRlIGRhcms6YmctemluYy05MDAgcHgtMyBweS0yIHByLTEwIHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHt5ZWFycy5tYXAoeSA9PiAoXG4gICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3l9IHZhbHVlPXt5fT57eX08L29wdGlvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSBpbnNldC15LTAgcmlnaHQtMCBmbGV4IGl0ZW1zLWNlbnRlciBweC0zIHRleHQtemluYy01MDBcIj5cbiAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJoLTQgdy00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTE5IDlsLTcgNy03LTdcIj48L3BhdGg+XG4gICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBTdW1tYXJ5IENhcmRzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00IG1iLThcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHAtNCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+VG90YWwgUGxhbm5lZCBCdWRnZXQ8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZSBtdC0xXCI+e2Zvcm1hdEFtb3VudCh0b3RhbFBsYW5uZWQpfTwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHAtNCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+VG90YWwgU3BlbnQ8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXJlZC01MDAgbXQtMVwiPntmb3JtYXRBbW91bnQodG90YWxBY3R1YWwpfTwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHAtNCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+UmVtYWluaW5nIEJ1ZGdldDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdGV4dC0yeGwgZm9udC1ib2xkIG10LTEgJHt0b3RhbFJlbWFpbmluZyA8IDAgPyBcInRleHQtcmVkLTUwMFwiIDogXCJ0ZXh0LWVtZXJhbGQtNTAwXCJ9YH0+XG4gICAgICAgICAgICB7Zm9ybWF0UmVtYWluaW5nKHRvdGFsUmVtYWluaW5nKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIE1haW4gQnVkZ2V0IFNoZWV0IC8gVGFibGUgKi99XG4gICAgICB7aXNMb2FkaW5nID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC02NCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC16aW5jLTUwMFwiPkxvYWRpbmcgYnVkZ2V0IHNoZWV0Li4uPC9kaXY+XG4gICAgICApIDogZXhwZW5zZUNhdGVnb3JpZXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctemluYy05MDAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMCBwLTEyIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy16aW5jLTEwMCBkYXJrOmJnLXppbmMtODAwIHctMTYgaC0xNiByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0byBtYi00XCI+XG4gICAgICAgICAgICA8SW5mbyBjbGFzc05hbWU9XCJoLTggdy04IHRleHQtemluYy00MDBcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgbWItMlwiPk5vIEV4cGVuc2UgQ2F0ZWdvcmllcyBGb3VuZDwvaDM+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00MDAgbWF4LXctc20gbXgtYXV0b1wiPlxuICAgICAgICAgICAgUGxlYXNlIGRlZmluZSBzb21lIGV4cGVuc2UgY2F0ZWdvcmllcyBvbiB0aGUgQ2F0ZWdvcmllcyBwYWdlIGZpcnN0IHRvIHNjaGVkdWxlIG1vbnRobHkgYnVkZ2V0cy5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgYm9yZGVyLWNvbGxhcHNlXCI+XG4gICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAgYmctemluYy01MCBkYXJrOmJnLXppbmMtOTAwLzUwXCI+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTUwMCB1cHBlcmNhc2VcIj5DYXRlZ29yeTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTUwMCB1cHBlcmNhc2UgdGV4dC1yaWdodFwiPlBsYW5uZWQgTGltaXQ8L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTQgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtemluYy01MDAgdXBwZXJjYXNlIHRleHQtcmlnaHRcIj5BY3R1YWwgU3BlbnQ8L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTQgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtemluYy01MDAgdXBwZXJjYXNlIHRleHQtcmlnaHRcIj5SZW1haW5pbmcgQmFsYW5jZTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTUwMCB1cHBlcmNhc2VcIj5Qcm9ncmVzcyBTdGF0dXM8L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTQgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtemluYy01MDAgdXBwZXJjYXNlIHRleHQtY2VudGVyXCI+QWN0aW9uPC90aD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXppbmMtMTAwIGRhcms6ZGl2aWRlLXppbmMtODAwXCI+XG4gICAgICAgICAgICAgIHtleHBlbnNlQ2F0ZWdvcmllcy5tYXAoKGNhdCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nQnVkZ2V0ID0gYnVkZ2V0cy5maW5kKGIgPT4gYi5jYXRlZ29yeV9pZCA9PT0gY2F0LmlkKTtcbiAgICAgICAgICAgICAgICBjb25zdCBwbGFubmVkID0gZXhpc3RpbmdCdWRnZXQgPyBOdW1iZXIoZXhpc3RpbmdCdWRnZXQucGxhbm5lZF9hbW91bnQpIDogMDtcbiAgICAgICAgICAgICAgICBjb25zdCBhY3R1YWwgPSBhY3R1YWxTcGVuZGluZ01hcFtjYXQuaWRdIHx8IDA7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVtYWluaW5nID0gcGxhbm5lZCAtIGFjdHVhbDtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAvLyBQcm9ncmVzcyBjYWxjdWxhdGlvbnNcbiAgICAgICAgICAgICAgICBjb25zdCBwcm9ncmVzc1BlcmNlbnRhZ2UgPSBwbGFubmVkID4gMCA/IE1hdGgubWluKChhY3R1YWwgLyBwbGFubmVkKSAqIDEwMCwgMTAwKSA6IDA7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNPdmVyQnVkZ2V0ID0gcmVtYWluaW5nIDwgMDtcblxuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8dHIga2V5PXtjYXQuaWR9IGNsYXNzTmFtZT1cImhvdmVyOmJnLXppbmMtNTAgZGFyazpob3ZlcjpiZy16aW5jLTgwMC8yMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICB7LyogQ2F0ZWdvcnkgTmFtZSAqL31cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgYWxpZ24tdG9wXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2NhdC5uYW1lfVxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgey8qIFBsYW5uZWQgTGltaXQgKi99XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTQgdGV4dC1zbSB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC16aW5jLTMwMCB0ZXh0LXJpZ2h0IGZvbnQtbWVkaXVtIGFsaWduLXRvcFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtleGlzdGluZ0J1ZGdldCA/IGZvcm1hdEFtb3VudChwbGFubmVkKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtemluYy00MDAgZGFyazp0ZXh0LXppbmMtNjAwIGl0YWxpY1wiPk5vdCBzZXQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICB7LyogQWN0dWFsIFNwZW50ICovfVxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC00IHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtemluYy0zMDAgdGV4dC1yaWdodCBmb250LW1lZGl1bSBhbGlnbi10b3BcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0QW1vdW50KGFjdHVhbCl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIFJlbWFpbmluZyAqL31cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT17YHAtNCB0ZXh0LXNtIHRleHQtcmlnaHQgZm9udC1zZW1pYm9sZCBhbGlnbi10b3AgJHtpc092ZXJCdWRnZXQgPyBcInRleHQtcmVkLTUwMFwiIDogXCJ0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC16aW5jLTMwMFwifWB9PlxuICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRSZW1haW5pbmcocmVtYWluaW5nKX1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICB7LyogUHJvZ3Jlc3MgQmFyICYgQmFkZ2VzICovfVxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC00IGFsaWduLXRvcFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtwbGFubmVkID4gMCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbSBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC16aW5jLTUwMFwiPntwcm9ncmVzc1BlcmNlbnRhZ2UudG9GaXhlZCgwKX0lIHVzZWQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzT3ZlckJ1ZGdldCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTAuNSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE92ZXJzcGVudCFcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctemluYy0yMDAgZGFyazpiZy16aW5jLTgwMCBoLTIgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BoLWZ1bGwgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc092ZXJCdWRnZXQgPyBcImJnLXJlZC01MDBcIiA6IFwiYmctZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7cHJvZ3Jlc3NQZXJjZW50YWdlfSVgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXppbmMtNDAwIGRhcms6dGV4dC16aW5jLTYwMFwiPk5vIGJ1ZGdldCBwbGFubmVkPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIEFjdGlvbiBidXR0b24gKi99XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTQgdGV4dC1jZW50ZXIgYWxpZ24tdG9wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlT3BlbkVkaXQoY2F0LmlkLCBjYXQubmFtZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD17YGVkaXQtYnVkZ2V0LWJ1dHRvbi0ke2NhdC5uYW1lLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvXFxzKy9nLCAnLScpfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXppbmMtNDAwIGhvdmVyOnRleHQtZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC01MCBkYXJrOmhvdmVyOmJnLWVtZXJhbGQtNTAwLzEwIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1jb2xvcnMgaW5saW5lLWZsZXhcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxFZGl0MiBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIEVkaXQgQnVkZ2V0IE1vZGFsICovfVxuICAgICAgPE1vZGFsXG4gICAgICAgIGlzT3Blbj17ZWRpdGluZ0J1ZGdldCAhPT0gbnVsbH1cbiAgICAgICAgb25DbG9zZT17aGFuZGxlQ2xvc2VFZGl0fVxuICAgICAgICB0aXRsZT17YCR7ZWRpdGluZ0J1ZGdldD8uYnVkZ2V0ID8gXCJFZGl0XCIgOiBcIlNldFwifSBCdWRnZXQgZm9yICR7ZWRpdGluZ0J1ZGdldD8uY2F0ZWdvcnlOYW1lfWB9XG4gICAgICA+XG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXQob25Gb3JtU3VibWl0KX0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtemluYy03MDAgZGFyazp0ZXh0LXppbmMtMzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgUGxhbm5lZCBCdWRnZXQgQW1vdW50IChScClcbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcInBsYW5uZWRfYW1vdW50XCIpfVxuICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cInBsYW5uZWQtYW1vdW50LWlucHV0XCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJnLXdoaXRlIGRhcms6YmctemluYy05MDAgcHgtMyBweS0yIHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwICR7XG4gICAgICAgICAgICAgICAgZXJyb3JzLnBsYW5uZWRfYW1vdW50ID8gXCJib3JkZXItcmVkLTUwMCBmb2N1czpib3JkZXItcmVkLTUwMFwiIDogXCJib3JkZXItemluYy0zMDAgZGFyazpib3JkZXItemluYy03MDAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwXCJcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAge2Vycm9ycy5wbGFubmVkX2Ftb3VudCAmJiA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1yZWQtNTAwXCI+e2Vycm9ycy5wbGFubmVkX2Ftb3VudC5tZXNzYWdlfTwvcD59XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJidWRnZXQtc3VibWl0LWJ1dHRvblwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gcm91bmRlZC1sZyBiZy1lbWVyYWxkLTYwMCBweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGhvdmVyOmJnLWVtZXJhbGQtNzAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMCBmb2N1czpyaW5nLW9mZnNldC0yIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgU2F2ZSBCdWRnZXRcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Zvcm0+XG4gICAgICA8L01vZGFsPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl19