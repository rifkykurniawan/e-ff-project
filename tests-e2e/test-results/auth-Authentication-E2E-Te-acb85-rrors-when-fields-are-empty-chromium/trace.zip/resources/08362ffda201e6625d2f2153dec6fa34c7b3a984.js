import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/TransactionsPage.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=513be775";
import { Plus, Trash2, Edit2, ArrowRight, ArrowDownLeft, ArrowUpRight, ArrowLeftRight, Filter, Calendar } from "/node_modules/.vite/deps/lucide-react.js?v=7df35618";
import { useTransactions } from "/src/hooks/useTransactions.ts";
import { useAccounts } from "/src/hooks/useAccounts.ts";
import { useCategories } from "/src/hooks/useCategories.ts";
import { Modal } from "/src/components/Modal.tsx";
import { TransactionForm } from "/src/features/transactions/TransactionForm.tsx";
import { useOutletContext } from "/node_modules/.vite/deps/react-router-dom.js?v=63710477";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/TransactionsPage.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
var _s = $RefreshSig$();
export function TransactionsPage() {
	_s();
	const [isModalOpen, setIsModalOpen] = useState(false);
	const [editingTransaction, setEditingTransaction] = useState(null);
	const currentDate = new Date();
	const year = currentDate.getFullYear();
	const month = currentDate.getMonth() + 1;
	const defaultStartDate = `${year}-${String(month).padStart(2, "0")}-01`;
	const lastDay = new Date(year, month, 0).getDate();
	const defaultEndDate = `${year}-${String(month).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`;
	const [filters, setFilters] = useState({
		accountId: "",
		categoryId: "",
		type: "",
		startDate: defaultStartDate,
		endDate: defaultEndDate
	});
	const { showBalances } = useOutletContext();
	const formatAmount = (val) => {
		return showBalances ? `Rp ${val.toLocaleString()}` : "Rp ••••••";
	};
	const { accounts } = useAccounts();
	const { categories } = useCategories();
	const { transactions, isLoading, createTransaction, updateTransaction, deleteTransaction, isCreating, isUpdating } = useTransactions(filters);
	const handleOpenAddModal = () => {
		setEditingTransaction(null);
		setIsModalOpen(true);
	};
	const handleOpenEditModal = (t) => {
		setEditingTransaction(t);
		setIsModalOpen(true);
	};
	const handleCloseModal = () => {
		setIsModalOpen(false);
		setEditingTransaction(null);
	};
	const handleSubmit = async (data) => {
		try {
			if (editingTransaction) {
				await updateTransaction({
					id: editingTransaction.id,
					input: data
				});
			} else {
				await createTransaction(data);
			}
			handleCloseModal();
		} catch (error) {
			console.error("Failed to save transaction", error);
			alert(error.message || "An error occurred while saving the transaction.");
		}
	};
	const handleDelete = async (id) => {
		if (confirm("Are you sure you want to delete this transaction? This will revert account balance updates.")) {
			try {
				await deleteTransaction(id);
			} catch (error) {
				console.error("Failed to delete transaction", error);
				alert(error.message || "Failed to delete transaction.");
			}
		}
	};
	const handleFilterChange = (key, value) => {
		setFilters((prev) => ({
			...prev,
			[key]: value
		}));
	};
	const handleClearFilters = () => {
		setFilters({
			accountId: "",
			categoryId: "",
			type: "",
			startDate: defaultStartDate,
			endDate: defaultEndDate
		});
	};
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-2xl font-bold text-zinc-900 dark:text-white tracking-tight",
				children: "Transactions"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 105,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-zinc-500 dark:text-zinc-400 mt-1",
				children: "Review and manage your family transaction history."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 104,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				onClick: handleOpenAddModal,
				"data-testid": "add-transaction-button",
				className: "flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-lg text-sm font-medium transition-colors shadow-sm",
				children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "h-4 w-4" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 113,
					columnNumber: 11
				}, this), "Log Transaction"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 108,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 103,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 p-5 mb-6",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 mb-4 text-zinc-900 dark:text-white font-medium text-sm",
					children: [/* @__PURE__ */ _jsxDEV(Filter, { className: "h-4 w-4 text-emerald-500" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 121,
						columnNumber: 11
					}, this), "Filter Transactions"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 120,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-medium text-zinc-500 dark:text-zinc-400 mb-1",
							children: "Account"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "relative",
							children: [/* @__PURE__ */ _jsxDEV("select", {
								value: filters.accountId,
								onChange: (e) => handleFilterChange("accountId", e.target.value),
								"data-testid": "filter-account-select",
								className: "w-full appearance-none rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 px-3 py-1.5 pr-10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
								children: [/* @__PURE__ */ _jsxDEV("option", {
									value: "",
									children: "All Accounts"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 135,
									columnNumber: 17
								}, this), accounts.map((acc) => /* @__PURE__ */ _jsxDEV("option", {
									value: acc.id,
									children: acc.name
								}, acc.id, false, {
									fileName: _jsxFileName,
									lineNumber: 137,
									columnNumber: 19
								}, this))]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-zinc-500",
								children: /* @__PURE__ */ _jsxDEV("svg", {
									className: "h-4 w-4",
									fill: "none",
									stroke: "currentColor",
									viewBox: "0 0 24 24",
									xmlns: "http://www.w3.org/2000/svg",
									children: /* @__PURE__ */ _jsxDEV("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										strokeWidth: "2",
										d: "M19 9l-7 7-7-7"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 142,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 141,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 140,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-medium text-zinc-500 dark:text-zinc-400 mb-1",
							children: "Category"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 150,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "relative",
							children: [/* @__PURE__ */ _jsxDEV("select", {
								value: filters.categoryId,
								onChange: (e) => handleFilterChange("categoryId", e.target.value),
								"data-testid": "filter-category-select",
								className: "w-full appearance-none rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 px-3 py-1.5 pr-10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
								children: [/* @__PURE__ */ _jsxDEV("option", {
									value: "",
									children: "All Categories"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 158,
									columnNumber: 17
								}, this), categories.map((cat) => /* @__PURE__ */ _jsxDEV("option", {
									value: cat.id,
									children: [
										cat.name,
										" (",
										cat.type,
										")"
									]
								}, cat.id, true, {
									fileName: _jsxFileName,
									lineNumber: 160,
									columnNumber: 19
								}, this))]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-zinc-500",
								children: /* @__PURE__ */ _jsxDEV("svg", {
									className: "h-4 w-4",
									fill: "none",
									stroke: "currentColor",
									viewBox: "0 0 24 24",
									xmlns: "http://www.w3.org/2000/svg",
									children: /* @__PURE__ */ _jsxDEV("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										strokeWidth: "2",
										d: "M19 9l-7 7-7-7"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 165,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 164,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 163,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-medium text-zinc-500 dark:text-zinc-400 mb-1",
							children: "Type"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 173,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "relative",
							children: [/* @__PURE__ */ _jsxDEV("select", {
								value: filters.type,
								onChange: (e) => handleFilterChange("type", e.target.value),
								"data-testid": "filter-type-select",
								className: "w-full appearance-none rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 px-3 py-1.5 pr-10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500",
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: "",
										children: "All Types"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 181,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "Income",
										children: "Income"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 182,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "Expense",
										children: "Expense"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 183,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: "Transfer",
										children: "Transfer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 184,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 175,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-zinc-500",
								children: /* @__PURE__ */ _jsxDEV("svg", {
									className: "h-4 w-4",
									fill: "none",
									stroke: "currentColor",
									viewBox: "0 0 24 24",
									xmlns: "http://www.w3.org/2000/svg",
									children: /* @__PURE__ */ _jsxDEV("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										strokeWidth: "2",
										d: "M19 9l-7 7-7-7"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 188,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 187,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 186,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 174,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 172,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-medium text-zinc-500 dark:text-zinc-400 mb-1",
							children: "Start Date"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "date",
							value: filters.startDate,
							onChange: (e) => handleFilterChange("startDate", e.target.value),
							"data-testid": "filter-start-date-input",
							className: "w-full rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 px-3 py-1.5 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 197,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 195,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-medium text-zinc-500 dark:text-zinc-400 mb-1",
							children: "End Date"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "date",
							value: filters.endDate,
							onChange: (e) => handleFilterChange("endDate", e.target.value),
							"data-testid": "filter-end-date-input",
							className: "w-full rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 px-3 py-1.5 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 209,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 207,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 9
				}, this),
				(filters.accountId || filters.categoryId || filters.type || filters.startDate || filters.endDate) && /* @__PURE__ */ _jsxDEV("div", {
					className: "mt-4 flex justify-end",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleClearFilters,
						"data-testid": "clear-filters-button",
						className: "text-xs font-medium text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300",
						children: "Clear Filters"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 221,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 220,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 119,
			columnNumber: 7
		}, this),
		isLoading ? /* @__PURE__ */ _jsxDEV("div", {
			className: "flex h-64 items-center justify-center text-zinc-500",
			children: "Loading transactions..."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 234,
			columnNumber: 9
		}, this) : transactions.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 p-12 text-center",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-zinc-100 dark:bg-zinc-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4",
					children: /* @__PURE__ */ _jsxDEV(Calendar, { className: "h-8 w-8 text-zinc-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 238,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 237,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-lg font-semibold text-zinc-900 dark:text-white mb-2",
					children: "No transactions found"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 240,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-zinc-500 dark:text-zinc-400 mb-6 max-w-sm mx-auto",
					children: "Try adjusting your filters or record a new transaction to populate the ledger."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 241,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 236,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ _jsxDEV("table", {
					className: "w-full text-left border-collapse",
					children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
						className: "border-b border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/50",
						children: [
							/* @__PURE__ */ _jsxDEV("th", {
								className: "p-4 text-xs font-semibold text-zinc-500 uppercase",
								children: "Date"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 251,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "p-4 text-xs font-semibold text-zinc-500 uppercase",
								children: "Description"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 252,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "p-4 text-xs font-semibold text-zinc-500 uppercase",
								children: "Type"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 253,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "p-4 text-xs font-semibold text-zinc-500 uppercase",
								children: "Category"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 254,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "p-4 text-xs font-semibold text-zinc-500 uppercase",
								children: "Accounts"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 255,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "p-4 text-xs font-semibold text-zinc-500 uppercase text-right",
								children: "Amount"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 256,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("th", {
								className: "p-4 text-xs font-semibold text-zinc-500 uppercase text-center",
								children: "Actions"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 257,
								columnNumber: 19
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 250,
						columnNumber: 17
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 249,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("tbody", {
						className: "divide-y divide-zinc-100 dark:divide-zinc-800",
						children: transactions.map((t) => {
							const isIncome = t.type === "Income";
							const isExpense = t.type === "Expense";
							const isTransfer = t.type === "Transfer";
							return /* @__PURE__ */ _jsxDEV("tr", {
								className: "hover:bg-zinc-50 dark:hover:bg-zinc-800/20 transition-colors",
								children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-4 text-sm text-zinc-950 dark:text-zinc-300 font-medium",
										children: new Date(t.date).toLocaleDateString(undefined, {
											month: "short",
											day: "numeric",
											year: "numeric"
										})
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 268,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-4 text-sm",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "text-zinc-950 dark:text-white font-medium",
											children: t.description
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 272,
											columnNumber: 25
										}, this), t.notes && /* @__PURE__ */ _jsxDEV("div", {
											className: "text-xs text-zinc-400 dark:text-zinc-500 mt-0.5",
											children: t.notes
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 273,
											columnNumber: 37
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 271,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-4",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: `inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full ${isIncome ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400" : isExpense ? "bg-red-50 text-red-700 dark:bg-red-500/10 dark:text-red-400" : "bg-blue-50 text-blue-700 dark:bg-blue-500/10 dark:text-blue-400"}`,
											children: [
												isIncome && /* @__PURE__ */ _jsxDEV(ArrowUpRight, { className: "h-3 w-3" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 281,
													columnNumber: 40
												}, this),
												isExpense && /* @__PURE__ */ _jsxDEV(ArrowDownLeft, { className: "h-3 w-3" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 282,
													columnNumber: 41
												}, this),
												isTransfer && /* @__PURE__ */ _jsxDEV(ArrowLeftRight, { className: "h-3 w-3" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 283,
													columnNumber: 42
												}, this),
												t.type
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 276,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 275,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-4 text-sm text-zinc-600 dark:text-zinc-400",
										children: t.categories?.name || /* @__PURE__ */ _jsxDEV("span", {
											className: "text-zinc-400 dark:text-zinc-600",
											children: "—"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 288,
											columnNumber: 48
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 287,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-4 text-sm",
										children: [
											isIncome && /* @__PURE__ */ _jsxDEV("span", {
												className: "text-emerald-600 dark:text-emerald-400 font-medium",
												children: ["To: ", t.destination_accounts?.name]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 292,
												columnNumber: 27
											}, this),
											isExpense && /* @__PURE__ */ _jsxDEV("span", {
												className: "text-red-600 dark:text-red-400 font-medium",
												children: ["From: ", t.source_accounts?.name]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 297,
												columnNumber: 27
											}, this),
											isTransfer && /* @__PURE__ */ _jsxDEV("span", {
												className: "text-zinc-700 dark:text-zinc-300 font-medium flex items-center gap-1.5",
												children: [
													t.source_accounts?.name,
													" ",
													/* @__PURE__ */ _jsxDEV(ArrowRight, { className: "h-3.5 w-3.5 text-zinc-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 303,
														columnNumber: 55
													}, this),
													" ",
													t.destination_accounts?.name
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 302,
												columnNumber: 27
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 290,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: `p-4 text-sm font-semibold text-right ${isIncome ? "text-emerald-600 dark:text-emerald-400" : isExpense ? "text-red-600 dark:text-red-400" : "text-zinc-700 dark:text-zinc-300"}`,
										children: [isIncome ? "+" : isExpense ? "-" : "", formatAmount(t.amount)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 307,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "p-4 text-center",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => handleOpenEditModal(t),
											"data-testid": "edit-transaction-button",
											className: "p-1.5 text-zinc-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-500/10 rounded-md transition-colors inline-flex mr-1.5",
											children: /* @__PURE__ */ _jsxDEV(Edit2, { className: "h-4 w-4" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 320,
												columnNumber: 27
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 315,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => handleDelete(t.id),
											"data-testid": "delete-transaction-button",
											className: "p-1.5 text-zinc-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10 rounded-md transition-colors inline-flex",
											children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "h-4 w-4" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 327,
												columnNumber: 27
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 322,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 314,
										columnNumber: 23
									}, this)
								]
							}, t.id, true, {
								fileName: _jsxFileName,
								lineNumber: 267,
								columnNumber: 21
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 260,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 248,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 247,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 246,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(Modal, {
			isOpen: isModalOpen,
			onClose: handleCloseModal,
			title: editingTransaction ? "Edit Transaction" : "Log Transaction",
			children: /* @__PURE__ */ _jsxDEV(TransactionForm, {
				accounts,
				categories,
				onSubmit: handleSubmit,
				isSubmitting: isCreating || isUpdating,
				initialData: editingTransaction || undefined
			}, editingTransaction ? editingTransaction.id : "new-transaction", false, {
				fileName: _jsxFileName,
				lineNumber: 345,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 340,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 102,
		columnNumber: 5
	}, this);
}
_s(TransactionsPage, "hDcQUtPNbZDeb+4SSUzMv+gQzZs=", false, function() {
	return [
		useOutletContext,
		useAccounts,
		useCategories,
		useTransactions
	];
});
_c = TransactionsPage;
var _c;
$RefreshReg$(_c, "TransactionsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/TransactionsPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/TransactionsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/TransactionsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/TransactionsPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLFFBQVEsT0FBTyxZQUFZLGVBQWUsY0FBYyxnQkFBZ0IsUUFBUSxnQkFBZ0I7QUFDL0csU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsdUJBQXVCO0FBRWhDLFNBQVMsd0JBQXdCOzs7O0FBRWpDLE9BQU8sU0FBUyxtQkFBbUI7O0NBQ2pDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FDcEQsTUFBTSxDQUFDLG9CQUFvQix5QkFBeUIsU0FBNkIsSUFBSTtDQUVyRixNQUFNLGNBQWMsSUFBSSxLQUFLO0NBQzdCLE1BQU0sT0FBTyxZQUFZLFlBQVk7Q0FDckMsTUFBTSxRQUFRLFlBQVksU0FBUyxJQUFJO0NBQ3ZDLE1BQU0sbUJBQW1CLEdBQUcsS0FBSyxHQUFHLE9BQU8sS0FBSyxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUcsRUFBRTtDQUNuRSxNQUFNLFVBQVUsSUFBSSxLQUFLLE1BQU0sT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRO0NBQ2pELE1BQU0saUJBQWlCLEdBQUcsS0FBSyxHQUFHLE9BQU8sS0FBSyxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUcsRUFBRSxHQUFHLE9BQU8sT0FBTyxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7Q0FFbkcsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTO0VBQ3JDLFdBQVc7RUFDWCxZQUFZO0VBQ1osTUFBTTtFQUNOLFdBQVc7RUFDWCxTQUFTO0NBQ1gsQ0FBQztDQUNELE1BQU0sRUFBRSxpQkFBaUIsaUJBQTRDO0NBRXJFLE1BQU0sZ0JBQWdCLFFBQWdCO0VBQ3BDLE9BQU8sZUFBZSxNQUFNLElBQUksZUFBZSxNQUFNO0NBQ3ZEO0NBRUEsTUFBTSxFQUFFLGFBQWEsWUFBWTtDQUNqQyxNQUFNLEVBQUUsZUFBZSxjQUFjO0NBQ3JDLE1BQU0sRUFDSixjQUNBLFdBQ0EsbUJBQ0EsbUJBQ0EsbUJBQ0EsWUFDQSxlQUNFLGdCQUFnQixPQUFPO0NBRTNCLE1BQU0sMkJBQTJCO0VBQy9CLHNCQUFzQixJQUFJO0VBQzFCLGVBQWUsSUFBSTtDQUNyQjtDQUVBLE1BQU0sdUJBQXVCLE1BQW1CO0VBQzlDLHNCQUFzQixDQUFDO0VBQ3ZCLGVBQWUsSUFBSTtDQUNyQjtDQUVBLE1BQU0seUJBQXlCO0VBQzdCLGVBQWUsS0FBSztFQUNwQixzQkFBc0IsSUFBSTtDQUM1QjtDQUVBLE1BQU0sZUFBZSxPQUFPLFNBQTJCO0VBQ3JELElBQUk7R0FDRixJQUFJLG9CQUFvQjtJQUN0QixNQUFNLGtCQUFrQjtLQUFFLElBQUksbUJBQW1CO0tBQUksT0FBTztJQUFLLENBQUM7R0FDcEUsT0FBTztJQUNMLE1BQU0sa0JBQWtCLElBQUk7R0FDOUI7R0FDQSxpQkFBaUI7RUFDbkIsU0FBUyxPQUFZO0dBQ25CLFFBQVEsTUFBTSw4QkFBOEIsS0FBSztHQUNqRCxNQUFNLE1BQU0sV0FBVyxpREFBaUQ7RUFDMUU7Q0FDRjtDQUVBLE1BQU0sZUFBZSxPQUFPLE9BQWU7RUFDekMsSUFBSSxRQUFRLDZGQUE2RixHQUFHO0dBQzFHLElBQUk7SUFDRixNQUFNLGtCQUFrQixFQUFFO0dBQzVCLFNBQVMsT0FBWTtJQUNuQixRQUFRLE1BQU0sZ0NBQWdDLEtBQUs7SUFDbkQsTUFBTSxNQUFNLFdBQVcsK0JBQStCO0dBQ3hEO0VBQ0Y7Q0FDRjtDQUVBLE1BQU0sc0JBQXNCLEtBQTJCLFVBQWtCO0VBQ3ZFLFlBQVksVUFBVTtHQUFFLEdBQUc7SUFBTyxNQUFNO0VBQU0sRUFBRTtDQUNsRDtDQUVBLE1BQU0sMkJBQTJCO0VBQy9CLFdBQVc7R0FDVCxXQUFXO0dBQ1gsWUFBWTtHQUNaLE1BQU07R0FDTixXQUFXO0dBQ1gsU0FBUztFQUNYLENBQUM7Q0FDSDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBa0U7R0FBZ0I7Ozs7YUFDaEcsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBd0M7R0FBcUQ7Ozs7V0FDdkc7Ozs7YUFDTCx3QkFBQyxVQUFEO0lBQ0UsU0FBUztJQUNULGVBQVk7SUFDWixXQUFVO2NBSFosQ0FLRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7O2NBQUMsaUJBRXRCOzs7OztXQUNMOzs7Ozs7RUFHTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDJCQUE0Qjs7OztlQUFDLHFCQUU1Qzs7Ozs7O0lBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUVFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBa0U7TUFBYzs7OztnQkFDakcsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQ0UsT0FBTyxRQUFRO1FBQ2YsV0FBVyxNQUFNLG1CQUFtQixhQUFhLEVBQUUsT0FBTyxLQUFLO1FBQy9ELGVBQVk7UUFDWixXQUFVO2tCQUpaLENBTUUsd0JBQUMsVUFBRDtTQUFRLE9BQU07bUJBQUc7UUFBb0I7Ozs7a0JBQ3BDLFNBQVMsS0FBSyxRQUNiLHdCQUFDLFVBQUQ7U0FBcUIsT0FBTyxJQUFJO21CQUFLLElBQUk7UUFBYSxHQUF6QyxJQUFJOzs7O2VBQXFDLENBQ3ZELENBQ0s7Ozs7O2lCQUNSLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO1NBQVUsTUFBSztTQUFPLFFBQU87U0FBZSxTQUFRO1NBQVksT0FBTTttQkFDbkYsd0JBQUMsUUFBRDtVQUFNLGVBQWM7VUFBUSxnQkFBZTtVQUFRLGFBQVk7VUFBSSxHQUFFO1NBQXVCOzs7OztRQUN6Rjs7Ozs7T0FDRjs7OztlQUNGOzs7OztjQUNGOzs7OztNQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBa0U7TUFBZTs7OztnQkFDbEcsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQ0UsT0FBTyxRQUFRO1FBQ2YsV0FBVyxNQUFNLG1CQUFtQixjQUFjLEVBQUUsT0FBTyxLQUFLO1FBQ2hFLGVBQVk7UUFDWixXQUFVO2tCQUpaLENBTUUsd0JBQUMsVUFBRDtTQUFRLE9BQU07bUJBQUc7UUFBc0I7Ozs7a0JBQ3RDLFdBQVcsS0FBSyxRQUNmLHdCQUFDLFVBQUQ7U0FBcUIsT0FBTyxJQUFJO21CQUFoQztVQUFxQyxJQUFJO1VBQUs7VUFBRyxJQUFJO1VBQUs7U0FBUztXQUF0RCxJQUFJOzs7O2VBQWtELENBQ3BFLENBQ0s7Ozs7O2lCQUNSLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO1NBQVUsTUFBSztTQUFPLFFBQU87U0FBZSxTQUFRO1NBQVksT0FBTTttQkFDbkYsd0JBQUMsUUFBRDtVQUFNLGVBQWM7VUFBUSxnQkFBZTtVQUFRLGFBQVk7VUFBSSxHQUFFO1NBQXVCOzs7OztRQUN6Rjs7Ozs7T0FDRjs7OztlQUNGOzs7OztjQUNGOzs7OztNQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBa0U7TUFBVzs7OztnQkFDOUYsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQ0UsT0FBTyxRQUFRO1FBQ2YsV0FBVyxNQUFNLG1CQUFtQixRQUFRLEVBQUUsT0FBTyxLQUFLO1FBQzFELGVBQVk7UUFDWixXQUFVO2tCQUpaO1NBTUUsd0JBQUMsVUFBRDtVQUFRLE9BQU07b0JBQUc7U0FBaUI7Ozs7O1NBQ2xDLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFTO1NBQWM7Ozs7O1NBQ3JDLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFVO1NBQWU7Ozs7O1NBQ3ZDLHdCQUFDLFVBQUQ7VUFBUSxPQUFNO29CQUFXO1NBQWdCOzs7OztRQUNuQzs7Ozs7aUJBQ1Isd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsT0FBRDtTQUFLLFdBQVU7U0FBVSxNQUFLO1NBQU8sUUFBTztTQUFlLFNBQVE7U0FBWSxPQUFNO21CQUNuRix3QkFBQyxRQUFEO1VBQU0sZUFBYztVQUFRLGdCQUFlO1VBQVEsYUFBWTtVQUFJLEdBQUU7U0FBdUI7Ozs7O1FBQ3pGOzs7OztPQUNGOzs7O2VBQ0Y7Ozs7O2NBQ0Y7Ozs7O01BR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFrRTtNQUFpQjs7OztnQkFDcEcsd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTCxPQUFPLFFBQVE7T0FDZixXQUFXLE1BQU0sbUJBQW1CLGFBQWEsRUFBRSxPQUFPLEtBQUs7T0FDL0QsZUFBWTtPQUNaLFdBQVU7TUFDWDs7OztjQUNFOzs7OztNQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBa0U7TUFBZTs7OztnQkFDbEcsd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTCxPQUFPLFFBQVE7T0FDZixXQUFXLE1BQU0sbUJBQW1CLFdBQVcsRUFBRSxPQUFPLEtBQUs7T0FDN0QsZUFBWTtPQUNaLFdBQVU7TUFDWDs7OztjQUNFOzs7OztLQUNGOzs7Ozs7S0FFSCxRQUFRLGFBQWEsUUFBUSxjQUFjLFFBQVEsUUFBUSxRQUFRLGFBQWEsUUFBUSxZQUN4Rix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsZUFBWTtNQUNaLFdBQVU7Z0JBQ1g7S0FFTzs7Ozs7SUFDTDs7Ozs7R0FFSjs7Ozs7O0VBR0osWUFDQyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFzRDtFQUE0Qjs7OzthQUMvRixhQUFhLFdBQVcsSUFDMUIsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsVUFBRCxFQUFVLFdBQVUsd0JBQXlCOzs7OztJQUMxQzs7Ozs7SUFDTCx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUEyRDtJQUF5Qjs7Ozs7SUFDbEcsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBeUQ7SUFFbkU7Ozs7O0dBQ0E7Ozs7O2FBRUwsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDYix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWpCLENBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkO09BQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQW9EO09BQVE7Ozs7O09BQzFFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFvRDtPQUFlOzs7OztPQUNqRix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBb0Q7T0FBUTs7Ozs7T0FDMUUsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQW9EO09BQVk7Ozs7O09BQzlFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFvRDtPQUFZOzs7OztPQUM5RSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBK0Q7T0FBVTs7Ozs7T0FDdkYsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWdFO09BQVc7Ozs7O01BQ3ZGOzs7OztjQUNDOzs7O2VBQ1Asd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQ2QsYUFBYSxLQUFLLE1BQU07T0FDdkIsTUFBTSxXQUFXLEVBQUUsU0FBUztPQUM1QixNQUFNLFlBQVksRUFBRSxTQUFTO09BQzdCLE1BQU0sYUFBYSxFQUFFLFNBQVM7T0FFOUIsT0FDRSx3QkFBQyxNQUFEO1FBQWUsV0FBVTtrQkFBekI7U0FDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxJQUFJLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxtQkFBbUIsV0FBVztXQUFFLE9BQU87V0FBUyxLQUFLO1dBQVcsTUFBTTtVQUFVLENBQUM7U0FDakc7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQsQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBNkMsRUFBRTtVQUFpQjs7OztvQkFDOUUsRUFBRSxTQUFTLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFtRCxFQUFFO1VBQVc7Ozs7a0JBQ3pGOzs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWix3QkFBQyxRQUFEO1dBQU0sV0FBVywrRUFDZixXQUFXLGdGQUNYLFlBQVksZ0VBQ1o7cUJBSEY7WUFLRyxZQUFZLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFVBQVc7Ozs7O1lBQy9DLGFBQWEsd0JBQUMsZUFBRCxFQUFlLFdBQVUsVUFBVzs7Ozs7WUFDakQsY0FBYyx3QkFBQyxnQkFBRCxFQUFnQixXQUFVLFVBQVc7Ozs7O1lBQ25ELEVBQUU7V0FDQzs7Ozs7O1NBQ0o7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1gsRUFBRSxZQUFZLFFBQVEsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQW1DO1VBQU87Ozs7O1NBQy9FOzs7OztTQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkO1dBQ0csWUFDQyx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEIsQ0FBcUUsUUFDOUQsRUFBRSxzQkFBc0IsSUFDekI7Ozs7OztXQUVQLGFBQ0Msd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWhCLENBQTZELFVBQ3BELEVBQUUsaUJBQWlCLElBQ3RCOzs7Ozs7V0FFUCxjQUNDLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQjthQUNHLEVBQUUsaUJBQWlCO2FBQUs7YUFBQyx3QkFBQyxZQUFELEVBQVksV0FBVSw0QkFBNkI7Ozs7O2FBQUM7YUFBRSxFQUFFLHNCQUFzQjtZQUNwRzs7Ozs7O1VBRU47Ozs7OztTQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFXLHdDQUNiLFdBQVcsMkNBQ1gsWUFBWSxtQ0FDWjtvQkFIRixDQUtHLFdBQVcsTUFBTSxZQUFZLE1BQU0sSUFBSSxhQUFhLEVBQUUsTUFBTSxDQUMzRDs7Ozs7O1NBQ0osd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQsQ0FDRSx3QkFBQyxVQUFEO1dBQ0UsZUFBZSxvQkFBb0IsQ0FBQztXQUNwQyxlQUFZO1dBQ1osV0FBVTtxQkFFVix3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7OztVQUN0Qjs7OztvQkFDUix3QkFBQyxVQUFEO1dBQ0UsZUFBZSxhQUFhLEVBQUUsRUFBRTtXQUNoQyxlQUFZO1dBQ1osV0FBVTtxQkFFVix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztVQUN2Qjs7OztrQkFDTjs7Ozs7O1FBQ0Y7VUEvREssRUFBRTs7OztjQStEUDtNQUVSLENBQUM7S0FDSTs7OzthQUNGOzs7Ozs7R0FDSjs7Ozs7RUFDRjs7Ozs7RUFJUCx3QkFBQyxPQUFEO0dBQ0UsUUFBUTtHQUNSLFNBQVM7R0FDVCxPQUFPLHFCQUFxQixxQkFBcUI7YUFFakQsd0JBQUMsaUJBQUQ7SUFFWTtJQUNFO0lBQ1osVUFBVTtJQUNWLGNBQWMsY0FBYztJQUM1QixhQUFhLHNCQUFzQjtHQUNwQyxHQU5NLHFCQUFxQixtQkFBbUIsS0FBSzs7OztVQU1uRDtFQUNJOzs7OztDQUNKOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlRyYW5zYWN0aW9uc1BhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBQbHVzLCBUcmFzaDIsIEVkaXQyLCBBcnJvd1JpZ2h0LCBBcnJvd0Rvd25MZWZ0LCBBcnJvd1VwUmlnaHQsIEFycm93TGVmdFJpZ2h0LCBGaWx0ZXIsIENhbGVuZGFyIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgdXNlVHJhbnNhY3Rpb25zIH0gZnJvbSBcIi4uL2hvb2tzL3VzZVRyYW5zYWN0aW9uc1wiO1xuaW1wb3J0IHsgdXNlQWNjb3VudHMgfSBmcm9tIFwiLi4vaG9va3MvdXNlQWNjb3VudHNcIjtcbmltcG9ydCB7IHVzZUNhdGVnb3JpZXMgfSBmcm9tIFwiLi4vaG9va3MvdXNlQ2F0ZWdvcmllc1wiO1xuaW1wb3J0IHsgTW9kYWwgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9Nb2RhbFwiO1xuaW1wb3J0IHsgVHJhbnNhY3Rpb25Gb3JtIH0gZnJvbSBcIi4uL2ZlYXR1cmVzL3RyYW5zYWN0aW9ucy9UcmFuc2FjdGlvbkZvcm1cIjtcbmltcG9ydCB0eXBlIHsgVHJhbnNhY3Rpb25JbnB1dCwgVHJhbnNhY3Rpb24gfSBmcm9tIFwiLi4vdHlwZXMvdHJhbnNhY3Rpb25zXCI7XG5pbXBvcnQgeyB1c2VPdXRsZXRDb250ZXh0IH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcblxuZXhwb3J0IGZ1bmN0aW9uIFRyYW5zYWN0aW9uc1BhZ2UoKSB7XG4gIGNvbnN0IFtpc01vZGFsT3Blbiwgc2V0SXNNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZWRpdGluZ1RyYW5zYWN0aW9uLCBzZXRFZGl0aW5nVHJhbnNhY3Rpb25dID0gdXNlU3RhdGU8VHJhbnNhY3Rpb24gfCBudWxsPihudWxsKTtcblxuICBjb25zdCBjdXJyZW50RGF0ZSA9IG5ldyBEYXRlKCk7XG4gIGNvbnN0IHllYXIgPSBjdXJyZW50RGF0ZS5nZXRGdWxsWWVhcigpO1xuICBjb25zdCBtb250aCA9IGN1cnJlbnREYXRlLmdldE1vbnRoKCkgKyAxO1xuICBjb25zdCBkZWZhdWx0U3RhcnREYXRlID0gYCR7eWVhcn0tJHtTdHJpbmcobW9udGgpLnBhZFN0YXJ0KDIsIFwiMFwiKX0tMDFgO1xuICBjb25zdCBsYXN0RGF5ID0gbmV3IERhdGUoeWVhciwgbW9udGgsIDApLmdldERhdGUoKTtcbiAgY29uc3QgZGVmYXVsdEVuZERhdGUgPSBgJHt5ZWFyfS0ke1N0cmluZyhtb250aCkucGFkU3RhcnQoMiwgXCIwXCIpfS0ke1N0cmluZyhsYXN0RGF5KS5wYWRTdGFydCgyLCBcIjBcIil9YDtcblxuICBjb25zdCBbZmlsdGVycywgc2V0RmlsdGVyc10gPSB1c2VTdGF0ZSh7XG4gICAgYWNjb3VudElkOiBcIlwiLFxuICAgIGNhdGVnb3J5SWQ6IFwiXCIsXG4gICAgdHlwZTogXCJcIixcbiAgICBzdGFydERhdGU6IGRlZmF1bHRTdGFydERhdGUsXG4gICAgZW5kRGF0ZTogZGVmYXVsdEVuZERhdGUsXG4gIH0pO1xuICBjb25zdCB7IHNob3dCYWxhbmNlcyB9ID0gdXNlT3V0bGV0Q29udGV4dDx7IHNob3dCYWxhbmNlczogYm9vbGVhbiB9PigpO1xuXG4gIGNvbnN0IGZvcm1hdEFtb3VudCA9ICh2YWw6IG51bWJlcikgPT4ge1xuICAgIHJldHVybiBzaG93QmFsYW5jZXMgPyBgUnAgJHt2YWwudG9Mb2NhbGVTdHJpbmcoKX1gIDogXCJScCDigKLigKLigKLigKLigKLigKJcIjtcbiAgfTtcblxuICBjb25zdCB7IGFjY291bnRzIH0gPSB1c2VBY2NvdW50cygpO1xuICBjb25zdCB7IGNhdGVnb3JpZXMgfSA9IHVzZUNhdGVnb3JpZXMoKTtcbiAgY29uc3QgeyBcbiAgICB0cmFuc2FjdGlvbnMsIFxuICAgIGlzTG9hZGluZywgXG4gICAgY3JlYXRlVHJhbnNhY3Rpb24sIFxuICAgIHVwZGF0ZVRyYW5zYWN0aW9uLFxuICAgIGRlbGV0ZVRyYW5zYWN0aW9uLCBcbiAgICBpc0NyZWF0aW5nLFxuICAgIGlzVXBkYXRpbmdcbiAgfSA9IHVzZVRyYW5zYWN0aW9ucyhmaWx0ZXJzKTtcblxuICBjb25zdCBoYW5kbGVPcGVuQWRkTW9kYWwgPSAoKSA9PiB7XG4gICAgc2V0RWRpdGluZ1RyYW5zYWN0aW9uKG51bGwpO1xuICAgIHNldElzTW9kYWxPcGVuKHRydWUpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZU9wZW5FZGl0TW9kYWwgPSAodDogVHJhbnNhY3Rpb24pID0+IHtcbiAgICBzZXRFZGl0aW5nVHJhbnNhY3Rpb24odCk7XG4gICAgc2V0SXNNb2RhbE9wZW4odHJ1ZSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ2xvc2VNb2RhbCA9ICgpID0+IHtcbiAgICBzZXRJc01vZGFsT3BlbihmYWxzZSk7XG4gICAgc2V0RWRpdGluZ1RyYW5zYWN0aW9uKG51bGwpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChkYXRhOiBUcmFuc2FjdGlvbklucHV0KSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGlmIChlZGl0aW5nVHJhbnNhY3Rpb24pIHtcbiAgICAgICAgYXdhaXQgdXBkYXRlVHJhbnNhY3Rpb24oeyBpZDogZWRpdGluZ1RyYW5zYWN0aW9uLmlkLCBpbnB1dDogZGF0YSB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGF3YWl0IGNyZWF0ZVRyYW5zYWN0aW9uKGRhdGEpO1xuICAgICAgfVxuICAgICAgaGFuZGxlQ2xvc2VNb2RhbCgpO1xuICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gc2F2ZSB0cmFuc2FjdGlvblwiLCBlcnJvcik7XG4gICAgICBhbGVydChlcnJvci5tZXNzYWdlIHx8IFwiQW4gZXJyb3Igb2NjdXJyZWQgd2hpbGUgc2F2aW5nIHRoZSB0cmFuc2FjdGlvbi5cIik7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChpZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKGNvbmZpcm0oXCJBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVsZXRlIHRoaXMgdHJhbnNhY3Rpb24/IFRoaXMgd2lsbCByZXZlcnQgYWNjb3VudCBiYWxhbmNlIHVwZGF0ZXMuXCIpKSB7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBkZWxldGVUcmFuc2FjdGlvbihpZCk7XG4gICAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZGVsZXRlIHRyYW5zYWN0aW9uXCIsIGVycm9yKTtcbiAgICAgICAgYWxlcnQoZXJyb3IubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBkZWxldGUgdHJhbnNhY3Rpb24uXCIpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVGaWx0ZXJDaGFuZ2UgPSAoa2V5OiBrZXlvZiB0eXBlb2YgZmlsdGVycywgdmFsdWU6IHN0cmluZykgPT4ge1xuICAgIHNldEZpbHRlcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIFtrZXldOiB2YWx1ZSB9KSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ2xlYXJGaWx0ZXJzID0gKCkgPT4ge1xuICAgIHNldEZpbHRlcnMoe1xuICAgICAgYWNjb3VudElkOiBcIlwiLFxuICAgICAgY2F0ZWdvcnlJZDogXCJcIixcbiAgICAgIHR5cGU6IFwiXCIsXG4gICAgICBzdGFydERhdGU6IGRlZmF1bHRTdGFydERhdGUsXG4gICAgICBlbmREYXRlOiBkZWZhdWx0RW5kRGF0ZSxcbiAgICB9KTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IHNtOml0ZW1zLWNlbnRlciBtYi04IGdhcC00XCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZSB0cmFja2luZy10aWdodFwiPlRyYW5zYWN0aW9uczwvaDI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00MDAgbXQtMVwiPlJldmlldyBhbmQgbWFuYWdlIHlvdXIgZmFtaWx5IHRyYW5zYWN0aW9uIGhpc3RvcnkuPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZU9wZW5BZGRNb2RhbH1cbiAgICAgICAgICBkYXRhLXRlc3RpZD1cImFkZC10cmFuc2FjdGlvbi1idXR0b25cIlxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLWVtZXJhbGQtNjAwIGhvdmVyOmJnLWVtZXJhbGQtNzAwIHRleHQtd2hpdGUgcHgtNCBweS0yLjUgcm91bmRlZC1sZyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tY29sb3JzIHNoYWRvdy1zbVwiXG4gICAgICAgID5cbiAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICBMb2cgVHJhbnNhY3Rpb25cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEZpbHRlcnMgU2VjdGlvbiAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwIHAtNSBtYi02XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItNCB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZSBmb250LW1lZGl1bSB0ZXh0LXNtXCI+XG4gICAgICAgICAgPEZpbHRlciBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtZW1lcmFsZC01MDBcIiAvPlxuICAgICAgICAgIEZpbHRlciBUcmFuc2FjdGlvbnNcbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtNSBnYXAtNFwiPlxuICAgICAgICAgIHsvKiBBY2NvdW50IEZpbHRlciAqL31cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00MDAgbWItMVwiPkFjY291bnQ8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlcnMuYWNjb3VudElkfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsdGVyQ2hhbmdlKFwiYWNjb3VudElkXCIsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cImZpbHRlci1hY2NvdW50LXNlbGVjdFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFwcGVhcmFuY2Utbm9uZSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAgYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCBweC0zIHB5LTEuNSBwci0xMCB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBBY2NvdW50czwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIHthY2NvdW50cy5tYXAoKGFjYykgPT4gKFxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2FjYy5pZH0gdmFsdWU9e2FjYy5pZH0+e2FjYy5uYW1lfTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIGluc2V0LXktMCByaWdodC0wIGZsZXggaXRlbXMtY2VudGVyIHB4LTMgdGV4dC16aW5jLTUwMFwiPlxuICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwiaC00IHctNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cbiAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTE5IDlsLTcgNy03LTdcIj48L3BhdGg+XG4gICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ2F0ZWdvcnkgRmlsdGVyICovfVxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMCBtYi0xXCI+Q2F0ZWdvcnk8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlcnMuY2F0ZWdvcnlJZH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUZpbHRlckNoYW5nZShcImNhdGVnb3J5SWRcIiwgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwiZmlsdGVyLWNhdGVnb3J5LXNlbGVjdFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFwcGVhcmFuY2Utbm9uZSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAgYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCBweC0zIHB5LTEuNSBwci0xMCB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBDYXRlZ29yaWVzPC9vcHRpb24+XG4gICAgICAgICAgICAgICAge2NhdGVnb3JpZXMubWFwKChjYXQpID0+IChcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtjYXQuaWR9IHZhbHVlPXtjYXQuaWR9PntjYXQubmFtZX0gKHtjYXQudHlwZX0pPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBvaW50ZXItZXZlbnRzLW5vbmUgYWJzb2x1dGUgaW5zZXQteS0wIHJpZ2h0LTAgZmxleCBpdGVtcy1jZW50ZXIgcHgtMyB0ZXh0LXppbmMtNTAwXCI+XG4gICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJoLTQgdy00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTkgOWwtNyA3LTctN1wiPjwvcGF0aD5cbiAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBUeXBlIEZpbHRlciAqL31cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00MDAgbWItMVwiPlR5cGU8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlcnMudHlwZX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUZpbHRlckNoYW5nZShcInR5cGVcIiwgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwiZmlsdGVyLXR5cGUtc2VsZWN0XCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYXBwZWFyYW5jZS1ub25lIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMCBiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHB4LTMgcHktMS41IHByLTEwIHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+QWxsIFR5cGVzPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkluY29tZVwiPkluY29tZTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJFeHBlbnNlXCI+RXhwZW5zZTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUcmFuc2ZlclwiPlRyYW5zZmVyPC9vcHRpb24+XG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBvaW50ZXItZXZlbnRzLW5vbmUgYWJzb2x1dGUgaW5zZXQteS0wIHJpZ2h0LTAgZmxleCBpdGVtcy1jZW50ZXIgcHgtMyB0ZXh0LXppbmMtNTAwXCI+XG4gICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJoLTQgdy00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTkgOWwtNyA3LTctN1wiPjwvcGF0aD5cbiAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBTdGFydCBEYXRlICovfVxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMCBtYi0xXCI+U3RhcnQgRGF0ZTwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICB2YWx1ZT17ZmlsdGVycy5zdGFydERhdGV9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsdGVyQ2hhbmdlKFwic3RhcnREYXRlXCIsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJmaWx0ZXItc3RhcnQtZGF0ZS1pbnB1dFwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAgYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCBweC0zIHB5LTEuNSB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBFbmQgRGF0ZSAqL31cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00MDAgbWItMVwiPkVuZCBEYXRlPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXG4gICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJzLmVuZERhdGV9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsdGVyQ2hhbmdlKFwiZW5kRGF0ZVwiLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwiZmlsdGVyLWVuZC1kYXRlLWlucHV0XCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMCBiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHB4LTMgcHktMS41IHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7KGZpbHRlcnMuYWNjb3VudElkIHx8IGZpbHRlcnMuY2F0ZWdvcnlJZCB8fCBmaWx0ZXJzLnR5cGUgfHwgZmlsdGVycy5zdGFydERhdGUgfHwgZmlsdGVycy5lbmREYXRlKSAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IGZsZXgganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xlYXJGaWx0ZXJzfVxuICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cImNsZWFyLWZpbHRlcnMtYnV0dG9uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXJlZC02MDAgaG92ZXI6dGV4dC1yZWQtNzAwIGRhcms6dGV4dC1yZWQtNDAwIGRhcms6aG92ZXI6dGV4dC1yZWQtMzAwXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgQ2xlYXIgRmlsdGVyc1xuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIExlZGdlciBUYWJsZSAqL31cbiAgICAgIHtpc0xvYWRpbmcgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTY0IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXppbmMtNTAwXCI+TG9hZGluZyB0cmFuc2FjdGlvbnMuLi48L2Rpdj5cbiAgICAgICkgOiB0cmFuc2FjdGlvbnMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctemluYy05MDAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMCBwLTEyIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy16aW5jLTEwMCBkYXJrOmJnLXppbmMtODAwIHctMTYgaC0xNiByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0byBtYi00XCI+XG4gICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwiaC04IHctOCB0ZXh0LXppbmMtNDAwXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIG1iLTJcIj5ObyB0cmFuc2FjdGlvbnMgZm91bmQ8L2gzPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtemluYy01MDAgZGFyazp0ZXh0LXppbmMtNDAwIG1iLTYgbWF4LXctc20gbXgtYXV0b1wiPlxuICAgICAgICAgICAgVHJ5IGFkanVzdGluZyB5b3VyIGZpbHRlcnMgb3IgcmVjb3JkIGEgbmV3IHRyYW5zYWN0aW9uIHRvIHBvcHVsYXRlIHRoZSBsZWRnZXIuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCBib3JkZXItY29sbGFwc2VcIj5cbiAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAgYmctemluYy01MCBkYXJrOmJnLXppbmMtOTAwLzUwXCI+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXppbmMtNTAwIHVwcGVyY2FzZVwiPkRhdGU8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTUwMCB1cHBlcmNhc2VcIj5EZXNjcmlwdGlvbjwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXppbmMtNTAwIHVwcGVyY2FzZVwiPlR5cGU8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTUwMCB1cHBlcmNhc2VcIj5DYXRlZ29yeTwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXppbmMtNTAwIHVwcGVyY2FzZVwiPkFjY291bnRzPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTQgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtemluYy01MDAgdXBwZXJjYXNlIHRleHQtcmlnaHRcIj5BbW91bnQ8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTUwMCB1cHBlcmNhc2UgdGV4dC1jZW50ZXJcIj5BY3Rpb25zPC90aD5cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXppbmMtMTAwIGRhcms6ZGl2aWRlLXppbmMtODAwXCI+XG4gICAgICAgICAgICAgICAge3RyYW5zYWN0aW9ucy5tYXAoKHQpID0+IHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGlzSW5jb21lID0gdC50eXBlID09PSBcIkluY29tZVwiO1xuICAgICAgICAgICAgICAgICAgY29uc3QgaXNFeHBlbnNlID0gdC50eXBlID09PSBcIkV4cGVuc2VcIjtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGlzVHJhbnNmZXIgPSB0LnR5cGUgPT09IFwiVHJhbnNmZXJcIjtcblxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17dC5pZH0gY2xhc3NOYW1lPVwiaG92ZXI6YmctemluYy01MCBkYXJrOmhvdmVyOmJnLXppbmMtODAwLzIwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXNtIHRleHQtemluYy05NTAgZGFyazp0ZXh0LXppbmMtMzAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUodC5kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcodW5kZWZpbmVkLCB7IG1vbnRoOiBcInNob3J0XCIsIGRheTogXCJudW1lcmljXCIsIHllYXI6IFwibnVtZXJpY1wiIH0pfVxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtemluYy05NTAgZGFyazp0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtXCI+e3QuZGVzY3JpcHRpb259PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dC5ub3RlcyAmJiA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC16aW5jLTQwMCBkYXJrOnRleHQtemluYy01MDAgbXQtMC41XCI+e3Qubm90ZXN9PC9kaXY+fVxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQteHMgZm9udC1tZWRpdW0gcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzSW5jb21lID8gXCJiZy1lbWVyYWxkLTUwIHRleHQtZW1lcmFsZC03MDAgZGFyazpiZy1lbWVyYWxkLTUwMC8xMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIiA6XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzRXhwZW5zZSA/IFwiYmctcmVkLTUwIHRleHQtcmVkLTcwMCBkYXJrOmJnLXJlZC01MDAvMTAgZGFyazp0ZXh0LXJlZC00MDBcIiA6XG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiYmctYmx1ZS01MCB0ZXh0LWJsdWUtNzAwIGRhcms6YmctYmx1ZS01MDAvMTAgZGFyazp0ZXh0LWJsdWUtNDAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2lzSW5jb21lICYmIDxBcnJvd1VwUmlnaHQgY2xhc3NOYW1lPVwiaC0zIHctM1wiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNFeHBlbnNlICYmIDxBcnJvd0Rvd25MZWZ0IGNsYXNzTmFtZT1cImgtMyB3LTNcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2lzVHJhbnNmZXIgJiYgPEFycm93TGVmdFJpZ2h0IGNsYXNzTmFtZT1cImgtMyB3LTNcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3QudHlwZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTQgdGV4dC1zbSB0ZXh0LXppbmMtNjAwIGRhcms6dGV4dC16aW5jLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3QuY2F0ZWdvcmllcz8ubmFtZSB8fCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtNDAwIGRhcms6dGV4dC16aW5jLTYwMFwiPuKAlDwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC00IHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc0luY29tZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVG86IHt0LmRlc3RpbmF0aW9uX2FjY291bnRzPy5uYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAge2lzRXhwZW5zZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMCBkYXJrOnRleHQtcmVkLTQwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEZyb206IHt0LnNvdXJjZV9hY2NvdW50cz8ubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpc1RyYW5zZmVyICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC16aW5jLTcwMCBkYXJrOnRleHQtemluYy0zMDAgZm9udC1tZWRpdW0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0LnNvdXJjZV9hY2NvdW50cz8ubmFtZX0gPEFycm93UmlnaHQgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjUgdGV4dC16aW5jLTQwMFwiIC8+IHt0LmRlc3RpbmF0aW9uX2FjY291bnRzPy5uYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT17YHAtNCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1yaWdodCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgaXNJbmNvbWUgPyBcInRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCIgOlxuICAgICAgICAgICAgICAgICAgICAgICAgaXNFeHBlbnNlID8gXCJ0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC00MDBcIiA6XG4gICAgICAgICAgICAgICAgICAgICAgICBcInRleHQtemluYy03MDAgZGFyazp0ZXh0LXppbmMtMzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNJbmNvbWUgPyBcIitcIiA6IGlzRXhwZW5zZSA/IFwiLVwiIDogXCJcIn17Zm9ybWF0QW1vdW50KHQuYW1vdW50KX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTQgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlT3BlbkVkaXRNb2RhbCh0KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJlZGl0LXRyYW5zYWN0aW9uLWJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtemluYy00MDAgaG92ZXI6dGV4dC1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTUwIGRhcms6aG92ZXI6YmctZW1lcmFsZC01MDAvMTAgcm91bmRlZC1tZCB0cmFuc2l0aW9uLWNvbG9ycyBpbmxpbmUtZmxleCBtci0xLjVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RWRpdDIgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlKHQuaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cImRlbGV0ZS10cmFuc2FjdGlvbi1idXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXppbmMtNDAwIGhvdmVyOnRleHQtcmVkLTYwMCBob3ZlcjpiZy1yZWQtNTAgZGFyazpob3ZlcjpiZy1yZWQtNTAwLzEwIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1jb2xvcnMgaW5saW5lLWZsZXhcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBMb2cgVHJhbnNhY3Rpb24gTW9kYWwgKi99XG4gICAgICA8TW9kYWxcbiAgICAgICAgaXNPcGVuPXtpc01vZGFsT3Blbn1cbiAgICAgICAgb25DbG9zZT17aGFuZGxlQ2xvc2VNb2RhbH1cbiAgICAgICAgdGl0bGU9e2VkaXRpbmdUcmFuc2FjdGlvbiA/IFwiRWRpdCBUcmFuc2FjdGlvblwiIDogXCJMb2cgVHJhbnNhY3Rpb25cIn1cbiAgICAgID5cbiAgICAgICAgPFRyYW5zYWN0aW9uRm9ybVxuICAgICAgICAgIGtleT17ZWRpdGluZ1RyYW5zYWN0aW9uID8gZWRpdGluZ1RyYW5zYWN0aW9uLmlkIDogXCJuZXctdHJhbnNhY3Rpb25cIn1cbiAgICAgICAgICBhY2NvdW50cz17YWNjb3VudHN9XG4gICAgICAgICAgY2F0ZWdvcmllcz17Y2F0ZWdvcmllc31cbiAgICAgICAgICBvblN1Ym1pdD17aGFuZGxlU3VibWl0fVxuICAgICAgICAgIGlzU3VibWl0dGluZz17aXNDcmVhdGluZyB8fCBpc1VwZGF0aW5nfVxuICAgICAgICAgIGluaXRpYWxEYXRhPXtlZGl0aW5nVHJhbnNhY3Rpb24gfHwgdW5kZWZpbmVkfVxuICAgICAgICAvPlxuICAgICAgPC9Nb2RhbD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==