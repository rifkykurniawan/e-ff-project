import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ReportsPage.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=513be775";
import { useTransactions } from "/src/hooks/useTransactions.ts";
import { useOutletContext } from "/node_modules/.vite/deps/react-router-dom.js?v=63710477";
import { BarChart3, TrendingUp, TrendingDown, FileText, Wallet } from "/node_modules/.vite/deps/lucide-react.js?v=7df35618";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/ReportsPage.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
var _s = $RefreshSig$();
export function ReportsPage() {
	_s();
	const currentDate = new Date();
	const [selectedYear, setSelectedYear] = useState(currentDate.getFullYear());
	const [selectedMonth, setSelectedMonth] = useState(currentDate.getMonth() + 1);
	const { showBalances } = useOutletContext();
	// Date boundaries
	const startDate = `${selectedYear}-${String(selectedMonth).padStart(2, "0")}-01`;
	const lastDay = new Date(selectedYear, selectedMonth, 0).getDate();
	const endDate = `${selectedYear}-${String(selectedMonth).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`;
	// Fetch all transactions for the selected month
	const { transactions, isLoading } = useTransactions({
		startDate,
		endDate
	});
	// Filter transactions
	const incomes = transactions.filter((t) => t.type === "Income");
	const expenses = transactions.filter((t) => t.type === "Expense");
	// Sums
	const totalIncome = incomes.reduce((sum, t) => sum + Number(t.amount), 0);
	const totalExpense = expenses.reduce((sum, t) => sum + Number(t.amount), 0);
	const netFlow = totalIncome - totalExpense;
	// Group by category helper
	const groupByCategory = (txList) => {
		const grouped = txList.reduce((acc, t) => {
			const catName = t.categories?.name || "Uncategorized";
			acc[catName] = (acc[catName] || 0) + Number(t.amount);
			return acc;
		}, {});
		return Object.entries(grouped).map(([name, amount]) => ({
			name,
			amount
		})).sort((a, b) => b.amount - a.amount);
	};
	const incomeCategories = groupByCategory(incomes);
	const expenseCategories = groupByCategory(expenses);
	const formatAmount = (val) => {
		return showBalances ? new Intl.NumberFormat("id-ID", {
			style: "currency",
			currency: "IDR",
			minimumFractionDigits: 0
		}).format(val) : "Rp ••••••";
	};
	const months = [
		{
			value: 1,
			label: "January"
		},
		{
			value: 2,
			label: "February"
		},
		{
			value: 3,
			label: "March"
		},
		{
			value: 4,
			label: "April"
		},
		{
			value: 5,
			label: "May"
		},
		{
			value: 6,
			label: "June"
		},
		{
			value: 7,
			label: "July"
		},
		{
			value: 8,
			label: "August"
		},
		{
			value: 9,
			label: "September"
		},
		{
			value: 10,
			label: "October"
		},
		{
			value: 11,
			label: "November"
		},
		{
			value: 12,
			label: "December"
		}
	];
	const years = Array.from({ length: 7 }, (_, i) => currentDate.getFullYear() - 5 + i);
	const handleExport = (type) => {
		alert(`Exporting monthly report as ${type.toUpperCase()} is scheduled for the next release phase.`);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-2xl font-bold text-zinc-900 dark:text-white tracking-tight flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(BarChart3, { className: "h-6 w-6 text-emerald-500" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 13
					}, this), "Monthly Reports"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-zinc-500 dark:text-zinc-400 mt-1",
					children: "Analyze your family income, outcomes, and category breakdowns."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-center gap-3 w-full sm:w-auto",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "relative flex-1 sm:flex-initial",
							children: [/* @__PURE__ */ _jsxDEV("select", {
								value: selectedMonth,
								onChange: (e) => setSelectedMonth(Number(e.target.value)),
								"data-testid": "month-select",
								className: "w-full appearance-none rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 px-3 py-2 pr-10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 cursor-pointer",
								children: months.map((m) => /* @__PURE__ */ _jsxDEV("option", {
									value: m.value,
									children: m.label
								}, m.value, false, {
									fileName: _jsxFileName,
									lineNumber: 99,
									columnNumber: 17
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 92,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-zinc-500",
								children: /* @__PURE__ */ _jsxDEV("svg", {
									className: "h-4 w-4",
									fill: "none",
									stroke: "currentColor",
									viewBox: "0 0 24 24",
									xmlns: "http://www.w3.org/2000/svg",
									children: /* @__PURE__ */ _jsxDEV("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										strokeWidth: "2",
										d: "M19 9l-7 7-7-7"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 104,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 103,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 91,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "relative flex-1 sm:flex-initial",
							children: [/* @__PURE__ */ _jsxDEV("select", {
								value: selectedYear,
								onChange: (e) => setSelectedYear(Number(e.target.value)),
								"data-testid": "year-select",
								className: "w-full appearance-none rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 px-3 py-2 pr-10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 cursor-pointer",
								children: years.map((y) => /* @__PURE__ */ _jsxDEV("option", {
									value: y,
									children: y
								}, y, false, {
									fileName: _jsxFileName,
									lineNumber: 118,
									columnNumber: 17
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-zinc-500",
								children: /* @__PURE__ */ _jsxDEV("svg", {
									className: "h-4 w-4",
									fill: "none",
									stroke: "currentColor",
									viewBox: "0 0 24 24",
									xmlns: "http://www.w3.org/2000/svg",
									children: /* @__PURE__ */ _jsxDEV("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										strokeWidth: "2",
										d: "M19 9l-7 7-7-7"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 123,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 122,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 121,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 110,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex gap-2 w-full sm:w-auto",
							children: /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleExport("pdf"),
								"data-testid": "export-pdf-button",
								className: "flex-1 sm:flex-initial flex items-center justify-center gap-1.5 rounded-lg bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700/80 px-3.5 py-2 text-sm font-semibold text-zinc-700 dark:text-zinc-300 border border-zinc-200 dark:border-zinc-700 cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV(FileText, { className: "h-4 w-4 text-red-650 dark:text-red-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 135,
									columnNumber: 15
								}, this), " Export PDF"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 130,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-3 gap-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-sm flex items-center gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-emerald-50 dark:bg-emerald-500/10 p-3 rounded-xl text-emerald-600 dark:text-emerald-400",
							children: /* @__PURE__ */ _jsxDEV(TrendingUp, { className: "h-6 w-6" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 145,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "text-zinc-500 dark:text-zinc-400 text-xs font-semibold uppercase tracking-wider",
							children: "Total Income"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "text-xl font-bold text-zinc-900 dark:text-white mt-1",
							children: formatAmount(totalIncome)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 143,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-sm flex items-center gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-rose-50 dark:bg-rose-500/10 p-3 rounded-xl text-rose-600 dark:text-rose-400",
							children: /* @__PURE__ */ _jsxDEV(TrendingDown, { className: "h-6 w-6" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 154,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "text-zinc-500 dark:text-zinc-400 text-xs font-semibold uppercase tracking-wider",
							children: "Total Outcome"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 158,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "text-xl font-bold text-red-500 mt-1",
							children: formatAmount(totalExpense)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 159,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 157,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 153,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-sm flex items-center gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: `p-3 rounded-xl ${netFlow >= 0 ? "bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" : "bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400"}`,
							children: /* @__PURE__ */ _jsxDEV(Wallet, { className: "h-6 w-6" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 165,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 164,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "text-zinc-500 dark:text-zinc-400 text-xs font-semibold uppercase tracking-wider",
							children: "Net Cash Flow"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 168,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: `text-xl font-bold mt-1 ${netFlow >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-red-500"}`,
							children: formatAmount(netFlow)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 169,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 167,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 163,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 142,
				columnNumber: 7
			}, this),
			isLoading ? /* @__PURE__ */ _jsxDEV("div", {
				className: "flex h-64 items-center justify-center text-zinc-500",
				children: "Loading monthly report..."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 177,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-2 gap-6",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-6 shadow-sm",
					children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-lg font-bold text-zinc-900 dark:text-white mb-4",
						children: "Income by Category"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 184,
						columnNumber: 15
					}, this), incomeCategories.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm text-zinc-500 dark:text-zinc-400 italic",
						children: "No income logged in this month."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 186,
						columnNumber: 17
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-4",
						children: incomeCategories.map((c) => {
							const percentage = totalIncome > 0 ? c.amount / totalIncome * 100 : 0;
							return /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between text-sm font-semibold",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-zinc-700 dark:text-zinc-300",
										children: c.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 194,
										columnNumber: 27
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-zinc-900 dark:text-white",
										children: [
											formatAmount(c.amount),
											" (",
											percentage.toFixed(0),
											"%)"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 195,
										columnNumber: 27
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 193,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "w-full bg-zinc-100 dark:bg-zinc-800 h-2 rounded-full overflow-hidden",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "h-full bg-emerald-500 rounded-full",
										style: { width: `${percentage}%` }
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 200,
										columnNumber: 27
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 199,
									columnNumber: 25
								}, this)]
							}, c.name, true, {
								fileName: _jsxFileName,
								lineNumber: 192,
								columnNumber: 23
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 188,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 183,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-6 shadow-sm",
					children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-lg font-bold text-zinc-900 dark:text-white mb-4",
						children: "Outcome by Category"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 211,
						columnNumber: 15
					}, this), expenseCategories.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm text-zinc-500 dark:text-zinc-400 italic",
						children: "No outcome logged in this month."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 213,
						columnNumber: 17
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-4",
						children: expenseCategories.map((c) => {
							const percentage = totalExpense > 0 ? c.amount / totalExpense * 100 : 0;
							return /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between text-sm font-semibold",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-zinc-700 dark:text-zinc-300",
										children: c.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 221,
										columnNumber: 27
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-zinc-900 dark:text-white",
										children: [
											formatAmount(c.amount),
											" (",
											percentage.toFixed(0),
											"%)"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 222,
										columnNumber: 27
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 220,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "w-full bg-zinc-100 dark:bg-zinc-800 h-2 rounded-full overflow-hidden",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "h-full bg-rose-500 rounded-full",
										style: { width: `${percentage}%` }
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 227,
										columnNumber: 27
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 226,
									columnNumber: 25
								}, this)]
							}, c.name, true, {
								fileName: _jsxFileName,
								lineNumber: 219,
								columnNumber: 23
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 215,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 210,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 181,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-2 gap-6",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-6 shadow-sm overflow-hidden flex flex-col",
					children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-lg font-bold text-zinc-900 dark:text-white mb-4",
						children: "Income Transactions"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 241,
						columnNumber: 15
					}, this), incomes.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm text-zinc-500 dark:text-zinc-400 italic",
						children: "No income transactions in this period."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 243,
						columnNumber: 17
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "overflow-x-auto -mx-6 max-h-96 overflow-y-auto",
						children: /* @__PURE__ */ _jsxDEV("table", {
							className: "w-full text-left border-collapse",
							children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-zinc-250 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-900/50 text-xs font-semibold text-zinc-500 uppercase sticky top-0 backdrop-blur z-10",
								children: [
									/* @__PURE__ */ _jsxDEV("th", {
										className: "p-4 pl-6 bg-zinc-50/90 dark:bg-zinc-900/90",
										children: "Date"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 249,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "p-4 bg-zinc-50/90 dark:bg-zinc-900/90",
										children: "Category"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 250,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "p-4 bg-zinc-50/90 dark:bg-zinc-900/90",
										children: "Account"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 251,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "p-4 text-right pr-6 bg-zinc-50/90 dark:bg-zinc-900/90",
										children: "Amount"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 252,
										columnNumber: 25
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 248,
								columnNumber: 23
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 247,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("tbody", {
								className: "divide-y divide-zinc-100 dark:divide-zinc-800/80",
								children: incomes.map((t) => /* @__PURE__ */ _jsxDEV("tr", {
									className: "hover:bg-zinc-50/50 dark:hover:bg-zinc-800/10 transition-colors",
									children: [
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-4 pl-6 text-xs text-zinc-500 whitespace-nowrap",
											children: new Date(t.date).toLocaleDateString(undefined, {
												month: "short",
												day: "numeric"
											})
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 258,
											columnNumber: 27
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-4 text-sm text-zinc-900 dark:text-white font-medium",
											children: t.categories?.name || "Uncategorized"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 261,
											columnNumber: 27
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-4 text-xs text-zinc-505 dark:text-zinc-500",
											children: t.destination_accounts?.name || "-"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 264,
											columnNumber: 27
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-4 text-sm font-semibold text-emerald-600 dark:text-emerald-400 text-right pr-6 whitespace-nowrap",
											children: ["+", formatAmount(t.amount)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 267,
											columnNumber: 27
										}, this)
									]
								}, t.id, true, {
									fileName: _jsxFileName,
									lineNumber: 257,
									columnNumber: 25
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 255,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 246,
							columnNumber: 19
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 245,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 240,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-6 shadow-sm overflow-hidden flex flex-col",
					children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-lg font-bold text-zinc-900 dark:text-white mb-4",
						children: "Outcome Transactions"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 280,
						columnNumber: 15
					}, this), expenses.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm text-zinc-500 dark:text-zinc-400 italic",
						children: "No outcome transactions in this period."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 282,
						columnNumber: 17
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "overflow-x-auto -mx-6 max-h-96 overflow-y-auto",
						children: /* @__PURE__ */ _jsxDEV("table", {
							className: "w-full text-left border-collapse",
							children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-zinc-250 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-900/50 text-xs font-semibold text-zinc-500 uppercase sticky top-0 backdrop-blur z-10",
								children: [
									/* @__PURE__ */ _jsxDEV("th", {
										className: "p-4 pl-6 bg-zinc-50/90 dark:bg-zinc-900/90",
										children: "Date"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 288,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "p-4 bg-zinc-50/90 dark:bg-zinc-900/90",
										children: "Category"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 289,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "p-4 bg-zinc-50/90 dark:bg-zinc-900/90",
										children: "Account"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 290,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "p-4 text-right pr-6 bg-zinc-50/90 dark:bg-zinc-900/90",
										children: "Amount"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 291,
										columnNumber: 25
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 287,
								columnNumber: 23
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 286,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("tbody", {
								className: "divide-y divide-zinc-100 dark:divide-zinc-800/80",
								children: expenses.map((t) => /* @__PURE__ */ _jsxDEV("tr", {
									className: "hover:bg-zinc-50/50 dark:hover:bg-zinc-800/10 transition-colors",
									children: [
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-4 pl-6 text-xs text-zinc-500 whitespace-nowrap",
											children: new Date(t.date).toLocaleDateString(undefined, {
												month: "short",
												day: "numeric"
											})
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 297,
											columnNumber: 27
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-4 text-sm text-zinc-900 dark:text-white font-medium",
											children: t.categories?.name || "Uncategorized"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 300,
											columnNumber: 27
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-4 text-xs text-zinc-505 dark:text-zinc-500",
											children: t.source_accounts?.name || "-"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 303,
											columnNumber: 27
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "p-4 text-sm font-semibold text-red-600 dark:text-red-400 text-right pr-6 whitespace-nowrap",
											children: ["-", formatAmount(t.amount)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 306,
											columnNumber: 27
										}, this)
									]
								}, t.id, true, {
									fileName: _jsxFileName,
									lineNumber: 296,
									columnNumber: 25
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 294,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 285,
							columnNumber: 19
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 284,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 279,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 238,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 179,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 76,
		columnNumber: 5
	}, this);
}
_s(ReportsPage, "x1LAiZw5kng/6DADLqUTjX+Izpo=", false, function() {
	return [useOutletContext, useTransactions];
});
_c = ReportsPage;
var _c;
$RefreshReg$(_c, "ReportsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/ReportsPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/ReportsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/ReportsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/ReportsPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxXQUFXLFlBQVksY0FBYyxVQUFVLGNBQWM7Ozs7QUFFdEUsT0FBTyxTQUFTLGNBQWM7O0NBQzVCLE1BQU0sY0FBYyxJQUFJLEtBQUs7Q0FDN0IsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsWUFBWSxZQUFZLENBQUM7Q0FDMUUsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsWUFBWSxTQUFTLElBQUksQ0FBQztDQUM3RSxNQUFNLEVBQUUsaUJBQWlCLGlCQUE0Qzs7Q0FHckUsTUFBTSxZQUFZLEdBQUcsYUFBYSxHQUFHLE9BQU8sYUFBYSxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUcsRUFBRTtDQUM1RSxNQUFNLFVBQVUsSUFBSSxLQUFLLGNBQWMsZUFBZSxDQUFDLENBQUMsQ0FBQyxRQUFRO0NBQ2pFLE1BQU0sVUFBVSxHQUFHLGFBQWEsR0FBRyxPQUFPLGFBQWEsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLEVBQUUsR0FBRyxPQUFPLE9BQU8sQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHOztDQUc1RyxNQUFNLEVBQUUsY0FBYyxjQUFjLGdCQUFnQjtFQUNsRDtFQUNBO0NBQ0YsQ0FBQzs7Q0FHRCxNQUFNLFVBQVUsYUFBYSxRQUFRLE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FDOUQsTUFBTSxXQUFXLGFBQWEsUUFBUSxNQUFNLEVBQUUsU0FBUyxTQUFTOztDQUdoRSxNQUFNLGNBQWMsUUFBUSxRQUFRLEtBQUssTUFBTSxNQUFNLE9BQU8sRUFBRSxNQUFNLEdBQUcsQ0FBQztDQUN4RSxNQUFNLGVBQWUsU0FBUyxRQUFRLEtBQUssTUFBTSxNQUFNLE9BQU8sRUFBRSxNQUFNLEdBQUcsQ0FBQztDQUMxRSxNQUFNLFVBQVUsY0FBYzs7Q0FHOUIsTUFBTSxtQkFBbUIsV0FBZ0M7RUFDdkQsTUFBTSxVQUFVLE9BQU8sUUFBUSxLQUFLLE1BQU07R0FDeEMsTUFBTSxVQUFVLEVBQUUsWUFBWSxRQUFRO0dBQ3RDLElBQUksWUFBWSxJQUFJLFlBQVksS0FBSyxPQUFPLEVBQUUsTUFBTTtHQUNwRCxPQUFPO0VBQ1QsR0FBRyxDQUFDLENBQTJCO0VBRS9CLE9BQU8sT0FBTyxRQUFRLE9BQU8sQ0FBQyxDQUMzQixLQUFLLENBQUMsTUFBTSxhQUFhO0dBQUU7R0FBTTtFQUFPLEVBQUUsQ0FBQyxDQUMzQyxNQUFNLEdBQUcsTUFBTSxFQUFFLFNBQVMsRUFBRSxNQUFNO0NBQ3ZDO0NBRUEsTUFBTSxtQkFBbUIsZ0JBQWdCLE9BQU87Q0FDaEQsTUFBTSxvQkFBb0IsZ0JBQWdCLFFBQVE7Q0FFbEQsTUFBTSxnQkFBZ0IsUUFBZ0I7RUFDcEMsT0FBTyxlQUNILElBQUksS0FBSyxhQUFhLFNBQVM7R0FBRSxPQUFPO0dBQVksVUFBVTtHQUFPLHVCQUF1QjtFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRyxJQUMzRztDQUNOO0NBRUEsTUFBTSxTQUFTO0VBQ2I7R0FBRSxPQUFPO0dBQUcsT0FBTztFQUFVO0VBQzdCO0dBQUUsT0FBTztHQUFHLE9BQU87RUFBVztFQUM5QjtHQUFFLE9BQU87R0FBRyxPQUFPO0VBQVE7RUFDM0I7R0FBRSxPQUFPO0dBQUcsT0FBTztFQUFRO0VBQzNCO0dBQUUsT0FBTztHQUFHLE9BQU87RUFBTTtFQUN6QjtHQUFFLE9BQU87R0FBRyxPQUFPO0VBQU87RUFDMUI7R0FBRSxPQUFPO0dBQUcsT0FBTztFQUFPO0VBQzFCO0dBQUUsT0FBTztHQUFHLE9BQU87RUFBUztFQUM1QjtHQUFFLE9BQU87R0FBRyxPQUFPO0VBQVk7RUFDL0I7R0FBRSxPQUFPO0dBQUksT0FBTztFQUFVO0VBQzlCO0dBQUUsT0FBTztHQUFJLE9BQU87RUFBVztFQUMvQjtHQUFFLE9BQU87R0FBSSxPQUFPO0VBQVc7Q0FDakM7Q0FFQSxNQUFNLFFBQVEsTUFBTSxLQUFLLEVBQUUsUUFBUSxFQUFFLElBQUksR0FBRyxNQUFNLFlBQVksWUFBWSxJQUFJLElBQUksQ0FBQztDQUVuRixNQUFNLGdCQUFnQixTQUEwQjtFQUM5QyxNQUFNLCtCQUErQixLQUFLLFlBQVksRUFBRSwwQ0FBMEM7Q0FDcEc7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQsQ0FDRSx3QkFBQyxXQUFELEVBQVcsV0FBVSwyQkFBNEI7Ozs7ZUFBQyxpQkFFaEQ7Ozs7O2NBQ0osd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBd0M7SUFFbEQ7Ozs7WUFDQTs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQ7UUFDRSxPQUFPO1FBQ1AsV0FBVyxNQUFNLGlCQUFpQixPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7UUFDeEQsZUFBWTtRQUNaLFdBQVU7a0JBRVQsT0FBTyxLQUFLLE1BQ1gsd0JBQUMsVUFBRDtTQUFzQixPQUFPLEVBQUU7bUJBQVEsRUFBRTtRQUFjLEdBQTFDLEVBQUU7Ozs7ZUFBd0MsQ0FDeEQ7T0FDSzs7OztpQkFDUix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxPQUFEO1NBQUssV0FBVTtTQUFVLE1BQUs7U0FBTyxRQUFPO1NBQWUsU0FBUTtTQUFZLE9BQU07bUJBQ25GLHdCQUFDLFFBQUQ7VUFBTSxlQUFjO1VBQVEsZ0JBQWU7VUFBUSxhQUFZO1VBQUksR0FBRTtTQUF1Qjs7Ozs7UUFDekY7Ozs7O09BQ0Y7Ozs7ZUFDRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQ0UsT0FBTztRQUNQLFdBQVcsTUFBTSxnQkFBZ0IsT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO1FBQ3ZELGVBQVk7UUFDWixXQUFVO2tCQUVULE1BQU0sS0FBSyxNQUNWLHdCQUFDLFVBQUQ7U0FBZ0IsT0FBTzttQkFBSTtRQUFVLEdBQXhCOzs7O2VBQXdCLENBQ3RDO09BQ0s7Ozs7aUJBQ1Isd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsT0FBRDtTQUFLLFdBQVU7U0FBVSxNQUFLO1NBQU8sUUFBTztTQUFlLFNBQVE7U0FBWSxPQUFNO21CQUNuRix3QkFBQyxRQUFEO1VBQU0sZUFBYztVQUFRLGdCQUFlO1VBQVEsYUFBWTtVQUFJLEdBQUU7U0FBdUI7Ozs7O1FBQ3pGOzs7OztPQUNGOzs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLGFBQWEsS0FBSztRQUNqQyxlQUFZO1FBQ1osV0FBVTtrQkFIWixDQUtFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlDQUEwQzs7OztrQkFBQyxhQUN6RDs7Ozs7O01BQ0w7Ozs7O0tBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFlBQUQsRUFBWSxXQUFVLFVBQVc7Ozs7O01BQzlCOzs7O2dCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBa0Y7TUFBaUI7Ozs7Z0JBQ2xILHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUF3RCxhQUFhLFdBQVc7TUFBTzs7OztjQUNuRzs7OztjQUNGOzs7Ozs7S0FFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFVBQVc7Ozs7O01BQ2hDOzs7O2dCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBa0Y7TUFBa0I7Ozs7Z0JBQ25ILHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUF1QyxhQUFhLFlBQVk7TUFBTzs7OztjQUNuRjs7OztjQUNGOzs7Ozs7S0FFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFXLGtCQUFrQixXQUFXLElBQUksZ0ZBQWdGO2lCQUMvSCx3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztNQUMxQjs7OztnQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWtGO01BQWtCOzs7O2dCQUNuSCx3QkFBQyxPQUFEO09BQUssV0FBVywwQkFBMEIsV0FBVyxJQUFJLDJDQUEyQztpQkFDakcsYUFBYSxPQUFPO01BQ2xCOzs7O2NBQ0Y7Ozs7Y0FDRjs7Ozs7O0lBQ0Y7Ozs7OztHQUVKLFlBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBc0Q7R0FBOEI7Ozs7Y0FFbkcsZ0RBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBdUQ7S0FBc0I7Ozs7ZUFDMUYsaUJBQWlCLFdBQVcsSUFDM0Isd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWtEO0tBQWtDOzs7O2dCQUVqRyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWixpQkFBaUIsS0FBSyxNQUFNO09BQzNCLE1BQU0sYUFBYSxjQUFjLElBQUssRUFBRSxTQUFTLGNBQWUsTUFBTTtPQUN0RSxPQUNFLHdCQUFDLE9BQUQ7UUFBa0IsV0FBVTtrQkFBNUIsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFvQyxFQUFFO1NBQVc7Ozs7bUJBQ2pFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQjtXQUNHLGFBQWEsRUFBRSxNQUFNO1dBQUU7V0FBRyxXQUFXLFFBQVEsQ0FBQztXQUFFO1VBQzdDOzs7OztpQkFDSDs7Ozs7a0JBQ0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ2Isd0JBQUMsT0FBRDtVQUFLLFdBQVU7VUFBcUMsT0FBTyxFQUFFLE9BQU8sR0FBRyxXQUFXLEdBQUc7U0FBSTs7Ozs7UUFDdEY7Ozs7Z0JBQ0Y7VUFWSyxFQUFFOzs7O2NBVVA7TUFFVCxDQUFDO0tBQ0U7Ozs7YUFFSjs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXVEO0tBQXVCOzs7O2VBQzNGLGtCQUFrQixXQUFXLElBQzVCLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFrRDtLQUFtQzs7OztnQkFFbEcsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1osa0JBQWtCLEtBQUssTUFBTTtPQUM1QixNQUFNLGFBQWEsZUFBZSxJQUFLLEVBQUUsU0FBUyxlQUFnQixNQUFNO09BQ3hFLE9BQ0Usd0JBQUMsT0FBRDtRQUFrQixXQUFVO2tCQUE1QixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQW9DLEVBQUU7U0FBVzs7OzttQkFDakUsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCO1dBQ0csYUFBYSxFQUFFLE1BQU07V0FBRTtXQUFHLFdBQVcsUUFBUSxDQUFDO1dBQUU7VUFDN0M7Ozs7O2lCQUNIOzs7OztrQkFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxPQUFEO1VBQUssV0FBVTtVQUFrQyxPQUFPLEVBQUUsT0FBTyxHQUFHLFdBQVcsR0FBRztTQUFJOzs7OztRQUNuRjs7OztnQkFDRjtVQVZLLEVBQUU7Ozs7Y0FVUDtNQUVULENBQUM7S0FDRTs7OzthQUVKOzs7OztZQUNGOzs7OzthQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXVEO0tBQXVCOzs7O2VBQzNGLFFBQVEsV0FBVyxJQUNsQix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBa0Q7S0FBeUM7Ozs7Z0JBRXhHLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZDtTQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUE2QztTQUFROzs7OztTQUNuRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBd0M7U0FBWTs7Ozs7U0FDbEUsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQXdDO1NBQVc7Ozs7O1NBQ2pFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUF3RDtTQUFVOzs7OztRQUM5RTs7Ozs7Z0JBQ0M7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQ2QsUUFBUSxLQUFLLE1BQ1osd0JBQUMsTUFBRDtTQUFlLFdBQVU7bUJBQXpCO1VBQ0Usd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQ1gsSUFBSSxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsbUJBQW1CLFdBQVc7WUFBRSxPQUFPO1lBQVMsS0FBSztXQUFVLENBQUM7VUFDaEY7Ozs7O1VBQ0osd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQ1gsRUFBRSxZQUFZLFFBQVE7VUFDckI7Ozs7O1VBQ0osd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQ1gsRUFBRSxzQkFBc0IsUUFBUTtVQUMvQjs7Ozs7VUFDSix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBZCxDQUFtSCxLQUMvRyxhQUFhLEVBQUUsTUFBTSxDQUNyQjs7Ozs7O1NBQ0Y7V0FiSyxFQUFFOzs7O2VBYVAsQ0FDTDtPQUNJOzs7O2VBQ0Y7Ozs7OztLQUNKOzs7O2FBRUo7Ozs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUF1RDtLQUF3Qjs7OztlQUM1RixTQUFTLFdBQVcsSUFDbkIsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWtEO0tBQTBDOzs7O2dCQUV6Ryx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBakIsQ0FDRSx3QkFBQyxTQUFELFlBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQ7U0FDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBNkM7U0FBUTs7Ozs7U0FDbkUsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQXdDO1NBQVk7Ozs7O1NBQ2xFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUF3QztTQUFXOzs7OztTQUNqRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBd0Q7U0FBVTs7Ozs7UUFDOUU7Ozs7O2dCQUNDOzs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUNkLFNBQVMsS0FBSyxNQUNiLHdCQUFDLE1BQUQ7U0FBZSxXQUFVO21CQUF6QjtVQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNYLElBQUksS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDLG1CQUFtQixXQUFXO1lBQUUsT0FBTztZQUFTLEtBQUs7V0FBVSxDQUFDO1VBQ2hGOzs7OztVQUNKLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNYLEVBQUUsWUFBWSxRQUFRO1VBQ3JCOzs7OztVQUNKLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUNYLEVBQUUsaUJBQWlCLFFBQVE7VUFDMUI7Ozs7O1VBQ0osd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQWQsQ0FBMkcsS0FDdkcsYUFBYSxFQUFFLE1BQU0sQ0FDckI7Ozs7OztTQUNGO1dBYkssRUFBRTs7OztlQWFQLENBQ0w7T0FDSTs7OztlQUNGOzs7Ozs7S0FDSjs7OzthQUVKOzs7OztZQUNGOzs7OztXQUdMOzs7OztFQUVEOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJSZXBvcnRzUGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZVRyYW5zYWN0aW9ucyB9IGZyb20gXCIuLi9ob29rcy91c2VUcmFuc2FjdGlvbnNcIjtcbmltcG9ydCB7IHVzZU91dGxldENvbnRleHQgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgQmFyQ2hhcnQzLCBUcmVuZGluZ1VwLCBUcmVuZGluZ0Rvd24sIEZpbGVUZXh0LCBXYWxsZXQgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBSZXBvcnRzUGFnZSgpIHtcbiAgY29uc3QgY3VycmVudERhdGUgPSBuZXcgRGF0ZSgpO1xuICBjb25zdCBbc2VsZWN0ZWRZZWFyLCBzZXRTZWxlY3RlZFllYXJdID0gdXNlU3RhdGUoY3VycmVudERhdGUuZ2V0RnVsbFllYXIoKSk7XG4gIGNvbnN0IFtzZWxlY3RlZE1vbnRoLCBzZXRTZWxlY3RlZE1vbnRoXSA9IHVzZVN0YXRlKGN1cnJlbnREYXRlLmdldE1vbnRoKCkgKyAxKTtcbiAgY29uc3QgeyBzaG93QmFsYW5jZXMgfSA9IHVzZU91dGxldENvbnRleHQ8eyBzaG93QmFsYW5jZXM6IGJvb2xlYW4gfT4oKTtcblxuICAvLyBEYXRlIGJvdW5kYXJpZXNcbiAgY29uc3Qgc3RhcnREYXRlID0gYCR7c2VsZWN0ZWRZZWFyfS0ke1N0cmluZyhzZWxlY3RlZE1vbnRoKS5wYWRTdGFydCgyLCBcIjBcIil9LTAxYDtcbiAgY29uc3QgbGFzdERheSA9IG5ldyBEYXRlKHNlbGVjdGVkWWVhciwgc2VsZWN0ZWRNb250aCwgMCkuZ2V0RGF0ZSgpO1xuICBjb25zdCBlbmREYXRlID0gYCR7c2VsZWN0ZWRZZWFyfS0ke1N0cmluZyhzZWxlY3RlZE1vbnRoKS5wYWRTdGFydCgyLCBcIjBcIil9LSR7U3RyaW5nKGxhc3REYXkpLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xuXG4gIC8vIEZldGNoIGFsbCB0cmFuc2FjdGlvbnMgZm9yIHRoZSBzZWxlY3RlZCBtb250aFxuICBjb25zdCB7IHRyYW5zYWN0aW9ucywgaXNMb2FkaW5nIH0gPSB1c2VUcmFuc2FjdGlvbnMoe1xuICAgIHN0YXJ0RGF0ZSxcbiAgICBlbmREYXRlXG4gIH0pO1xuXG4gIC8vIEZpbHRlciB0cmFuc2FjdGlvbnNcbiAgY29uc3QgaW5jb21lcyA9IHRyYW5zYWN0aW9ucy5maWx0ZXIoKHQpID0+IHQudHlwZSA9PT0gXCJJbmNvbWVcIik7XG4gIGNvbnN0IGV4cGVuc2VzID0gdHJhbnNhY3Rpb25zLmZpbHRlcigodCkgPT4gdC50eXBlID09PSBcIkV4cGVuc2VcIik7XG5cbiAgLy8gU3Vtc1xuICBjb25zdCB0b3RhbEluY29tZSA9IGluY29tZXMucmVkdWNlKChzdW0sIHQpID0+IHN1bSArIE51bWJlcih0LmFtb3VudCksIDApO1xuICBjb25zdCB0b3RhbEV4cGVuc2UgPSBleHBlbnNlcy5yZWR1Y2UoKHN1bSwgdCkgPT4gc3VtICsgTnVtYmVyKHQuYW1vdW50KSwgMCk7XG4gIGNvbnN0IG5ldEZsb3cgPSB0b3RhbEluY29tZSAtIHRvdGFsRXhwZW5zZTtcblxuICAvLyBHcm91cCBieSBjYXRlZ29yeSBoZWxwZXJcbiAgY29uc3QgZ3JvdXBCeUNhdGVnb3J5ID0gKHR4TGlzdDogdHlwZW9mIHRyYW5zYWN0aW9ucykgPT4ge1xuICAgIGNvbnN0IGdyb3VwZWQgPSB0eExpc3QucmVkdWNlKChhY2MsIHQpID0+IHtcbiAgICAgIGNvbnN0IGNhdE5hbWUgPSB0LmNhdGVnb3JpZXM/Lm5hbWUgfHwgXCJVbmNhdGVnb3JpemVkXCI7XG4gICAgICBhY2NbY2F0TmFtZV0gPSAoYWNjW2NhdE5hbWVdIHx8IDApICsgTnVtYmVyKHQuYW1vdW50KTtcbiAgICAgIHJldHVybiBhY2M7XG4gICAgfSwge30gYXMgUmVjb3JkPHN0cmluZywgbnVtYmVyPik7XG5cbiAgICByZXR1cm4gT2JqZWN0LmVudHJpZXMoZ3JvdXBlZClcbiAgICAgIC5tYXAoKFtuYW1lLCBhbW91bnRdKSA9PiAoeyBuYW1lLCBhbW91bnQgfSkpXG4gICAgICAuc29ydCgoYSwgYikgPT4gYi5hbW91bnQgLSBhLmFtb3VudCk7XG4gIH07XG5cbiAgY29uc3QgaW5jb21lQ2F0ZWdvcmllcyA9IGdyb3VwQnlDYXRlZ29yeShpbmNvbWVzKTtcbiAgY29uc3QgZXhwZW5zZUNhdGVnb3JpZXMgPSBncm91cEJ5Q2F0ZWdvcnkoZXhwZW5zZXMpO1xuXG4gIGNvbnN0IGZvcm1hdEFtb3VudCA9ICh2YWw6IG51bWJlcikgPT4ge1xuICAgIHJldHVybiBzaG93QmFsYW5jZXMgXG4gICAgICA/IG5ldyBJbnRsLk51bWJlckZvcm1hdChcImlkLUlEXCIsIHsgc3R5bGU6IFwiY3VycmVuY3lcIiwgY3VycmVuY3k6IFwiSURSXCIsIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMCB9KS5mb3JtYXQodmFsKVxuICAgICAgOiBcIlJwIOKAouKAouKAouKAouKAouKAolwiO1xuICB9O1xuXG4gIGNvbnN0IG1vbnRocyA9IFtcbiAgICB7IHZhbHVlOiAxLCBsYWJlbDogXCJKYW51YXJ5XCIgfSxcbiAgICB7IHZhbHVlOiAyLCBsYWJlbDogXCJGZWJydWFyeVwiIH0sXG4gICAgeyB2YWx1ZTogMywgbGFiZWw6IFwiTWFyY2hcIiB9LFxuICAgIHsgdmFsdWU6IDQsIGxhYmVsOiBcIkFwcmlsXCIgfSxcbiAgICB7IHZhbHVlOiA1LCBsYWJlbDogXCJNYXlcIiB9LFxuICAgIHsgdmFsdWU6IDYsIGxhYmVsOiBcIkp1bmVcIiB9LFxuICAgIHsgdmFsdWU6IDcsIGxhYmVsOiBcIkp1bHlcIiB9LFxuICAgIHsgdmFsdWU6IDgsIGxhYmVsOiBcIkF1Z3VzdFwiIH0sXG4gICAgeyB2YWx1ZTogOSwgbGFiZWw6IFwiU2VwdGVtYmVyXCIgfSxcbiAgICB7IHZhbHVlOiAxMCwgbGFiZWw6IFwiT2N0b2JlclwiIH0sXG4gICAgeyB2YWx1ZTogMTEsIGxhYmVsOiBcIk5vdmVtYmVyXCIgfSxcbiAgICB7IHZhbHVlOiAxMiwgbGFiZWw6IFwiRGVjZW1iZXJcIiB9LFxuICBdO1xuXG4gIGNvbnN0IHllYXJzID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogNyB9LCAoXywgaSkgPT4gY3VycmVudERhdGUuZ2V0RnVsbFllYXIoKSAtIDUgKyBpKTtcblxuICBjb25zdCBoYW5kbGVFeHBvcnQgPSAodHlwZTogXCJleGNlbFwiIHwgXCJwZGZcIikgPT4ge1xuICAgIGFsZXJ0KGBFeHBvcnRpbmcgbW9udGhseSByZXBvcnQgYXMgJHt0eXBlLnRvVXBwZXJDYXNlKCl9IGlzIHNjaGVkdWxlZCBmb3IgdGhlIG5leHQgcmVsZWFzZSBwaGFzZS5gKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICB7LyogSGVhZGVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBzbTppdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8QmFyQ2hhcnQzIGNsYXNzTmFtZT1cImgtNiB3LTYgdGV4dC1lbWVyYWxkLTUwMFwiIC8+XG4gICAgICAgICAgICBNb250aGx5IFJlcG9ydHNcbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtemluYy01MDAgZGFyazp0ZXh0LXppbmMtNDAwIG10LTFcIj5cbiAgICAgICAgICAgIEFuYWx5emUgeW91ciBmYW1pbHkgaW5jb21lLCBvdXRjb21lcywgYW5kIGNhdGVnb3J5IGJyZWFrZG93bnMuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMyB3LWZ1bGwgc206dy1hdXRvXCI+XG4gICAgICAgICAgey8qIE1vbnRoIFNlbGVjdCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXgtMSBzbTpmbGV4LWluaXRpYWxcIj5cbiAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTW9udGh9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRNb250aChOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJtb250aC1zZWxlY3RcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYXBwZWFyYW5jZS1ub25lIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMCBiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHB4LTMgcHktMiBwci0xMCB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7bW9udGhzLm1hcCgobSkgPT4gKFxuICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXttLnZhbHVlfSB2YWx1ZT17bS52YWx1ZX0+e20ubGFiZWx9PC9vcHRpb24+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBvaW50ZXItZXZlbnRzLW5vbmUgYWJzb2x1dGUgaW5zZXQteS0wIHJpZ2h0LTAgZmxleCBpdGVtcy1jZW50ZXIgcHgtMyB0ZXh0LXppbmMtNTAwXCI+XG4gICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwiaC00IHctNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cbiAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xOSA5bC03IDctNy03XCI+PC9wYXRoPlxuICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFllYXIgU2VsZWN0ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleC0xIHNtOmZsZXgtaW5pdGlhbFwiPlxuICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRZZWFyfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkWWVhcihOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJ5ZWFyLXNlbGVjdFwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhcHBlYXJhbmNlLW5vbmUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwIGJnLXdoaXRlIGRhcms6YmctemluYy05MDAgcHgtMyBweS0yIHByLTEwIHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHt5ZWFycy5tYXAoKHkpID0+IChcbiAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17eX0gdmFsdWU9e3l9Pnt5fTwvb3B0aW9uPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIGluc2V0LXktMCByaWdodC0wIGZsZXggaXRlbXMtY2VudGVyIHB4LTMgdGV4dC16aW5jLTUwMFwiPlxuICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cImgtNCB3LTRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XG4gICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTkgOWwtNyA3LTctN1wiPjwvcGF0aD5cbiAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBFeHBvcnQgQnV0dG9ucyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTIgdy1mdWxsIHNtOnctYXV0b1wiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVFeHBvcnQoXCJwZGZcIil9XG4gICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwiZXhwb3J0LXBkZi1idXR0b25cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgc206ZmxleC1pbml0aWFsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgcm91bmRlZC1sZyBiZy16aW5jLTEwMCBob3ZlcjpiZy16aW5jLTIwMCBkYXJrOmJnLXppbmMtODAwIGRhcms6aG92ZXI6YmctemluYy03MDAvODAgcHgtMy41IHB5LTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtemluYy03MDAgZGFyazp0ZXh0LXppbmMtMzAwIGJvcmRlciBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy03MDAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8RmlsZVRleHQgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LXJlZC02NTAgZGFyazp0ZXh0LXJlZC01MDBcIiAvPiBFeHBvcnQgUERGXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFN1bW1hcnkgQ2FyZHMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHAtNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwIHNoYWRvdy1zbSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtNTAwLzEwIHAtMyByb3VuZGVkLXhsIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICA8VHJlbmRpbmdVcCBjbGFzc05hbWU9XCJoLTYgdy02XCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+VG90YWwgSW5jb21lPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIG10LTFcIj57Zm9ybWF0QW1vdW50KHRvdGFsSW5jb21lKX08L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHAtNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwIHNoYWRvdy1zbSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcm9zZS01MCBkYXJrOmJnLXJvc2UtNTAwLzEwIHAtMyByb3VuZGVkLXhsIHRleHQtcm9zZS02MDAgZGFyazp0ZXh0LXJvc2UtNDAwXCI+XG4gICAgICAgICAgICA8VHJlbmRpbmdEb3duIGNsYXNzTmFtZT1cImgtNiB3LTZcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtemluYy01MDAgZGFyazp0ZXh0LXppbmMtNDAwIHRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5Ub3RhbCBPdXRjb21lPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtcmVkLTUwMCBtdC0xXCI+e2Zvcm1hdEFtb3VudCh0b3RhbEV4cGVuc2UpfTwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctemluYy05MDAgcC01IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAgc2hhZG93LXNtIGZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BwLTMgcm91bmRlZC14bCAke25ldEZsb3cgPj0gMCA/IFwiYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtNTAwLzEwIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCIgOiBcImJnLXJvc2UtNTAgZGFyazpiZy1yb3NlLTUwMC8xMCB0ZXh0LXJvc2UtNjAwIGRhcms6dGV4dC1yb3NlLTQwMFwifWB9PlxuICAgICAgICAgICAgPFdhbGxldCBjbGFzc05hbWU9XCJoLTYgdy02XCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+TmV0IENhc2ggRmxvdzwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B0ZXh0LXhsIGZvbnQtYm9sZCBtdC0xICR7bmV0RmxvdyA+PSAwID8gXCJ0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiIDogXCJ0ZXh0LXJlZC01MDBcIn1gfT5cbiAgICAgICAgICAgICAge2Zvcm1hdEFtb3VudChuZXRGbG93KX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7aXNMb2FkaW5nID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC02NCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC16aW5jLTUwMFwiPkxvYWRpbmcgbW9udGhseSByZXBvcnQuLi48L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgIDw+XG4gICAgICAgICAgey8qIFZpc3VhbCBCcmVha2Rvd24gR3JpZCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTIgZ2FwLTZcIj5cbiAgICAgICAgICAgIHsvKiBJbmNvbWUgYnkgQ2F0ZWdvcnkgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctemluYy05MDAgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMCByb3VuZGVkLTJ4bCBwLTYgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZSBtYi00XCI+SW5jb21lIGJ5IENhdGVnb3J5PC9oMz5cbiAgICAgICAgICAgICAge2luY29tZUNhdGVnb3JpZXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00MDAgaXRhbGljXCI+Tm8gaW5jb21lIGxvZ2dlZCBpbiB0aGlzIG1vbnRoLjwvcD5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAge2luY29tZUNhdGVnb3JpZXMubWFwKChjKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHBlcmNlbnRhZ2UgPSB0b3RhbEluY29tZSA+IDAgPyAoYy5hbW91bnQgLyB0b3RhbEluY29tZSkgKiAxMDAgOiAwO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtjLm5hbWV9IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtNzAwIGRhcms6dGV4dC16aW5jLTMwMFwiPntjLm5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRBbW91bnQoYy5hbW91bnQpfSAoe3BlcmNlbnRhZ2UudG9GaXhlZCgwKX0lKVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXppbmMtMTAwIGRhcms6YmctemluYy04MDAgaC0yIHJvdW5kZWQtZnVsbCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLWZ1bGwgYmctZW1lcmFsZC01MDAgcm91bmRlZC1mdWxsXCIgc3R5bGU9e3sgd2lkdGg6IGAke3BlcmNlbnRhZ2V9JWAgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIE91dGNvbWUgYnkgQ2F0ZWdvcnkgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctemluYy05MDAgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMCByb3VuZGVkLTJ4bCBwLTYgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZSBtYi00XCI+T3V0Y29tZSBieSBDYXRlZ29yeTwvaDM+XG4gICAgICAgICAgICAgIHtleHBlbnNlQ2F0ZWdvcmllcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMCBpdGFsaWNcIj5ObyBvdXRjb21lIGxvZ2dlZCBpbiB0aGlzIG1vbnRoLjwvcD5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAge2V4cGVuc2VDYXRlZ29yaWVzLm1hcCgoYykgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwZXJjZW50YWdlID0gdG90YWxFeHBlbnNlID4gMCA/IChjLmFtb3VudCAvIHRvdGFsRXhwZW5zZSkgKiAxMDAgOiAwO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtjLm5hbWV9IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtNzAwIGRhcms6dGV4dC16aW5jLTMwMFwiPntjLm5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRBbW91bnQoYy5hbW91bnQpfSAoe3BlcmNlbnRhZ2UudG9GaXhlZCgwKX0lKVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXppbmMtMTAwIGRhcms6YmctemluYy04MDAgaC0yIHJvdW5kZWQtZnVsbCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLWZ1bGwgYmctcm9zZS01MDAgcm91bmRlZC1mdWxsXCIgc3R5bGU9e3sgd2lkdGg6IGAke3BlcmNlbnRhZ2V9JWAgfX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBUcmFuc2FjdGlvbnMgVGFibGVzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMiBnYXAtNlwiPlxuICAgICAgICAgICAgey8qIEluY29tZSBUcmFuc2FjdGlvbnMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctemluYy05MDAgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMCByb3VuZGVkLTJ4bCBwLTYgc2hhZG93LXNtIG92ZXJmbG93LWhpZGRlbiBmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZSBtYi00XCI+SW5jb21lIFRyYW5zYWN0aW9uczwvaDM+XG4gICAgICAgICAgICAgIHtpbmNvbWVzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtemluYy01MDAgZGFyazp0ZXh0LXppbmMtNDAwIGl0YWxpY1wiPk5vIGluY29tZSB0cmFuc2FjdGlvbnMgaW4gdGhpcyBwZXJpb2QuPC9wPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIC1teC02IG1heC1oLTk2IG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgYm9yZGVyLWNvbGxhcHNlXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXppbmMtMjUwIGRhcms6Ym9yZGVyLXppbmMtODAwIGJnLXppbmMtNTAvNTAgZGFyazpiZy16aW5jLTkwMC81MCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTUwMCB1cHBlcmNhc2Ugc3RpY2t5IHRvcC0wIGJhY2tkcm9wLWJsdXIgei0xMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtNCBwbC02IGJnLXppbmMtNTAvOTAgZGFyazpiZy16aW5jLTkwMC85MFwiPkRhdGU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtNCBiZy16aW5jLTUwLzkwIGRhcms6YmctemluYy05MDAvOTBcIj5DYXRlZ29yeTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IGJnLXppbmMtNTAvOTAgZGFyazpiZy16aW5jLTkwMC85MFwiPkFjY291bnQ8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXJpZ2h0IHByLTYgYmctemluYy01MC85MCBkYXJrOmJnLXppbmMtOTAwLzkwXCI+QW1vdW50PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXppbmMtMTAwIGRhcms6ZGl2aWRlLXppbmMtODAwLzgwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2luY29tZXMubWFwKCh0KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXt0LmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy16aW5jLTUwLzUwIGRhcms6aG92ZXI6YmctemluYy04MDAvMTAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNCBwbC02IHRleHQteHMgdGV4dC16aW5jLTUwMCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZSh0LmRhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZyh1bmRlZmluZWQsIHsgbW9udGg6IFwic2hvcnRcIiwgZGF5OiBcIm51bWVyaWNcIiB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3QuY2F0ZWdvcmllcz8ubmFtZSB8fCBcIlVuY2F0ZWdvcml6ZWRcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXhzIHRleHQtemluYy01MDUgZGFyazp0ZXh0LXppbmMtNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3QuZGVzdGluYXRpb25fYWNjb3VudHM/Lm5hbWUgfHwgXCItXCJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTQgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIHRleHQtcmlnaHQgcHItNiB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICt7Zm9ybWF0QW1vdW50KHQuYW1vdW50KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBPdXRjb21lIFRyYW5zYWN0aW9ucyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwIHJvdW5kZWQtMnhsIHAtNiBzaGFkb3ctc20gb3ZlcmZsb3ctaGlkZGVuIGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIG1iLTRcIj5PdXRjb21lIFRyYW5zYWN0aW9uczwvaDM+XG4gICAgICAgICAgICAgIHtleHBlbnNlcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMCBpdGFsaWNcIj5ObyBvdXRjb21lIHRyYW5zYWN0aW9ucyBpbiB0aGlzIHBlcmlvZC48L3A+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gLW14LTYgbWF4LWgtOTYgb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCBib3JkZXItY29sbGFwc2VcIj5cbiAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItemluYy0yNTAgZGFyazpib3JkZXItemluYy04MDAgYmctemluYy01MC81MCBkYXJrOmJnLXppbmMtOTAwLzUwIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXppbmMtNTAwIHVwcGVyY2FzZSBzdGlja3kgdG9wLTAgYmFja2Ryb3AtYmx1ciB6LTEwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IHBsLTYgYmctemluYy01MC85MCBkYXJrOmJnLXppbmMtOTAwLzkwXCI+RGF0ZTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IGJnLXppbmMtNTAvOTAgZGFyazpiZy16aW5jLTkwMC85MFwiPkNhdGVnb3J5PC90aD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTQgYmctemluYy01MC85MCBkYXJrOmJnLXppbmMtOTAwLzkwXCI+QWNjb3VudDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IHRleHQtcmlnaHQgcHItNiBiZy16aW5jLTUwLzkwIGRhcms6YmctemluYy05MDAvOTBcIj5BbW91bnQ8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtemluYy0xMDAgZGFyazpkaXZpZGUtemluYy04MDAvODBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZXhwZW5zZXMubWFwKCh0KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXt0LmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy16aW5jLTUwLzUwIGRhcms6aG92ZXI6YmctemluYy04MDAvMTAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNCBwbC02IHRleHQteHMgdGV4dC16aW5jLTUwMCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZSh0LmRhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZyh1bmRlZmluZWQsIHsgbW9udGg6IFwic2hvcnRcIiwgZGF5OiBcIm51bWVyaWNcIiB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3QuY2F0ZWdvcmllcz8ubmFtZSB8fCBcIlVuY2F0ZWdvcml6ZWRcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXhzIHRleHQtemluYy01MDUgZGFyazp0ZXh0LXppbmMtNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Quc291cmNlX2FjY291bnRzPy5uYW1lIHx8IFwiLVwifVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC00IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC00MDAgdGV4dC1yaWdodCBwci02IHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLXtmb3JtYXRBbW91bnQodC5hbW91bnQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuXG4gICAgICAgIDwvPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==