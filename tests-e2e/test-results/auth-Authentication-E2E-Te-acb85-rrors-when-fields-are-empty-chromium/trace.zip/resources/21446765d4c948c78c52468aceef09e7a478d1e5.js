import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-B-1-B7_t.js?v=5f46ca65";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=513be775";
//#region node_modules/react-hook-form/dist/index.esm.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var isCheckBoxInput = (element) => element.type === "checkbox";
var isDateObject = (value) => value instanceof Date;
var isNullOrUndefined = (value) => value == null;
var isObjectType = (value) => typeof value === "object";
var isObject = (value) => !isNullOrUndefined(value) && !Array.isArray(value) && isObjectType(value) && !isDateObject(value);
var getEventValue = (event) => isObject(event) && event.target ? isCheckBoxInput(event.target) ? event.target.checked : event.target.value : event;
var isNameInFieldArray = (names, name) => name.split(".").some((part, index, arr) => !isNaN(Number(part)) && names.has(arr.slice(0, index).join(".")));
var isPlainObject = (tempObject) => {
	const prototypeCopy = tempObject.constructor && tempObject.constructor.prototype;
	return isObject(prototypeCopy) && prototypeCopy.hasOwnProperty("isPrototypeOf");
};
var isWeb = typeof window !== "undefined" && typeof window.HTMLElement !== "undefined" && typeof document !== "undefined";
function cloneObject(data) {
	if (data instanceof Date) return new Date(data);
	const isFileListInstance = typeof FileList !== "undefined" && data instanceof FileList;
	if (isWeb && (data instanceof Blob || isFileListInstance)) return data;
	const isArray = Array.isArray(data);
	if (!isArray && !(isObject(data) && isPlainObject(data))) return data;
	const copy = isArray ? [] : Object.create(Object.getPrototypeOf(data));
	for (const key in data) if (Object.prototype.hasOwnProperty.call(data, key)) copy[key] = cloneObject(data[key]);
	return copy;
}
var EVENTS = {
	BLUR: "blur",
	FOCUS_OUT: "focusout",
	CHANGE: "change",
	SUBMIT: "submit",
	TRIGGER: "trigger",
	VALID: "valid"
};
var VALIDATION_MODE = {
	onBlur: "onBlur",
	onChange: "onChange",
	onSubmit: "onSubmit",
	onTouched: "onTouched",
	all: "all"
};
var INPUT_VALIDATION_RULES = {
	max: "max",
	min: "min",
	maxLength: "maxLength",
	minLength: "minLength",
	pattern: "pattern",
	required: "required",
	validate: "validate"
};
var ROOT_ERROR_TYPE = "root";
var PROTOTYPE_KEYWORDS = [
	"__proto__",
	"constructor",
	"prototype"
];
var IS_KEY_RE = /^\w*$/;
var isKey = (value) => IS_KEY_RE.test(value);
var isUndefined = (val) => val === void 0;
var FIELD_PATH_RE = /[.[\]'"]/;
var stringToPath = (input) => input.split(FIELD_PATH_RE).filter(Boolean);
var get = (object, path, defaultValue) => {
	if (!path || !isObject(object)) return defaultValue;
	const paths = isKey(path) ? [path] : stringToPath(path);
	if (paths.some((key) => PROTOTYPE_KEYWORDS.includes(key))) return defaultValue;
	const result = paths.reduce((result, key) => {
		return isNullOrUndefined(result) ? void 0 : result[key];
	}, object);
	return isUndefined(result) || result === object ? isUndefined(object[path]) ? defaultValue : object[path] : result;
};
var isBoolean = (value) => typeof value === "boolean";
var isFunction = (value) => typeof value === "function";
var set = (object, path, value) => {
	let index = -1;
	const tempPath = isKey(path) ? [path] : stringToPath(path);
	const length = tempPath.length;
	const lastIndex = length - 1;
	while (++index < length) {
		const key = tempPath[index];
		let newValue = value;
		if (index !== lastIndex) {
			const objValue = object[key];
			newValue = isObject(objValue) || Array.isArray(objValue) ? objValue : !isNaN(+tempPath[index + 1]) ? [] : {};
		}
		if (PROTOTYPE_KEYWORDS.includes(key)) return;
		object[key] = newValue;
		object = object[key];
	}
};
/**
* Separate context for `control` to prevent unnecessary rerenders.
* Internal hooks that only need control use this instead of full form context.
*/
var HookFormControlContext = import_react.createContext(null);
HookFormControlContext.displayName = "HookFormControlContext";
/**
* @internal Internal hook to access only control from context.
*/
var useFormControlContext = () => import_react.useContext(HookFormControlContext);
var getProxyFormState = (formState, control, localProxyFormState, isRoot = true) => {
	const result = {};
	for (const key in formState) Object.defineProperty(result, key, { get: () => {
		const _key = key;
		if (control._proxyFormState[_key] !== VALIDATION_MODE.all) control._proxyFormState[_key] = !isRoot || VALIDATION_MODE.all;
		localProxyFormState && (localProxyFormState[_key] = true);
		return formState[_key];
	} });
	return result;
};
var useIsomorphicLayoutEffect = isWeb ? import_react.useLayoutEffect : import_react.useEffect;
/**
* This custom hook allows you to subscribe to each form state, and isolate the re-render at the custom hook level. It has its scope in terms of form state subscription, so it would not affect other useFormState and useForm. Using this hook can reduce the re-render impact on large and complex form application.
*
* @remarks
* [API](https://react-hook-form.com/docs/useformstate) • [Demo](https://codesandbox.io/s/useformstate-75xly)
*
* @param props - include options on specify fields to subscribe. {@link UseFormStateReturn}
*
* @example
* ```tsx
* function App() {
*   const { register, handleSubmit, control } = useForm({
*     defaultValues: {
*     firstName: "firstName"
*   }});
*   const { dirtyFields } = useFormState({
*     control
*   });
*   const onSubmit = (data) => console.log(data);
*
*   return (
*     <form onSubmit={handleSubmit(onSubmit)}>
*       <input {...register("firstName")} placeholder="First Name" />
*       {dirtyFields.firstName && <p>Field is dirty.</p>}
*       <input type="submit" />
*     </form>
*   );
* }
* ```
*/
function useFormState(props) {
	const formControl = useFormControlContext();
	const { control = formControl, disabled, name, exact } = props || {};
	const [formState, updateFormState] = import_react.useState(() => ({
		...control._formState,
		defaultValues: control._defaultValues
	}));
	const _localProxyFormState = import_react.useRef({
		isDirty: false,
		isLoading: false,
		dirtyFields: false,
		touchedFields: false,
		validatingFields: false,
		isValidating: false,
		isValid: false,
		errors: false
	});
	useIsomorphicLayoutEffect(() => control._subscribe({
		name,
		formState: _localProxyFormState.current,
		exact,
		callback: (formState) => {
			!disabled && updateFormState({
				...control._formState,
				...formState,
				defaultValues: control._defaultValues
			});
		}
	}), [
		name,
		disabled,
		exact
	]);
	import_react.useEffect(() => {
		_localProxyFormState.current.isValid && control._setValid(true);
	}, [control]);
	return import_react.useMemo(() => getProxyFormState(formState, control, _localProxyFormState.current, false), [formState, control]);
}
var isString = (value) => typeof value === "string";
var generateWatchOutput = (names, _names, formValues, isGlobal, defaultValue) => {
	if (isString(names)) {
		isGlobal && _names.watch.add(names);
		return get(formValues, names, defaultValue);
	}
	if (Array.isArray(names)) return names.map((fieldName) => (isGlobal && _names.watch.add(fieldName), get(formValues, fieldName)));
	isGlobal && (_names.watchAll = true);
	return formValues;
};
var isPrimitive = (value) => isNullOrUndefined(value) || !isObjectType(value);
var isEmptyObjectWithCustomPrototype = (object, keys) => keys.length === 0 && !Array.isArray(object) && !isPlainObject(object);
function deepEqual(object1, object2, visited = /* @__PURE__ */ new WeakMap()) {
	if (object1 === object2) return true;
	if (isPrimitive(object1) || isPrimitive(object2)) return Object.is(object1, object2);
	if (isDateObject(object1) && isDateObject(object2)) return Object.is(object1.getTime(), object2.getTime());
	const keys1 = Object.keys(object1);
	const keys2 = Object.keys(object2);
	if (keys1.length !== keys2.length) return false;
	if (isEmptyObjectWithCustomPrototype(object1, keys1) || isEmptyObjectWithCustomPrototype(object2, keys2)) return Object.is(object1, object2);
	if (!keys1.length && Array.isArray(object1) !== Array.isArray(object2)) return false;
	const visitedPairs = visited.get(object1);
	if (visitedPairs && visitedPairs.has(object2)) return true;
	if (visitedPairs) visitedPairs.add(object2);
	else {
		const ws = /* @__PURE__ */ new WeakSet();
		ws.add(object2);
		visited.set(object1, ws);
	}
	for (const key of keys1) {
		const val1 = object1[key];
		if (!(key in object2)) return false;
		if (key !== "ref") {
			const val2 = object2[key];
			if (isDateObject(val1) && isDateObject(val2) || (isObject(val1) || Array.isArray(val1)) && (isObject(val2) || Array.isArray(val2)) ? !deepEqual(val1, val2, visited) : !Object.is(val1, val2)) return false;
		}
	}
	return true;
}
/**
* Custom hook to subscribe to field change and isolate re-rendering at the component level.
*
* @remarks
*
* [API](https://react-hook-form.com/docs/usewatch) • [Demo](https://codesandbox.io/s/react-hook-form-v7-ts-usewatch-h9i5e)
*
* @example
* ```tsx
* const { control } = useForm();
* const values = useWatch({
*   name: "fieldName"
*   control,
* })
* ```
*/
function useWatch(props) {
	const formControl = useFormControlContext();
	const { control = formControl, name, defaultValue, disabled, exact, compute } = props || {};
	const _defaultValue = import_react.useRef(defaultValue);
	const _compute = import_react.useRef(compute);
	const _computeFormValues = import_react.useRef(void 0);
	const _prevControl = import_react.useRef(control);
	const _prevName = import_react.useRef(name);
	_compute.current = compute;
	const [value, updateValue] = import_react.useState(() => {
		const defaultValue = control._getWatch(name, _defaultValue.current);
		return _compute.current ? _compute.current(defaultValue) : defaultValue;
	});
	const getCurrentOutput = import_react.useCallback((values) => {
		const formValues = generateWatchOutput(name, control._names, values || control._formValues, false, _defaultValue.current);
		return _compute.current ? _compute.current(formValues) : formValues;
	}, [
		control._formValues,
		control._names,
		name
	]);
	const refreshValue = import_react.useCallback((values) => {
		if (!disabled) {
			const formValues = generateWatchOutput(name, control._names, values || control._formValues, false, _defaultValue.current);
			if (_compute.current) {
				const computedFormValues = _compute.current(formValues);
				if (!deepEqual(computedFormValues, _computeFormValues.current)) {
					updateValue(computedFormValues);
					_computeFormValues.current = computedFormValues;
				}
			} else updateValue(formValues);
		}
	}, [
		control._formValues,
		control._names,
		disabled,
		name
	]);
	useIsomorphicLayoutEffect(() => {
		if (_prevControl.current !== control || !deepEqual(_prevName.current, name)) {
			_prevControl.current = control;
			_prevName.current = name;
			refreshValue();
		}
		return control._subscribe({
			name,
			formState: { values: true },
			exact,
			callback: (formState) => {
				refreshValue(formState.values);
			}
		});
	}, [
		control,
		exact,
		name,
		refreshValue
	]);
	import_react.useEffect(() => control._removeUnmounted());
	const controlChanged = _prevControl.current !== control;
	const prevName = _prevName.current;
	const computedOutput = import_react.useMemo(() => {
		if (disabled) return null;
		const nameChanged = !controlChanged && !deepEqual(prevName, name);
		return controlChanged || nameChanged ? getCurrentOutput() : null;
	}, [
		disabled,
		controlChanged,
		name,
		prevName,
		getCurrentOutput
	]);
	return computedOutput !== null ? computedOutput : value;
}
/**
* Custom hook to work with controlled component, this function provide you with both form and field level state. Re-render is isolated at the hook level.
*
* @remarks
* [API](https://react-hook-form.com/docs/usecontroller) • [Demo](https://codesandbox.io/s/usecontroller-0o8px)
*
* @param props - the path name to the form field value, and validation rules.
*
* @returns field properties, field and form state. {@link UseControllerReturn}
*
* @example
* ```tsx
* function Input(props) {
*   const { field, fieldState, formState } = useController(props);
*   return (
*     <div>
*       <input {...field} placeholder={props.name} />
*       <p>{fieldState.isTouched && "Touched"}</p>
*       <p>{formState.isSubmitted ? "submitted" : ""}</p>
*     </div>
*   );
* }
* ```
*/
function useController(props) {
	const formControl = useFormControlContext();
	const { name, disabled, control = formControl, shouldUnregister, defaultValue, exact = true } = props;
	const isArrayField = isNameInFieldArray(control._names.array, name);
	const value = useWatch({
		control,
		name,
		defaultValue: import_react.useMemo(() => get(control._formValues, name, get(control._defaultValues, name, defaultValue)), [
			control,
			name,
			defaultValue
		]),
		exact
	});
	const formState = useFormState({
		control,
		name,
		exact
	});
	const _props = import_react.useRef(props);
	const _proxyRef = import_react.useRef(null);
	const _registerProps = import_react.useRef(control.register(name, {
		...props.rules,
		value,
		...isBoolean(props.disabled) ? { disabled: props.disabled } : {}
	}));
	_props.current = props;
	const fieldState = import_react.useMemo(() => Object.defineProperties({}, {
		invalid: {
			enumerable: true,
			get: () => !!get(formState.errors, name)
		},
		isDirty: {
			enumerable: true,
			get: () => !!get(formState.dirtyFields, name)
		},
		isTouched: {
			enumerable: true,
			get: () => !!get(formState.touchedFields, name)
		},
		isValidating: {
			enumerable: true,
			get: () => !!get(formState.validatingFields, name)
		},
		error: {
			enumerable: true,
			get: () => get(formState.errors, name)
		}
	}), [formState, name]);
	const onChange = import_react.useCallback((event) => {
		const value = getEventValue(event);
		if (!get(control._fields, name)) _registerProps.current = control.register(name, {
			..._props.current.rules,
			value
		});
		return _registerProps.current.onChange({
			target: {
				value: getEventValue(event),
				name
			},
			type: EVENTS.CHANGE
		});
	}, [name, control]);
	const onBlur = import_react.useCallback(() => _registerProps.current.onBlur({
		target: {
			value: get(control._formValues, name),
			name
		},
		type: EVENTS.BLUR
	}), [name, control._formValues]);
	const ref = import_react.useCallback((elm) => {
		if (elm) _proxyRef.current = {
			focus: () => isFunction(elm.focus) && elm.focus(),
			select: () => isFunction(elm.select) && elm.select(),
			setCustomValidity: (message) => isFunction(elm.setCustomValidity) && elm.setCustomValidity(message),
			reportValidity: () => isFunction(elm.reportValidity) && elm.reportValidity()
		};
		const field = get(control._fields, name);
		if (field && field._f && elm) field._f.ref = _proxyRef.current;
	}, [control._fields, name]);
	const field = import_react.useMemo(() => ({
		name,
		value,
		...isBoolean(disabled) || formState.disabled ? { disabled: formState.disabled || disabled } : {},
		onChange,
		onBlur,
		ref
	}), [
		name,
		disabled,
		formState.disabled,
		onChange,
		onBlur,
		ref,
		value
	]);
	import_react.useEffect(() => {
		const _shouldUnregisterField = control._options.shouldUnregister || shouldUnregister;
		control.register(name, {
			..._props.current.rules,
			...isBoolean(_props.current.disabled) ? { disabled: _props.current.disabled } : {}
		});
		const updateMounted = (name, value) => {
			const field = get(control._fields, name);
			if (field && field._f) field._f.mount = value;
		};
		updateMounted(name, true);
		if (_shouldUnregisterField) {
			const value = cloneObject(get(shouldUnregister ? control._defaultValues : control._options.values || control._defaultValues, name, get(control._options.defaultValues, name, _props.current.defaultValue)));
			set(control._defaultValues, name, value);
			if (isUndefined(get(control._formValues, name))) set(control._formValues, name, value);
		}
		!isArrayField && control.register(name);
		if (_proxyRef.current) {
			const field = get(control._fields, name);
			if (field && field._f) field._f.ref = _proxyRef.current;
		}
		return () => {
			(isArrayField ? _shouldUnregisterField && !control._state.action : _shouldUnregisterField) ? control.unregister(name) : updateMounted(name, false);
		};
	}, [
		name,
		control,
		isArrayField,
		shouldUnregister
	]);
	import_react.useEffect(() => {
		control._setDisabledField({
			disabled,
			name
		});
	}, [
		disabled,
		name,
		control
	]);
	return import_react.useMemo(() => ({
		field,
		formState,
		fieldState
	}), [
		field,
		formState,
		fieldState
	]);
}
/**
* Component based on `useController` hook to work with controlled component.
*
* @remarks
* [API](https://react-hook-form.com/docs/usecontroller/controller) • [Demo](https://codesandbox.io/s/react-hook-form-v6-controller-ts-jwyzw) • [Video](https://www.youtube.com/watch?v=N2UNk_UCVyA)
*
* @param props - the path name to the form field value, and validation rules.
*
* @returns provide field handler functions, field and form state.
*
* @example
* ```tsx
* function App() {
*   const { control } = useForm<FormValues>({
*     defaultValues: {
*       test: ""
*     }
*   });
*
*   return (
*     <form>
*       <Controller
*         control={control}
*         name="test"
*         render={({ field: { onChange, onBlur, value, ref }, formState, fieldState }) => (
*           <>
*             <input
*               onChange={onChange} // send value to hook form
*               onBlur={onBlur} // notify when input is touched
*               value={value} // return updated value
*               ref={ref} // set ref for focus management
*             />
*             <p>{formState.isSubmitted ? "submitted" : ""}</p>
*             <p>{fieldState.isTouched ? "touched" : ""}</p>
*           </>
*         )}
*       />
*     </form>
*   );
* }
* ```
*/
var Controller = (props) => props.render(useController(props));
var generateId = () => {
	if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
	const d = typeof performance === "undefined" ? Date.now() : performance.now() * 1e3;
	return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
		const r = (Math.random() * 16 + d) % 16 | 0;
		return (c == "x" ? r : r & 3 | 8).toString(16);
	});
};
var getFocusFieldName = (name, index, options = {}) => options.shouldFocus || isUndefined(options.shouldFocus) ? options.focusName || `${name}.${isUndefined(options.focusIndex) ? index : options.focusIndex}.` : "";
var getValidationModes = (mode) => ({
	isOnSubmit: !mode || mode === VALIDATION_MODE.onSubmit,
	isOnBlur: mode === VALIDATION_MODE.onBlur,
	isOnChange: mode === VALIDATION_MODE.onChange,
	isOnAll: mode === VALIDATION_MODE.all,
	isOnTouch: mode === VALIDATION_MODE.onTouched
});
var isWatched = (name, _names, isBlurEvent) => {
	if (isBlurEvent) return false;
	if (_names.watchAll || _names.watch.has(name)) return true;
	for (const watchName of _names.watch) if (name.startsWith(watchName) && name.charAt(watchName.length) === ".") return true;
	return false;
};
var iterateFieldsByAction = (fields, action, fieldsNames, abortEarly) => {
	for (const key of fieldsNames || Object.keys(fields)) {
		const field = get(fields, key);
		if (field) {
			const { _f, ...currentField } = field;
			if (_f) {
				if (_f.refs && _f.refs[0] && action(_f.refs[0], key) && !abortEarly) return true;
				else if (_f.ref && action(_f.ref, _f.name) && !abortEarly) return true;
				else if (iterateFieldsByAction(currentField, action)) break;
			} else if (isObject(currentField)) {
				if (iterateFieldsByAction(currentField, action)) break;
			}
		}
	}
};
var updateFieldArrayRootError = (errors, error, name) => {
	const existingErrors = get(errors, name);
	const fieldArrayErrors = Array.isArray(existingErrors) ? existingErrors : [];
	set(fieldArrayErrors, ROOT_ERROR_TYPE, error[name]);
	set(errors, name, fieldArrayErrors);
	return errors;
};
var isEmptyObject = (value) => isObject(value) && !Object.keys(value).length;
var isFileInput = (element) => element.type === "file";
var isHTMLElement = (value) => {
	if (!isWeb) return false;
	const owner = value ? value.ownerDocument : 0;
	return value instanceof (owner && owner.defaultView ? owner.defaultView.HTMLElement : HTMLElement);
};
var isRadioInput = (element) => element.type === "radio";
var isRegex = (value) => value instanceof RegExp;
var appendErrors = (name, validateAllFieldCriteria, errors, type, message) => validateAllFieldCriteria ? {
	...errors[name],
	types: {
		...errors[name] && errors[name].types ? errors[name].types : {},
		[type]: message || true
	}
} : {};
var defaultResult = {
	value: false,
	isValid: false
};
var validResult = {
	value: true,
	isValid: true
};
var getCheckboxValue = (options) => {
	if (Array.isArray(options)) {
		if (options.length > 1) {
			const values = options.filter((option) => option && option.checked && !option.disabled).map((option) => option.value);
			return {
				value: values,
				isValid: !!values.length
			};
		}
		return options[0].checked && !options[0].disabled ? options[0].attributes && !isUndefined(options[0].attributes.value) ? isUndefined(options[0].value) || options[0].value === "" ? validResult : {
			value: options[0].value,
			isValid: true
		} : validResult : defaultResult;
	}
	return defaultResult;
};
var defaultReturn = {
	isValid: false,
	value: null
};
var getRadioValue = (options) => Array.isArray(options) ? options.reduce((previous, option) => option && option.checked && !option.disabled ? {
	isValid: true,
	value: option.value
} : previous, defaultReturn) : defaultReturn;
function getValidateError(result, ref, type = "validate") {
	if (isString(result) || Array.isArray(result) && result.every(isString) || isBoolean(result) && !result) return {
		type,
		message: isString(result) ? result : "",
		ref
	};
}
var getValueAndMessage = (validationData) => isObject(validationData) && !isRegex(validationData) ? validationData : {
	value: validationData,
	message: ""
};
var validateField = async (field, disabledFieldNames, formValues, validateAllFieldCriteria, shouldUseNativeValidation, isFieldArray) => {
	const { ref, refs, required, maxLength, minLength, min, max, pattern, validate, name, valueAsNumber, mount } = field._f;
	const inputValue = get(formValues, name);
	if (!mount || disabledFieldNames.has(name)) return {};
	const inputRef = refs ? refs[0] : ref;
	const setCustomValidity = (message) => {
		if (shouldUseNativeValidation && inputRef.reportValidity) {
			const validityMessage = isBoolean(message) ? "" : message || "";
			if (refs) refs.forEach((ref) => ref.setCustomValidity(validityMessage));
			else inputRef.setCustomValidity(validityMessage);
			inputRef.reportValidity();
		}
	};
	const error = {};
	const isRadio = isRadioInput(ref);
	const isCheckBox = isCheckBoxInput(ref);
	const isRadioOrCheckbox = isRadio || isCheckBox;
	const isEmpty = (valueAsNumber || isFileInput(ref)) && isUndefined(ref.value) && isUndefined(inputValue) || isHTMLElement(ref) && ref.value === "" || inputValue === "" || Array.isArray(inputValue) && !inputValue.length;
	const appendErrorsCurry = appendErrors.bind(null, name, validateAllFieldCriteria, error);
	const getMinMaxMessage = (exceedMax, maxLengthMessage, minLengthMessage, maxType = INPUT_VALIDATION_RULES.maxLength, minType = INPUT_VALIDATION_RULES.minLength) => {
		const message = exceedMax ? maxLengthMessage : minLengthMessage;
		error[name] = {
			type: exceedMax ? maxType : minType,
			message,
			ref,
			...appendErrorsCurry(exceedMax ? maxType : minType, message)
		};
	};
	if (isFieldArray ? !Array.isArray(inputValue) || !inputValue.length : required && (!isRadioOrCheckbox && (isEmpty || isNullOrUndefined(inputValue)) || isBoolean(inputValue) && !inputValue || isCheckBox && !getCheckboxValue(refs).isValid || isRadio && !getRadioValue(refs).isValid)) {
		const { value, message } = isString(required) ? {
			value: !!required,
			message: required
		} : getValueAndMessage(required);
		if (value) {
			error[name] = {
				type: INPUT_VALIDATION_RULES.required,
				message,
				ref: inputRef,
				...appendErrorsCurry(INPUT_VALIDATION_RULES.required, message)
			};
			if (!validateAllFieldCriteria) {
				setCustomValidity(message);
				return error;
			}
		}
	}
	if (!isEmpty && (!isNullOrUndefined(min) || !isNullOrUndefined(max))) {
		let exceedMax;
		let exceedMin;
		const maxOutput = getValueAndMessage(max);
		const minOutput = getValueAndMessage(min);
		if (!isNullOrUndefined(inputValue) && !isNaN(inputValue)) {
			const valueNumber = ref.valueAsNumber || (inputValue ? +inputValue : inputValue);
			if (!isNullOrUndefined(maxOutput.value)) exceedMax = valueNumber > maxOutput.value;
			if (!isNullOrUndefined(minOutput.value)) exceedMin = valueNumber < minOutput.value;
		} else {
			const valueDate = ref.valueAsDate || new Date(inputValue);
			const convertTimeToDate = (time) => /* @__PURE__ */ new Date((/* @__PURE__ */ new Date()).toDateString() + " " + time);
			const isTime = ref.type == "time";
			const isWeek = ref.type == "week";
			if (isString(maxOutput.value) && inputValue) exceedMax = isTime ? convertTimeToDate(inputValue) > convertTimeToDate(maxOutput.value) : isWeek ? inputValue > maxOutput.value : valueDate > new Date(maxOutput.value);
			if (isString(minOutput.value) && inputValue) exceedMin = isTime ? convertTimeToDate(inputValue) < convertTimeToDate(minOutput.value) : isWeek ? inputValue < minOutput.value : valueDate < new Date(minOutput.value);
		}
		if (exceedMax || exceedMin) {
			getMinMaxMessage(!!exceedMax, maxOutput.message, minOutput.message, INPUT_VALIDATION_RULES.max, INPUT_VALIDATION_RULES.min);
			if (!validateAllFieldCriteria) {
				setCustomValidity(error[name].message);
				return error;
			}
		}
	}
	if ((maxLength || minLength) && !isEmpty && (isString(inputValue) || isFieldArray && Array.isArray(inputValue))) {
		const maxLengthOutput = getValueAndMessage(maxLength);
		const minLengthOutput = getValueAndMessage(minLength);
		const exceedMax = !isNullOrUndefined(maxLengthOutput.value) && inputValue.length > +maxLengthOutput.value;
		const exceedMin = !isNullOrUndefined(minLengthOutput.value) && inputValue.length < +minLengthOutput.value;
		if (exceedMax || exceedMin) {
			getMinMaxMessage(exceedMax, maxLengthOutput.message, minLengthOutput.message);
			if (!validateAllFieldCriteria) {
				setCustomValidity(error[name].message);
				return error;
			}
		}
	}
	if (pattern && !isEmpty && isString(inputValue)) {
		const { value: patternValue, message } = getValueAndMessage(pattern);
		if (isRegex(patternValue) && !inputValue.match(patternValue)) {
			error[name] = {
				type: INPUT_VALIDATION_RULES.pattern,
				message,
				ref,
				...appendErrorsCurry(INPUT_VALIDATION_RULES.pattern, message)
			};
			if (!validateAllFieldCriteria) {
				setCustomValidity(message);
				return error;
			}
		}
	}
	if (validate) {
		if (isFunction(validate)) {
			const validateError = getValidateError(await validate(inputValue, formValues), inputRef);
			if (validateError) {
				error[name] = {
					...validateError,
					...appendErrorsCurry(INPUT_VALIDATION_RULES.validate, validateError.message)
				};
				if (!validateAllFieldCriteria) {
					setCustomValidity(validateError.message);
					return error;
				}
			}
		} else if (isObject(validate)) {
			let validationResult = {};
			for (const key in validate) {
				if (!isEmptyObject(validationResult) && !validateAllFieldCriteria) break;
				const validateError = getValidateError(await validate[key](inputValue, formValues), inputRef, key);
				if (validateError) {
					validationResult = {
						...validateError,
						...appendErrorsCurry(key, validateError.message)
					};
					setCustomValidity(validateError.message);
					if (validateAllFieldCriteria) error[name] = validationResult;
				}
			}
			if (!isEmptyObject(validationResult)) {
				error[name] = {
					ref: inputRef,
					...validationResult
				};
				if (!validateAllFieldCriteria) return error;
			}
		}
	}
	setCustomValidity(true);
	return error;
};
var convertToArrayPayload = (value) => Array.isArray(value) ? value : [value];
var appendAt = (data, value) => [...data, ...convertToArrayPayload(value)];
var fillEmptyArray = (value) => Array.isArray(value) ? value.map(() => void 0) : void 0;
function insert(data, index, value) {
	return [
		...data.slice(0, index),
		...convertToArrayPayload(value),
		...data.slice(index)
	];
}
var moveArrayAt = (data, from, to) => {
	if (!Array.isArray(data)) return [];
	if (isUndefined(data[to])) data[to] = void 0;
	data.splice(to, 0, data.splice(from, 1)[0]);
	return data;
};
var prependAt = (data, value) => [...convertToArrayPayload(value), ...convertToArrayPayload(data)];
var compact = (value) => Array.isArray(value) ? value.filter(Boolean) : [];
function removeAtIndexes(data, indexes) {
	let i = 0;
	const temp = [...data];
	for (const index of indexes) {
		temp.splice(index - i, 1);
		i++;
	}
	return compact(temp).length ? temp : [];
}
var removeArrayAt = (data, index) => isUndefined(index) ? [] : removeAtIndexes(data, convertToArrayPayload(index).sort((a, b) => a - b));
var swapArrayAt = (data, indexA, indexB) => {
	[data[indexA], data[indexB]] = [data[indexB], data[indexA]];
};
function baseGet(object, updatePath) {
	const length = updatePath.slice(0, -1).length;
	let index = 0;
	while (index < length) {
		if (isNullOrUndefined(object)) {
			object = void 0;
			break;
		}
		object = object[updatePath[index]];
		index++;
	}
	return object;
}
function isEmptyArray(obj) {
	for (const key in obj) if (obj.hasOwnProperty(key) && !isUndefined(obj[key])) return false;
	return true;
}
function unset(object, path) {
	if (isString(path) && Object.prototype.hasOwnProperty.call(object, path)) {
		delete object[path];
		return object;
	}
	const paths = Array.isArray(path) ? path : isKey(path) ? [path] : stringToPath(path);
	if (paths.some((segment) => PROTOTYPE_KEYWORDS.includes(String(segment)))) return object;
	const childObject = paths.length === 1 ? object : baseGet(object, paths);
	const index = paths.length - 1;
	const key = paths[index];
	if (childObject) delete childObject[key];
	if (index !== 0 && (isObject(childObject) && isEmptyObject(childObject) || Array.isArray(childObject) && isEmptyArray(childObject))) unset(object, paths.slice(0, -1));
	return object;
}
var updateAt = (fieldValues, index, value) => {
	fieldValues[index] = value;
	return fieldValues;
};
/**
* A custom hook that exposes convenient methods to perform operations with a list of dynamic inputs that need to be appended, updated, removed etc. • [Demo](https://codesandbox.io/s/react-hook-form-usefieldarray-ssugn) • [Video](https://youtu.be/4MrbfGSFY2A)
*
* @remarks
* [API](https://react-hook-form.com/docs/usefieldarray) • [Demo](https://codesandbox.io/s/react-hook-form-usefieldarray-ssugn)
*
* @param props - useFieldArray props
*
* @returns methods - functions to manipulate with the Field Arrays (dynamic inputs) {@link UseFieldArrayReturn}
*
* @example
* ```tsx
* function App() {
*   const { register, control, handleSubmit, reset, trigger, setError } = useForm({
*     defaultValues: {
*       test: []
*     }
*   });
*   const { fields, append } = useFieldArray({
*     control,
*     name: "test"
*   });
*
*   return (
*     <form onSubmit={handleSubmit(data => console.log(data))}>
*       {fields.map((item, index) => (
*          <input key={item.id} {...register(`test.${index}.firstName`)}  />
*       ))}
*       <button type="button" onClick={() => append({ firstName: "bill" })}>
*         append
*       </button>
*       <input type="submit" />
*     </form>
*   );
* }
* ```
*/
function useFieldArray(props) {
	const formControl = useFormControlContext();
	const { control = formControl, name, keyName = "id", disabled, shouldUnregister, rules } = props;
	const [fields, setFields] = import_react.useState(control._getFieldArray(name));
	const ids = import_react.useRef(control._getFieldArray(name).map(generateId));
	const _actioned = import_react.useRef(false);
	if (!disabled) control._names.array.add(name);
	import_react.useMemo(() => !disabled && rules && fields.length >= 0 && control.register(name, rules), [
		control,
		name,
		fields.length,
		rules,
		disabled
	]);
	useIsomorphicLayoutEffect(() => {
		if (disabled) return;
		return control._subjects.array.subscribe({ next: ({ values, name: fieldArrayName }) => {
			if (fieldArrayName === name || !fieldArrayName) {
				const fieldValues = get(values, name);
				if (Array.isArray(fieldValues)) {
					setFields(fieldValues);
					ids.current = fieldValues.map(generateId);
				} else if (!fieldArrayName) {
					setFields([]);
					ids.current = [];
				}
			}
		} }).unsubscribe;
	}, [
		control,
		name,
		disabled
	]);
	const updateValues = import_react.useCallback((updatedFieldArrayValues) => {
		_actioned.current = true;
		control._setFieldArray(name, updatedFieldArrayValues);
	}, [control, name]);
	const append = (value, options) => {
		if (disabled) return;
		const appendValue = convertToArrayPayload(cloneObject(value));
		const updatedFieldArrayValues = appendAt(control._getFieldArray(name), appendValue);
		control._names.focus = getFocusFieldName(name, updatedFieldArrayValues.length - 1, options);
		ids.current = appendAt(ids.current, appendValue.map(generateId));
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, appendAt, { argA: fillEmptyArray(value) });
	};
	const prepend = (value, options) => {
		if (disabled) return;
		const prependValue = convertToArrayPayload(cloneObject(value));
		const updatedFieldArrayValues = prependAt(control._getFieldArray(name), prependValue);
		control._names.focus = getFocusFieldName(name, 0, options);
		ids.current = prependAt(ids.current, prependValue.map(generateId));
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, prependAt, { argA: fillEmptyArray(value) });
	};
	const remove = (index) => {
		if (disabled) return;
		const updatedFieldArrayValues = removeArrayAt(control._getFieldArray(name), index);
		ids.current = removeArrayAt(ids.current, index);
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		!Array.isArray(get(control._fields, name)) && set(control._fields, name, void 0);
		control._setFieldArray(name, updatedFieldArrayValues, removeArrayAt, { argA: index });
	};
	const insert$1 = (index, value, options) => {
		if (disabled) return;
		const insertValue = convertToArrayPayload(cloneObject(value));
		const updatedFieldArrayValues = insert(control._getFieldArray(name), index, insertValue);
		control._names.focus = getFocusFieldName(name, index, options);
		ids.current = insert(ids.current, index, insertValue.map(generateId));
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, insert, {
			argA: index,
			argB: fillEmptyArray(value)
		});
	};
	const swap = (indexA, indexB) => {
		if (disabled) return;
		const updatedFieldArrayValues = control._getFieldArray(name);
		swapArrayAt(updatedFieldArrayValues, indexA, indexB);
		swapArrayAt(ids.current, indexA, indexB);
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, swapArrayAt, {
			argA: indexA,
			argB: indexB
		}, false);
	};
	const move = (from, to) => {
		if (disabled) return;
		const updatedFieldArrayValues = control._getFieldArray(name);
		moveArrayAt(updatedFieldArrayValues, from, to);
		moveArrayAt(ids.current, from, to);
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, moveArrayAt, {
			argA: from,
			argB: to
		}, false);
	};
	const update = (index, value) => {
		if (disabled) return;
		const updateValue = cloneObject(value);
		const updatedFieldArrayValues = updateAt(control._getFieldArray(name), index, updateValue);
		ids.current = [...updatedFieldArrayValues].map((item, i) => !item || i === index ? generateId() : ids.current[i]);
		updateValues(updatedFieldArrayValues);
		setFields([...updatedFieldArrayValues]);
		control._setFieldArray(name, updatedFieldArrayValues, updateAt, {
			argA: index,
			argB: updateValue
		}, true, false);
	};
	const replace = (value) => {
		if (disabled) return;
		const updatedFieldArrayValues = convertToArrayPayload(cloneObject(value));
		ids.current = updatedFieldArrayValues.map(generateId);
		updateValues([...updatedFieldArrayValues]);
		setFields([...updatedFieldArrayValues]);
		control._setFieldArray(name, [...updatedFieldArrayValues], (data) => data, {}, true, false);
	};
	import_react.useEffect(() => {
		if (disabled) return;
		control._state.action = false;
		isWatched(name, control._names) && control._subjects.state.next({ ...control._formState });
		const validationModes = getValidationModes(control._options.mode);
		if (_actioned.current && (!validationModes.isOnSubmit || control._formState.isSubmitted) && !getValidationModes(control._options.reValidateMode).isOnSubmit && !validationModes.isOnBlur) if (control._options.resolver) control._runSchema([name]).then((result) => {
			var _a, _b;
			control._updateIsValidating([name]);
			const error = get(result.errors, name);
			const existingError = get(control._formState.errors, name);
			const existingErrorType = existingError && (existingError.type || ((_a = existingError.root) === null || _a === void 0 ? void 0 : _a.type));
			const existingErrorMessage = existingError && (existingError.message || ((_b = existingError.root) === null || _b === void 0 ? void 0 : _b.message));
			if (existingError ? !error && existingErrorType || error && (existingErrorType !== error.type || existingErrorMessage !== error.message) : error && error.type) {
				if (error) isObject(error) && !Object.keys(error).some((key) => !Number.isNaN(+key)) ? updateFieldArrayRootError(control._formState.errors, { [name]: error }, name) : set(control._formState.errors, name, error);
				else unset(control._formState.errors, name);
				control._subjects.state.next({ errors: control._formState.errors });
			}
		});
		else {
			const field = get(control._fields, name);
			if (field && field._f && !(getValidationModes(control._options.reValidateMode).isOnSubmit && getValidationModes(control._options.mode).isOnSubmit)) validateField(field, control._names.disabled, control._formValues, control._options.criteriaMode === VALIDATION_MODE.all, control._options.shouldUseNativeValidation, true).then((error) => !isEmptyObject(error) && control._subjects.state.next({ errors: updateFieldArrayRootError(control._formState.errors, error, name) }));
		}
		_actioned.current && control._subjects.state.next({
			name,
			values: cloneObject(control._formValues)
		});
		control._names.focus && iterateFieldsByAction(control._fields, (ref, key) => {
			if (control._names.focus && key.startsWith(control._names.focus) && ref.focus) {
				ref.focus();
				return 1;
			}
		});
		control._names.focus = "";
		control._setValid();
		_actioned.current = false;
	}, [
		fields,
		name,
		control,
		disabled
	]);
	import_react.useEffect(() => {
		if (!disabled) !get(control._formValues, name) && control._setFieldArray(name);
		return () => {
			if (disabled) return;
			const shouldKeepFieldArrayValues = !(control._options.shouldUnregister || shouldUnregister);
			const updateMounted = (name, value) => {
				const field = get(control._fields, name);
				if (field && field._f) field._f.mount = value;
			};
			if (_actioned.current && shouldKeepFieldArrayValues) control._subjects.state.next({
				name,
				values: cloneObject(control._formValues)
			});
			shouldKeepFieldArrayValues ? updateMounted(name, false) : control.unregister(name);
		};
	}, [
		name,
		control,
		keyName,
		shouldUnregister,
		disabled
	]);
	return {
		swap: import_react.useCallback(swap, [
			updateValues,
			name,
			control,
			disabled
		]),
		move: import_react.useCallback(move, [
			updateValues,
			name,
			control,
			disabled
		]),
		prepend: import_react.useCallback(prepend, [
			updateValues,
			name,
			control,
			disabled
		]),
		append: import_react.useCallback(append, [
			updateValues,
			name,
			control,
			disabled
		]),
		remove: import_react.useCallback(remove, [
			updateValues,
			name,
			control,
			disabled
		]),
		insert: import_react.useCallback(insert$1, [
			updateValues,
			name,
			control,
			disabled
		]),
		update: import_react.useCallback(update, [
			updateValues,
			name,
			control,
			disabled
		]),
		replace: import_react.useCallback(replace, [
			updateValues,
			name,
			control,
			disabled
		]),
		fields: import_react.useMemo(() => fields.map((field, index) => ({
			...field,
			...isBoolean(disabled) ? { disabled } : {},
			[keyName]: ids.current[index] || generateId()
		})), [
			fields,
			keyName,
			disabled
		])
	};
}
/**
* Component based on `useFieldArray` hook to work with controlled component.
*
* @example
* ```tsx
* function App() {
*   const { control, register } = useForm<FormValues>({
*     defaultValues: {
*       test: [
*         {
*           value: '',
*         },
*       ],
*     },
*   });
*
*   return (
*     <form>
*       <FieldArray
*         control={control}
*         name="test"
*         render={({ fields }) =>
*           fields.map((field, index) => (
*             <input key={field.id} {...register(`test.${index}.value`)} />
*           ))
*         }
*       />
*     </form>
*   );
* }
* ```
*/
var FieldArray = (props) => props.render(useFieldArray(props));
var flatten = (obj) => {
	const output = {};
	for (const key of Object.keys(obj)) if (isObjectType(obj[key]) && obj[key] !== null && !isDateObject(obj[key])) {
		const nested = flatten(obj[key]);
		for (const nestedKey of Object.keys(nested)) output[`${key}.${nestedKey}`] = nested[nestedKey];
	} else output[key] = obj[key];
	return output;
};
var HookFormContext = import_react.createContext(null);
HookFormContext.displayName = "HookFormContext";
/**
* This custom hook allows you to access the form context. useFormContext is intended to be used in deeply nested structures, where it would become inconvenient to pass the context as a prop. To be used with {@link FormProvider}.
*
* @remarks
* [API](https://react-hook-form.com/docs/useformcontext) • [Demo](https://codesandbox.io/s/react-hook-form-v7-form-context-ytudi)
*
* @returns return all useForm methods
*
* @example
* ```tsx
* function App() {
*   const methods = useForm();
*   const onSubmit = data => console.log(data);
*
*   return (
*     <FormProvider {...methods} >
*       <form onSubmit={methods.handleSubmit(onSubmit)}>
*         <NestedInput />
*         <input type="submit" />
*       </form>
*     </FormProvider>
*   );
* }
*
*  function NestedInput() {
*   const { register } = useFormContext(); // retrieve all hook methods
*   return <input {...register("test")} />;
* }
* ```
*/
var useFormContext = () => import_react.useContext(HookFormContext);
/**
* A provider component that propagates the `useForm` methods to all children components via [React Context](https://react.dev/reference/react/useContext) API. To be used with {@link useFormContext}.
*
* @remarks
* [API](https://react-hook-form.com/docs/useformcontext) • [Demo](https://codesandbox.io/s/react-hook-form-v7-form-context-ytudi)
*
* @param props - all useForm methods
*
* @example
* ```tsx
* function App() {
*   const methods = useForm();
*   const onSubmit = data => console.log(data);
*
*   return (
*     <FormProvider {...methods} >
*       <form onSubmit={methods.handleSubmit(onSubmit)}>
*         <NestedInput />
*         <input type="submit" />
*       </form>
*     </FormProvider>
*   );
* }
*
*  function NestedInput() {
*   const { register } = useFormContext(); // retrieve all hook methods
*   return <input {...register("test")} />;
* }
* ```
*/
var FormProvider = ({ children, watch, getValues, getFieldState, setError, clearErrors, setValue, setValues, trigger, formState, resetField, reset, resetDefaultValues, handleSubmit, unregister, control, register, setFocus, subscribe }) => {
	const memoizedValue = import_react.useMemo(() => ({
		watch,
		getValues,
		getFieldState,
		setError,
		clearErrors,
		setValue,
		setValues,
		trigger,
		formState,
		resetField,
		reset,
		resetDefaultValues,
		handleSubmit,
		unregister,
		control,
		register,
		setFocus,
		subscribe
	}), [
		clearErrors,
		control,
		formState,
		getFieldState,
		getValues,
		handleSubmit,
		register,
		reset,
		resetDefaultValues,
		resetField,
		setError,
		setFocus,
		setValue,
		setValues,
		subscribe,
		trigger,
		unregister,
		watch
	]);
	return import_react.createElement(HookFormContext.Provider, { value: memoizedValue }, import_react.createElement(HookFormControlContext.Provider, { value: memoizedValue.control }, children));
};
var POST_REQUEST = "post";
/**
* Form component to manage submission.
*
* @param props - to setup submission detail. {@link FormProps}
*
* @returns form component or headless render prop.
*
* @example
* ```tsx
* function App() {
*   const { control, formState: { errors } } = useForm();
*
*   return (
*     <Form action="/api" control={control}>
*       <input {...register("name")} />
*       <p>{errors?.root?.server && 'Server error'}</p>
*       <button>Submit</button>
*     </Form>
*   );
* }
* ```
*/
function Form(props) {
	const methods = useFormContext();
	const [mounted, setMounted] = import_react.useState(false);
	const { control = methods.control, onSubmit, children, action, method = POST_REQUEST, headers, encType, onError, render, onSuccess, validateStatus, ...rest } = props;
	const submit = import_react.useCallback(async (event) => {
		let hasError = false;
		let type = "";
		await control.handleSubmit(async (data) => {
			const formData = new FormData();
			let formDataJson = "";
			try {
				formDataJson = JSON.stringify(data);
			} catch (_a) {}
			const flattenFormValues = flatten(data);
			for (const key in flattenFormValues) formData.append(key, flattenFormValues[key]);
			if (onSubmit) await onSubmit({
				data,
				event,
				method,
				formData,
				formDataJson
			});
			if (action) try {
				const shouldStringifySubmissionData = [headers && headers["Content-Type"], encType].some((value) => value && value.includes("json"));
				const response = await fetch(String(action), {
					method,
					headers: {
						...headers,
						...encType && encType !== "multipart/form-data" ? { "Content-Type": encType } : {}
					},
					body: shouldStringifySubmissionData ? formDataJson : formData
				});
				if (response && (validateStatus ? !validateStatus(response.status) : response.status < 200 || response.status >= 300)) {
					hasError = true;
					onError && onError({ response });
					type = String(response.status);
				} else onSuccess && onSuccess({ response });
			} catch (error) {
				hasError = true;
				onError && onError({ error });
			}
		})(event);
		if (hasError && control) {
			control._subjects.state.next({ isSubmitSuccessful: false });
			control.setError("root.server", { type });
		}
	}, [
		control,
		onSubmit,
		method,
		action,
		headers,
		encType,
		validateStatus,
		onError,
		onSuccess
	]);
	import_react.useEffect(() => {
		setMounted(true);
	}, []);
	return render ? import_react.createElement(import_react.Fragment, null, render({ submit })) : import_react.createElement("form", {
		noValidate: mounted,
		action,
		method,
		encType,
		onSubmit: submit,
		...rest
	}, children);
}
var FormStateSubscribe = ({ control, disabled, exact, name, render }) => render(useFormState({
	control,
	name,
	disabled,
	exact
}));
var createSubject = () => {
	let _observers = [];
	const next = (value) => {
		for (const observer of _observers) observer.next && observer.next(value);
	};
	const subscribe = (observer) => {
		_observers.push(observer);
		return { unsubscribe: () => {
			_observers = _observers.filter((o) => o !== observer);
		} };
	};
	const unsubscribe = () => {
		_observers = [];
	};
	return {
		get observers() {
			return _observers;
		},
		next,
		subscribe,
		unsubscribe
	};
};
function extractFormValues(fieldsState, formValues) {
	const values = {};
	for (const key in fieldsState) if (fieldsState.hasOwnProperty(key)) {
		const fieldState = fieldsState[key];
		const fieldValue = formValues[key];
		if (fieldState && isObject(fieldState) && fieldValue) {
			const nestedFieldsState = extractFormValues(fieldState, fieldValue);
			if (isObject(nestedFieldsState)) values[key] = nestedFieldsState;
		} else if (fieldsState[key]) values[key] = fieldValue;
	}
	return values;
}
var isMultipleSelect = (element) => element.type === `select-multiple`;
var isRadioOrCheckbox = (ref) => isRadioInput(ref) || isCheckBoxInput(ref);
var live = (ref) => isHTMLElement(ref) && ref.isConnected;
var objectHasFunction = (data) => {
	for (const key in data) if (isFunction(data[key])) return true;
	return false;
};
function isTraversable(value) {
	return Array.isArray(value) || isObject(value) && !objectHasFunction(value);
}
function isRegisteredLeaf(fieldRef) {
	return !!(fieldRef && "_f" in fieldRef);
}
function isEmptyDirtyContainer(value) {
	return Array.isArray(value) ? !value.some((item) => !isUndefined(item)) : !Object.keys(value).length;
}
function clearDirtyField(container, key) {
	if (Array.isArray(container)) container[key] = void 0;
	else delete container[key];
}
function markFieldsDirty(data, fields = {}, fieldRefs) {
	for (const key in data) {
		const value = data[key];
		const fieldRef = fieldRefs && fieldRefs[key];
		if (isTraversable(value) && (!Array.isArray(value) || !isRegisteredLeaf(fieldRef))) {
			fields[key] = Array.isArray(value) ? [] : {};
			markFieldsDirty(value, fields[key], fieldRef);
			if (isEmptyDirtyContainer(fields[key])) clearDirtyField(fields, key);
		} else if (!isUndefined(value)) fields[key] = true;
	}
	return fields;
}
function getDirtyFields(data, formValues, dirtyFieldsFromValues, fieldRefs) {
	if (!dirtyFieldsFromValues) dirtyFieldsFromValues = markFieldsDirty(formValues, {}, fieldRefs);
	for (const key in data) {
		const value = data[key];
		const fieldRef = fieldRefs && fieldRefs[key];
		if (isTraversable(value) && (!Array.isArray(value) || !isRegisteredLeaf(fieldRef))) {
			if (isUndefined(formValues) || isPrimitive(dirtyFieldsFromValues[key])) dirtyFieldsFromValues[key] = markFieldsDirty(value, Array.isArray(value) ? [] : {}, fieldRef);
			else getDirtyFields(value, isNullOrUndefined(formValues) ? {} : formValues[key], dirtyFieldsFromValues[key], fieldRef);
			if (isEmptyDirtyContainer(dirtyFieldsFromValues[key])) clearDirtyField(dirtyFieldsFromValues, key);
		} else if (deepEqual(value, formValues[key])) clearDirtyField(dirtyFieldsFromValues, key);
		else dirtyFieldsFromValues[key] = true;
	}
	return dirtyFieldsFromValues;
}
var getFieldValueAs = (value, { valueAsNumber, valueAsDate, setValueAs }) => isUndefined(value) ? value : valueAsNumber ? value === "" ? NaN : value ? +value : value : valueAsDate && isString(value) ? new Date(value) : setValueAs ? setValueAs(value) : value;
function getFieldValue(_f) {
	const ref = _f.ref;
	if (isFileInput(ref)) return ref.files;
	if (isRadioInput(ref)) return getRadioValue(_f.refs).value;
	if (isMultipleSelect(ref)) return [...ref.selectedOptions].map(({ value }) => value);
	if (isCheckBoxInput(ref)) return getCheckboxValue(_f.refs).value;
	return getFieldValueAs(isUndefined(ref.value) ? _f.ref.value : ref.value, _f);
}
var getResolverOptions = (fieldsNames, _fields, criteriaMode, shouldUseNativeValidation) => {
	const fields = {};
	for (const name of fieldsNames) {
		const field = get(_fields, name);
		field && set(fields, name, field._f);
	}
	return {
		criteriaMode,
		names: [...fieldsNames],
		fields,
		shouldUseNativeValidation
	};
};
var getRuleValue = (rule) => isUndefined(rule) ? rule : isRegex(rule) ? rule.source : isObject(rule) ? isRegex(rule.value) ? rule.value.source : rule.value : rule;
var ASYNC_FUNCTION = "AsyncFunction";
var hasPromiseValidation = (fieldReference) => {
	if (!fieldReference || !fieldReference.validate) return false;
	if (isFunction(fieldReference.validate)) return fieldReference.validate.constructor.name === ASYNC_FUNCTION;
	if (isObject(fieldReference.validate)) {
		for (const key in fieldReference.validate) if (fieldReference.validate[key].constructor.name === ASYNC_FUNCTION) return true;
	}
	return false;
};
var hasValidation = (options) => options.mount && (options.required || options.min || options.max || options.maxLength || options.minLength || options.pattern || options.validate);
function schemaErrorLookup(errors, _fields, name) {
	const error = get(errors, name);
	if (error || isKey(name)) return {
		error,
		name
	};
	const names = name.split(".");
	while (names.length) {
		const fieldName = names.join(".");
		const field = get(_fields, fieldName);
		const foundError = get(errors, fieldName);
		if (field && !Array.isArray(field) && name !== fieldName) return { name };
		if (foundError && foundError.type) return {
			name: fieldName,
			error: foundError
		};
		if (foundError && foundError.root && foundError.root.type) return {
			name: `${fieldName}.root`,
			error: foundError.root
		};
		names.pop();
	}
	return { name };
}
var shouldRenderFormState = (formStateData, _proxyFormState, updateFormState, isRoot) => {
	updateFormState(formStateData);
	const { name, ...formState } = formStateData;
	const keys = Object.keys(formState);
	return !keys.length || isRoot && keys.length >= Object.keys(_proxyFormState).length || keys.find((key) => _proxyFormState[key] === (!isRoot || VALIDATION_MODE.all));
};
var shouldSubscribeByName = (name, signalName, exact) => !name || !signalName || name === signalName || convertToArrayPayload(name).some((currentName) => currentName && (exact ? currentName === signalName || currentName.startsWith(signalName + ".") : currentName.startsWith(signalName) || signalName.startsWith(currentName)));
var skipValidation = (isBlurEvent, isTouched, isSubmitted, reValidateMode, mode) => {
	if (mode.isOnAll) return false;
	else if (!isSubmitted && mode.isOnTouch) return !(isTouched || isBlurEvent);
	else if (isSubmitted ? reValidateMode.isOnBlur : mode.isOnBlur) return !isBlurEvent;
	else if (isSubmitted ? reValidateMode.isOnChange : mode.isOnChange) return isBlurEvent;
	return true;
};
var unsetEmptyArray = (ref, name) => !compact(get(ref, name)).length && unset(ref, name);
var defaultOptions = {
	mode: VALIDATION_MODE.onSubmit,
	reValidateMode: VALIDATION_MODE.onChange,
	shouldFocusError: true
};
var FORM_ERROR_TYPE = "form";
var DEFAULT_FORM_STATE = {
	submitCount: 0,
	isDirty: false,
	isReady: false,
	isValidating: false,
	isSubmitted: false,
	isSubmitting: false,
	isSubmitSuccessful: false,
	isValid: false,
	touchedFields: {},
	dirtyFields: {},
	validatingFields: {}
};
function createFormControl(props = {}) {
	let _options = {
		...defaultOptions,
		...props
	};
	let _formState = {
		...cloneObject(DEFAULT_FORM_STATE),
		isLoading: isFunction(_options.defaultValues),
		errors: _options.errors || {},
		disabled: _options.disabled || false
	};
	let _fields = {};
	let _defaultValues = isObject(_options.defaultValues) || isObject(_options.values) ? cloneObject(_options.defaultValues || _options.values) || {} : {};
	let _formValues = _options.shouldUnregister ? {} : cloneObject(_defaultValues);
	let _state = {
		action: false,
		mount: false,
		watch: false,
		keepIsValid: false
	};
	let _names = {
		mount: /* @__PURE__ */ new Set(),
		disabled: /* @__PURE__ */ new Set(),
		unMount: /* @__PURE__ */ new Set(),
		array: /* @__PURE__ */ new Set(),
		watch: /* @__PURE__ */ new Set(),
		registerName: /* @__PURE__ */ new Set()
	};
	const delayErrorCallbacks = {};
	const timers = {};
	let _valuesSubscriberCount = 0;
	let _validationModeBeforeSubmit = getValidationModes(_options.mode);
	let _validationModeAfterSubmit = getValidationModes(_options.reValidateMode);
	const defaultProxyFormState = {
		isDirty: false,
		dirtyFields: false,
		validatingFields: false,
		touchedFields: false,
		isValidating: false,
		isValid: false,
		errors: false
	};
	const _proxyFormState = { ...defaultProxyFormState };
	let _proxySubscribeFormState = { ..._proxyFormState };
	const _subjects = {
		array: createSubject(),
		state: createSubject()
	};
	let _setValidCallId = 0;
	const shouldDisplayAllAssociatedErrors = _options.criteriaMode === VALIDATION_MODE.all;
	const debounce = (name, callback) => (wait) => {
		clearTimeout(timers[name]);
		timers[name] = setTimeout(callback, wait);
	};
	const _setValid = async (shouldUpdateValid) => {
		if (_state.keepIsValid) return;
		if (!_options.disabled && (_proxyFormState.isValid || _proxySubscribeFormState.isValid || shouldUpdateValid)) {
			const callId = ++_setValidCallId;
			let isValid;
			if (_options.resolver) {
				isValid = isEmptyObject((await _runSchema()).errors);
				callId === _setValidCallId && _updateIsValidating();
			} else isValid = await executeBuiltInValidation({
				fields: _fields,
				onlyCheckValid: true,
				eventType: EVENTS.VALID
			});
			if (callId === _setValidCallId && isValid !== _formState.isValid) _subjects.state.next({ isValid });
		}
	};
	const _updateIsValidating = (names, isValidating) => {
		if (!_options.disabled && (_proxyFormState.isValidating || _proxyFormState.validatingFields || _proxySubscribeFormState.isValidating || _proxySubscribeFormState.validatingFields)) {
			(names || Array.from(_names.mount)).forEach((name) => {
				if (name) isValidating ? set(_formState.validatingFields, name, isValidating) : unset(_formState.validatingFields, name);
			});
			_subjects.state.next({
				validatingFields: _formState.validatingFields,
				isValidating: !isEmptyObject(_formState.validatingFields)
			});
		}
	};
	const _updateDirtyFields = () => {
		_formState.dirtyFields = getDirtyFields(_defaultValues, _formValues, void 0, _fields);
	};
	const _setFieldArray = (name, values = [], method, args, shouldSetValues = true, shouldUpdateFieldsAndState = true) => {
		if (args && method && !_options.disabled) {
			_state.action = true;
			if (shouldUpdateFieldsAndState && Array.isArray(get(_fields, name))) {
				const fieldValues = method(get(_fields, name), args.argA, args.argB);
				shouldSetValues && set(_fields, name, fieldValues);
			}
			if (shouldUpdateFieldsAndState && Array.isArray(get(_formState.errors, name))) {
				const errors = method(get(_formState.errors, name), args.argA, args.argB);
				shouldSetValues && set(_formState.errors, name, errors);
				unsetEmptyArray(_formState.errors, name);
			}
			if ((_proxyFormState.touchedFields || _proxySubscribeFormState.touchedFields) && shouldUpdateFieldsAndState && Array.isArray(get(_formState.touchedFields, name))) {
				const touchedFields = method(get(_formState.touchedFields, name), args.argA, args.argB);
				shouldSetValues && set(_formState.touchedFields, name, touchedFields);
			}
			if (_proxyFormState.dirtyFields || _proxySubscribeFormState.dirtyFields) _updateDirtyFields();
			_subjects.state.next({
				name,
				isDirty: _getDirty(name, values),
				dirtyFields: _formState.dirtyFields,
				errors: _formState.errors,
				isValid: _formState.isValid
			});
		} else set(_formValues, name, values);
	};
	const updateErrors = (name, error) => {
		set(_formState.errors, name, error);
		_formState.errors = { ..._formState.errors };
		_subjects.state.next({ errors: _formState.errors });
	};
	const _setErrors = (errors) => {
		_formState.errors = errors;
		_subjects.state.next({
			errors: _formState.errors,
			isValid: false
		});
	};
	const hasExplicitNullIntermediate = (name) => {
		const segments = isKey(name) ? [name] : stringToPath(name);
		let formValues = _formValues;
		let defaultValues = _defaultValues;
		for (let i = 0; i < segments.length - 1; i++) {
			const key = segments[i];
			formValues = isNullOrUndefined(formValues) ? formValues : formValues[key];
			defaultValues = isNullOrUndefined(defaultValues) ? defaultValues : defaultValues[key];
			if (formValues === null && defaultValues !== null) return true;
		}
		return false;
	};
	const updateValidAndValue = (name, shouldSkipSetValueAs, value, ref) => {
		const field = get(_fields, name);
		if (field) {
			if (hasExplicitNullIntermediate(name)) return;
			const wasUnsetInFormValues = isUndefined(get(_formValues, name));
			const defaultValue = get(_formValues, name, isUndefined(value) ? get(_defaultValues, name) : value);
			isUndefined(defaultValue) || ref && ref.defaultChecked || shouldSkipSetValueAs ? set(_formValues, name, shouldSkipSetValueAs ? defaultValue : getFieldValue(field._f)) : setFieldValue(name, defaultValue);
			if (_state.mount && !_state.action) {
				_setValid();
				if (wasUnsetInFormValues && _formState.isDirty && (_proxyFormState.isDirty || _proxySubscribeFormState.isDirty)) {
					if (!_getDirty()) {
						_formState.isDirty = false;
						_subjects.state.next({ ..._formState });
					}
				}
				if (props.shouldUnregister && wasUnsetInFormValues && !isUndefined(get(_formValues, name)) && isWatched(name, _names)) _state.watch = true;
			}
		}
	};
	const updateTouchAndDirty = (name, fieldValue, isBlurEvent, shouldDirty, shouldRender) => {
		let shouldUpdateField = false;
		let isPreviousDirty = false;
		const output = { name };
		if (!_options.disabled || shouldDirty === true) {
			if (!isBlurEvent || shouldDirty) {
				const isCurrentFieldPristine = deepEqual(get(_defaultValues, name), fieldValue);
				if (_proxyFormState.isDirty || _proxySubscribeFormState.isDirty) {
					isPreviousDirty = _formState.isDirty;
					_formState.isDirty = output.isDirty = !isCurrentFieldPristine || _getDirty();
					shouldUpdateField = isPreviousDirty !== output.isDirty;
				}
				isPreviousDirty = !!get(_formState.dirtyFields, name);
				if (isCurrentFieldPristine !== _formState.isDirty) _formState.dirtyFields = getDirtyFields(_defaultValues, _formValues, void 0, _fields);
				else isCurrentFieldPristine ? unset(_formState.dirtyFields, name) : set(_formState.dirtyFields, name, true);
				output.dirtyFields = _formState.dirtyFields;
				shouldUpdateField = shouldUpdateField || (_proxyFormState.dirtyFields || _proxySubscribeFormState.dirtyFields) && isPreviousDirty !== !isCurrentFieldPristine;
			}
			if (isBlurEvent) {
				const isPreviousFieldTouched = get(_formState.touchedFields, name);
				if (!isPreviousFieldTouched) {
					set(_formState.touchedFields, name, isBlurEvent);
					output.touchedFields = _formState.touchedFields;
					shouldUpdateField = shouldUpdateField || (_proxyFormState.touchedFields || _proxySubscribeFormState.touchedFields) && isPreviousFieldTouched !== isBlurEvent;
				}
			}
			shouldUpdateField && shouldRender && _subjects.state.next(output);
		}
		return shouldUpdateField ? output : {};
	};
	const shouldRenderByError = (name, isValid, error, fieldState) => {
		const previousFieldError = get(_formState.errors, name);
		const shouldUpdateValid = (_proxyFormState.isValid || _proxySubscribeFormState.isValid) && isBoolean(isValid) && _formState.isValid !== isValid;
		if (_options.delayError && error) {
			delayErrorCallbacks[name] = debounce(name, () => updateErrors(name, error));
			delayErrorCallbacks[name](_options.delayError);
		} else {
			clearTimeout(timers[name]);
			delete delayErrorCallbacks[name];
			error ? set(_formState.errors, name, error) : unset(_formState.errors, name);
			_formState.errors = { ..._formState.errors };
		}
		if ((error ? !deepEqual(previousFieldError, error) : previousFieldError) || !isEmptyObject(fieldState) || shouldUpdateValid) {
			const updatedFormState = {
				...fieldState,
				...shouldUpdateValid && isBoolean(isValid) ? { isValid } : {},
				errors: _formState.errors,
				name
			};
			_formState = {
				..._formState,
				...updatedFormState
			};
			_subjects.state.next(updatedFormState);
		}
	};
	const _runSchema = async (name) => {
		_updateIsValidating(name, true);
		return await _options.resolver(_formValues, _options.context, getResolverOptions(name || _names.mount, _fields, _options.criteriaMode, _options.shouldUseNativeValidation));
	};
	const executeSchemaAndUpdateState = async (names) => {
		const { errors } = await _runSchema(names);
		_updateIsValidating(names);
		if (names) {
			for (const name of names) {
				const error = get(errors, name);
				error ? _names.array.has(name) && isObject(error) && !Object.keys(error).some((key) => !Number.isNaN(Number(key))) ? updateFieldArrayRootError(_formState.errors, { [name]: error }, name) : set(_formState.errors, name, error) : unset(_formState.errors, name);
			}
			_formState.errors = { ..._formState.errors };
		} else _formState.errors = errors;
		return errors;
	};
	const validateForm = async ({ name, eventType }) => {
		if (props.validate) {
			const result = await props.validate({
				formValues: _formValues,
				formState: _formState,
				name,
				eventType
			});
			if (isObject(result)) for (const key in result) {
				const error = result[key];
				if (error) setError(`${FORM_ERROR_TYPE}.${key}`, {
					message: isString(error.message) ? error.message : "",
					type: error.type || INPUT_VALIDATION_RULES.validate
				});
			}
			else if (isString(result) || !result) setError(FORM_ERROR_TYPE, {
				message: result || "",
				type: INPUT_VALIDATION_RULES.validate
			});
			else clearErrors(FORM_ERROR_TYPE);
			return result;
		}
		return true;
	};
	const executeBuiltInValidation = async ({ fields, onlyCheckValid, name, eventType, context = {
		valid: true,
		runRootValidation: false
	} }) => {
		if (props.validate) {
			context.runRootValidation = true;
			if (!await validateForm({
				name,
				eventType
			})) {
				context.valid = false;
				if (onlyCheckValid) return context.valid;
			}
		}
		for (const name in fields) {
			const field = fields[name];
			if (field) {
				const { _f, ...fieldValue } = field;
				if (_f) {
					const isFieldArrayRoot = _names.array.has(_f.name);
					const isPromiseFunction = field._f && hasPromiseValidation(field._f);
					const shouldTrackIsValidatingState = _proxyFormState.validatingFields || _proxyFormState.isValidating || _proxySubscribeFormState.validatingFields || _proxySubscribeFormState.isValidating;
					if (isPromiseFunction && shouldTrackIsValidatingState) _updateIsValidating([_f.name], true);
					const fieldError = await validateField(field, _names.disabled, _formValues, shouldDisplayAllAssociatedErrors, _options.shouldUseNativeValidation && !onlyCheckValid, isFieldArrayRoot);
					if (isPromiseFunction && shouldTrackIsValidatingState) _updateIsValidating([_f.name]);
					if (fieldError[_f.name]) {
						context.valid = false;
						if (onlyCheckValid) break;
					}
					!onlyCheckValid && (get(fieldError, _f.name) ? isFieldArrayRoot ? updateFieldArrayRootError(_formState.errors, fieldError, _f.name) : set(_formState.errors, _f.name, fieldError[_f.name]) : unset(_formState.errors, _f.name));
					if (props.shouldUseNativeValidation && fieldError[_f.name]) break;
				}
				!isEmptyObject(fieldValue) && await executeBuiltInValidation({
					context,
					onlyCheckValid,
					fields: fieldValue,
					name,
					eventType
				});
			}
		}
		return context.valid;
	};
	const _removeUnmounted = () => {
		for (const name of _names.unMount) {
			const field = get(_fields, name);
			field && (field._f.refs ? field._f.refs.every((ref) => !live(ref)) : !live(field._f.ref)) && unregister(name);
		}
		_names.unMount = /* @__PURE__ */ new Set();
	};
	const _getDirty = (name, data) => (name && data && set(_formValues, name, data), !deepEqual(_state.mount ? _formValues : _defaultValues, _defaultValues));
	const _getWatch = (names, defaultValue, isGlobal) => generateWatchOutput(names, _names, { ..._state.mount ? _formValues : isUndefined(defaultValue) ? _defaultValues : isString(names) ? { [names]: defaultValue } : defaultValue }, isGlobal, defaultValue);
	const _getFieldArray = (name) => compact(get(_state.mount ? _formValues : _defaultValues, name, _options.shouldUnregister ? get(_defaultValues, name, []) : []));
	const setFieldValue = (name, value, options = {}, skipClone = false, skipRender = false) => {
		const field = get(_fields, name);
		let fieldValue = value;
		if (field) {
			const fieldReference = field._f;
			if (fieldReference) {
				!fieldReference.disabled && set(_formValues, name, getFieldValueAs(value, fieldReference));
				fieldValue = isHTMLElement(fieldReference.ref) && isNullOrUndefined(value) ? "" : value;
				if (isMultipleSelect(fieldReference.ref)) [...fieldReference.ref.options].forEach((optionRef) => optionRef.selected = fieldValue.includes(optionRef.value));
				else if (fieldReference.refs) if (isCheckBoxInput(fieldReference.ref)) fieldReference.refs.forEach((checkboxRef) => {
					if (!checkboxRef.defaultChecked || !checkboxRef.disabled) if (Array.isArray(fieldValue)) checkboxRef.checked = !!fieldValue.find((data) => data === checkboxRef.value);
					else checkboxRef.checked = fieldValue === checkboxRef.value || !!fieldValue;
				});
				else fieldReference.refs.forEach((radioRef) => radioRef.checked = radioRef.value === fieldValue);
				else if (isFileInput(fieldReference.ref)) fieldReference.ref.value = "";
				else {
					fieldReference.ref.value = fieldValue;
					if (!fieldReference.ref.type && !skipRender) _subjects.state.next({
						name,
						values: skipClone ? _formValues : cloneObject(_formValues)
					});
				}
			}
		}
		(options.shouldDirty || options.shouldTouch) && updateTouchAndDirty(name, fieldValue, options.shouldTouch, options.shouldDirty, !skipRender);
		options.shouldValidate && trigger(name, { delayError: options.delayError });
	};
	const setFieldValues = (name, value, options, skipClone = false, skipRender = false) => {
		for (const fieldKey in value) {
			if (!value.hasOwnProperty(fieldKey)) return;
			const fieldValue = value[fieldKey];
			const fieldName = name + "." + fieldKey;
			const field = get(_fields, fieldName);
			(_names.array.has(name) || isObject(fieldValue) || field && !field._f) && !isDateObject(fieldValue) ? setFieldValues(fieldName, fieldValue, options, skipClone, skipRender) : setFieldValue(fieldName, fieldValue, options, skipClone, skipRender);
		}
	};
	const _setValue = (name, value, options, skipClone, skipStateEmit = false) => {
		const field = get(_fields, name);
		const isFieldArray = _names.array.has(name);
		const cloneValue = skipClone ? value : cloneObject(value);
		const isValueUnchanged = deepEqual(get(_formValues, name), cloneValue);
		if (!isValueUnchanged) set(_formValues, name, cloneValue);
		if (isFieldArray) {
			_subjects.array.next({
				name,
				values: skipClone ? _formValues : cloneObject(_formValues)
			});
			if ((_proxyFormState.isDirty || _proxyFormState.dirtyFields || _proxySubscribeFormState.isDirty || _proxySubscribeFormState.dirtyFields) && options.shouldDirty) {
				_updateDirtyFields();
				if (!skipStateEmit) _subjects.state.next({
					name,
					dirtyFields: _formState.dirtyFields,
					isDirty: _getDirty(name, cloneValue)
				});
			}
		} else {
			const isEmpty = Array.isArray(cloneValue) && !cloneValue.length || isEmptyObject(cloneValue);
			if (!field || field._f || isNullOrUndefined(cloneValue) || isEmpty) setFieldValue(name, cloneValue, options, skipClone, skipStateEmit);
			else setFieldValues(name, cloneValue, options, skipClone, skipStateEmit);
		}
		if (!isValueUnchanged && !skipStateEmit) {
			const watched = isWatched(name, _names);
			const values = skipClone ? _formValues : cloneObject(_formValues);
			_subjects.state.next({
				...watched && _formState,
				name: _state.mount || watched ? name : void 0,
				values
			});
		}
	};
	const setValue = (name, value, options = {}) => _setValue(name, value, options, false);
	const setValues = (formValues, options = {}) => {
		const updatedFormValues = isFunction(formValues) ? formValues(_formValues) : formValues;
		if (!deepEqual(_formValues, updatedFormValues)) {
			_formValues = {
				..._formValues,
				...updatedFormValues
			};
			const flattenedUpdates = flatten(updatedFormValues);
			for (const fieldName of _names.mount) if (fieldName in flattenedUpdates) _setValue(fieldName, flattenedUpdates[fieldName], options, true, true);
			_subjects.state.next({
				..._formState,
				name: void 0,
				type: void 0,
				..._valuesSubscriberCount ? { values: _formValues } : {}
			});
			if (options.shouldValidate) _setValid();
		}
	};
	const onChange = async (event) => {
		_state.mount = true;
		const target = event.target;
		let name = target.name;
		let isFieldValueUpdated = true;
		const field = get(_fields, name);
		const _updateIsFieldValueUpdated = (fieldValue) => {
			isFieldValueUpdated = Number.isNaN(fieldValue) || isDateObject(fieldValue) && isNaN(fieldValue.getTime()) || deepEqual(fieldValue, get(_formValues, name, fieldValue));
		};
		if (field) {
			let error;
			let isValid;
			const fieldValue = target.type ? getFieldValue(field._f) : getEventValue(event);
			const isBlurEvent = event.type === EVENTS.BLUR || event.type === EVENTS.FOCUS_OUT;
			const hasNoValidationEffect = !hasValidation(field._f) && !props.validate && !_options.resolver && !get(_formState.errors, name) && !field._f.deps;
			const shouldSkipValidation = hasNoValidationEffect || skipValidation(isBlurEvent, get(_formState.touchedFields, name), _formState.isSubmitted, _validationModeAfterSubmit, _validationModeBeforeSubmit);
			const watched = isWatched(name, _names, isBlurEvent);
			set(_formValues, name, fieldValue);
			if (isBlurEvent) {
				if (!target || !target.readOnly) {
					field._f.onBlur && field._f.onBlur(event);
					const pendingDelayError = delayErrorCallbacks[name];
					pendingDelayError && pendingDelayError(0);
				}
			} else if (field._f.onChange) field._f.onChange(event);
			const fieldState = updateTouchAndDirty(name, fieldValue, isBlurEvent);
			const shouldRender = !isEmptyObject(fieldState) || watched;
			!isBlurEvent && _subjects.state.next({
				name,
				type: event.type,
				..._valuesSubscriberCount ? { values: cloneObject(_formValues) } : {}
			});
			if (shouldSkipValidation) {
				if ((!hasNoValidationEffect || !_formState.isValid) && (_proxyFormState.isValid || _proxySubscribeFormState.isValid)) {
					if (_options.mode === "onBlur") {
						if (isBlurEvent) _setValid();
					} else if (!isBlurEvent) _setValid();
				}
				return shouldRender && _subjects.state.next({
					name,
					...watched ? {} : fieldState
				});
			}
			if (!_options.resolver && props.validate) await validateForm({
				name,
				eventType: event.type
			});
			!isBlurEvent && watched && _subjects.state.next({ ..._formState });
			if (_options.resolver) {
				const { errors } = await _runSchema([name]);
				_updateIsValidating([name]);
				_updateIsFieldValueUpdated(fieldValue);
				if (!isFieldValueUpdated) {
					!isEmptyObject(fieldState) && _subjects.state.next(fieldState);
					return;
				}
				const previousErrorLookupResult = schemaErrorLookup(_formState.errors, _fields, name);
				const errorLookupResult = schemaErrorLookup(errors, _fields, previousErrorLookupResult.name || name);
				error = errorLookupResult.error;
				name = errorLookupResult.name;
				isValid = isEmptyObject(errors);
			} else {
				_updateIsValidating([name], true);
				error = (await validateField(field, _names.disabled, _formValues, shouldDisplayAllAssociatedErrors, _options.shouldUseNativeValidation))[name];
				_updateIsValidating([name]);
				_updateIsFieldValueUpdated(fieldValue);
				if (isFieldValueUpdated) {
					if (error) isValid = false;
					else if (_proxyFormState.isValid || _proxySubscribeFormState.isValid) isValid = await executeBuiltInValidation({
						fields: _fields,
						onlyCheckValid: true,
						name,
						eventType: event.type
					});
				}
			}
			if (isFieldValueUpdated) {
				field._f.deps && (!Array.isArray(field._f.deps) || field._f.deps.length > 0) && trigger(field._f.deps);
				shouldRenderByError(name, isValid, error, fieldState);
			}
		}
	};
	const _focusInput = (ref, key) => {
		if (get(_formState.errors, key) && ref.focus) {
			ref.focus();
			return 1;
		}
	};
	const trigger = async (name, options = {}) => {
		let isValid;
		let validationResult;
		const fieldNames = convertToArrayPayload(name);
		if (_options.resolver) {
			const errors = await executeSchemaAndUpdateState(isUndefined(name) ? name : fieldNames);
			isValid = isEmptyObject(errors);
			validationResult = name ? !fieldNames.some((name) => get(errors, name)) : isValid;
		} else if (name) {
			validationResult = (await Promise.all(fieldNames.map(async (fieldName) => {
				const field = get(_fields, fieldName);
				return await executeBuiltInValidation({
					fields: field && field._f ? { [fieldName]: field } : field,
					eventType: EVENTS.TRIGGER
				});
			}))).every(Boolean);
			!(!validationResult && !_formState.isValid) && _setValid();
		} else validationResult = isValid = await executeBuiltInValidation({
			fields: _fields,
			name,
			eventType: EVENTS.TRIGGER
		});
		if (options.delayError && _options.delayError && isString(name)) {
			const error = get(_formState.errors, name);
			if (error) {
				unset(_formState.errors, name);
				delayErrorCallbacks[name] = debounce(name, () => updateErrors(name, error));
				delayErrorCallbacks[name](_options.delayError);
			} else {
				clearTimeout(timers[name]);
				delete delayErrorCallbacks[name];
			}
		}
		_subjects.state.next({
			...!isString(name) || (_proxyFormState.isValid || _proxySubscribeFormState.isValid) && isValid !== _formState.isValid ? {} : { name },
			..._options.resolver || !name ? { isValid } : {},
			errors: _formState.errors
		});
		options.shouldFocus && !validationResult && iterateFieldsByAction(_fields, _focusInput, name ? fieldNames : _names.mount);
		return validationResult;
	};
	const getValues = (fieldNames, config) => {
		let values = { ..._state.mount ? _formValues : _defaultValues };
		if (config) values = extractFormValues(config.dirtyFields ? _formState.dirtyFields : _formState.touchedFields, values);
		return isUndefined(fieldNames) ? values : isString(fieldNames) ? get(values, fieldNames) : fieldNames.map((name) => get(values, name));
	};
	const getFieldState = (name, formState) => ({
		invalid: !!get((formState || _formState).errors, name),
		isDirty: !!get((formState || _formState).dirtyFields, name),
		error: get((formState || _formState).errors, name),
		isValidating: !!get(_formState.validatingFields, name),
		isTouched: !!get((formState || _formState).touchedFields, name)
	});
	const clearErrors = (name) => {
		const names = name ? convertToArrayPayload(name) : void 0;
		names === null || names === void 0 || names.forEach((inputName) => unset(_formState.errors, inputName));
		if (names) names.forEach((inputName) => {
			_subjects.state.next({
				name: inputName,
				errors: _formState.errors
			});
		});
		else _subjects.state.next({ errors: {} });
	};
	const setError = (name, error, options) => {
		const ref = (get(_fields, name, { _f: {} })._f || {}).ref;
		const { ref: currentRef, message, type, ...restOfErrorTree } = get(_formState.errors, name) || {};
		set(_formState.errors, name, {
			...restOfErrorTree,
			...error,
			ref
		});
		_subjects.state.next({
			name,
			errors: _formState.errors,
			isValid: false
		});
		options && options.shouldFocus && ref && ref.focus && ref.focus();
	};
	const watch = (name, defaultValue) => {
		if (isFunction(name)) {
			_valuesSubscriberCount++;
			const { unsubscribe } = _subjects.state.subscribe({ next: (payload) => "values" in payload && name(payload.values || _getWatch(void 0, defaultValue), payload) });
			let called = false;
			return { unsubscribe: () => {
				if (called) return;
				called = true;
				_valuesSubscriberCount--;
				unsubscribe();
			} };
		}
		return _getWatch(name, defaultValue, true);
	};
	const _subscribe = (props) => {
		var _a;
		const needsValues = !!((_a = props.formState) === null || _a === void 0 ? void 0 : _a.values);
		if (needsValues) _valuesSubscriberCount++;
		const { unsubscribe } = _subjects.state.subscribe({ next: (formState) => {
			if (shouldSubscribeByName(props.name, formState.name, props.exact) && shouldRenderFormState(formState, props.formState || _proxyFormState, _setFormState, props.reRenderRoot)) {
				const snapshot = { ..._formValues };
				props.callback({
					values: snapshot,
					..._formState,
					...formState,
					defaultValues: _defaultValues
				});
			}
		} });
		if (!needsValues) return unsubscribe;
		let called = false;
		return () => {
			if (called) return;
			called = true;
			_valuesSubscriberCount--;
			unsubscribe();
		};
	};
	const subscribe = (props) => {
		_state.mount = true;
		_proxySubscribeFormState = {
			..._proxySubscribeFormState,
			...props.formState
		};
		return _subscribe({
			...props,
			formState: {
				...defaultProxyFormState,
				...props.formState
			}
		});
	};
	const unregister = (name, options = {}) => {
		for (const fieldName of name ? convertToArrayPayload(name) : _names.mount) {
			_names.mount.delete(fieldName);
			_names.array.delete(fieldName);
			if (!options.keepValue) {
				unset(_fields, fieldName);
				unset(_formValues, fieldName);
			}
			!options.keepError && unset(_formState.errors, fieldName);
			!options.keepDirty && unset(_formState.dirtyFields, fieldName);
			!options.keepTouched && unset(_formState.touchedFields, fieldName);
			!options.keepIsValidating && unset(_formState.validatingFields, fieldName);
			!_options.shouldUnregister && !options.keepDefaultValue && unset(_defaultValues, fieldName);
		}
		_subjects.state.next({ values: cloneObject(_formValues) });
		_subjects.state.next({
			..._formState,
			...!options.keepDirty ? {} : { isDirty: _getDirty() }
		});
		!options.keepIsValid && _setValid();
	};
	const _setDisabledField = ({ disabled, name }) => {
		if (isBoolean(disabled) && _state.mount || !!disabled || _names.disabled.has(name)) {
			const disabledStateChanged = _names.disabled.has(name) !== !!disabled;
			disabled ? _names.disabled.add(name) : _names.disabled.delete(name);
			disabledStateChanged && _state.mount && !_state.action && _setValid();
		}
	};
	const register = (name, options = {}) => {
		let field = get(_fields, name);
		const disabledIsDefined = isBoolean(options.disabled) || isBoolean(_options.disabled);
		const shouldRevalidateRemount = !_names.registerName.has(name) && field && field._f && !field._f.mount;
		set(_fields, name, {
			...field || {},
			_f: {
				...field && field._f ? field._f : { ref: { name } },
				name,
				mount: true,
				...options
			}
		});
		_names.mount.add(name);
		if (field && !shouldRevalidateRemount) _setDisabledField({
			disabled: isBoolean(options.disabled) ? options.disabled : _options.disabled,
			name
		});
		else updateValidAndValue(name, true, options.value);
		return {
			...disabledIsDefined ? { disabled: options.disabled || _options.disabled } : {},
			..._options.progressive ? {
				required: !!options.required,
				min: getRuleValue(options.min),
				max: getRuleValue(options.max),
				minLength: getRuleValue(options.minLength),
				maxLength: getRuleValue(options.maxLength),
				pattern: getRuleValue(options.pattern)
			} : {},
			name,
			onChange,
			onBlur: onChange,
			ref: (ref) => {
				if (ref) {
					_names.registerName.add(name);
					register(name, options);
					_names.registerName.delete(name);
					field = get(_fields, name);
					const fieldRef = isUndefined(ref.value) ? ref.querySelectorAll ? ref.querySelectorAll("input,select,textarea")[0] || ref : ref : ref;
					const radioOrCheckbox = isRadioOrCheckbox(fieldRef);
					const refs = field._f.refs || [];
					if (radioOrCheckbox ? refs.find((option) => option === fieldRef) : fieldRef === field._f.ref) return;
					set(_fields, name, { _f: {
						...field._f,
						...radioOrCheckbox ? {
							refs: [
								...refs.filter(live),
								fieldRef,
								...Array.isArray(get(_defaultValues, name)) ? [{}] : []
							],
							ref: {
								type: fieldRef.type,
								name
							}
						} : { ref: fieldRef }
					} });
					updateValidAndValue(name, false, void 0, fieldRef);
				} else {
					field = get(_fields, name, {});
					if (field._f) field._f.mount = false;
					(_options.shouldUnregister || options.shouldUnregister) && !(isNameInFieldArray(_names.array, name) && _state.action) && _names.unMount.add(name);
				}
			}
		};
	};
	const _focusError = () => _options.shouldFocusError && !_options.shouldUseNativeValidation && iterateFieldsByAction(_fields, _focusInput, _names.mount);
	const _disableForm = (disabled) => {
		if (isBoolean(disabled)) {
			_subjects.state.next({ disabled });
			iterateFieldsByAction(_fields, (ref, name) => {
				const currentField = get(_fields, name);
				if (currentField) {
					ref.disabled = currentField._f.disabled || disabled;
					if (Array.isArray(currentField._f.refs)) currentField._f.refs.forEach((inputRef) => {
						inputRef.disabled = currentField._f.disabled || disabled;
					});
				}
			}, 0, false);
		}
	};
	const handleSubmit = (onValid, onInvalid) => async (e) => {
		let onValidError = void 0;
		if (e) {
			e.preventDefault && e.preventDefault();
			e.persist && e.persist();
		}
		let fieldValues = cloneObject(_formValues);
		_subjects.state.next({ isSubmitting: true });
		if (_options.resolver) {
			const { errors, values } = await _runSchema();
			_updateIsValidating();
			_formState.errors = errors;
			fieldValues = cloneObject(values);
		} else await executeBuiltInValidation({
			fields: _fields,
			eventType: EVENTS.SUBMIT
		});
		if (_names.disabled.size) for (const name of _names.disabled) unset(fieldValues, name);
		unset(_formState.errors, ROOT_ERROR_TYPE);
		if (isEmptyObject(_formState.errors)) {
			_subjects.state.next({ errors: {} });
			try {
				await onValid(fieldValues, e);
			} catch (error) {
				onValidError = error;
			}
		} else {
			if (onInvalid) await onInvalid({ ..._formState.errors }, e);
			_focusError();
			setTimeout(_focusError);
		}
		_subjects.state.next({
			isSubmitted: true,
			isSubmitting: false,
			isSubmitSuccessful: isEmptyObject(_formState.errors) && !onValidError,
			submitCount: _formState.submitCount + 1,
			errors: _formState.errors
		});
		if (onValidError) throw onValidError;
	};
	const resetField = (name, options = {}) => {
		if (get(_fields, name)) {
			if (isUndefined(options.defaultValue)) setValue(name, cloneObject(get(_defaultValues, name)));
			else {
				setValue(name, options.defaultValue);
				set(_defaultValues, name, cloneObject(options.defaultValue));
			}
			if (!options.keepTouched) unset(_formState.touchedFields, name);
			if (!options.keepDirty) {
				unset(_formState.dirtyFields, name);
				_formState.isDirty = options.defaultValue ? _getDirty(name, cloneObject(get(_defaultValues, name))) : _getDirty();
			}
			if (!options.keepError) {
				unset(_formState.errors, name);
				_proxyFormState.isValid && _setValid();
			}
			_subjects.state.next({ ..._formState });
		}
	};
	const _reset = (formValues, keepStateOptions = {}) => {
		const updatedValues = formValues ? cloneObject(formValues) : _defaultValues;
		const cloneUpdatedValues = cloneObject(updatedValues);
		const isEmptyResetValues = isEmptyObject(formValues);
		const values = cloneUpdatedValues;
		const fieldRefs = _fields;
		if (!keepStateOptions.keepDefaultValues) _defaultValues = updatedValues;
		if (!keepStateOptions.keepValues) {
			if (keepStateOptions.keepDirtyValues) {
				const fieldsToCheck = /* @__PURE__ */ new Set([..._names.mount, ...Object.keys(getDirtyFields(_defaultValues, _formValues, void 0, fieldRefs))]);
				for (const fieldName of Array.from(fieldsToCheck)) {
					const isDirty = get(_formState.dirtyFields, fieldName);
					const existingValue = get(_formValues, fieldName);
					const newValue = get(values, fieldName);
					if (isDirty && !isUndefined(existingValue)) set(values, fieldName, existingValue);
					else if (!isDirty && !isUndefined(newValue)) setValue(fieldName, newValue);
				}
			} else {
				if (isWeb && isUndefined(formValues)) for (const name of _names.mount) {
					const field = get(_fields, name);
					if (field && field._f) {
						const fieldReference = Array.isArray(field._f.refs) ? field._f.refs[0] : field._f.ref;
						if (isHTMLElement(fieldReference)) {
							const form = fieldReference.closest("form");
							if (form) {
								form.reset();
								break;
							}
						}
					}
				}
				if (keepStateOptions.keepFieldsRef) for (const fieldName of _names.mount) setValue(fieldName, get(values, fieldName));
				else _fields = {};
			}
			if (_options.shouldUnregister) {
				_formValues = keepStateOptions.keepDefaultValues ? cloneObject(_defaultValues) : {};
				if (keepStateOptions.keepFieldsRef) for (const fieldName of _names.mount) set(_formValues, fieldName, get(values, fieldName));
			} else _formValues = cloneObject(values);
			_subjects.array.next({ values: { ...values } });
			_subjects.state.next({
				name: void 0,
				type: void 0,
				values: { ...values }
			});
		}
		_names = {
			mount: keepStateOptions.keepDirtyValues ? _names.mount : /* @__PURE__ */ new Set(),
			unMount: /* @__PURE__ */ new Set(),
			array: /* @__PURE__ */ new Set(),
			registerName: /* @__PURE__ */ new Set(),
			disabled: /* @__PURE__ */ new Set(),
			watch: /* @__PURE__ */ new Set(),
			watchAll: false,
			focus: ""
		};
		_state.mount = !_proxyFormState.isValid || !!keepStateOptions.keepIsValid || !!keepStateOptions.keepDirtyValues || !_options.shouldUnregister && !isEmptyObject(values);
		_state.watch = !!_options.shouldUnregister;
		_state.keepIsValid = !!keepStateOptions.keepIsValid;
		_state.action = false;
		if (!keepStateOptions.keepErrors) _formState.errors = {};
		_subjects.state.next({
			submitCount: keepStateOptions.keepSubmitCount ? _formState.submitCount : 0,
			isDirty: isEmptyResetValues ? false : keepStateOptions.keepDirty ? _formState.isDirty : keepStateOptions.keepValues ? _getDirty() : !!(keepStateOptions.keepDefaultValues && !deepEqual(formValues, _defaultValues)),
			isSubmitted: keepStateOptions.keepIsSubmitted ? _formState.isSubmitted : false,
			dirtyFields: isEmptyResetValues ? {} : keepStateOptions.keepDirtyValues ? keepStateOptions.keepDefaultValues && _formValues ? getDirtyFields(_defaultValues, _formValues, void 0, fieldRefs) : _formState.dirtyFields : keepStateOptions.keepDefaultValues && formValues ? getDirtyFields(_defaultValues, formValues, void 0, fieldRefs) : keepStateOptions.keepDirty ? _formState.dirtyFields : {},
			touchedFields: keepStateOptions.keepTouched ? _formState.touchedFields : {},
			errors: keepStateOptions.keepErrors ? _formState.errors : {},
			isSubmitSuccessful: keepStateOptions.keepIsSubmitSuccessful ? _formState.isSubmitSuccessful : false,
			isSubmitting: false,
			defaultValues: _defaultValues
		});
	};
	const reset = (formValues, keepStateOptions) => _reset(isFunction(formValues) ? formValues(_formValues) : formValues, {
		..._options.resetOptions,
		...keepStateOptions
	});
	const setFocus = (name, options = {}) => {
		const field = get(_fields, name);
		const fieldReference = field && field._f;
		if (fieldReference) {
			const fieldRef = fieldReference.refs ? fieldReference.refs[0] : fieldReference.ref;
			if (fieldRef.focus) setTimeout(() => {
				fieldRef.focus();
				options.shouldSelect && isFunction(fieldRef.select) && fieldRef.select();
			});
		}
	};
	const _setFormState = (updatedFormState) => {
		const { name, type, values, ...formState } = updatedFormState;
		_formState = {
			..._formState,
			...formState
		};
	};
	const _resetDefaultValues = () => isFunction(_options.defaultValues) && _options.defaultValues().then((values) => {
		reset(values, _options.resetOptions);
		_subjects.state.next({ isLoading: false });
	});
	const resetDefaultValues = (values, options = {}) => {
		_defaultValues = cloneObject(values);
		if (!options.keepDirty) {
			const newDirtyFields = getDirtyFields(_defaultValues, _formValues, void 0, _fields);
			_formState.dirtyFields = newDirtyFields;
			_formState.isDirty = !isEmptyObject(newDirtyFields);
		}
		if (!options.keepIsValid) _setValid();
		_subjects.state.next({
			..._formState,
			defaultValues: _defaultValues
		});
	};
	const methods = {
		control: {
			register,
			unregister,
			getFieldState,
			handleSubmit,
			setError,
			_subscribe,
			_runSchema,
			_updateIsValidating,
			_focusError,
			_getWatch,
			_getDirty,
			_setValid,
			_setFieldArray,
			_setDisabledField,
			_setErrors,
			_getFieldArray,
			_reset,
			_resetDefaultValues,
			_removeUnmounted,
			_disableForm,
			_subjects,
			_proxyFormState,
			get _fields() {
				return _fields;
			},
			get _formValues() {
				return _formValues;
			},
			get _state() {
				return _state;
			},
			set _state(value) {
				_state = value;
			},
			get _defaultValues() {
				return _defaultValues;
			},
			get _names() {
				return _names;
			},
			set _names(value) {
				_names = value;
			},
			get _formState() {
				return _formState;
			},
			get _options() {
				return _options;
			},
			set _options(value) {
				_options = {
					..._options,
					...value
				};
				_validationModeBeforeSubmit = getValidationModes(_options.mode);
				_validationModeAfterSubmit = getValidationModes(_options.reValidateMode);
			}
		},
		subscribe,
		trigger,
		register,
		handleSubmit,
		watch,
		setValue,
		setValues,
		getValues,
		reset,
		resetField,
		resetDefaultValues,
		clearErrors,
		unregister,
		setError,
		setFocus,
		getFieldState
	};
	return {
		...methods,
		formControl: methods
	};
}
/**
* Custom hook to manage the entire form.
*
* @remarks
* [API](https://react-hook-form.com/docs/useform) • [Demo](https://codesandbox.io/s/react-hook-form-get-started-ts-5ksmm) • [Video](https://www.youtube.com/watch?v=RkXv4AXXC_4)
*
* @param props - form configuration and validation parameters.
*
* @returns methods - individual functions to manage the form state. {@link UseFormReturn}
*
* @example
* ```tsx
* function App() {
*   const { register, handleSubmit, watch, formState: { errors } } = useForm();
*   const onSubmit = data => console.log(data);
*
*   console.log(watch("example"));
*
*   return (
*     <form onSubmit={handleSubmit(onSubmit)}>
*       <input defaultValue="test" {...register("example")} />
*       <input {...register("exampleRequired", { required: true })} />
*       {errors.exampleRequired && <span>This field is required</span>}
*       <button>Submit</button>
*     </form>
*   );
* }
* ```
*/
function useForm(props = {}) {
	const _formControl = import_react.useRef(void 0);
	const _values = import_react.useRef(void 0);
	const _formControlProp = import_react.useRef(props.formControl);
	const [formState, updateFormState] = import_react.useState(() => ({
		...cloneObject(DEFAULT_FORM_STATE),
		isLoading: isFunction(props.defaultValues),
		errors: props.errors || {},
		disabled: props.disabled || false,
		defaultValues: isFunction(props.defaultValues) ? void 0 : props.defaultValues
	}));
	if (!_formControl.current || props.formControl && _formControlProp.current !== props.formControl) {
		_formControlProp.current = props.formControl;
		if (props.formControl) {
			_formControl.current = {
				...props.formControl,
				formState
			};
			if (props.defaultValues && !isFunction(props.defaultValues)) props.formControl.reset(props.defaultValues, props.resetOptions);
		} else {
			const { formControl, ...rest } = createFormControl(props);
			_formControl.current = {
				...rest,
				formState
			};
		}
	}
	const control = _formControl.current.control;
	control._options = props;
	useIsomorphicLayoutEffect(() => {
		const sub = control._subscribe({
			formState: control._proxyFormState,
			callback: () => updateFormState({
				...control._formState,
				defaultValues: control._defaultValues
			}),
			reRenderRoot: true
		});
		updateFormState((data) => ({
			...data,
			isReady: true
		}));
		control._formState.isReady = true;
		return sub;
	}, [control]);
	import_react.useEffect(() => control._disableForm(props.disabled), [control, props.disabled]);
	import_react.useEffect(() => {
		if (props.mode) control._options.mode = props.mode;
		if (props.reValidateMode) control._options.reValidateMode = props.reValidateMode;
	}, [
		control,
		props.mode,
		props.reValidateMode
	]);
	import_react.useEffect(() => {
		if (props.errors) {
			control._setErrors(props.errors);
			control._focusError();
		}
	}, [control, props.errors]);
	import_react.useEffect(() => {
		props.shouldUnregister && control._subjects.state.next({ values: control._getWatch() });
	}, [control, props.shouldUnregister]);
	import_react.useEffect(() => {
		if (control._proxyFormState.isDirty) {
			const isDirty = control._getDirty();
			if (isDirty !== formState.isDirty) control._subjects.state.next({ isDirty });
		}
	}, [control, formState.isDirty]);
	import_react.useEffect(() => {
		var _a;
		if (props.values && !deepEqual(props.values, _values.current)) {
			control._reset(props.values, {
				keepFieldsRef: true,
				...control._options.resetOptions
			});
			if (!((_a = control._options.resetOptions) === null || _a === void 0 ? void 0 : _a.keepIsValid)) control._setValid();
			_values.current = props.values;
			updateFormState((state) => ({ ...state }));
		} else control._resetDefaultValues();
	}, [control, props.values]);
	import_react.useEffect(() => {
		if (!control._state.mount) {
			control._setValid();
			control._state.mount = true;
		}
		if (control._state.watch) {
			control._state.watch = false;
			control._subjects.state.next({ ...control._formState });
		}
		control._removeUnmounted();
	});
	_formControl.current.formState = import_react.useMemo(() => getProxyFormState(formState, control), [control, formState]);
	return _formControl.current;
}
/**
* Watch component that subscribes to form field changes and re-renders when watched fields update.
*
* @param control - The form control object from useForm
* @param name - Can be field name, array of field names, or undefined to watch the entire form
* @param disabled - Disable subscription
* @param exact - Whether to watch exact field names or not
* @param defaultValue - The default value to use if the field is not yet set
* @param compute - Function to compute derived values from watched fields
* @param render - The function that receives watched values and returns ReactNode
* @returns The result of calling render function with watched values
*
* @example
* The `Watch` component only re-render when the values of `foo`, `bar`, and `baz.qux` change.
* The types of `foo`, `bar`, and `baz.qux` are precisely inferred.
*
* ```tsx
* const { control } = useForm();
*
* <Watch
*   control={control}
*   names={['foo', 'bar', 'baz.qux']}
*   render={([foo, bar, baz_qux]) => <div>{foo}{bar}{baz_qux}</div>}
* />
* ```
*/
var Watch = (props) => props.render(useWatch({
	name: props.names,
	...props
}));
//#endregion
export { Controller, FieldArray, Form, FormProvider, FormStateSubscribe, Watch, appendErrors, createFormControl, get, set, useController, useFieldArray, useForm, useFormContext, useFormState, useWatch };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVhY3QtaG9vay1mb3JtLmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uL3JlYWN0LWhvb2stZm9ybS9kaXN0L2luZGV4LmVzbS5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcblxudmFyIGlzQ2hlY2tCb3hJbnB1dCA9IChlbGVtZW50KSA9PiBlbGVtZW50LnR5cGUgPT09ICdjaGVja2JveCc7XG5cbnZhciBpc0RhdGVPYmplY3QgPSAodmFsdWUpID0+IHZhbHVlIGluc3RhbmNlb2YgRGF0ZTtcblxudmFyIGlzTnVsbE9yVW5kZWZpbmVkID0gKHZhbHVlKSA9PiB2YWx1ZSA9PSBudWxsO1xuXG5jb25zdCBpc09iamVjdFR5cGUgPSAodmFsdWUpID0+IHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCc7XG52YXIgaXNPYmplY3QgPSAodmFsdWUpID0+ICFpc051bGxPclVuZGVmaW5lZCh2YWx1ZSkgJiZcbiAgICAhQXJyYXkuaXNBcnJheSh2YWx1ZSkgJiZcbiAgICBpc09iamVjdFR5cGUodmFsdWUpICYmXG4gICAgIWlzRGF0ZU9iamVjdCh2YWx1ZSk7XG5cbnZhciBnZXRFdmVudFZhbHVlID0gKGV2ZW50KSA9PiBpc09iamVjdChldmVudCkgJiYgZXZlbnQudGFyZ2V0XG4gICAgPyBpc0NoZWNrQm94SW5wdXQoZXZlbnQudGFyZ2V0KVxuICAgICAgICA/IGV2ZW50LnRhcmdldC5jaGVja2VkXG4gICAgICAgIDogZXZlbnQudGFyZ2V0LnZhbHVlXG4gICAgOiBldmVudDtcblxudmFyIGlzTmFtZUluRmllbGRBcnJheSA9IChuYW1lcywgbmFtZSkgPT4gbmFtZVxuICAgIC5zcGxpdCgnLicpXG4gICAgLnNvbWUoKHBhcnQsIGluZGV4LCBhcnIpID0+ICFpc05hTihOdW1iZXIocGFydCkpICYmIG5hbWVzLmhhcyhhcnIuc2xpY2UoMCwgaW5kZXgpLmpvaW4oJy4nKSkpO1xuXG52YXIgaXNQbGFpbk9iamVjdCA9ICh0ZW1wT2JqZWN0KSA9PiB7XG4gICAgY29uc3QgcHJvdG90eXBlQ29weSA9IHRlbXBPYmplY3QuY29uc3RydWN0b3IgJiYgdGVtcE9iamVjdC5jb25zdHJ1Y3Rvci5wcm90b3R5cGU7XG4gICAgcmV0dXJuIChpc09iamVjdChwcm90b3R5cGVDb3B5KSAmJiBwcm90b3R5cGVDb3B5Lmhhc093blByb3BlcnR5KCdpc1Byb3RvdHlwZU9mJykpO1xufTtcblxudmFyIGlzV2ViID0gdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICB0eXBlb2Ygd2luZG93LkhUTUxFbGVtZW50ICE9PSAndW5kZWZpbmVkJyAmJlxuICAgIHR5cGVvZiBkb2N1bWVudCAhPT0gJ3VuZGVmaW5lZCc7XG5cbmZ1bmN0aW9uIGNsb25lT2JqZWN0KGRhdGEpIHtcbiAgICBpZiAoZGF0YSBpbnN0YW5jZW9mIERhdGUpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBEYXRlKGRhdGEpO1xuICAgIH1cbiAgICBjb25zdCBpc0ZpbGVMaXN0SW5zdGFuY2UgPSB0eXBlb2YgRmlsZUxpc3QgIT09ICd1bmRlZmluZWQnICYmIGRhdGEgaW5zdGFuY2VvZiBGaWxlTGlzdDtcbiAgICBpZiAoaXNXZWIgJiYgKGRhdGEgaW5zdGFuY2VvZiBCbG9iIHx8IGlzRmlsZUxpc3RJbnN0YW5jZSkpIHtcbiAgICAgICAgcmV0dXJuIGRhdGE7XG4gICAgfVxuICAgIGNvbnN0IGlzQXJyYXkgPSBBcnJheS5pc0FycmF5KGRhdGEpO1xuICAgIGlmICghaXNBcnJheSAmJiAhKGlzT2JqZWN0KGRhdGEpICYmIGlzUGxhaW5PYmplY3QoZGF0YSkpKSB7XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgIH1cbiAgICBjb25zdCBjb3B5ID0gaXNBcnJheSA/IFtdIDogT2JqZWN0LmNyZWF0ZShPYmplY3QuZ2V0UHJvdG90eXBlT2YoZGF0YSkpO1xuICAgIGZvciAoY29uc3Qga2V5IGluIGRhdGEpIHtcbiAgICAgICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChkYXRhLCBrZXkpKSB7XG4gICAgICAgICAgICBjb3B5W2tleV0gPSBjbG9uZU9iamVjdChkYXRhW2tleV0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBjb3B5O1xufVxuXG5jb25zdCBFVkVOVFMgPSB7XG4gICAgQkxVUjogJ2JsdXInLFxuICAgIEZPQ1VTX09VVDogJ2ZvY3Vzb3V0JyxcbiAgICBDSEFOR0U6ICdjaGFuZ2UnLFxuICAgIFNVQk1JVDogJ3N1Ym1pdCcsXG4gICAgVFJJR0dFUjogJ3RyaWdnZXInLFxuICAgIFZBTElEOiAndmFsaWQnLFxufTtcbmNvbnN0IFZBTElEQVRJT05fTU9ERSA9IHtcbiAgICBvbkJsdXI6ICdvbkJsdXInLFxuICAgIG9uQ2hhbmdlOiAnb25DaGFuZ2UnLFxuICAgIG9uU3VibWl0OiAnb25TdWJtaXQnLFxuICAgIG9uVG91Y2hlZDogJ29uVG91Y2hlZCcsXG4gICAgYWxsOiAnYWxsJyxcbn07XG5jb25zdCBJTlBVVF9WQUxJREFUSU9OX1JVTEVTID0ge1xuICAgIG1heDogJ21heCcsXG4gICAgbWluOiAnbWluJyxcbiAgICBtYXhMZW5ndGg6ICdtYXhMZW5ndGgnLFxuICAgIG1pbkxlbmd0aDogJ21pbkxlbmd0aCcsXG4gICAgcGF0dGVybjogJ3BhdHRlcm4nLFxuICAgIHJlcXVpcmVkOiAncmVxdWlyZWQnLFxuICAgIHZhbGlkYXRlOiAndmFsaWRhdGUnLFxufTtcbmNvbnN0IFJPT1RfRVJST1JfVFlQRSA9ICdyb290JztcbmNvbnN0IFBST1RPVFlQRV9LRVlXT1JEUyA9IFsnX19wcm90b19fJywgJ2NvbnN0cnVjdG9yJywgJ3Byb3RvdHlwZSddO1xuXG5jb25zdCBJU19LRVlfUkUgPSAvXlxcdyokLztcbnZhciBpc0tleSA9ICh2YWx1ZSkgPT4gSVNfS0VZX1JFLnRlc3QodmFsdWUpO1xuXG52YXIgaXNVbmRlZmluZWQgPSAodmFsKSA9PiB2YWwgPT09IHVuZGVmaW5lZDtcblxuY29uc3QgRklFTERfUEFUSF9SRSA9IC9bLltcXF0nXCJdLztcbnZhciBzdHJpbmdUb1BhdGggPSAoaW5wdXQpID0+IGlucHV0LnNwbGl0KEZJRUxEX1BBVEhfUkUpLmZpbHRlcihCb29sZWFuKTtcblxudmFyIGdldCA9IChvYmplY3QsIHBhdGgsIGRlZmF1bHRWYWx1ZSkgPT4ge1xuICAgIGlmICghcGF0aCB8fCAhaXNPYmplY3Qob2JqZWN0KSkge1xuICAgICAgICByZXR1cm4gZGVmYXVsdFZhbHVlO1xuICAgIH1cbiAgICBjb25zdCBwYXRocyA9IGlzS2V5KHBhdGgpID8gW3BhdGhdIDogc3RyaW5nVG9QYXRoKHBhdGgpO1xuICAgIGlmIChwYXRocy5zb21lKChrZXkpID0+IFBST1RPVFlQRV9LRVlXT1JEUy5pbmNsdWRlcyhrZXkpKSkge1xuICAgICAgICByZXR1cm4gZGVmYXVsdFZhbHVlO1xuICAgIH1cbiAgICBjb25zdCByZXN1bHQgPSBwYXRocy5yZWR1Y2UoKHJlc3VsdCwga2V5KSA9PiB7XG4gICAgICAgIHJldHVybiBpc051bGxPclVuZGVmaW5lZChyZXN1bHQpID8gdW5kZWZpbmVkIDogcmVzdWx0W2tleV07XG4gICAgfSwgb2JqZWN0KTtcbiAgICByZXR1cm4gaXNVbmRlZmluZWQocmVzdWx0KSB8fCByZXN1bHQgPT09IG9iamVjdFxuICAgICAgICA/IGlzVW5kZWZpbmVkKG9iamVjdFtwYXRoXSlcbiAgICAgICAgICAgID8gZGVmYXVsdFZhbHVlXG4gICAgICAgICAgICA6IG9iamVjdFtwYXRoXVxuICAgICAgICA6IHJlc3VsdDtcbn07XG5cbnZhciBpc0Jvb2xlYW4gPSAodmFsdWUpID0+IHR5cGVvZiB2YWx1ZSA9PT0gJ2Jvb2xlYW4nO1xuXG52YXIgaXNGdW5jdGlvbiA9ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSAnZnVuY3Rpb24nO1xuXG52YXIgc2V0ID0gKG9iamVjdCwgcGF0aCwgdmFsdWUpID0+IHtcbiAgICBsZXQgaW5kZXggPSAtMTtcbiAgICBjb25zdCB0ZW1wUGF0aCA9IGlzS2V5KHBhdGgpID8gW3BhdGhdIDogc3RyaW5nVG9QYXRoKHBhdGgpO1xuICAgIGNvbnN0IGxlbmd0aCA9IHRlbXBQYXRoLmxlbmd0aDtcbiAgICBjb25zdCBsYXN0SW5kZXggPSBsZW5ndGggLSAxO1xuICAgIHdoaWxlICgrK2luZGV4IDwgbGVuZ3RoKSB7XG4gICAgICAgIGNvbnN0IGtleSA9IHRlbXBQYXRoW2luZGV4XTtcbiAgICAgICAgbGV0IG5ld1ZhbHVlID0gdmFsdWU7XG4gICAgICAgIGlmIChpbmRleCAhPT0gbGFzdEluZGV4KSB7XG4gICAgICAgICAgICBjb25zdCBvYmpWYWx1ZSA9IG9iamVjdFtrZXldO1xuICAgICAgICAgICAgbmV3VmFsdWUgPVxuICAgICAgICAgICAgICAgIGlzT2JqZWN0KG9ialZhbHVlKSB8fCBBcnJheS5pc0FycmF5KG9ialZhbHVlKVxuICAgICAgICAgICAgICAgICAgICA/IG9ialZhbHVlXG4gICAgICAgICAgICAgICAgICAgIDogIWlzTmFOKCt0ZW1wUGF0aFtpbmRleCArIDFdKVxuICAgICAgICAgICAgICAgICAgICAgICAgPyBbXVxuICAgICAgICAgICAgICAgICAgICAgICAgOiB7fTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoUFJPVE9UWVBFX0tFWVdPUkRTLmluY2x1ZGVzKGtleSkpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBvYmplY3Rba2V5XSA9IG5ld1ZhbHVlO1xuICAgICAgICBvYmplY3QgPSBvYmplY3Rba2V5XTtcbiAgICB9XG59O1xuXG4vKipcbiAqIFNlcGFyYXRlIGNvbnRleHQgZm9yIGBjb250cm9sYCB0byBwcmV2ZW50IHVubmVjZXNzYXJ5IHJlcmVuZGVycy5cbiAqIEludGVybmFsIGhvb2tzIHRoYXQgb25seSBuZWVkIGNvbnRyb2wgdXNlIHRoaXMgaW5zdGVhZCBvZiBmdWxsIGZvcm0gY29udGV4dC5cbiAqL1xuY29uc3QgSG9va0Zvcm1Db250cm9sQ29udGV4dCA9IFJlYWN0LmNyZWF0ZUNvbnRleHQobnVsbCk7XG5Ib29rRm9ybUNvbnRyb2xDb250ZXh0LmRpc3BsYXlOYW1lID0gJ0hvb2tGb3JtQ29udHJvbENvbnRleHQnO1xuLyoqXG4gKiBAaW50ZXJuYWwgSW50ZXJuYWwgaG9vayB0byBhY2Nlc3Mgb25seSBjb250cm9sIGZyb20gY29udGV4dC5cbiAqL1xuY29uc3QgdXNlRm9ybUNvbnRyb2xDb250ZXh0ID0gKCkgPT4gUmVhY3QudXNlQ29udGV4dChIb29rRm9ybUNvbnRyb2xDb250ZXh0KTtcblxudmFyIGdldFByb3h5Rm9ybVN0YXRlID0gKGZvcm1TdGF0ZSwgY29udHJvbCwgbG9jYWxQcm94eUZvcm1TdGF0ZSwgaXNSb290ID0gdHJ1ZSkgPT4ge1xuICAgIGNvbnN0IHJlc3VsdCA9IHt9O1xuICAgIGZvciAoY29uc3Qga2V5IGluIGZvcm1TdGF0ZSkge1xuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkocmVzdWx0LCBrZXksIHtcbiAgICAgICAgICAgIGdldDogKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IF9rZXkgPSBrZXk7XG4gICAgICAgICAgICAgICAgaWYgKGNvbnRyb2wuX3Byb3h5Rm9ybVN0YXRlW19rZXldICE9PSBWQUxJREFUSU9OX01PREUuYWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRyb2wuX3Byb3h5Rm9ybVN0YXRlW19rZXldID0gIWlzUm9vdCB8fCBWQUxJREFUSU9OX01PREUuYWxsO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBsb2NhbFByb3h5Rm9ybVN0YXRlICYmIChsb2NhbFByb3h5Rm9ybVN0YXRlW19rZXldID0gdHJ1ZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZvcm1TdGF0ZVtfa2V5XTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufTtcblxuY29uc3QgdXNlSXNvbW9ycGhpY0xheW91dEVmZmVjdCA9IGlzV2ViXG4gICAgPyBSZWFjdC51c2VMYXlvdXRFZmZlY3RcbiAgICA6IFJlYWN0LnVzZUVmZmVjdDtcblxuLyoqXG4gKiBUaGlzIGN1c3RvbSBob29rIGFsbG93cyB5b3UgdG8gc3Vic2NyaWJlIHRvIGVhY2ggZm9ybSBzdGF0ZSwgYW5kIGlzb2xhdGUgdGhlIHJlLXJlbmRlciBhdCB0aGUgY3VzdG9tIGhvb2sgbGV2ZWwuIEl0IGhhcyBpdHMgc2NvcGUgaW4gdGVybXMgb2YgZm9ybSBzdGF0ZSBzdWJzY3JpcHRpb24sIHNvIGl0IHdvdWxkIG5vdCBhZmZlY3Qgb3RoZXIgdXNlRm9ybVN0YXRlIGFuZCB1c2VGb3JtLiBVc2luZyB0aGlzIGhvb2sgY2FuIHJlZHVjZSB0aGUgcmUtcmVuZGVyIGltcGFjdCBvbiBsYXJnZSBhbmQgY29tcGxleCBmb3JtIGFwcGxpY2F0aW9uLlxuICpcbiAqIEByZW1hcmtzXG4gKiBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2Vmb3Jtc3RhdGUpIOKAoiBbRGVtb10oaHR0cHM6Ly9jb2Rlc2FuZGJveC5pby9zL3VzZWZvcm1zdGF0ZS03NXhseSlcbiAqXG4gKiBAcGFyYW0gcHJvcHMgLSBpbmNsdWRlIG9wdGlvbnMgb24gc3BlY2lmeSBmaWVsZHMgdG8gc3Vic2NyaWJlLiB7QGxpbmsgVXNlRm9ybVN0YXRlUmV0dXJufVxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c3hcbiAqIGZ1bmN0aW9uIEFwcCgpIHtcbiAqICAgY29uc3QgeyByZWdpc3RlciwgaGFuZGxlU3VibWl0LCBjb250cm9sIH0gPSB1c2VGb3JtKHtcbiAqICAgICBkZWZhdWx0VmFsdWVzOiB7XG4gKiAgICAgZmlyc3ROYW1lOiBcImZpcnN0TmFtZVwiXG4gKiAgIH19KTtcbiAqICAgY29uc3QgeyBkaXJ0eUZpZWxkcyB9ID0gdXNlRm9ybVN0YXRlKHtcbiAqICAgICBjb250cm9sXG4gKiAgIH0pO1xuICogICBjb25zdCBvblN1Ym1pdCA9IChkYXRhKSA9PiBjb25zb2xlLmxvZyhkYXRhKTtcbiAqXG4gKiAgIHJldHVybiAoXG4gKiAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChvblN1Ym1pdCl9PlxuICogICAgICAgPGlucHV0IHsuLi5yZWdpc3RlcihcImZpcnN0TmFtZVwiKX0gcGxhY2Vob2xkZXI9XCJGaXJzdCBOYW1lXCIgLz5cbiAqICAgICAgIHtkaXJ0eUZpZWxkcy5maXJzdE5hbWUgJiYgPHA+RmllbGQgaXMgZGlydHkuPC9wPn1cbiAqICAgICAgIDxpbnB1dCB0eXBlPVwic3VibWl0XCIgLz5cbiAqICAgICA8L2Zvcm0+XG4gKiAgICk7XG4gKiB9XG4gKiBgYGBcbiAqL1xuZnVuY3Rpb24gdXNlRm9ybVN0YXRlKHByb3BzKSB7XG4gICAgY29uc3QgZm9ybUNvbnRyb2wgPSB1c2VGb3JtQ29udHJvbENvbnRleHQoKTtcbiAgICBjb25zdCB7IGNvbnRyb2wgPSBmb3JtQ29udHJvbCwgZGlzYWJsZWQsIG5hbWUsIGV4YWN0IH0gPSBwcm9wcyB8fCB7fTtcbiAgICBjb25zdCBbZm9ybVN0YXRlLCB1cGRhdGVGb3JtU3RhdGVdID0gUmVhY3QudXNlU3RhdGUoKCkgPT4gKHtcbiAgICAgICAgLi4uY29udHJvbC5fZm9ybVN0YXRlLFxuICAgICAgICBkZWZhdWx0VmFsdWVzOiBjb250cm9sLl9kZWZhdWx0VmFsdWVzLFxuICAgIH0pKTtcbiAgICBjb25zdCBfbG9jYWxQcm94eUZvcm1TdGF0ZSA9IFJlYWN0LnVzZVJlZih7XG4gICAgICAgIGlzRGlydHk6IGZhbHNlLFxuICAgICAgICBpc0xvYWRpbmc6IGZhbHNlLFxuICAgICAgICBkaXJ0eUZpZWxkczogZmFsc2UsXG4gICAgICAgIHRvdWNoZWRGaWVsZHM6IGZhbHNlLFxuICAgICAgICB2YWxpZGF0aW5nRmllbGRzOiBmYWxzZSxcbiAgICAgICAgaXNWYWxpZGF0aW5nOiBmYWxzZSxcbiAgICAgICAgaXNWYWxpZDogZmFsc2UsXG4gICAgICAgIGVycm9yczogZmFsc2UsXG4gICAgfSk7XG4gICAgdXNlSXNvbW9ycGhpY0xheW91dEVmZmVjdCgoKSA9PiBjb250cm9sLl9zdWJzY3JpYmUoe1xuICAgICAgICBuYW1lLFxuICAgICAgICBmb3JtU3RhdGU6IF9sb2NhbFByb3h5Rm9ybVN0YXRlLmN1cnJlbnQsXG4gICAgICAgIGV4YWN0LFxuICAgICAgICBjYWxsYmFjazogKGZvcm1TdGF0ZSkgPT4ge1xuICAgICAgICAgICAgIWRpc2FibGVkICYmXG4gICAgICAgICAgICAgICAgdXBkYXRlRm9ybVN0YXRlKHtcbiAgICAgICAgICAgICAgICAgICAgLi4uY29udHJvbC5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgICAgICAuLi5mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZXM6IGNvbnRyb2wuX2RlZmF1bHRWYWx1ZXMsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgfSksIFtuYW1lLCBkaXNhYmxlZCwgZXhhY3RdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBfbG9jYWxQcm94eUZvcm1TdGF0ZS5jdXJyZW50LmlzVmFsaWQgJiYgY29udHJvbC5fc2V0VmFsaWQodHJ1ZSk7XG4gICAgfSwgW2NvbnRyb2xdKTtcbiAgICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiBnZXRQcm94eUZvcm1TdGF0ZShmb3JtU3RhdGUsIGNvbnRyb2wsIF9sb2NhbFByb3h5Rm9ybVN0YXRlLmN1cnJlbnQsIGZhbHNlKSwgW2Zvcm1TdGF0ZSwgY29udHJvbF0pO1xufVxuXG52YXIgaXNTdHJpbmcgPSAodmFsdWUpID0+IHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZyc7XG5cbnZhciBnZW5lcmF0ZVdhdGNoT3V0cHV0ID0gKG5hbWVzLCBfbmFtZXMsIGZvcm1WYWx1ZXMsIGlzR2xvYmFsLCBkZWZhdWx0VmFsdWUpID0+IHtcbiAgICBpZiAoaXNTdHJpbmcobmFtZXMpKSB7XG4gICAgICAgIGlzR2xvYmFsICYmIF9uYW1lcy53YXRjaC5hZGQobmFtZXMpO1xuICAgICAgICByZXR1cm4gZ2V0KGZvcm1WYWx1ZXMsIG5hbWVzLCBkZWZhdWx0VmFsdWUpO1xuICAgIH1cbiAgICBpZiAoQXJyYXkuaXNBcnJheShuYW1lcykpIHtcbiAgICAgICAgcmV0dXJuIG5hbWVzLm1hcCgoZmllbGROYW1lKSA9PiAoaXNHbG9iYWwgJiYgX25hbWVzLndhdGNoLmFkZChmaWVsZE5hbWUpLFxuICAgICAgICAgICAgZ2V0KGZvcm1WYWx1ZXMsIGZpZWxkTmFtZSkpKTtcbiAgICB9XG4gICAgaXNHbG9iYWwgJiYgKF9uYW1lcy53YXRjaEFsbCA9IHRydWUpO1xuICAgIHJldHVybiBmb3JtVmFsdWVzO1xufTtcblxudmFyIGlzUHJpbWl0aXZlID0gKHZhbHVlKSA9PiBpc051bGxPclVuZGVmaW5lZCh2YWx1ZSkgfHwgIWlzT2JqZWN0VHlwZSh2YWx1ZSk7XG5cbmNvbnN0IGlzRW1wdHlPYmplY3RXaXRoQ3VzdG9tUHJvdG90eXBlID0gKG9iamVjdCwga2V5cykgPT4ga2V5cy5sZW5ndGggPT09IDAgJiYgIUFycmF5LmlzQXJyYXkob2JqZWN0KSAmJiAhaXNQbGFpbk9iamVjdChvYmplY3QpO1xuZnVuY3Rpb24gZGVlcEVxdWFsKG9iamVjdDEsIG9iamVjdDIsIHZpc2l0ZWQgPSBuZXcgV2Vha01hcCgpKSB7XG4gICAgaWYgKG9iamVjdDEgPT09IG9iamVjdDIpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmIChpc1ByaW1pdGl2ZShvYmplY3QxKSB8fCBpc1ByaW1pdGl2ZShvYmplY3QyKSkge1xuICAgICAgICByZXR1cm4gT2JqZWN0LmlzKG9iamVjdDEsIG9iamVjdDIpO1xuICAgIH1cbiAgICBpZiAoaXNEYXRlT2JqZWN0KG9iamVjdDEpICYmIGlzRGF0ZU9iamVjdChvYmplY3QyKSkge1xuICAgICAgICByZXR1cm4gT2JqZWN0LmlzKG9iamVjdDEuZ2V0VGltZSgpLCBvYmplY3QyLmdldFRpbWUoKSk7XG4gICAgfVxuICAgIGNvbnN0IGtleXMxID0gT2JqZWN0LmtleXMob2JqZWN0MSk7XG4gICAgY29uc3Qga2V5czIgPSBPYmplY3Qua2V5cyhvYmplY3QyKTtcbiAgICBpZiAoa2V5czEubGVuZ3RoICE9PSBrZXlzMi5sZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpZiAoaXNFbXB0eU9iamVjdFdpdGhDdXN0b21Qcm90b3R5cGUob2JqZWN0MSwga2V5czEpIHx8XG4gICAgICAgIGlzRW1wdHlPYmplY3RXaXRoQ3VzdG9tUHJvdG90eXBlKG9iamVjdDIsIGtleXMyKSkge1xuICAgICAgICByZXR1cm4gT2JqZWN0LmlzKG9iamVjdDEsIG9iamVjdDIpO1xuICAgIH1cbiAgICBpZiAoIWtleXMxLmxlbmd0aCAmJiBBcnJheS5pc0FycmF5KG9iamVjdDEpICE9PSBBcnJheS5pc0FycmF5KG9iamVjdDIpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgY29uc3QgdmlzaXRlZFBhaXJzID0gdmlzaXRlZC5nZXQob2JqZWN0MSk7XG4gICAgaWYgKHZpc2l0ZWRQYWlycyAmJiB2aXNpdGVkUGFpcnMuaGFzKG9iamVjdDIpKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAodmlzaXRlZFBhaXJzKSB7XG4gICAgICAgIHZpc2l0ZWRQYWlycy5hZGQob2JqZWN0Mik7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBjb25zdCB3cyA9IG5ldyBXZWFrU2V0KCk7XG4gICAgICAgIHdzLmFkZChvYmplY3QyKTtcbiAgICAgICAgdmlzaXRlZC5zZXQob2JqZWN0MSwgd3MpO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IGtleSBvZiBrZXlzMSkge1xuICAgICAgICBjb25zdCB2YWwxID0gb2JqZWN0MVtrZXldO1xuICAgICAgICBpZiAoIShrZXkgaW4gb2JqZWN0MikpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoa2V5ICE9PSAncmVmJykge1xuICAgICAgICAgICAgY29uc3QgdmFsMiA9IG9iamVjdDJba2V5XTtcbiAgICAgICAgICAgIGlmICgoaXNEYXRlT2JqZWN0KHZhbDEpICYmIGlzRGF0ZU9iamVjdCh2YWwyKSkgfHxcbiAgICAgICAgICAgICAgICAoKGlzT2JqZWN0KHZhbDEpIHx8IEFycmF5LmlzQXJyYXkodmFsMSkpICYmXG4gICAgICAgICAgICAgICAgICAgIChpc09iamVjdCh2YWwyKSB8fCBBcnJheS5pc0FycmF5KHZhbDIpKSlcbiAgICAgICAgICAgICAgICA/ICFkZWVwRXF1YWwodmFsMSwgdmFsMiwgdmlzaXRlZClcbiAgICAgICAgICAgICAgICA6ICFPYmplY3QuaXModmFsMSwgdmFsMikpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG59XG5cbi8qKlxuICogQ3VzdG9tIGhvb2sgdG8gc3Vic2NyaWJlIHRvIGZpZWxkIGNoYW5nZSBhbmQgaXNvbGF0ZSByZS1yZW5kZXJpbmcgYXQgdGhlIGNvbXBvbmVudCBsZXZlbC5cbiAqXG4gKiBAcmVtYXJrc1xuICpcbiAqIFtBUEldKGh0dHBzOi8vcmVhY3QtaG9vay1mb3JtLmNvbS9kb2NzL3VzZXdhdGNoKSDigKIgW0RlbW9dKGh0dHBzOi8vY29kZXNhbmRib3guaW8vcy9yZWFjdC1ob29rLWZvcm0tdjctdHMtdXNld2F0Y2gtaDlpNWUpXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogY29uc3QgeyBjb250cm9sIH0gPSB1c2VGb3JtKCk7XG4gKiBjb25zdCB2YWx1ZXMgPSB1c2VXYXRjaCh7XG4gKiAgIG5hbWU6IFwiZmllbGROYW1lXCJcbiAqICAgY29udHJvbCxcbiAqIH0pXG4gKiBgYGBcbiAqL1xuZnVuY3Rpb24gdXNlV2F0Y2gocHJvcHMpIHtcbiAgICBjb25zdCBmb3JtQ29udHJvbCA9IHVzZUZvcm1Db250cm9sQ29udGV4dCgpO1xuICAgIGNvbnN0IHsgY29udHJvbCA9IGZvcm1Db250cm9sLCBuYW1lLCBkZWZhdWx0VmFsdWUsIGRpc2FibGVkLCBleGFjdCwgY29tcHV0ZSwgfSA9IHByb3BzIHx8IHt9O1xuICAgIGNvbnN0IF9kZWZhdWx0VmFsdWUgPSBSZWFjdC51c2VSZWYoZGVmYXVsdFZhbHVlKTtcbiAgICBjb25zdCBfY29tcHV0ZSA9IFJlYWN0LnVzZVJlZihjb21wdXRlKTtcbiAgICBjb25zdCBfY29tcHV0ZUZvcm1WYWx1ZXMgPSBSZWFjdC51c2VSZWYodW5kZWZpbmVkKTtcbiAgICBjb25zdCBfcHJldkNvbnRyb2wgPSBSZWFjdC51c2VSZWYoY29udHJvbCk7XG4gICAgY29uc3QgX3ByZXZOYW1lID0gUmVhY3QudXNlUmVmKG5hbWUpO1xuICAgIF9jb21wdXRlLmN1cnJlbnQgPSBjb21wdXRlO1xuICAgIGNvbnN0IFt2YWx1ZSwgdXBkYXRlVmFsdWVdID0gUmVhY3QudXNlU3RhdGUoKCkgPT4ge1xuICAgICAgICBjb25zdCBkZWZhdWx0VmFsdWUgPSBjb250cm9sLl9nZXRXYXRjaChuYW1lLCBfZGVmYXVsdFZhbHVlLmN1cnJlbnQpO1xuICAgICAgICByZXR1cm4gX2NvbXB1dGUuY3VycmVudCA/IF9jb21wdXRlLmN1cnJlbnQoZGVmYXVsdFZhbHVlKSA6IGRlZmF1bHRWYWx1ZTtcbiAgICB9KTtcbiAgICBjb25zdCBnZXRDdXJyZW50T3V0cHV0ID0gUmVhY3QudXNlQ2FsbGJhY2soKHZhbHVlcykgPT4ge1xuICAgICAgICBjb25zdCBmb3JtVmFsdWVzID0gZ2VuZXJhdGVXYXRjaE91dHB1dChuYW1lLCBjb250cm9sLl9uYW1lcywgdmFsdWVzIHx8IGNvbnRyb2wuX2Zvcm1WYWx1ZXMsIGZhbHNlLCBfZGVmYXVsdFZhbHVlLmN1cnJlbnQpO1xuICAgICAgICByZXR1cm4gX2NvbXB1dGUuY3VycmVudCA/IF9jb21wdXRlLmN1cnJlbnQoZm9ybVZhbHVlcykgOiBmb3JtVmFsdWVzO1xuICAgIH0sIFtjb250cm9sLl9mb3JtVmFsdWVzLCBjb250cm9sLl9uYW1lcywgbmFtZV0pO1xuICAgIGNvbnN0IHJlZnJlc2hWYWx1ZSA9IFJlYWN0LnVzZUNhbGxiYWNrKCh2YWx1ZXMpID0+IHtcbiAgICAgICAgaWYgKCFkaXNhYmxlZCkge1xuICAgICAgICAgICAgY29uc3QgZm9ybVZhbHVlcyA9IGdlbmVyYXRlV2F0Y2hPdXRwdXQobmFtZSwgY29udHJvbC5fbmFtZXMsIHZhbHVlcyB8fCBjb250cm9sLl9mb3JtVmFsdWVzLCBmYWxzZSwgX2RlZmF1bHRWYWx1ZS5jdXJyZW50KTtcbiAgICAgICAgICAgIGlmIChfY29tcHV0ZS5jdXJyZW50KSB7XG4gICAgICAgICAgICAgICAgY29uc3QgY29tcHV0ZWRGb3JtVmFsdWVzID0gX2NvbXB1dGUuY3VycmVudChmb3JtVmFsdWVzKTtcbiAgICAgICAgICAgICAgICBpZiAoIWRlZXBFcXVhbChjb21wdXRlZEZvcm1WYWx1ZXMsIF9jb21wdXRlRm9ybVZhbHVlcy5jdXJyZW50KSkge1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVWYWx1ZShjb21wdXRlZEZvcm1WYWx1ZXMpO1xuICAgICAgICAgICAgICAgICAgICBfY29tcHV0ZUZvcm1WYWx1ZXMuY3VycmVudCA9IGNvbXB1dGVkRm9ybVZhbHVlcztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICB1cGRhdGVWYWx1ZShmb3JtVmFsdWVzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sIFtjb250cm9sLl9mb3JtVmFsdWVzLCBjb250cm9sLl9uYW1lcywgZGlzYWJsZWQsIG5hbWVdKTtcbiAgICB1c2VJc29tb3JwaGljTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKF9wcmV2Q29udHJvbC5jdXJyZW50ICE9PSBjb250cm9sIHx8XG4gICAgICAgICAgICAhZGVlcEVxdWFsKF9wcmV2TmFtZS5jdXJyZW50LCBuYW1lKSkge1xuICAgICAgICAgICAgX3ByZXZDb250cm9sLmN1cnJlbnQgPSBjb250cm9sO1xuICAgICAgICAgICAgX3ByZXZOYW1lLmN1cnJlbnQgPSBuYW1lO1xuICAgICAgICAgICAgcmVmcmVzaFZhbHVlKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNvbnRyb2wuX3N1YnNjcmliZSh7XG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgZm9ybVN0YXRlOiB7XG4gICAgICAgICAgICAgICAgdmFsdWVzOiB0cnVlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGV4YWN0LFxuICAgICAgICAgICAgY2FsbGJhY2s6IChmb3JtU3RhdGUpID0+IHtcbiAgICAgICAgICAgICAgICByZWZyZXNoVmFsdWUoZm9ybVN0YXRlLnZhbHVlcyk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9LCBbY29udHJvbCwgZXhhY3QsIG5hbWUsIHJlZnJlc2hWYWx1ZV0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiBjb250cm9sLl9yZW1vdmVVbm1vdW50ZWQoKSk7XG4gICAgLy8gSWYgbmFtZSBvciBjb250cm9sIGNoYW5nZWQgZm9yIHRoaXMgcmVuZGVyLCBzeW5jaHJvbm91c2x5IHJlZmxlY3QgdGhlXG4gICAgLy8gbGF0ZXN0IHZhbHVlIHNvIGNhbGxlcnMgKGxpa2UgdXNlQ29udHJvbGxlcikgc2VlIHRoZSBjb3JyZWN0IHZhbHVlXG4gICAgLy8gaW1tZWRpYXRlbHkgb24gdGhlIHNhbWUgcmVuZGVyLlxuICAgIC8vIE9wdGltaXplOiBDaGVjayBjb250cm9sIHJlZmVyZW5jZSBmaXJzdCBiZWZvcmUgZXhwZW5zaXZlIGRlZXBFcXVhbFxuICAgIGNvbnN0IGNvbnRyb2xDaGFuZ2VkID0gX3ByZXZDb250cm9sLmN1cnJlbnQgIT09IGNvbnRyb2w7XG4gICAgY29uc3QgcHJldk5hbWUgPSBfcHJldk5hbWUuY3VycmVudDtcbiAgICAvLyBDYWNoZSB0aGUgY29tcHV0ZWQgb3V0cHV0IHRvIGF2b2lkIGR1cGxpY2F0ZSBjYWxscyB3aXRoaW4gdGhlIHNhbWUgcmVuZGVyXG4gICAgLy8gV2UgaW5jbHVkZSBzaG91bGRSZXR1cm5JbW1lZGlhdGUgaW4gZGVwcyB0byBlbnN1cmUgcHJvcGVyIHJlY29tcHV0YXRpb25cbiAgICBjb25zdCBjb21wdXRlZE91dHB1dCA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG5hbWVDaGFuZ2VkID0gIWNvbnRyb2xDaGFuZ2VkICYmICFkZWVwRXF1YWwocHJldk5hbWUsIG5hbWUpO1xuICAgICAgICBjb25zdCBzaG91bGRSZXR1cm5JbW1lZGlhdGUgPSBjb250cm9sQ2hhbmdlZCB8fCBuYW1lQ2hhbmdlZDtcbiAgICAgICAgcmV0dXJuIHNob3VsZFJldHVybkltbWVkaWF0ZSA/IGdldEN1cnJlbnRPdXRwdXQoKSA6IG51bGw7XG4gICAgfSwgW2Rpc2FibGVkLCBjb250cm9sQ2hhbmdlZCwgbmFtZSwgcHJldk5hbWUsIGdldEN1cnJlbnRPdXRwdXRdKTtcbiAgICByZXR1cm4gY29tcHV0ZWRPdXRwdXQgIT09IG51bGwgPyBjb21wdXRlZE91dHB1dCA6IHZhbHVlO1xufVxuXG4vKipcbiAqIEN1c3RvbSBob29rIHRvIHdvcmsgd2l0aCBjb250cm9sbGVkIGNvbXBvbmVudCwgdGhpcyBmdW5jdGlvbiBwcm92aWRlIHlvdSB3aXRoIGJvdGggZm9ybSBhbmQgZmllbGQgbGV2ZWwgc3RhdGUuIFJlLXJlbmRlciBpcyBpc29sYXRlZCBhdCB0aGUgaG9vayBsZXZlbC5cbiAqXG4gKiBAcmVtYXJrc1xuICogW0FQSV0oaHR0cHM6Ly9yZWFjdC1ob29rLWZvcm0uY29tL2RvY3MvdXNlY29udHJvbGxlcikg4oCiIFtEZW1vXShodHRwczovL2NvZGVzYW5kYm94LmlvL3MvdXNlY29udHJvbGxlci0wbzhweClcbiAqXG4gKiBAcGFyYW0gcHJvcHMgLSB0aGUgcGF0aCBuYW1lIHRvIHRoZSBmb3JtIGZpZWxkIHZhbHVlLCBhbmQgdmFsaWRhdGlvbiBydWxlcy5cbiAqXG4gKiBAcmV0dXJucyBmaWVsZCBwcm9wZXJ0aWVzLCBmaWVsZCBhbmQgZm9ybSBzdGF0ZS4ge0BsaW5rIFVzZUNvbnRyb2xsZXJSZXR1cm59XG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogZnVuY3Rpb24gSW5wdXQocHJvcHMpIHtcbiAqICAgY29uc3QgeyBmaWVsZCwgZmllbGRTdGF0ZSwgZm9ybVN0YXRlIH0gPSB1c2VDb250cm9sbGVyKHByb3BzKTtcbiAqICAgcmV0dXJuIChcbiAqICAgICA8ZGl2PlxuICogICAgICAgPGlucHV0IHsuLi5maWVsZH0gcGxhY2Vob2xkZXI9e3Byb3BzLm5hbWV9IC8+XG4gKiAgICAgICA8cD57ZmllbGRTdGF0ZS5pc1RvdWNoZWQgJiYgXCJUb3VjaGVkXCJ9PC9wPlxuICogICAgICAgPHA+e2Zvcm1TdGF0ZS5pc1N1Ym1pdHRlZCA/IFwic3VibWl0dGVkXCIgOiBcIlwifTwvcD5cbiAqICAgICA8L2Rpdj5cbiAqICAgKTtcbiAqIH1cbiAqIGBgYFxuICovXG5mdW5jdGlvbiB1c2VDb250cm9sbGVyKHByb3BzKSB7XG4gICAgY29uc3QgZm9ybUNvbnRyb2wgPSB1c2VGb3JtQ29udHJvbENvbnRleHQoKTtcbiAgICBjb25zdCB7IG5hbWUsIGRpc2FibGVkLCBjb250cm9sID0gZm9ybUNvbnRyb2wsIHNob3VsZFVucmVnaXN0ZXIsIGRlZmF1bHRWYWx1ZSwgZXhhY3QgPSB0cnVlLCB9ID0gcHJvcHM7XG4gICAgY29uc3QgaXNBcnJheUZpZWxkID0gaXNOYW1lSW5GaWVsZEFycmF5KGNvbnRyb2wuX25hbWVzLmFycmF5LCBuYW1lKTtcbiAgICBjb25zdCBkZWZhdWx0VmFsdWVNZW1vID0gUmVhY3QudXNlTWVtbygoKSA9PiBnZXQoY29udHJvbC5fZm9ybVZhbHVlcywgbmFtZSwgZ2V0KGNvbnRyb2wuX2RlZmF1bHRWYWx1ZXMsIG5hbWUsIGRlZmF1bHRWYWx1ZSkpLCBbY29udHJvbCwgbmFtZSwgZGVmYXVsdFZhbHVlXSk7XG4gICAgY29uc3QgdmFsdWUgPSB1c2VXYXRjaCh7XG4gICAgICAgIGNvbnRyb2wsXG4gICAgICAgIG5hbWUsXG4gICAgICAgIGRlZmF1bHRWYWx1ZTogZGVmYXVsdFZhbHVlTWVtbyxcbiAgICAgICAgZXhhY3QsXG4gICAgfSk7XG4gICAgY29uc3QgZm9ybVN0YXRlID0gdXNlRm9ybVN0YXRlKHtcbiAgICAgICAgY29udHJvbCxcbiAgICAgICAgbmFtZSxcbiAgICAgICAgZXhhY3QsXG4gICAgfSk7XG4gICAgY29uc3QgX3Byb3BzID0gUmVhY3QudXNlUmVmKHByb3BzKTtcbiAgICBjb25zdCBfcHJveHlSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gICAgY29uc3QgX3JlZ2lzdGVyUHJvcHMgPSBSZWFjdC51c2VSZWYoY29udHJvbC5yZWdpc3RlcihuYW1lLCB7XG4gICAgICAgIC4uLnByb3BzLnJ1bGVzLFxuICAgICAgICB2YWx1ZSxcbiAgICAgICAgLi4uKGlzQm9vbGVhbihwcm9wcy5kaXNhYmxlZCkgPyB7IGRpc2FibGVkOiBwcm9wcy5kaXNhYmxlZCB9IDoge30pLFxuICAgIH0pKTtcbiAgICBfcHJvcHMuY3VycmVudCA9IHByb3BzO1xuICAgIGNvbnN0IGZpZWxkU3RhdGUgPSBSZWFjdC51c2VNZW1vKCgpID0+IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKHt9LCB7XG4gICAgICAgIGludmFsaWQ6IHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBnZXQ6ICgpID0+ICEhZ2V0KGZvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpLFxuICAgICAgICB9LFxuICAgICAgICBpc0RpcnR5OiB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgZ2V0OiAoKSA9PiAhIWdldChmb3JtU3RhdGUuZGlydHlGaWVsZHMsIG5hbWUpLFxuICAgICAgICB9LFxuICAgICAgICBpc1RvdWNoZWQ6IHtcbiAgICAgICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgICAgICBnZXQ6ICgpID0+ICEhZ2V0KGZvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBuYW1lKSxcbiAgICAgICAgfSxcbiAgICAgICAgaXNWYWxpZGF0aW5nOiB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgZ2V0OiAoKSA9PiAhIWdldChmb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcywgbmFtZSksXG4gICAgICAgIH0sXG4gICAgICAgIGVycm9yOiB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgZ2V0OiAoKSA9PiBnZXQoZm9ybVN0YXRlLmVycm9ycywgbmFtZSksXG4gICAgICAgIH0sXG4gICAgfSksIFtmb3JtU3RhdGUsIG5hbWVdKTtcbiAgICBjb25zdCBvbkNoYW5nZSA9IFJlYWN0LnVzZUNhbGxiYWNrKChldmVudCkgPT4ge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGdldEV2ZW50VmFsdWUoZXZlbnQpO1xuICAgICAgICBpZiAoIWdldChjb250cm9sLl9maWVsZHMsIG5hbWUpKSB7XG4gICAgICAgICAgICBfcmVnaXN0ZXJQcm9wcy5jdXJyZW50ID0gY29udHJvbC5yZWdpc3RlcihuYW1lLCB7XG4gICAgICAgICAgICAgICAgLi4uX3Byb3BzLmN1cnJlbnQucnVsZXMsXG4gICAgICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gX3JlZ2lzdGVyUHJvcHMuY3VycmVudC5vbkNoYW5nZSh7XG4gICAgICAgICAgICB0YXJnZXQ6IHtcbiAgICAgICAgICAgICAgICB2YWx1ZTogZ2V0RXZlbnRWYWx1ZShldmVudCksXG4gICAgICAgICAgICAgICAgbmFtZTogbmFtZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0eXBlOiBFVkVOVFMuQ0hBTkdFLFxuICAgICAgICB9KTtcbiAgICB9LCBbbmFtZSwgY29udHJvbF0pO1xuICAgIGNvbnN0IG9uQmx1ciA9IFJlYWN0LnVzZUNhbGxiYWNrKCgpID0+IF9yZWdpc3RlclByb3BzLmN1cnJlbnQub25CbHVyKHtcbiAgICAgICAgdGFyZ2V0OiB7XG4gICAgICAgICAgICB2YWx1ZTogZ2V0KGNvbnRyb2wuX2Zvcm1WYWx1ZXMsIG5hbWUpLFxuICAgICAgICAgICAgbmFtZTogbmFtZSxcbiAgICAgICAgfSxcbiAgICAgICAgdHlwZTogRVZFTlRTLkJMVVIsXG4gICAgfSksIFtuYW1lLCBjb250cm9sLl9mb3JtVmFsdWVzXSk7XG4gICAgY29uc3QgcmVmID0gUmVhY3QudXNlQ2FsbGJhY2soKGVsbSkgPT4ge1xuICAgICAgICBpZiAoZWxtKSB7XG4gICAgICAgICAgICBfcHJveHlSZWYuY3VycmVudCA9IHtcbiAgICAgICAgICAgICAgICBmb2N1czogKCkgPT4gaXNGdW5jdGlvbihlbG0uZm9jdXMpICYmIGVsbS5mb2N1cygpLFxuICAgICAgICAgICAgICAgIHNlbGVjdDogKCkgPT4gaXNGdW5jdGlvbihlbG0uc2VsZWN0KSAmJiBlbG0uc2VsZWN0KCksXG4gICAgICAgICAgICAgICAgc2V0Q3VzdG9tVmFsaWRpdHk6IChtZXNzYWdlKSA9PiBpc0Z1bmN0aW9uKGVsbS5zZXRDdXN0b21WYWxpZGl0eSkgJiYgZWxtLnNldEN1c3RvbVZhbGlkaXR5KG1lc3NhZ2UpLFxuICAgICAgICAgICAgICAgIHJlcG9ydFZhbGlkaXR5OiAoKSA9PiBpc0Z1bmN0aW9uKGVsbS5yZXBvcnRWYWxpZGl0eSkgJiYgZWxtLnJlcG9ydFZhbGlkaXR5KCksXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KGNvbnRyb2wuX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgIGlmIChmaWVsZCAmJiBmaWVsZC5fZiAmJiBlbG0pIHtcbiAgICAgICAgICAgIGZpZWxkLl9mLnJlZiA9IF9wcm94eVJlZi5jdXJyZW50O1xuICAgICAgICB9XG4gICAgfSwgW2NvbnRyb2wuX2ZpZWxkcywgbmFtZV0pO1xuICAgIGNvbnN0IGZpZWxkID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgICAgICBuYW1lLFxuICAgICAgICB2YWx1ZSxcbiAgICAgICAgLi4uKGlzQm9vbGVhbihkaXNhYmxlZCkgfHwgZm9ybVN0YXRlLmRpc2FibGVkXG4gICAgICAgICAgICA/IHsgZGlzYWJsZWQ6IGZvcm1TdGF0ZS5kaXNhYmxlZCB8fCBkaXNhYmxlZCB9XG4gICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgb25DaGFuZ2UsXG4gICAgICAgIG9uQmx1cixcbiAgICAgICAgcmVmLFxuICAgIH0pLCBbbmFtZSwgZGlzYWJsZWQsIGZvcm1TdGF0ZS5kaXNhYmxlZCwgb25DaGFuZ2UsIG9uQmx1ciwgcmVmLCB2YWx1ZV0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IF9zaG91bGRVbnJlZ2lzdGVyRmllbGQgPSBjb250cm9sLl9vcHRpb25zLnNob3VsZFVucmVnaXN0ZXIgfHwgc2hvdWxkVW5yZWdpc3RlcjtcbiAgICAgICAgY29udHJvbC5yZWdpc3RlcihuYW1lLCB7XG4gICAgICAgICAgICAuLi5fcHJvcHMuY3VycmVudC5ydWxlcyxcbiAgICAgICAgICAgIC4uLihpc0Jvb2xlYW4oX3Byb3BzLmN1cnJlbnQuZGlzYWJsZWQpXG4gICAgICAgICAgICAgICAgPyB7IGRpc2FibGVkOiBfcHJvcHMuY3VycmVudC5kaXNhYmxlZCB9XG4gICAgICAgICAgICAgICAgOiB7fSksXG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCB1cGRhdGVNb3VudGVkID0gKG5hbWUsIHZhbHVlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZCA9IGdldChjb250cm9sLl9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgaWYgKGZpZWxkICYmIGZpZWxkLl9mKSB7XG4gICAgICAgICAgICAgICAgZmllbGQuX2YubW91bnQgPSB2YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgdXBkYXRlTW91bnRlZChuYW1lLCB0cnVlKTtcbiAgICAgICAgaWYgKF9zaG91bGRVbnJlZ2lzdGVyRmllbGQpIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gY2xvbmVPYmplY3QoZ2V0KHNob3VsZFVucmVnaXN0ZXJcbiAgICAgICAgICAgICAgICA/IGNvbnRyb2wuX2RlZmF1bHRWYWx1ZXNcbiAgICAgICAgICAgICAgICA6IGNvbnRyb2wuX29wdGlvbnMudmFsdWVzIHx8IGNvbnRyb2wuX2RlZmF1bHRWYWx1ZXMsIG5hbWUsIGdldChjb250cm9sLl9vcHRpb25zLmRlZmF1bHRWYWx1ZXMsIG5hbWUsIF9wcm9wcy5jdXJyZW50LmRlZmF1bHRWYWx1ZSkpKTtcbiAgICAgICAgICAgIHNldChjb250cm9sLl9kZWZhdWx0VmFsdWVzLCBuYW1lLCB2YWx1ZSk7XG4gICAgICAgICAgICBpZiAoaXNVbmRlZmluZWQoZ2V0KGNvbnRyb2wuX2Zvcm1WYWx1ZXMsIG5hbWUpKSkge1xuICAgICAgICAgICAgICAgIHNldChjb250cm9sLl9mb3JtVmFsdWVzLCBuYW1lLCB2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgIWlzQXJyYXlGaWVsZCAmJiBjb250cm9sLnJlZ2lzdGVyKG5hbWUpO1xuICAgICAgICBpZiAoX3Byb3h5UmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KGNvbnRyb2wuX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICBpZiAoZmllbGQgJiYgZmllbGQuX2YpIHtcbiAgICAgICAgICAgICAgICBmaWVsZC5fZi5yZWYgPSBfcHJveHlSZWYuY3VycmVudDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgKGlzQXJyYXlGaWVsZFxuICAgICAgICAgICAgICAgID8gX3Nob3VsZFVucmVnaXN0ZXJGaWVsZCAmJiAhY29udHJvbC5fc3RhdGUuYWN0aW9uXG4gICAgICAgICAgICAgICAgOiBfc2hvdWxkVW5yZWdpc3RlckZpZWxkKVxuICAgICAgICAgICAgICAgID8gY29udHJvbC51bnJlZ2lzdGVyKG5hbWUpXG4gICAgICAgICAgICAgICAgOiB1cGRhdGVNb3VudGVkKG5hbWUsIGZhbHNlKTtcbiAgICAgICAgfTtcbiAgICB9LCBbbmFtZSwgY29udHJvbCwgaXNBcnJheUZpZWxkLCBzaG91bGRVbnJlZ2lzdGVyXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29udHJvbC5fc2V0RGlzYWJsZWRGaWVsZCh7XG4gICAgICAgICAgICBkaXNhYmxlZCxcbiAgICAgICAgICAgIG5hbWUsXG4gICAgICAgIH0pO1xuICAgIH0sIFtkaXNhYmxlZCwgbmFtZSwgY29udHJvbF0pO1xuICAgIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgICAgIGZpZWxkLFxuICAgICAgICBmb3JtU3RhdGUsXG4gICAgICAgIGZpZWxkU3RhdGUsXG4gICAgfSksIFtmaWVsZCwgZm9ybVN0YXRlLCBmaWVsZFN0YXRlXSk7XG59XG5cbi8qKlxuICogQ29tcG9uZW50IGJhc2VkIG9uIGB1c2VDb250cm9sbGVyYCBob29rIHRvIHdvcmsgd2l0aCBjb250cm9sbGVkIGNvbXBvbmVudC5cbiAqXG4gKiBAcmVtYXJrc1xuICogW0FQSV0oaHR0cHM6Ly9yZWFjdC1ob29rLWZvcm0uY29tL2RvY3MvdXNlY29udHJvbGxlci9jb250cm9sbGVyKSDigKIgW0RlbW9dKGh0dHBzOi8vY29kZXNhbmRib3guaW8vcy9yZWFjdC1ob29rLWZvcm0tdjYtY29udHJvbGxlci10cy1qd3l6dykg4oCiIFtWaWRlb10oaHR0cHM6Ly93d3cueW91dHViZS5jb20vd2F0Y2g/dj1OMlVOa19VQ1Z5QSlcbiAqXG4gKiBAcGFyYW0gcHJvcHMgLSB0aGUgcGF0aCBuYW1lIHRvIHRoZSBmb3JtIGZpZWxkIHZhbHVlLCBhbmQgdmFsaWRhdGlvbiBydWxlcy5cbiAqXG4gKiBAcmV0dXJucyBwcm92aWRlIGZpZWxkIGhhbmRsZXIgZnVuY3Rpb25zLCBmaWVsZCBhbmQgZm9ybSBzdGF0ZS5cbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiBmdW5jdGlvbiBBcHAoKSB7XG4gKiAgIGNvbnN0IHsgY29udHJvbCB9ID0gdXNlRm9ybTxGb3JtVmFsdWVzPih7XG4gKiAgICAgZGVmYXVsdFZhbHVlczoge1xuICogICAgICAgdGVzdDogXCJcIlxuICogICAgIH1cbiAqICAgfSk7XG4gKlxuICogICByZXR1cm4gKFxuICogICAgIDxmb3JtPlxuICogICAgICAgPENvbnRyb2xsZXJcbiAqICAgICAgICAgY29udHJvbD17Y29udHJvbH1cbiAqICAgICAgICAgbmFtZT1cInRlc3RcIlxuICogICAgICAgICByZW5kZXI9eyh7IGZpZWxkOiB7IG9uQ2hhbmdlLCBvbkJsdXIsIHZhbHVlLCByZWYgfSwgZm9ybVN0YXRlLCBmaWVsZFN0YXRlIH0pID0+IChcbiAqICAgICAgICAgICA8PlxuICogICAgICAgICAgICAgPGlucHV0XG4gKiAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtvbkNoYW5nZX0gLy8gc2VuZCB2YWx1ZSB0byBob29rIGZvcm1cbiAqICAgICAgICAgICAgICAgb25CbHVyPXtvbkJsdXJ9IC8vIG5vdGlmeSB3aGVuIGlucHV0IGlzIHRvdWNoZWRcbiAqICAgICAgICAgICAgICAgdmFsdWU9e3ZhbHVlfSAvLyByZXR1cm4gdXBkYXRlZCB2YWx1ZVxuICogICAgICAgICAgICAgICByZWY9e3JlZn0gLy8gc2V0IHJlZiBmb3IgZm9jdXMgbWFuYWdlbWVudFxuICogICAgICAgICAgICAgLz5cbiAqICAgICAgICAgICAgIDxwPntmb3JtU3RhdGUuaXNTdWJtaXR0ZWQgPyBcInN1Ym1pdHRlZFwiIDogXCJcIn08L3A+XG4gKiAgICAgICAgICAgICA8cD57ZmllbGRTdGF0ZS5pc1RvdWNoZWQgPyBcInRvdWNoZWRcIiA6IFwiXCJ9PC9wPlxuICogICAgICAgICAgIDwvPlxuICogICAgICAgICApfVxuICogICAgICAgLz5cbiAqICAgICA8L2Zvcm0+XG4gKiAgICk7XG4gKiB9XG4gKiBgYGBcbiAqL1xuY29uc3QgQ29udHJvbGxlciA9IChwcm9wcykgPT4gcHJvcHMucmVuZGVyKHVzZUNvbnRyb2xsZXIocHJvcHMpKTtcblxudmFyIGdlbmVyYXRlSWQgPSAoKSA9PiB7XG4gICAgaWYgKHR5cGVvZiBjcnlwdG8gIT09ICd1bmRlZmluZWQnICYmIGNyeXB0by5yYW5kb21VVUlEKSB7XG4gICAgICAgIHJldHVybiBjcnlwdG8ucmFuZG9tVVVJRCgpO1xuICAgIH1cbiAgICBjb25zdCBkID0gdHlwZW9mIHBlcmZvcm1hbmNlID09PSAndW5kZWZpbmVkJyA/IERhdGUubm93KCkgOiBwZXJmb3JtYW5jZS5ub3coKSAqIDEwMDA7XG4gICAgcmV0dXJuICd4eHh4eHh4eC14eHh4LTR4eHgteXh4eC14eHh4eHh4eHh4eHgnLnJlcGxhY2UoL1t4eV0vZywgKGMpID0+IHtcbiAgICAgICAgY29uc3QgciA9ICgoTWF0aC5yYW5kb20oKSAqIDE2ICsgZCkgJSAxNikgfCAwO1xuICAgICAgICByZXR1cm4gKGMgPT0gJ3gnID8gciA6IChyICYgMHgzKSB8IDB4OCkudG9TdHJpbmcoMTYpO1xuICAgIH0pO1xufTtcblxudmFyIGdldEZvY3VzRmllbGROYW1lID0gKG5hbWUsIGluZGV4LCBvcHRpb25zID0ge30pID0+IG9wdGlvbnMuc2hvdWxkRm9jdXMgfHwgaXNVbmRlZmluZWQob3B0aW9ucy5zaG91bGRGb2N1cylcbiAgICA/IG9wdGlvbnMuZm9jdXNOYW1lIHx8XG4gICAgICAgIGAke25hbWV9LiR7aXNVbmRlZmluZWQob3B0aW9ucy5mb2N1c0luZGV4KSA/IGluZGV4IDogb3B0aW9ucy5mb2N1c0luZGV4fS5gXG4gICAgOiAnJztcblxudmFyIGdldFZhbGlkYXRpb25Nb2RlcyA9IChtb2RlKSA9PiAoe1xuICAgIGlzT25TdWJtaXQ6ICFtb2RlIHx8IG1vZGUgPT09IFZBTElEQVRJT05fTU9ERS5vblN1Ym1pdCxcbiAgICBpc09uQmx1cjogbW9kZSA9PT0gVkFMSURBVElPTl9NT0RFLm9uQmx1cixcbiAgICBpc09uQ2hhbmdlOiBtb2RlID09PSBWQUxJREFUSU9OX01PREUub25DaGFuZ2UsXG4gICAgaXNPbkFsbDogbW9kZSA9PT0gVkFMSURBVElPTl9NT0RFLmFsbCxcbiAgICBpc09uVG91Y2g6IG1vZGUgPT09IFZBTElEQVRJT05fTU9ERS5vblRvdWNoZWQsXG59KTtcblxudmFyIGlzV2F0Y2hlZCA9IChuYW1lLCBfbmFtZXMsIGlzQmx1ckV2ZW50KSA9PiB7XG4gICAgaWYgKGlzQmx1ckV2ZW50KVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgaWYgKF9uYW1lcy53YXRjaEFsbCB8fCBfbmFtZXMud2F0Y2guaGFzKG5hbWUpKVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICBmb3IgKGNvbnN0IHdhdGNoTmFtZSBvZiBfbmFtZXMud2F0Y2gpIHtcbiAgICAgICAgaWYgKG5hbWUuc3RhcnRzV2l0aCh3YXRjaE5hbWUpICYmIG5hbWUuY2hhckF0KHdhdGNoTmFtZS5sZW5ndGgpID09PSAnLicpXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xufTtcblxuY29uc3QgaXRlcmF0ZUZpZWxkc0J5QWN0aW9uID0gKGZpZWxkcywgYWN0aW9uLCBmaWVsZHNOYW1lcywgYWJvcnRFYXJseSkgPT4ge1xuICAgIGZvciAoY29uc3Qga2V5IG9mIGZpZWxkc05hbWVzIHx8IE9iamVjdC5rZXlzKGZpZWxkcykpIHtcbiAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoZmllbGRzLCBrZXkpO1xuICAgICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgX2YsIC4uLmN1cnJlbnRGaWVsZCB9ID0gZmllbGQ7XG4gICAgICAgICAgICBpZiAoX2YpIHtcbiAgICAgICAgICAgICAgICBpZiAoX2YucmVmcyAmJiBfZi5yZWZzWzBdICYmIGFjdGlvbihfZi5yZWZzWzBdLCBrZXkpICYmICFhYm9ydEVhcmx5KSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChfZi5yZWYgJiYgYWN0aW9uKF9mLnJlZiwgX2YubmFtZSkgJiYgIWFib3J0RWFybHkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXRlcmF0ZUZpZWxkc0J5QWN0aW9uKGN1cnJlbnRGaWVsZCwgYWN0aW9uKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChpc09iamVjdChjdXJyZW50RmllbGQpKSB7XG4gICAgICAgICAgICAgICAgaWYgKGl0ZXJhdGVGaWVsZHNCeUFjdGlvbihjdXJyZW50RmllbGQsIGFjdGlvbikpIHtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybjtcbn07XG5cbnZhciB1cGRhdGVGaWVsZEFycmF5Um9vdEVycm9yID0gKGVycm9ycywgZXJyb3IsIG5hbWUpID0+IHtcbiAgICBjb25zdCBleGlzdGluZ0Vycm9ycyA9IGdldChlcnJvcnMsIG5hbWUpO1xuICAgIGNvbnN0IGZpZWxkQXJyYXlFcnJvcnMgPSBBcnJheS5pc0FycmF5KGV4aXN0aW5nRXJyb3JzKSA/IGV4aXN0aW5nRXJyb3JzIDogW107XG4gICAgc2V0KGZpZWxkQXJyYXlFcnJvcnMsIFJPT1RfRVJST1JfVFlQRSwgZXJyb3JbbmFtZV0pO1xuICAgIHNldChlcnJvcnMsIG5hbWUsIGZpZWxkQXJyYXlFcnJvcnMpO1xuICAgIHJldHVybiBlcnJvcnM7XG59O1xuXG52YXIgaXNFbXB0eU9iamVjdCA9ICh2YWx1ZSkgPT4gaXNPYmplY3QodmFsdWUpICYmICFPYmplY3Qua2V5cyh2YWx1ZSkubGVuZ3RoO1xuXG52YXIgaXNGaWxlSW5wdXQgPSAoZWxlbWVudCkgPT4gZWxlbWVudC50eXBlID09PSAnZmlsZSc7XG5cbnZhciBpc0hUTUxFbGVtZW50ID0gKHZhbHVlKSA9PiB7XG4gICAgaWYgKCFpc1dlYikge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IG93bmVyID0gdmFsdWUgPyB2YWx1ZS5vd25lckRvY3VtZW50IDogMDtcbiAgICByZXR1cm4gKHZhbHVlIGluc3RhbmNlb2ZcbiAgICAgICAgKG93bmVyICYmIG93bmVyLmRlZmF1bHRWaWV3ID8gb3duZXIuZGVmYXVsdFZpZXcuSFRNTEVsZW1lbnQgOiBIVE1MRWxlbWVudCkpO1xufTtcblxudmFyIGlzUmFkaW9JbnB1dCA9IChlbGVtZW50KSA9PiBlbGVtZW50LnR5cGUgPT09ICdyYWRpbyc7XG5cbnZhciBpc1JlZ2V4ID0gKHZhbHVlKSA9PiB2YWx1ZSBpbnN0YW5jZW9mIFJlZ0V4cDtcblxudmFyIGFwcGVuZEVycm9ycyA9IChuYW1lLCB2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEsIGVycm9ycywgdHlwZSwgbWVzc2FnZSkgPT4gdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhXG4gICAgPyB7XG4gICAgICAgIC4uLmVycm9yc1tuYW1lXSxcbiAgICAgICAgdHlwZXM6IHtcbiAgICAgICAgICAgIC4uLihlcnJvcnNbbmFtZV0gJiYgZXJyb3JzW25hbWVdLnR5cGVzID8gZXJyb3JzW25hbWVdLnR5cGVzIDoge30pLFxuICAgICAgICAgICAgW3R5cGVdOiBtZXNzYWdlIHx8IHRydWUsXG4gICAgICAgIH0sXG4gICAgfVxuICAgIDoge307XG5cbmNvbnN0IGRlZmF1bHRSZXN1bHQgPSB7XG4gICAgdmFsdWU6IGZhbHNlLFxuICAgIGlzVmFsaWQ6IGZhbHNlLFxufTtcbmNvbnN0IHZhbGlkUmVzdWx0ID0geyB2YWx1ZTogdHJ1ZSwgaXNWYWxpZDogdHJ1ZSB9O1xudmFyIGdldENoZWNrYm94VmFsdWUgPSAob3B0aW9ucykgPT4ge1xuICAgIGlmIChBcnJheS5pc0FycmF5KG9wdGlvbnMpKSB7XG4gICAgICAgIGlmIChvcHRpb25zLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlcyA9IG9wdGlvbnNcbiAgICAgICAgICAgICAgICAuZmlsdGVyKChvcHRpb24pID0+IG9wdGlvbiAmJiBvcHRpb24uY2hlY2tlZCAmJiAhb3B0aW9uLmRpc2FibGVkKVxuICAgICAgICAgICAgICAgIC5tYXAoKG9wdGlvbikgPT4gb3B0aW9uLnZhbHVlKTtcbiAgICAgICAgICAgIHJldHVybiB7IHZhbHVlOiB2YWx1ZXMsIGlzVmFsaWQ6ICEhdmFsdWVzLmxlbmd0aCB9O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBvcHRpb25zWzBdLmNoZWNrZWQgJiYgIW9wdGlvbnNbMF0uZGlzYWJsZWRcbiAgICAgICAgICAgID8gLy8gQHRzLWV4cGVjdC1lcnJvciBleHBlY3RlZCB0byB3b3JrIGluIHRoZSBicm93c2VyXG4gICAgICAgICAgICAgICAgb3B0aW9uc1swXS5hdHRyaWJ1dGVzICYmICFpc1VuZGVmaW5lZChvcHRpb25zWzBdLmF0dHJpYnV0ZXMudmFsdWUpXG4gICAgICAgICAgICAgICAgICAgID8gaXNVbmRlZmluZWQob3B0aW9uc1swXS52YWx1ZSkgfHwgb3B0aW9uc1swXS52YWx1ZSA9PT0gJydcbiAgICAgICAgICAgICAgICAgICAgICAgID8gdmFsaWRSZXN1bHRcbiAgICAgICAgICAgICAgICAgICAgICAgIDogeyB2YWx1ZTogb3B0aW9uc1swXS52YWx1ZSwgaXNWYWxpZDogdHJ1ZSB9XG4gICAgICAgICAgICAgICAgICAgIDogdmFsaWRSZXN1bHRcbiAgICAgICAgICAgIDogZGVmYXVsdFJlc3VsdDtcbiAgICB9XG4gICAgcmV0dXJuIGRlZmF1bHRSZXN1bHQ7XG59O1xuXG5jb25zdCBkZWZhdWx0UmV0dXJuID0ge1xuICAgIGlzVmFsaWQ6IGZhbHNlLFxuICAgIHZhbHVlOiBudWxsLFxufTtcbnZhciBnZXRSYWRpb1ZhbHVlID0gKG9wdGlvbnMpID0+IEFycmF5LmlzQXJyYXkob3B0aW9ucylcbiAgICA/IG9wdGlvbnMucmVkdWNlKChwcmV2aW91cywgb3B0aW9uKSA9PiBvcHRpb24gJiYgb3B0aW9uLmNoZWNrZWQgJiYgIW9wdGlvbi5kaXNhYmxlZFxuICAgICAgICA/IHtcbiAgICAgICAgICAgIGlzVmFsaWQ6IHRydWUsXG4gICAgICAgICAgICB2YWx1ZTogb3B0aW9uLnZhbHVlLFxuICAgICAgICB9XG4gICAgICAgIDogcHJldmlvdXMsIGRlZmF1bHRSZXR1cm4pXG4gICAgOiBkZWZhdWx0UmV0dXJuO1xuXG5mdW5jdGlvbiBnZXRWYWxpZGF0ZUVycm9yKHJlc3VsdCwgcmVmLCB0eXBlID0gJ3ZhbGlkYXRlJykge1xuICAgIGlmIChpc1N0cmluZyhyZXN1bHQpIHx8XG4gICAgICAgIChBcnJheS5pc0FycmF5KHJlc3VsdCkgJiYgcmVzdWx0LmV2ZXJ5KGlzU3RyaW5nKSkgfHxcbiAgICAgICAgKGlzQm9vbGVhbihyZXN1bHQpICYmICFyZXN1bHQpKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB0eXBlLFxuICAgICAgICAgICAgbWVzc2FnZTogaXNTdHJpbmcocmVzdWx0KSA/IHJlc3VsdCA6ICcnLFxuICAgICAgICAgICAgcmVmLFxuICAgICAgICB9O1xuICAgIH1cbn1cblxudmFyIGdldFZhbHVlQW5kTWVzc2FnZSA9ICh2YWxpZGF0aW9uRGF0YSkgPT4gaXNPYmplY3QodmFsaWRhdGlvbkRhdGEpICYmICFpc1JlZ2V4KHZhbGlkYXRpb25EYXRhKVxuICAgID8gdmFsaWRhdGlvbkRhdGFcbiAgICA6IHtcbiAgICAgICAgdmFsdWU6IHZhbGlkYXRpb25EYXRhLFxuICAgICAgICBtZXNzYWdlOiAnJyxcbiAgICB9O1xuXG52YXIgdmFsaWRhdGVGaWVsZCA9IGFzeW5jIChmaWVsZCwgZGlzYWJsZWRGaWVsZE5hbWVzLCBmb3JtVmFsdWVzLCB2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEsIHNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24sIGlzRmllbGRBcnJheSkgPT4ge1xuICAgIGNvbnN0IHsgcmVmLCByZWZzLCByZXF1aXJlZCwgbWF4TGVuZ3RoLCBtaW5MZW5ndGgsIG1pbiwgbWF4LCBwYXR0ZXJuLCB2YWxpZGF0ZSwgbmFtZSwgdmFsdWVBc051bWJlciwgbW91bnQsIH0gPSBmaWVsZC5fZjtcbiAgICBjb25zdCBpbnB1dFZhbHVlID0gZ2V0KGZvcm1WYWx1ZXMsIG5hbWUpO1xuICAgIGlmICghbW91bnQgfHwgZGlzYWJsZWRGaWVsZE5hbWVzLmhhcyhuYW1lKSkge1xuICAgICAgICByZXR1cm4ge307XG4gICAgfVxuICAgIGNvbnN0IGlucHV0UmVmID0gcmVmcyA/IHJlZnNbMF0gOiByZWY7XG4gICAgY29uc3Qgc2V0Q3VzdG9tVmFsaWRpdHkgPSAobWVzc2FnZSkgPT4ge1xuICAgICAgICBpZiAoc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbiAmJiBpbnB1dFJlZi5yZXBvcnRWYWxpZGl0eSkge1xuICAgICAgICAgICAgY29uc3QgdmFsaWRpdHlNZXNzYWdlID0gaXNCb29sZWFuKG1lc3NhZ2UpID8gJycgOiBtZXNzYWdlIHx8ICcnO1xuICAgICAgICAgICAgaWYgKHJlZnMpIHtcbiAgICAgICAgICAgICAgICByZWZzLmZvckVhY2goKHJlZikgPT4gcmVmLnNldEN1c3RvbVZhbGlkaXR5KHZhbGlkaXR5TWVzc2FnZSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgaW5wdXRSZWYuc2V0Q3VzdG9tVmFsaWRpdHkodmFsaWRpdHlNZXNzYWdlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlucHV0UmVmLnJlcG9ydFZhbGlkaXR5KCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGVycm9yID0ge307XG4gICAgY29uc3QgaXNSYWRpbyA9IGlzUmFkaW9JbnB1dChyZWYpO1xuICAgIGNvbnN0IGlzQ2hlY2tCb3ggPSBpc0NoZWNrQm94SW5wdXQocmVmKTtcbiAgICBjb25zdCBpc1JhZGlvT3JDaGVja2JveCA9IGlzUmFkaW8gfHwgaXNDaGVja0JveDtcbiAgICBjb25zdCBpc0VtcHR5ID0gKCh2YWx1ZUFzTnVtYmVyIHx8IGlzRmlsZUlucHV0KHJlZikpICYmXG4gICAgICAgIGlzVW5kZWZpbmVkKHJlZi52YWx1ZSkgJiZcbiAgICAgICAgaXNVbmRlZmluZWQoaW5wdXRWYWx1ZSkpIHx8XG4gICAgICAgIChpc0hUTUxFbGVtZW50KHJlZikgJiYgcmVmLnZhbHVlID09PSAnJykgfHxcbiAgICAgICAgaW5wdXRWYWx1ZSA9PT0gJycgfHxcbiAgICAgICAgKEFycmF5LmlzQXJyYXkoaW5wdXRWYWx1ZSkgJiYgIWlucHV0VmFsdWUubGVuZ3RoKTtcbiAgICBjb25zdCBhcHBlbmRFcnJvcnNDdXJyeSA9IGFwcGVuZEVycm9ycy5iaW5kKG51bGwsIG5hbWUsIHZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSwgZXJyb3IpO1xuICAgIGNvbnN0IGdldE1pbk1heE1lc3NhZ2UgPSAoZXhjZWVkTWF4LCBtYXhMZW5ndGhNZXNzYWdlLCBtaW5MZW5ndGhNZXNzYWdlLCBtYXhUeXBlID0gSU5QVVRfVkFMSURBVElPTl9SVUxFUy5tYXhMZW5ndGgsIG1pblR5cGUgPSBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1pbkxlbmd0aCkgPT4ge1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gZXhjZWVkTWF4ID8gbWF4TGVuZ3RoTWVzc2FnZSA6IG1pbkxlbmd0aE1lc3NhZ2U7XG4gICAgICAgIGVycm9yW25hbWVdID0ge1xuICAgICAgICAgICAgdHlwZTogZXhjZWVkTWF4ID8gbWF4VHlwZSA6IG1pblR5cGUsXG4gICAgICAgICAgICBtZXNzYWdlLFxuICAgICAgICAgICAgcmVmLFxuICAgICAgICAgICAgLi4uYXBwZW5kRXJyb3JzQ3VycnkoZXhjZWVkTWF4ID8gbWF4VHlwZSA6IG1pblR5cGUsIG1lc3NhZ2UpLFxuICAgICAgICB9O1xuICAgIH07XG4gICAgaWYgKGlzRmllbGRBcnJheVxuICAgICAgICA/ICFBcnJheS5pc0FycmF5KGlucHV0VmFsdWUpIHx8ICFpbnB1dFZhbHVlLmxlbmd0aFxuICAgICAgICA6IHJlcXVpcmVkICYmXG4gICAgICAgICAgICAoKCFpc1JhZGlvT3JDaGVja2JveCAmJiAoaXNFbXB0eSB8fCBpc051bGxPclVuZGVmaW5lZChpbnB1dFZhbHVlKSkpIHx8XG4gICAgICAgICAgICAgICAgKGlzQm9vbGVhbihpbnB1dFZhbHVlKSAmJiAhaW5wdXRWYWx1ZSkgfHxcbiAgICAgICAgICAgICAgICAoaXNDaGVja0JveCAmJiAhZ2V0Q2hlY2tib3hWYWx1ZShyZWZzKS5pc1ZhbGlkKSB8fFxuICAgICAgICAgICAgICAgIChpc1JhZGlvICYmICFnZXRSYWRpb1ZhbHVlKHJlZnMpLmlzVmFsaWQpKSkge1xuICAgICAgICBjb25zdCB7IHZhbHVlLCBtZXNzYWdlIH0gPSBpc1N0cmluZyhyZXF1aXJlZClcbiAgICAgICAgICAgID8geyB2YWx1ZTogISFyZXF1aXJlZCwgbWVzc2FnZTogcmVxdWlyZWQgfVxuICAgICAgICAgICAgOiBnZXRWYWx1ZUFuZE1lc3NhZ2UocmVxdWlyZWQpO1xuICAgICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgICAgIGVycm9yW25hbWVdID0ge1xuICAgICAgICAgICAgICAgIHR5cGU6IElOUFVUX1ZBTElEQVRJT05fUlVMRVMucmVxdWlyZWQsXG4gICAgICAgICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICAgICAgICByZWY6IGlucHV0UmVmLFxuICAgICAgICAgICAgICAgIC4uLmFwcGVuZEVycm9yc0N1cnJ5KElOUFVUX1ZBTElEQVRJT05fUlVMRVMucmVxdWlyZWQsIG1lc3NhZ2UpLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGlmICghdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhKSB7XG4gICAgICAgICAgICAgICAgc2V0Q3VzdG9tVmFsaWRpdHkobWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGVycm9yO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGlmICghaXNFbXB0eSAmJiAoIWlzTnVsbE9yVW5kZWZpbmVkKG1pbikgfHwgIWlzTnVsbE9yVW5kZWZpbmVkKG1heCkpKSB7XG4gICAgICAgIGxldCBleGNlZWRNYXg7XG4gICAgICAgIGxldCBleGNlZWRNaW47XG4gICAgICAgIGNvbnN0IG1heE91dHB1dCA9IGdldFZhbHVlQW5kTWVzc2FnZShtYXgpO1xuICAgICAgICBjb25zdCBtaW5PdXRwdXQgPSBnZXRWYWx1ZUFuZE1lc3NhZ2UobWluKTtcbiAgICAgICAgaWYgKCFpc051bGxPclVuZGVmaW5lZChpbnB1dFZhbHVlKSAmJiAhaXNOYU4oaW5wdXRWYWx1ZSkpIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlTnVtYmVyID0gcmVmLnZhbHVlQXNOdW1iZXIgfHxcbiAgICAgICAgICAgICAgICAoaW5wdXRWYWx1ZSA/ICtpbnB1dFZhbHVlIDogaW5wdXRWYWx1ZSk7XG4gICAgICAgICAgICBpZiAoIWlzTnVsbE9yVW5kZWZpbmVkKG1heE91dHB1dC52YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICBleGNlZWRNYXggPSB2YWx1ZU51bWJlciA+IG1heE91dHB1dC52YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghaXNOdWxsT3JVbmRlZmluZWQobWluT3V0cHV0LnZhbHVlKSkge1xuICAgICAgICAgICAgICAgIGV4Y2VlZE1pbiA9IHZhbHVlTnVtYmVyIDwgbWluT3V0cHV0LnZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgdmFsdWVEYXRlID0gcmVmLnZhbHVlQXNEYXRlIHx8IG5ldyBEYXRlKGlucHV0VmFsdWUpO1xuICAgICAgICAgICAgY29uc3QgY29udmVydFRpbWVUb0RhdGUgPSAodGltZSkgPT4gbmV3IERhdGUobmV3IERhdGUoKS50b0RhdGVTdHJpbmcoKSArICcgJyArIHRpbWUpO1xuICAgICAgICAgICAgY29uc3QgaXNUaW1lID0gcmVmLnR5cGUgPT0gJ3RpbWUnO1xuICAgICAgICAgICAgY29uc3QgaXNXZWVrID0gcmVmLnR5cGUgPT0gJ3dlZWsnO1xuICAgICAgICAgICAgaWYgKGlzU3RyaW5nKG1heE91dHB1dC52YWx1ZSkgJiYgaW5wdXRWYWx1ZSkge1xuICAgICAgICAgICAgICAgIGV4Y2VlZE1heCA9IGlzVGltZVxuICAgICAgICAgICAgICAgICAgICA/IGNvbnZlcnRUaW1lVG9EYXRlKGlucHV0VmFsdWUpID4gY29udmVydFRpbWVUb0RhdGUobWF4T3V0cHV0LnZhbHVlKVxuICAgICAgICAgICAgICAgICAgICA6IGlzV2Vla1xuICAgICAgICAgICAgICAgICAgICAgICAgPyBpbnB1dFZhbHVlID4gbWF4T3V0cHV0LnZhbHVlXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHZhbHVlRGF0ZSA+IG5ldyBEYXRlKG1heE91dHB1dC52YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaXNTdHJpbmcobWluT3V0cHV0LnZhbHVlKSAmJiBpbnB1dFZhbHVlKSB7XG4gICAgICAgICAgICAgICAgZXhjZWVkTWluID0gaXNUaW1lXG4gICAgICAgICAgICAgICAgICAgID8gY29udmVydFRpbWVUb0RhdGUoaW5wdXRWYWx1ZSkgPCBjb252ZXJ0VGltZVRvRGF0ZShtaW5PdXRwdXQudmFsdWUpXG4gICAgICAgICAgICAgICAgICAgIDogaXNXZWVrXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGlucHV0VmFsdWUgPCBtaW5PdXRwdXQudmFsdWVcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdmFsdWVEYXRlIDwgbmV3IERhdGUobWluT3V0cHV0LnZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoZXhjZWVkTWF4IHx8IGV4Y2VlZE1pbikge1xuICAgICAgICAgICAgZ2V0TWluTWF4TWVzc2FnZSghIWV4Y2VlZE1heCwgbWF4T3V0cHV0Lm1lc3NhZ2UsIG1pbk91dHB1dC5tZXNzYWdlLCBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1heCwgSU5QVVRfVkFMSURBVElPTl9SVUxFUy5taW4pO1xuICAgICAgICAgICAgaWYgKCF2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICBzZXRDdXN0b21WYWxpZGl0eShlcnJvcltuYW1lXS5tZXNzYWdlKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKChtYXhMZW5ndGggfHwgbWluTGVuZ3RoKSAmJlxuICAgICAgICAhaXNFbXB0eSAmJlxuICAgICAgICAoaXNTdHJpbmcoaW5wdXRWYWx1ZSkgfHwgKGlzRmllbGRBcnJheSAmJiBBcnJheS5pc0FycmF5KGlucHV0VmFsdWUpKSkpIHtcbiAgICAgICAgY29uc3QgbWF4TGVuZ3RoT3V0cHV0ID0gZ2V0VmFsdWVBbmRNZXNzYWdlKG1heExlbmd0aCk7XG4gICAgICAgIGNvbnN0IG1pbkxlbmd0aE91dHB1dCA9IGdldFZhbHVlQW5kTWVzc2FnZShtaW5MZW5ndGgpO1xuICAgICAgICBjb25zdCBleGNlZWRNYXggPSAhaXNOdWxsT3JVbmRlZmluZWQobWF4TGVuZ3RoT3V0cHV0LnZhbHVlKSAmJlxuICAgICAgICAgICAgaW5wdXRWYWx1ZS5sZW5ndGggPiArbWF4TGVuZ3RoT3V0cHV0LnZhbHVlO1xuICAgICAgICBjb25zdCBleGNlZWRNaW4gPSAhaXNOdWxsT3JVbmRlZmluZWQobWluTGVuZ3RoT3V0cHV0LnZhbHVlKSAmJlxuICAgICAgICAgICAgaW5wdXRWYWx1ZS5sZW5ndGggPCArbWluTGVuZ3RoT3V0cHV0LnZhbHVlO1xuICAgICAgICBpZiAoZXhjZWVkTWF4IHx8IGV4Y2VlZE1pbikge1xuICAgICAgICAgICAgZ2V0TWluTWF4TWVzc2FnZShleGNlZWRNYXgsIG1heExlbmd0aE91dHB1dC5tZXNzYWdlLCBtaW5MZW5ndGhPdXRwdXQubWVzc2FnZSk7XG4gICAgICAgICAgICBpZiAoIXZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSkge1xuICAgICAgICAgICAgICAgIHNldEN1c3RvbVZhbGlkaXR5KGVycm9yW25hbWVdLm1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgIHJldHVybiBlcnJvcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAocGF0dGVybiAmJiAhaXNFbXB0eSAmJiBpc1N0cmluZyhpbnB1dFZhbHVlKSkge1xuICAgICAgICBjb25zdCB7IHZhbHVlOiBwYXR0ZXJuVmFsdWUsIG1lc3NhZ2UgfSA9IGdldFZhbHVlQW5kTWVzc2FnZShwYXR0ZXJuKTtcbiAgICAgICAgaWYgKGlzUmVnZXgocGF0dGVyblZhbHVlKSAmJiAhaW5wdXRWYWx1ZS5tYXRjaChwYXR0ZXJuVmFsdWUpKSB7XG4gICAgICAgICAgICBlcnJvcltuYW1lXSA9IHtcbiAgICAgICAgICAgICAgICB0eXBlOiBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLnBhdHRlcm4sXG4gICAgICAgICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICAgICAgICByZWYsXG4gICAgICAgICAgICAgICAgLi4uYXBwZW5kRXJyb3JzQ3VycnkoSU5QVVRfVkFMSURBVElPTl9SVUxFUy5wYXR0ZXJuLCBtZXNzYWdlKSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBpZiAoIXZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSkge1xuICAgICAgICAgICAgICAgIHNldEN1c3RvbVZhbGlkaXR5KG1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgIHJldHVybiBlcnJvcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAodmFsaWRhdGUpIHtcbiAgICAgICAgaWYgKGlzRnVuY3Rpb24odmFsaWRhdGUpKSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB2YWxpZGF0ZShpbnB1dFZhbHVlLCBmb3JtVmFsdWVzKTtcbiAgICAgICAgICAgIGNvbnN0IHZhbGlkYXRlRXJyb3IgPSBnZXRWYWxpZGF0ZUVycm9yKHJlc3VsdCwgaW5wdXRSZWYpO1xuICAgICAgICAgICAgaWYgKHZhbGlkYXRlRXJyb3IpIHtcbiAgICAgICAgICAgICAgICBlcnJvcltuYW1lXSA9IHtcbiAgICAgICAgICAgICAgICAgICAgLi4udmFsaWRhdGVFcnJvcixcbiAgICAgICAgICAgICAgICAgICAgLi4uYXBwZW5kRXJyb3JzQ3VycnkoSU5QVVRfVkFMSURBVElPTl9SVUxFUy52YWxpZGF0ZSwgdmFsaWRhdGVFcnJvci5tZXNzYWdlKSxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIGlmICghdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhKSB7XG4gICAgICAgICAgICAgICAgICAgIHNldEN1c3RvbVZhbGlkaXR5KHZhbGlkYXRlRXJyb3IubWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBlcnJvcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoaXNPYmplY3QodmFsaWRhdGUpKSB7XG4gICAgICAgICAgICBsZXQgdmFsaWRhdGlvblJlc3VsdCA9IHt9O1xuICAgICAgICAgICAgZm9yIChjb25zdCBrZXkgaW4gdmFsaWRhdGUpIHtcbiAgICAgICAgICAgICAgICBpZiAoIWlzRW1wdHlPYmplY3QodmFsaWRhdGlvblJlc3VsdCkgJiYgIXZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSkge1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsaWRhdGVFcnJvciA9IGdldFZhbGlkYXRlRXJyb3IoYXdhaXQgdmFsaWRhdGVba2V5XShpbnB1dFZhbHVlLCBmb3JtVmFsdWVzKSwgaW5wdXRSZWYsIGtleSk7XG4gICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRlRXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdGlvblJlc3VsdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnZhbGlkYXRlRXJyb3IsXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5hcHBlbmRFcnJvcnNDdXJyeShrZXksIHZhbGlkYXRlRXJyb3IubWVzc2FnZSksXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHNldEN1c3RvbVZhbGlkaXR5KHZhbGlkYXRlRXJyb3IubWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yW25hbWVdID0gdmFsaWRhdGlvblJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghaXNFbXB0eU9iamVjdCh2YWxpZGF0aW9uUmVzdWx0KSkge1xuICAgICAgICAgICAgICAgIGVycm9yW25hbWVdID0ge1xuICAgICAgICAgICAgICAgICAgICByZWY6IGlucHV0UmVmLFxuICAgICAgICAgICAgICAgICAgICAuLi52YWxpZGF0aW9uUmVzdWx0LFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgaWYgKCF2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGVycm9yO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBzZXRDdXN0b21WYWxpZGl0eSh0cnVlKTtcbiAgICByZXR1cm4gZXJyb3I7XG59O1xuXG52YXIgY29udmVydFRvQXJyYXlQYXlsb2FkID0gKHZhbHVlKSA9PiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZSA6IFt2YWx1ZV0pO1xuXG52YXIgYXBwZW5kQXQgPSAoZGF0YSwgdmFsdWUpID0+IFtcbiAgICAuLi5kYXRhLFxuICAgIC4uLmNvbnZlcnRUb0FycmF5UGF5bG9hZCh2YWx1ZSksXG5dO1xuXG52YXIgZmlsbEVtcHR5QXJyYXkgPSAodmFsdWUpID0+IEFycmF5LmlzQXJyYXkodmFsdWUpID8gdmFsdWUubWFwKCgpID0+IHVuZGVmaW5lZCkgOiB1bmRlZmluZWQ7XG5cbmZ1bmN0aW9uIGluc2VydChkYXRhLCBpbmRleCwgdmFsdWUpIHtcbiAgICByZXR1cm4gW1xuICAgICAgICAuLi5kYXRhLnNsaWNlKDAsIGluZGV4KSxcbiAgICAgICAgLi4uY29udmVydFRvQXJyYXlQYXlsb2FkKHZhbHVlKSxcbiAgICAgICAgLi4uZGF0YS5zbGljZShpbmRleCksXG4gICAgXTtcbn1cblxudmFyIG1vdmVBcnJheUF0ID0gKGRhdGEsIGZyb20sIHRvKSA9PiB7XG4gICAgaWYgKCFBcnJheS5pc0FycmF5KGRhdGEpKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG4gICAgaWYgKGlzVW5kZWZpbmVkKGRhdGFbdG9dKSkge1xuICAgICAgICBkYXRhW3RvXSA9IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgZGF0YS5zcGxpY2UodG8sIDAsIGRhdGEuc3BsaWNlKGZyb20sIDEpWzBdKTtcbiAgICByZXR1cm4gZGF0YTtcbn07XG5cbnZhciBwcmVwZW5kQXQgPSAoZGF0YSwgdmFsdWUpID0+IFtcbiAgICAuLi5jb252ZXJ0VG9BcnJheVBheWxvYWQodmFsdWUpLFxuICAgIC4uLmNvbnZlcnRUb0FycmF5UGF5bG9hZChkYXRhKSxcbl07XG5cbnZhciBjb21wYWN0ID0gKHZhbHVlKSA9PiBBcnJheS5pc0FycmF5KHZhbHVlKSA/IHZhbHVlLmZpbHRlcihCb29sZWFuKSA6IFtdO1xuXG5mdW5jdGlvbiByZW1vdmVBdEluZGV4ZXMoZGF0YSwgaW5kZXhlcykge1xuICAgIGxldCBpID0gMDtcbiAgICBjb25zdCB0ZW1wID0gWy4uLmRhdGFdO1xuICAgIGZvciAoY29uc3QgaW5kZXggb2YgaW5kZXhlcykge1xuICAgICAgICB0ZW1wLnNwbGljZShpbmRleCAtIGksIDEpO1xuICAgICAgICBpKys7XG4gICAgfVxuICAgIHJldHVybiBjb21wYWN0KHRlbXApLmxlbmd0aCA/IHRlbXAgOiBbXTtcbn1cbnZhciByZW1vdmVBcnJheUF0ID0gKGRhdGEsIGluZGV4KSA9PiBpc1VuZGVmaW5lZChpbmRleClcbiAgICA/IFtdXG4gICAgOiByZW1vdmVBdEluZGV4ZXMoZGF0YSwgY29udmVydFRvQXJyYXlQYXlsb2FkKGluZGV4KS5zb3J0KChhLCBiKSA9PiBhIC0gYikpO1xuXG52YXIgc3dhcEFycmF5QXQgPSAoZGF0YSwgaW5kZXhBLCBpbmRleEIpID0+IHtcbiAgICBbZGF0YVtpbmRleEFdLCBkYXRhW2luZGV4Ql1dID0gW2RhdGFbaW5kZXhCXSwgZGF0YVtpbmRleEFdXTtcbn07XG5cbmZ1bmN0aW9uIGJhc2VHZXQob2JqZWN0LCB1cGRhdGVQYXRoKSB7XG4gICAgY29uc3QgbGVuZ3RoID0gdXBkYXRlUGF0aC5zbGljZSgwLCAtMSkubGVuZ3RoO1xuICAgIGxldCBpbmRleCA9IDA7XG4gICAgd2hpbGUgKGluZGV4IDwgbGVuZ3RoKSB7XG4gICAgICAgIGlmIChpc051bGxPclVuZGVmaW5lZChvYmplY3QpKSB7XG4gICAgICAgICAgICBvYmplY3QgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBvYmplY3QgPSBvYmplY3RbdXBkYXRlUGF0aFtpbmRleF1dO1xuICAgICAgICBpbmRleCsrO1xuICAgIH1cbiAgICByZXR1cm4gb2JqZWN0O1xufVxuZnVuY3Rpb24gaXNFbXB0eUFycmF5KG9iaikge1xuICAgIGZvciAoY29uc3Qga2V5IGluIG9iaikge1xuICAgICAgICBpZiAob2JqLmhhc093blByb3BlcnR5KGtleSkgJiYgIWlzVW5kZWZpbmVkKG9ialtrZXldKSkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gdW5zZXQob2JqZWN0LCBwYXRoKSB7XG4gICAgaWYgKGlzU3RyaW5nKHBhdGgpICYmIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHBhdGgpKSB7XG4gICAgICAgIGRlbGV0ZSBvYmplY3RbcGF0aF07XG4gICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgfVxuICAgIGNvbnN0IHBhdGhzID0gQXJyYXkuaXNBcnJheShwYXRoKVxuICAgICAgICA/IHBhdGhcbiAgICAgICAgOiBpc0tleShwYXRoKVxuICAgICAgICAgICAgPyBbcGF0aF1cbiAgICAgICAgICAgIDogc3RyaW5nVG9QYXRoKHBhdGgpO1xuICAgIGlmIChwYXRocy5zb21lKChzZWdtZW50KSA9PiBQUk9UT1RZUEVfS0VZV09SRFMuaW5jbHVkZXMoU3RyaW5nKHNlZ21lbnQpKSkpIHtcbiAgICAgICAgcmV0dXJuIG9iamVjdDtcbiAgICB9XG4gICAgY29uc3QgY2hpbGRPYmplY3QgPSBwYXRocy5sZW5ndGggPT09IDEgPyBvYmplY3QgOiBiYXNlR2V0KG9iamVjdCwgcGF0aHMpO1xuICAgIGNvbnN0IGluZGV4ID0gcGF0aHMubGVuZ3RoIC0gMTtcbiAgICBjb25zdCBrZXkgPSBwYXRoc1tpbmRleF07XG4gICAgaWYgKGNoaWxkT2JqZWN0KSB7XG4gICAgICAgIGRlbGV0ZSBjaGlsZE9iamVjdFtrZXldO1xuICAgIH1cbiAgICBpZiAoaW5kZXggIT09IDAgJiZcbiAgICAgICAgKChpc09iamVjdChjaGlsZE9iamVjdCkgJiYgaXNFbXB0eU9iamVjdChjaGlsZE9iamVjdCkpIHx8XG4gICAgICAgICAgICAoQXJyYXkuaXNBcnJheShjaGlsZE9iamVjdCkgJiYgaXNFbXB0eUFycmF5KGNoaWxkT2JqZWN0KSkpKSB7XG4gICAgICAgIHVuc2V0KG9iamVjdCwgcGF0aHMuc2xpY2UoMCwgLTEpKTtcbiAgICB9XG4gICAgcmV0dXJuIG9iamVjdDtcbn1cblxudmFyIHVwZGF0ZUF0ID0gKGZpZWxkVmFsdWVzLCBpbmRleCwgdmFsdWUpID0+IHtcbiAgICBmaWVsZFZhbHVlc1tpbmRleF0gPSB2YWx1ZTtcbiAgICByZXR1cm4gZmllbGRWYWx1ZXM7XG59O1xuXG4vKipcbiAqIEEgY3VzdG9tIGhvb2sgdGhhdCBleHBvc2VzIGNvbnZlbmllbnQgbWV0aG9kcyB0byBwZXJmb3JtIG9wZXJhdGlvbnMgd2l0aCBhIGxpc3Qgb2YgZHluYW1pYyBpbnB1dHMgdGhhdCBuZWVkIHRvIGJlIGFwcGVuZGVkLCB1cGRhdGVkLCByZW1vdmVkIGV0Yy4g4oCiIFtEZW1vXShodHRwczovL2NvZGVzYW5kYm94LmlvL3MvcmVhY3QtaG9vay1mb3JtLXVzZWZpZWxkYXJyYXktc3N1Z24pIOKAoiBbVmlkZW9dKGh0dHBzOi8veW91dHUuYmUvNE1yYmZHU0ZZMkEpXG4gKlxuICogQHJlbWFya3NcbiAqIFtBUEldKGh0dHBzOi8vcmVhY3QtaG9vay1mb3JtLmNvbS9kb2NzL3VzZWZpZWxkYXJyYXkpIOKAoiBbRGVtb10oaHR0cHM6Ly9jb2Rlc2FuZGJveC5pby9zL3JlYWN0LWhvb2stZm9ybS11c2VmaWVsZGFycmF5LXNzdWduKVxuICpcbiAqIEBwYXJhbSBwcm9wcyAtIHVzZUZpZWxkQXJyYXkgcHJvcHNcbiAqXG4gKiBAcmV0dXJucyBtZXRob2RzIC0gZnVuY3Rpb25zIHRvIG1hbmlwdWxhdGUgd2l0aCB0aGUgRmllbGQgQXJyYXlzIChkeW5hbWljIGlucHV0cykge0BsaW5rIFVzZUZpZWxkQXJyYXlSZXR1cm59XG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogZnVuY3Rpb24gQXBwKCkge1xuICogICBjb25zdCB7IHJlZ2lzdGVyLCBjb250cm9sLCBoYW5kbGVTdWJtaXQsIHJlc2V0LCB0cmlnZ2VyLCBzZXRFcnJvciB9ID0gdXNlRm9ybSh7XG4gKiAgICAgZGVmYXVsdFZhbHVlczoge1xuICogICAgICAgdGVzdDogW11cbiAqICAgICB9XG4gKiAgIH0pO1xuICogICBjb25zdCB7IGZpZWxkcywgYXBwZW5kIH0gPSB1c2VGaWVsZEFycmF5KHtcbiAqICAgICBjb250cm9sLFxuICogICAgIG5hbWU6IFwidGVzdFwiXG4gKiAgIH0pO1xuICpcbiAqICAgcmV0dXJuIChcbiAqICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0KGRhdGEgPT4gY29uc29sZS5sb2coZGF0YSkpfT5cbiAqICAgICAgIHtmaWVsZHMubWFwKChpdGVtLCBpbmRleCkgPT4gKFxuICogICAgICAgICAgPGlucHV0IGtleT17aXRlbS5pZH0gey4uLnJlZ2lzdGVyKGB0ZXN0LiR7aW5kZXh9LmZpcnN0TmFtZWApfSAgLz5cbiAqICAgICAgICkpfVxuICogICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gYXBwZW5kKHsgZmlyc3ROYW1lOiBcImJpbGxcIiB9KX0+XG4gKiAgICAgICAgIGFwcGVuZFxuICogICAgICAgPC9idXR0b24+XG4gKiAgICAgICA8aW5wdXQgdHlwZT1cInN1Ym1pdFwiIC8+XG4gKiAgICAgPC9mb3JtPlxuICogICApO1xuICogfVxuICogYGBgXG4gKi9cbmZ1bmN0aW9uIHVzZUZpZWxkQXJyYXkocHJvcHMpIHtcbiAgICBjb25zdCBmb3JtQ29udHJvbCA9IHVzZUZvcm1Db250cm9sQ29udGV4dCgpO1xuICAgIGNvbnN0IHsgY29udHJvbCA9IGZvcm1Db250cm9sLCBuYW1lLCBrZXlOYW1lID0gJ2lkJywgZGlzYWJsZWQsIHNob3VsZFVucmVnaXN0ZXIsIHJ1bGVzLCB9ID0gcHJvcHM7XG4gICAgY29uc3QgW2ZpZWxkcywgc2V0RmllbGRzXSA9IFJlYWN0LnVzZVN0YXRlKGNvbnRyb2wuX2dldEZpZWxkQXJyYXkobmFtZSkpO1xuICAgIGNvbnN0IGlkcyA9IFJlYWN0LnVzZVJlZihjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpLm1hcChnZW5lcmF0ZUlkKSk7XG4gICAgY29uc3QgX2FjdGlvbmVkID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgICBpZiAoIWRpc2FibGVkKSB7XG4gICAgICAgIGNvbnRyb2wuX25hbWVzLmFycmF5LmFkZChuYW1lKTtcbiAgICB9XG4gICAgUmVhY3QudXNlTWVtbygoKSA9PiAhZGlzYWJsZWQgJiZcbiAgICAgICAgcnVsZXMgJiZcbiAgICAgICAgZmllbGRzLmxlbmd0aCA+PSAwICYmXG4gICAgICAgIGNvbnRyb2wucmVnaXN0ZXIobmFtZSwgcnVsZXMpLCBbY29udHJvbCwgbmFtZSwgZmllbGRzLmxlbmd0aCwgcnVsZXMsIGRpc2FibGVkXSk7XG4gICAgdXNlSXNvbW9ycGhpY0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjb250cm9sLl9zdWJqZWN0cy5hcnJheS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKHsgdmFsdWVzLCBuYW1lOiBmaWVsZEFycmF5TmFtZSwgfSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChmaWVsZEFycmF5TmFtZSA9PT0gbmFtZSB8fCAhZmllbGRBcnJheU5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZmllbGRWYWx1ZXMgPSBnZXQodmFsdWVzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoZmllbGRWYWx1ZXMpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGaWVsZHMoZmllbGRWYWx1ZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWRzLmN1cnJlbnQgPSBmaWVsZFZhbHVlcy5tYXAoZ2VuZXJhdGVJZCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoIWZpZWxkQXJyYXlOYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGaWVsZHMoW10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWRzLmN1cnJlbnQgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pLnVuc3Vic2NyaWJlO1xuICAgIH0sIFtjb250cm9sLCBuYW1lLCBkaXNhYmxlZF0pO1xuICAgIGNvbnN0IHVwZGF0ZVZhbHVlcyA9IFJlYWN0LnVzZUNhbGxiYWNrKCh1cGRhdGVkRmllbGRBcnJheVZhbHVlcykgPT4ge1xuICAgICAgICBfYWN0aW9uZWQuY3VycmVudCA9IHRydWU7XG4gICAgICAgIGNvbnRyb2wuX3NldEZpZWxkQXJyYXkobmFtZSwgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgIH0sIFtjb250cm9sLCBuYW1lXSk7XG4gICAgY29uc3QgYXBwZW5kID0gKHZhbHVlLCBvcHRpb25zKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGFwcGVuZFZhbHVlID0gY29udmVydFRvQXJyYXlQYXlsb2FkKGNsb25lT2JqZWN0KHZhbHVlKSk7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gYXBwZW5kQXQoY29udHJvbC5fZ2V0RmllbGRBcnJheShuYW1lKSwgYXBwZW5kVmFsdWUpO1xuICAgICAgICBjb250cm9sLl9uYW1lcy5mb2N1cyA9IGdldEZvY3VzRmllbGROYW1lKG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLmxlbmd0aCAtIDEsIG9wdGlvbnMpO1xuICAgICAgICBpZHMuY3VycmVudCA9IGFwcGVuZEF0KGlkcy5jdXJyZW50LCBhcHBlbmRWYWx1ZS5tYXAoZ2VuZXJhdGVJZCkpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCBhcHBlbmRBdCwge1xuICAgICAgICAgICAgYXJnQTogZmlsbEVtcHR5QXJyYXkodmFsdWUpLFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IHByZXBlbmQgPSAodmFsdWUsIG9wdGlvbnMpID0+IHtcbiAgICAgICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcHJlcGVuZFZhbHVlID0gY29udmVydFRvQXJyYXlQYXlsb2FkKGNsb25lT2JqZWN0KHZhbHVlKSk7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gcHJlcGVuZEF0KGNvbnRyb2wuX2dldEZpZWxkQXJyYXkobmFtZSksIHByZXBlbmRWYWx1ZSk7XG4gICAgICAgIGNvbnRyb2wuX25hbWVzLmZvY3VzID0gZ2V0Rm9jdXNGaWVsZE5hbWUobmFtZSwgMCwgb3B0aW9ucyk7XG4gICAgICAgIGlkcy5jdXJyZW50ID0gcHJlcGVuZEF0KGlkcy5jdXJyZW50LCBwcmVwZW5kVmFsdWUubWFwKGdlbmVyYXRlSWQpKTtcbiAgICAgICAgdXBkYXRlVmFsdWVzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgc2V0RmllbGRzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgY29udHJvbC5fc2V0RmllbGRBcnJheShuYW1lLCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcywgcHJlcGVuZEF0LCB7XG4gICAgICAgICAgICBhcmdBOiBmaWxsRW1wdHlBcnJheSh2YWx1ZSksXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgcmVtb3ZlID0gKGluZGV4KSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gcmVtb3ZlQXJyYXlBdChjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpLCBpbmRleCk7XG4gICAgICAgIGlkcy5jdXJyZW50ID0gcmVtb3ZlQXJyYXlBdChpZHMuY3VycmVudCwgaW5kZXgpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICAhQXJyYXkuaXNBcnJheShnZXQoY29udHJvbC5fZmllbGRzLCBuYW1lKSkgJiZcbiAgICAgICAgICAgIHNldChjb250cm9sLl9maWVsZHMsIG5hbWUsIHVuZGVmaW5lZCk7XG4gICAgICAgIGNvbnRyb2wuX3NldEZpZWxkQXJyYXkobmFtZSwgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMsIHJlbW92ZUFycmF5QXQsIHtcbiAgICAgICAgICAgIGFyZ0E6IGluZGV4LFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IGluc2VydCQxID0gKGluZGV4LCB2YWx1ZSwgb3B0aW9ucykgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBpbnNlcnRWYWx1ZSA9IGNvbnZlcnRUb0FycmF5UGF5bG9hZChjbG9uZU9iamVjdCh2YWx1ZSkpO1xuICAgICAgICBjb25zdCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcyA9IGluc2VydChjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpLCBpbmRleCwgaW5zZXJ0VmFsdWUpO1xuICAgICAgICBjb250cm9sLl9uYW1lcy5mb2N1cyA9IGdldEZvY3VzRmllbGROYW1lKG5hbWUsIGluZGV4LCBvcHRpb25zKTtcbiAgICAgICAgaWRzLmN1cnJlbnQgPSBpbnNlcnQoaWRzLmN1cnJlbnQsIGluZGV4LCBpbnNlcnRWYWx1ZS5tYXAoZ2VuZXJhdGVJZCkpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCBpbnNlcnQsIHtcbiAgICAgICAgICAgIGFyZ0E6IGluZGV4LFxuICAgICAgICAgICAgYXJnQjogZmlsbEVtcHR5QXJyYXkodmFsdWUpLFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IHN3YXAgPSAoaW5kZXhBLCBpbmRleEIpID0+IHtcbiAgICAgICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMgPSBjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpO1xuICAgICAgICBzd2FwQXJyYXlBdCh1cGRhdGVkRmllbGRBcnJheVZhbHVlcywgaW5kZXhBLCBpbmRleEIpO1xuICAgICAgICBzd2FwQXJyYXlBdChpZHMuY3VycmVudCwgaW5kZXhBLCBpbmRleEIpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCBzd2FwQXJyYXlBdCwge1xuICAgICAgICAgICAgYXJnQTogaW5kZXhBLFxuICAgICAgICAgICAgYXJnQjogaW5kZXhCLFxuICAgICAgICB9LCBmYWxzZSk7XG4gICAgfTtcbiAgICBjb25zdCBtb3ZlID0gKGZyb20sIHRvKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gY29udHJvbC5fZ2V0RmllbGRBcnJheShuYW1lKTtcbiAgICAgICAgbW92ZUFycmF5QXQodXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMsIGZyb20sIHRvKTtcbiAgICAgICAgbW92ZUFycmF5QXQoaWRzLmN1cnJlbnQsIGZyb20sIHRvKTtcbiAgICAgICAgdXBkYXRlVmFsdWVzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgc2V0RmllbGRzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgY29udHJvbC5fc2V0RmllbGRBcnJheShuYW1lLCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcywgbW92ZUFycmF5QXQsIHtcbiAgICAgICAgICAgIGFyZ0E6IGZyb20sXG4gICAgICAgICAgICBhcmdCOiB0byxcbiAgICAgICAgfSwgZmFsc2UpO1xuICAgIH07XG4gICAgY29uc3QgdXBkYXRlID0gKGluZGV4LCB2YWx1ZSkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1cGRhdGVWYWx1ZSA9IGNsb25lT2JqZWN0KHZhbHVlKTtcbiAgICAgICAgY29uc3QgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMgPSB1cGRhdGVBdChjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpLCBpbmRleCwgdXBkYXRlVmFsdWUpO1xuICAgICAgICBpZHMuY3VycmVudCA9IFsuLi51cGRhdGVkRmllbGRBcnJheVZhbHVlc10ubWFwKChpdGVtLCBpKSA9PiAhaXRlbSB8fCBpID09PSBpbmRleCA/IGdlbmVyYXRlSWQoKSA6IGlkcy5jdXJyZW50W2ldKTtcbiAgICAgICAgdXBkYXRlVmFsdWVzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgc2V0RmllbGRzKFsuLi51cGRhdGVkRmllbGRBcnJheVZhbHVlc10pO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCB1cGRhdGVBdCwge1xuICAgICAgICAgICAgYXJnQTogaW5kZXgsXG4gICAgICAgICAgICBhcmdCOiB1cGRhdGVWYWx1ZSxcbiAgICAgICAgfSwgdHJ1ZSwgZmFsc2UpO1xuICAgIH07XG4gICAgY29uc3QgcmVwbGFjZSA9ICh2YWx1ZSkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcyA9IGNvbnZlcnRUb0FycmF5UGF5bG9hZChjbG9uZU9iamVjdCh2YWx1ZSkpO1xuICAgICAgICBpZHMuY3VycmVudCA9IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLm1hcChnZW5lcmF0ZUlkKTtcbiAgICAgICAgdXBkYXRlVmFsdWVzKFsuLi51cGRhdGVkRmllbGRBcnJheVZhbHVlc10pO1xuICAgICAgICBzZXRGaWVsZHMoWy4uLnVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzXSk7XG4gICAgICAgIGNvbnRyb2wuX3NldEZpZWxkQXJyYXkobmFtZSwgWy4uLnVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzXSwgKGRhdGEpID0+IGRhdGEsIHt9LCB0cnVlLCBmYWxzZSk7XG4gICAgfTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb250cm9sLl9zdGF0ZS5hY3Rpb24gPSBmYWxzZTtcbiAgICAgICAgaXNXYXRjaGVkKG5hbWUsIGNvbnRyb2wuX25hbWVzKSAmJlxuICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgLi4uY29udHJvbC5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IHZhbGlkYXRpb25Nb2RlcyA9IGdldFZhbGlkYXRpb25Nb2Rlcyhjb250cm9sLl9vcHRpb25zLm1vZGUpO1xuICAgICAgICBpZiAoX2FjdGlvbmVkLmN1cnJlbnQgJiZcbiAgICAgICAgICAgICghdmFsaWRhdGlvbk1vZGVzLmlzT25TdWJtaXQgfHwgY29udHJvbC5fZm9ybVN0YXRlLmlzU3VibWl0dGVkKSAmJlxuICAgICAgICAgICAgIWdldFZhbGlkYXRpb25Nb2Rlcyhjb250cm9sLl9vcHRpb25zLnJlVmFsaWRhdGVNb2RlKS5pc09uU3VibWl0ICYmXG4gICAgICAgICAgICAhdmFsaWRhdGlvbk1vZGVzLmlzT25CbHVyKSB7XG4gICAgICAgICAgICBpZiAoY29udHJvbC5fb3B0aW9ucy5yZXNvbHZlcikge1xuICAgICAgICAgICAgICAgIGNvbnRyb2wuX3J1blNjaGVtYShbbmFtZV0pLnRoZW4oKHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB2YXIgX2EsIF9iO1xuICAgICAgICAgICAgICAgICAgICBjb250cm9sLl91cGRhdGVJc1ZhbGlkYXRpbmcoW25hbWVdKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXJyb3IgPSBnZXQocmVzdWx0LmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nRXJyb3IgPSBnZXQoY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nRXJyb3JUeXBlID0gZXhpc3RpbmdFcnJvciAmJiAoZXhpc3RpbmdFcnJvci50eXBlIHx8ICgoX2EgPSBleGlzdGluZ0Vycm9yLnJvb3QpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS50eXBlKSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nRXJyb3JNZXNzYWdlID0gZXhpc3RpbmdFcnJvciAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgKGV4aXN0aW5nRXJyb3IubWVzc2FnZSB8fCAoKF9iID0gZXhpc3RpbmdFcnJvci5yb290KSA9PT0gbnVsbCB8fCBfYiA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2IubWVzc2FnZSkpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXhpc3RpbmdFcnJvclxuICAgICAgICAgICAgICAgICAgICAgICAgPyAoIWVycm9yICYmIGV4aXN0aW5nRXJyb3JUeXBlKSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChlcnJvciAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZXhpc3RpbmdFcnJvclR5cGUgIT09IGVycm9yLnR5cGUgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nRXJyb3JNZXNzYWdlICE9PSBlcnJvci5tZXNzYWdlKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIDogZXJyb3IgJiYgZXJyb3IudHlwZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNPYmplY3QoZXJyb3IpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICFPYmplY3Qua2V5cyhlcnJvcikuc29tZSgoa2V5KSA9PiAhTnVtYmVyLmlzTmFOKCtrZXkpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHVwZGF0ZUZpZWxkQXJyYXlSb290RXJyb3IoY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycywgeyBbbmFtZV06IGVycm9yIH0sIG5hbWUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogc2V0KGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUsIGVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVuc2V0KGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JzOiBjb250cm9sLl9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KGNvbnRyb2wuX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgaWYgKGZpZWxkICYmXG4gICAgICAgICAgICAgICAgICAgIGZpZWxkLl9mICYmXG4gICAgICAgICAgICAgICAgICAgICEoZ2V0VmFsaWRhdGlvbk1vZGVzKGNvbnRyb2wuX29wdGlvbnMucmVWYWxpZGF0ZU1vZGUpLmlzT25TdWJtaXQgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIGdldFZhbGlkYXRpb25Nb2Rlcyhjb250cm9sLl9vcHRpb25zLm1vZGUpLmlzT25TdWJtaXQpKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRlRmllbGQoZmllbGQsIGNvbnRyb2wuX25hbWVzLmRpc2FibGVkLCBjb250cm9sLl9mb3JtVmFsdWVzLCBjb250cm9sLl9vcHRpb25zLmNyaXRlcmlhTW9kZSA9PT0gVkFMSURBVElPTl9NT0RFLmFsbCwgY29udHJvbC5fb3B0aW9ucy5zaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uLCB0cnVlKS50aGVuKChlcnJvcikgPT4gIWlzRW1wdHlPYmplY3QoZXJyb3IpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sLl9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlcnJvcnM6IHVwZGF0ZUZpZWxkQXJyYXlSb290RXJyb3IoY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycywgZXJyb3IsIG5hbWUpLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBFeHRlcm5hbCB1cGRhdGVzIHRoYXQgY2hhbmdlIGBmaWVsZHNgIChlLmcuIHJlc2V0KCkgb3Igc2V0VmFsdWUoKSBvblxuICAgICAgICAvLyB0aGUgYXJyYXkpIGFscmVhZHkgbm90aWZ5IHN1YnNjcmliZXJzIHdpdGggdGhlIHVwLXRvLWRhdGUgdmFsdWVzXG4gICAgICAgIC8vIHRoZW1zZWx2ZXMsIHNvIG9ubHkgcmUtYnJvYWRjYXN0IGhlcmUgZm9yIGdlbnVpbmUgYXJyYXkgbWV0aG9kIGNhbGxzLlxuICAgICAgICBfYWN0aW9uZWQuY3VycmVudCAmJlxuICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICB2YWx1ZXM6IGNsb25lT2JqZWN0KGNvbnRyb2wuX2Zvcm1WYWx1ZXMpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIGNvbnRyb2wuX25hbWVzLmZvY3VzICYmXG4gICAgICAgICAgICBpdGVyYXRlRmllbGRzQnlBY3Rpb24oY29udHJvbC5fZmllbGRzLCAocmVmLCBrZXkpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoY29udHJvbC5fbmFtZXMuZm9jdXMgJiZcbiAgICAgICAgICAgICAgICAgICAga2V5LnN0YXJ0c1dpdGgoY29udHJvbC5fbmFtZXMuZm9jdXMpICYmXG4gICAgICAgICAgICAgICAgICAgIHJlZi5mb2N1cykge1xuICAgICAgICAgICAgICAgICAgICByZWYuZm9jdXMoKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDE7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICBjb250cm9sLl9uYW1lcy5mb2N1cyA9ICcnO1xuICAgICAgICBjb250cm9sLl9zZXRWYWxpZCgpO1xuICAgICAgICBfYWN0aW9uZWQuY3VycmVudCA9IGZhbHNlO1xuICAgIH0sIFtmaWVsZHMsIG5hbWUsIGNvbnRyb2wsIGRpc2FibGVkXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKCFkaXNhYmxlZCkge1xuICAgICAgICAgICAgIWdldChjb250cm9sLl9mb3JtVmFsdWVzLCBuYW1lKSAmJiBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBzaG91bGRLZWVwRmllbGRBcnJheVZhbHVlcyA9ICEoY29udHJvbC5fb3B0aW9ucy5zaG91bGRVbnJlZ2lzdGVyIHx8IHNob3VsZFVucmVnaXN0ZXIpO1xuICAgICAgICAgICAgY29uc3QgdXBkYXRlTW91bnRlZCA9IChuYW1lLCB2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KGNvbnRyb2wuX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgaWYgKGZpZWxkICYmIGZpZWxkLl9mKSB7XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkLl9mLm1vdW50ID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGlmIChfYWN0aW9uZWQuY3VycmVudCAmJiBzaG91bGRLZWVwRmllbGRBcnJheVZhbHVlcykge1xuICAgICAgICAgICAgICAgIGNvbnRyb2wuX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZXM6IGNsb25lT2JqZWN0KGNvbnRyb2wuX2Zvcm1WYWx1ZXMpLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2hvdWxkS2VlcEZpZWxkQXJyYXlWYWx1ZXNcbiAgICAgICAgICAgICAgICA/IHVwZGF0ZU1vdW50ZWQobmFtZSwgZmFsc2UpXG4gICAgICAgICAgICAgICAgOiBjb250cm9sLnVucmVnaXN0ZXIobmFtZSk7XG4gICAgICAgIH07XG4gICAgfSwgW25hbWUsIGNvbnRyb2wsIGtleU5hbWUsIHNob3VsZFVucmVnaXN0ZXIsIGRpc2FibGVkXSk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgc3dhcDogUmVhY3QudXNlQ2FsbGJhY2soc3dhcCwgW3VwZGF0ZVZhbHVlcywgbmFtZSwgY29udHJvbCwgZGlzYWJsZWRdKSxcbiAgICAgICAgbW92ZTogUmVhY3QudXNlQ2FsbGJhY2sobW92ZSwgW3VwZGF0ZVZhbHVlcywgbmFtZSwgY29udHJvbCwgZGlzYWJsZWRdKSxcbiAgICAgICAgcHJlcGVuZDogUmVhY3QudXNlQ2FsbGJhY2socHJlcGVuZCwgW1xuICAgICAgICAgICAgdXBkYXRlVmFsdWVzLFxuICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgIGNvbnRyb2wsXG4gICAgICAgICAgICBkaXNhYmxlZCxcbiAgICAgICAgXSksXG4gICAgICAgIGFwcGVuZDogUmVhY3QudXNlQ2FsbGJhY2soYXBwZW5kLCBbdXBkYXRlVmFsdWVzLCBuYW1lLCBjb250cm9sLCBkaXNhYmxlZF0pLFxuICAgICAgICByZW1vdmU6IFJlYWN0LnVzZUNhbGxiYWNrKHJlbW92ZSwgW3VwZGF0ZVZhbHVlcywgbmFtZSwgY29udHJvbCwgZGlzYWJsZWRdKSxcbiAgICAgICAgaW5zZXJ0OiBSZWFjdC51c2VDYWxsYmFjayhpbnNlcnQkMSwgW3VwZGF0ZVZhbHVlcywgbmFtZSwgY29udHJvbCwgZGlzYWJsZWRdKSxcbiAgICAgICAgdXBkYXRlOiBSZWFjdC51c2VDYWxsYmFjayh1cGRhdGUsIFt1cGRhdGVWYWx1ZXMsIG5hbWUsIGNvbnRyb2wsIGRpc2FibGVkXSksXG4gICAgICAgIHJlcGxhY2U6IFJlYWN0LnVzZUNhbGxiYWNrKHJlcGxhY2UsIFtcbiAgICAgICAgICAgIHVwZGF0ZVZhbHVlcyxcbiAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICBjb250cm9sLFxuICAgICAgICAgICAgZGlzYWJsZWQsXG4gICAgICAgIF0pLFxuICAgICAgICBmaWVsZHM6IFJlYWN0LnVzZU1lbW8oKCkgPT4gZmllbGRzLm1hcCgoZmllbGQsIGluZGV4KSA9PiAoe1xuICAgICAgICAgICAgLi4uZmllbGQsXG4gICAgICAgICAgICAuLi4oaXNCb29sZWFuKGRpc2FibGVkKSA/IHsgZGlzYWJsZWQgfSA6IHt9KSxcbiAgICAgICAgICAgIFtrZXlOYW1lXTogaWRzLmN1cnJlbnRbaW5kZXhdIHx8IGdlbmVyYXRlSWQoKSxcbiAgICAgICAgfSkpLCBbZmllbGRzLCBrZXlOYW1lLCBkaXNhYmxlZF0pLFxuICAgIH07XG59XG5cbi8qKlxuICogQ29tcG9uZW50IGJhc2VkIG9uIGB1c2VGaWVsZEFycmF5YCBob29rIHRvIHdvcmsgd2l0aCBjb250cm9sbGVkIGNvbXBvbmVudC5cbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiBmdW5jdGlvbiBBcHAoKSB7XG4gKiAgIGNvbnN0IHsgY29udHJvbCwgcmVnaXN0ZXIgfSA9IHVzZUZvcm08Rm9ybVZhbHVlcz4oe1xuICogICAgIGRlZmF1bHRWYWx1ZXM6IHtcbiAqICAgICAgIHRlc3Q6IFtcbiAqICAgICAgICAge1xuICogICAgICAgICAgIHZhbHVlOiAnJyxcbiAqICAgICAgICAgfSxcbiAqICAgICAgIF0sXG4gKiAgICAgfSxcbiAqICAgfSk7XG4gKlxuICogICByZXR1cm4gKFxuICogICAgIDxmb3JtPlxuICogICAgICAgPEZpZWxkQXJyYXlcbiAqICAgICAgICAgY29udHJvbD17Y29udHJvbH1cbiAqICAgICAgICAgbmFtZT1cInRlc3RcIlxuICogICAgICAgICByZW5kZXI9eyh7IGZpZWxkcyB9KSA9PlxuICogICAgICAgICAgIGZpZWxkcy5tYXAoKGZpZWxkLCBpbmRleCkgPT4gKFxuICogICAgICAgICAgICAgPGlucHV0IGtleT17ZmllbGQuaWR9IHsuLi5yZWdpc3RlcihgdGVzdC4ke2luZGV4fS52YWx1ZWApfSAvPlxuICogICAgICAgICAgICkpXG4gKiAgICAgICAgIH1cbiAqICAgICAgIC8+XG4gKiAgICAgPC9mb3JtPlxuICogICApO1xuICogfVxuICogYGBgXG4gKi9cbmNvbnN0IEZpZWxkQXJyYXkgPSAocHJvcHMpID0+IHByb3BzLnJlbmRlcih1c2VGaWVsZEFycmF5KHByb3BzKSk7XG5cbmNvbnN0IGZsYXR0ZW4gPSAob2JqKSA9PiB7XG4gICAgY29uc3Qgb3V0cHV0ID0ge307XG4gICAgZm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMob2JqKSkge1xuICAgICAgICBpZiAoaXNPYmplY3RUeXBlKG9ialtrZXldKSAmJlxuICAgICAgICAgICAgb2JqW2tleV0gIT09IG51bGwgJiZcbiAgICAgICAgICAgICFpc0RhdGVPYmplY3Qob2JqW2tleV0pKSB7XG4gICAgICAgICAgICBjb25zdCBuZXN0ZWQgPSBmbGF0dGVuKG9ialtrZXldKTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgbmVzdGVkS2V5IG9mIE9iamVjdC5rZXlzKG5lc3RlZCkpIHtcbiAgICAgICAgICAgICAgICBvdXRwdXRbYCR7a2V5fS4ke25lc3RlZEtleX1gXSA9IG5lc3RlZFtuZXN0ZWRLZXldO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgb3V0cHV0W2tleV0gPSBvYmpba2V5XTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gb3V0cHV0O1xufTtcblxuY29uc3QgSG9va0Zvcm1Db250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dChudWxsKTtcbkhvb2tGb3JtQ29udGV4dC5kaXNwbGF5TmFtZSA9ICdIb29rRm9ybUNvbnRleHQnO1xuLyoqXG4gKiBUaGlzIGN1c3RvbSBob29rIGFsbG93cyB5b3UgdG8gYWNjZXNzIHRoZSBmb3JtIGNvbnRleHQuIHVzZUZvcm1Db250ZXh0IGlzIGludGVuZGVkIHRvIGJlIHVzZWQgaW4gZGVlcGx5IG5lc3RlZCBzdHJ1Y3R1cmVzLCB3aGVyZSBpdCB3b3VsZCBiZWNvbWUgaW5jb252ZW5pZW50IHRvIHBhc3MgdGhlIGNvbnRleHQgYXMgYSBwcm9wLiBUbyBiZSB1c2VkIHdpdGgge0BsaW5rIEZvcm1Qcm92aWRlcn0uXG4gKlxuICogQHJlbWFya3NcbiAqIFtBUEldKGh0dHBzOi8vcmVhY3QtaG9vay1mb3JtLmNvbS9kb2NzL3VzZWZvcm1jb250ZXh0KSDigKIgW0RlbW9dKGh0dHBzOi8vY29kZXNhbmRib3guaW8vcy9yZWFjdC1ob29rLWZvcm0tdjctZm9ybS1jb250ZXh0LXl0dWRpKVxuICpcbiAqIEByZXR1cm5zIHJldHVybiBhbGwgdXNlRm9ybSBtZXRob2RzXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogZnVuY3Rpb24gQXBwKCkge1xuICogICBjb25zdCBtZXRob2RzID0gdXNlRm9ybSgpO1xuICogICBjb25zdCBvblN1Ym1pdCA9IGRhdGEgPT4gY29uc29sZS5sb2coZGF0YSk7XG4gKlxuICogICByZXR1cm4gKFxuICogICAgIDxGb3JtUHJvdmlkZXIgey4uLm1ldGhvZHN9ID5cbiAqICAgICAgIDxmb3JtIG9uU3VibWl0PXttZXRob2RzLmhhbmRsZVN1Ym1pdChvblN1Ym1pdCl9PlxuICogICAgICAgICA8TmVzdGVkSW5wdXQgLz5cbiAqICAgICAgICAgPGlucHV0IHR5cGU9XCJzdWJtaXRcIiAvPlxuICogICAgICAgPC9mb3JtPlxuICogICAgIDwvRm9ybVByb3ZpZGVyPlxuICogICApO1xuICogfVxuICpcbiAqICBmdW5jdGlvbiBOZXN0ZWRJbnB1dCgpIHtcbiAqICAgY29uc3QgeyByZWdpc3RlciB9ID0gdXNlRm9ybUNvbnRleHQoKTsgLy8gcmV0cmlldmUgYWxsIGhvb2sgbWV0aG9kc1xuICogICByZXR1cm4gPGlucHV0IHsuLi5yZWdpc3RlcihcInRlc3RcIil9IC8+O1xuICogfVxuICogYGBgXG4gKi9cbmNvbnN0IHVzZUZvcm1Db250ZXh0ID0gKCkgPT4gUmVhY3QudXNlQ29udGV4dChIb29rRm9ybUNvbnRleHQpO1xuLyoqXG4gKiBBIHByb3ZpZGVyIGNvbXBvbmVudCB0aGF0IHByb3BhZ2F0ZXMgdGhlIGB1c2VGb3JtYCBtZXRob2RzIHRvIGFsbCBjaGlsZHJlbiBjb21wb25lbnRzIHZpYSBbUmVhY3QgQ29udGV4dF0oaHR0cHM6Ly9yZWFjdC5kZXYvcmVmZXJlbmNlL3JlYWN0L3VzZUNvbnRleHQpIEFQSS4gVG8gYmUgdXNlZCB3aXRoIHtAbGluayB1c2VGb3JtQ29udGV4dH0uXG4gKlxuICogQHJlbWFya3NcbiAqIFtBUEldKGh0dHBzOi8vcmVhY3QtaG9vay1mb3JtLmNvbS9kb2NzL3VzZWZvcm1jb250ZXh0KSDigKIgW0RlbW9dKGh0dHBzOi8vY29kZXNhbmRib3guaW8vcy9yZWFjdC1ob29rLWZvcm0tdjctZm9ybS1jb250ZXh0LXl0dWRpKVxuICpcbiAqIEBwYXJhbSBwcm9wcyAtIGFsbCB1c2VGb3JtIG1ldGhvZHNcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiBmdW5jdGlvbiBBcHAoKSB7XG4gKiAgIGNvbnN0IG1ldGhvZHMgPSB1c2VGb3JtKCk7XG4gKiAgIGNvbnN0IG9uU3VibWl0ID0gZGF0YSA9PiBjb25zb2xlLmxvZyhkYXRhKTtcbiAqXG4gKiAgIHJldHVybiAoXG4gKiAgICAgPEZvcm1Qcm92aWRlciB7Li4ubWV0aG9kc30gPlxuICogICAgICAgPGZvcm0gb25TdWJtaXQ9e21ldGhvZHMuaGFuZGxlU3VibWl0KG9uU3VibWl0KX0+XG4gKiAgICAgICAgIDxOZXN0ZWRJbnB1dCAvPlxuICogICAgICAgICA8aW5wdXQgdHlwZT1cInN1Ym1pdFwiIC8+XG4gKiAgICAgICA8L2Zvcm0+XG4gKiAgICAgPC9Gb3JtUHJvdmlkZXI+XG4gKiAgICk7XG4gKiB9XG4gKlxuICogIGZ1bmN0aW9uIE5lc3RlZElucHV0KCkge1xuICogICBjb25zdCB7IHJlZ2lzdGVyIH0gPSB1c2VGb3JtQ29udGV4dCgpOyAvLyByZXRyaWV2ZSBhbGwgaG9vayBtZXRob2RzXG4gKiAgIHJldHVybiA8aW5wdXQgey4uLnJlZ2lzdGVyKFwidGVzdFwiKX0gLz47XG4gKiB9XG4gKiBgYGBcbiAqL1xuY29uc3QgRm9ybVByb3ZpZGVyID0gKHsgY2hpbGRyZW4sIHdhdGNoLCBnZXRWYWx1ZXMsIGdldEZpZWxkU3RhdGUsIHNldEVycm9yLCBjbGVhckVycm9ycywgc2V0VmFsdWUsIHNldFZhbHVlcywgdHJpZ2dlciwgZm9ybVN0YXRlLCByZXNldEZpZWxkLCByZXNldCwgcmVzZXREZWZhdWx0VmFsdWVzLCBoYW5kbGVTdWJtaXQsIHVucmVnaXN0ZXIsIGNvbnRyb2wsIHJlZ2lzdGVyLCBzZXRGb2N1cywgc3Vic2NyaWJlLCB9KSA9PiB7XG4gICAgY29uc3QgbWVtb2l6ZWRWYWx1ZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICAgICAgd2F0Y2gsXG4gICAgICAgIGdldFZhbHVlcyxcbiAgICAgICAgZ2V0RmllbGRTdGF0ZSxcbiAgICAgICAgc2V0RXJyb3IsXG4gICAgICAgIGNsZWFyRXJyb3JzLFxuICAgICAgICBzZXRWYWx1ZSxcbiAgICAgICAgc2V0VmFsdWVzLFxuICAgICAgICB0cmlnZ2VyLFxuICAgICAgICBmb3JtU3RhdGUsXG4gICAgICAgIHJlc2V0RmllbGQsXG4gICAgICAgIHJlc2V0LFxuICAgICAgICByZXNldERlZmF1bHRWYWx1ZXMsXG4gICAgICAgIGhhbmRsZVN1Ym1pdCxcbiAgICAgICAgdW5yZWdpc3RlcixcbiAgICAgICAgY29udHJvbCxcbiAgICAgICAgcmVnaXN0ZXIsXG4gICAgICAgIHNldEZvY3VzLFxuICAgICAgICBzdWJzY3JpYmUsXG4gICAgfSksIFtcbiAgICAgICAgY2xlYXJFcnJvcnMsXG4gICAgICAgIGNvbnRyb2wsXG4gICAgICAgIGZvcm1TdGF0ZSxcbiAgICAgICAgZ2V0RmllbGRTdGF0ZSxcbiAgICAgICAgZ2V0VmFsdWVzLFxuICAgICAgICBoYW5kbGVTdWJtaXQsXG4gICAgICAgIHJlZ2lzdGVyLFxuICAgICAgICByZXNldCxcbiAgICAgICAgcmVzZXREZWZhdWx0VmFsdWVzLFxuICAgICAgICByZXNldEZpZWxkLFxuICAgICAgICBzZXRFcnJvcixcbiAgICAgICAgc2V0Rm9jdXMsXG4gICAgICAgIHNldFZhbHVlLFxuICAgICAgICBzZXRWYWx1ZXMsXG4gICAgICAgIHN1YnNjcmliZSxcbiAgICAgICAgdHJpZ2dlcixcbiAgICAgICAgdW5yZWdpc3RlcixcbiAgICAgICAgd2F0Y2gsXG4gICAgXSk7XG4gICAgcmV0dXJuIChSZWFjdC5jcmVhdGVFbGVtZW50KEhvb2tGb3JtQ29udGV4dC5Qcm92aWRlciwgeyB2YWx1ZTogbWVtb2l6ZWRWYWx1ZSB9LFxuICAgICAgICBSZWFjdC5jcmVhdGVFbGVtZW50KEhvb2tGb3JtQ29udHJvbENvbnRleHQuUHJvdmlkZXIsIHsgdmFsdWU6IG1lbW9pemVkVmFsdWUuY29udHJvbCB9LCBjaGlsZHJlbikpKTtcbn07XG5cbmNvbnN0IFBPU1RfUkVRVUVTVCA9ICdwb3N0Jztcbi8qKlxuICogRm9ybSBjb21wb25lbnQgdG8gbWFuYWdlIHN1Ym1pc3Npb24uXG4gKlxuICogQHBhcmFtIHByb3BzIC0gdG8gc2V0dXAgc3VibWlzc2lvbiBkZXRhaWwuIHtAbGluayBGb3JtUHJvcHN9XG4gKlxuICogQHJldHVybnMgZm9ybSBjb21wb25lbnQgb3IgaGVhZGxlc3MgcmVuZGVyIHByb3AuXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogZnVuY3Rpb24gQXBwKCkge1xuICogICBjb25zdCB7IGNvbnRyb2wsIGZvcm1TdGF0ZTogeyBlcnJvcnMgfSB9ID0gdXNlRm9ybSgpO1xuICpcbiAqICAgcmV0dXJuIChcbiAqICAgICA8Rm9ybSBhY3Rpb249XCIvYXBpXCIgY29udHJvbD17Y29udHJvbH0+XG4gKiAgICAgICA8aW5wdXQgey4uLnJlZ2lzdGVyKFwibmFtZVwiKX0gLz5cbiAqICAgICAgIDxwPntlcnJvcnM/LnJvb3Q/LnNlcnZlciAmJiAnU2VydmVyIGVycm9yJ308L3A+XG4gKiAgICAgICA8YnV0dG9uPlN1Ym1pdDwvYnV0dG9uPlxuICogICAgIDwvRm9ybT5cbiAqICAgKTtcbiAqIH1cbiAqIGBgYFxuICovXG5mdW5jdGlvbiBGb3JtKHByb3BzKSB7XG4gICAgY29uc3QgbWV0aG9kcyA9IHVzZUZvcm1Db250ZXh0KCk7XG4gICAgY29uc3QgW21vdW50ZWQsIHNldE1vdW50ZWRdID0gUmVhY3QudXNlU3RhdGUoZmFsc2UpO1xuICAgIGNvbnN0IHsgY29udHJvbCA9IG1ldGhvZHMuY29udHJvbCwgb25TdWJtaXQsIGNoaWxkcmVuLCBhY3Rpb24sIG1ldGhvZCA9IFBPU1RfUkVRVUVTVCwgaGVhZGVycywgZW5jVHlwZSwgb25FcnJvciwgcmVuZGVyLCBvblN1Y2Nlc3MsIHZhbGlkYXRlU3RhdHVzLCAuLi5yZXN0IH0gPSBwcm9wcztcbiAgICBjb25zdCBzdWJtaXQgPSBSZWFjdC51c2VDYWxsYmFjayhhc3luYyAoZXZlbnQpID0+IHtcbiAgICAgICAgbGV0IGhhc0Vycm9yID0gZmFsc2U7XG4gICAgICAgIGxldCB0eXBlID0gJyc7XG4gICAgICAgIGF3YWl0IGNvbnRyb2wuaGFuZGxlU3VibWl0KGFzeW5jIChkYXRhKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xuICAgICAgICAgICAgbGV0IGZvcm1EYXRhSnNvbiA9ICcnO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBmb3JtRGF0YUpzb24gPSBKU09OLnN0cmluZ2lmeShkYXRhKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChfYSkgeyB9XG4gICAgICAgICAgICBjb25zdCBmbGF0dGVuRm9ybVZhbHVlcyA9IGZsYXR0ZW4oZGF0YSk7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGtleSBpbiBmbGF0dGVuRm9ybVZhbHVlcykge1xuICAgICAgICAgICAgICAgIGZvcm1EYXRhLmFwcGVuZChrZXksIGZsYXR0ZW5Gb3JtVmFsdWVzW2tleV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG9uU3VibWl0KSB7XG4gICAgICAgICAgICAgICAgYXdhaXQgb25TdWJtaXQoe1xuICAgICAgICAgICAgICAgICAgICBkYXRhLFxuICAgICAgICAgICAgICAgICAgICBldmVudCxcbiAgICAgICAgICAgICAgICAgICAgbWV0aG9kLFxuICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YSxcbiAgICAgICAgICAgICAgICAgICAgZm9ybURhdGFKc29uLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGFjdGlvbikge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHNob3VsZFN0cmluZ2lmeVN1Ym1pc3Npb25EYXRhID0gW1xuICAgICAgICAgICAgICAgICAgICAgICAgaGVhZGVycyAmJiBoZWFkZXJzWydDb250ZW50LVR5cGUnXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGVuY1R5cGUsXG4gICAgICAgICAgICAgICAgICAgIF0uc29tZSgodmFsdWUpID0+IHZhbHVlICYmIHZhbHVlLmluY2x1ZGVzKCdqc29uJykpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFN0cmluZyhhY3Rpb24pLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBtZXRob2QsXG4gICAgICAgICAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uaGVhZGVycyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi4oZW5jVHlwZSAmJiBlbmNUeXBlICE9PSAnbXVsdGlwYXJ0L2Zvcm0tZGF0YSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB7ICdDb250ZW50LVR5cGUnOiBlbmNUeXBlIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB7fSksXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgYm9keTogc2hvdWxkU3RyaW5naWZ5U3VibWlzc2lvbkRhdGEgPyBmb3JtRGF0YUpzb24gOiBmb3JtRGF0YSxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgKHZhbGlkYXRlU3RhdHVzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAhdmFsaWRhdGVTdGF0dXMocmVzcG9uc2Uuc3RhdHVzKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogcmVzcG9uc2Uuc3RhdHVzIDwgMjAwIHx8IHJlc3BvbnNlLnN0YXR1cyA+PSAzMDApKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBoYXNFcnJvciA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkVycm9yICYmIG9uRXJyb3IoeyByZXNwb25zZSB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGUgPSBTdHJpbmcocmVzcG9uc2Uuc3RhdHVzKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uU3VjY2VzcyAmJiBvblN1Y2Nlc3MoeyByZXNwb25zZSB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgaGFzRXJyb3IgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICBvbkVycm9yICYmIG9uRXJyb3IoeyBlcnJvciB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pKGV2ZW50KTtcbiAgICAgICAgaWYgKGhhc0Vycm9yICYmIGNvbnRyb2wpIHtcbiAgICAgICAgICAgIGNvbnRyb2wuX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIGlzU3VibWl0U3VjY2Vzc2Z1bDogZmFsc2UsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNvbnRyb2wuc2V0RXJyb3IoJ3Jvb3Quc2VydmVyJywge1xuICAgICAgICAgICAgICAgIHR5cGUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0sIFtcbiAgICAgICAgY29udHJvbCxcbiAgICAgICAgb25TdWJtaXQsXG4gICAgICAgIG1ldGhvZCxcbiAgICAgICAgYWN0aW9uLFxuICAgICAgICBoZWFkZXJzLFxuICAgICAgICBlbmNUeXBlLFxuICAgICAgICB2YWxpZGF0ZVN0YXR1cyxcbiAgICAgICAgb25FcnJvcixcbiAgICAgICAgb25TdWNjZXNzLFxuICAgIF0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHNldE1vdW50ZWQodHJ1ZSk7XG4gICAgfSwgW10pO1xuICAgIHJldHVybiByZW5kZXIgPyAoUmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5GcmFnbWVudCwgbnVsbCwgcmVuZGVyKHtcbiAgICAgICAgc3VibWl0LFxuICAgIH0pKSkgOiAoUmVhY3QuY3JlYXRlRWxlbWVudChcImZvcm1cIiwgeyBub1ZhbGlkYXRlOiBtb3VudGVkLCBhY3Rpb246IGFjdGlvbiwgbWV0aG9kOiBtZXRob2QsIGVuY1R5cGU6IGVuY1R5cGUsIG9uU3VibWl0OiBzdWJtaXQsIC4uLnJlc3QgfSwgY2hpbGRyZW4pKTtcbn1cblxuY29uc3QgRm9ybVN0YXRlU3Vic2NyaWJlID0gKHsgY29udHJvbCwgZGlzYWJsZWQsIGV4YWN0LCBuYW1lLCByZW5kZXIsIH0pID0+IHJlbmRlcih1c2VGb3JtU3RhdGUoeyBjb250cm9sLCBuYW1lLCBkaXNhYmxlZCwgZXhhY3QgfSkpO1xuXG52YXIgY3JlYXRlU3ViamVjdCA9ICgpID0+IHtcbiAgICBsZXQgX29ic2VydmVycyA9IFtdO1xuICAgIGNvbnN0IG5leHQgPSAodmFsdWUpID0+IHtcbiAgICAgICAgZm9yIChjb25zdCBvYnNlcnZlciBvZiBfb2JzZXJ2ZXJzKSB7XG4gICAgICAgICAgICBvYnNlcnZlci5uZXh0ICYmIG9ic2VydmVyLm5leHQodmFsdWUpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBzdWJzY3JpYmUgPSAob2JzZXJ2ZXIpID0+IHtcbiAgICAgICAgX29ic2VydmVycy5wdXNoKG9ic2VydmVyKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHVuc3Vic2NyaWJlOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgX29ic2VydmVycyA9IF9vYnNlcnZlcnMuZmlsdGVyKChvKSA9PiBvICE9PSBvYnNlcnZlcik7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgIH07XG4gICAgY29uc3QgdW5zdWJzY3JpYmUgPSAoKSA9PiB7XG4gICAgICAgIF9vYnNlcnZlcnMgPSBbXTtcbiAgICB9O1xuICAgIHJldHVybiB7XG4gICAgICAgIGdldCBvYnNlcnZlcnMoKSB7XG4gICAgICAgICAgICByZXR1cm4gX29ic2VydmVycztcbiAgICAgICAgfSxcbiAgICAgICAgbmV4dCxcbiAgICAgICAgc3Vic2NyaWJlLFxuICAgICAgICB1bnN1YnNjcmliZSxcbiAgICB9O1xufTtcblxuZnVuY3Rpb24gZXh0cmFjdEZvcm1WYWx1ZXMoZmllbGRzU3RhdGUsIGZvcm1WYWx1ZXMpIHtcbiAgICBjb25zdCB2YWx1ZXMgPSB7fTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBmaWVsZHNTdGF0ZSkge1xuICAgICAgICBpZiAoZmllbGRzU3RhdGUuaGFzT3duUHJvcGVydHkoa2V5KSkge1xuICAgICAgICAgICAgY29uc3QgZmllbGRTdGF0ZSA9IGZpZWxkc1N0YXRlW2tleV07XG4gICAgICAgICAgICBjb25zdCBmaWVsZFZhbHVlID0gZm9ybVZhbHVlc1trZXldO1xuICAgICAgICAgICAgaWYgKGZpZWxkU3RhdGUgJiYgaXNPYmplY3QoZmllbGRTdGF0ZSkgJiYgZmllbGRWYWx1ZSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IG5lc3RlZEZpZWxkc1N0YXRlID0gZXh0cmFjdEZvcm1WYWx1ZXMoZmllbGRTdGF0ZSwgZmllbGRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgaWYgKGlzT2JqZWN0KG5lc3RlZEZpZWxkc1N0YXRlKSkge1xuICAgICAgICAgICAgICAgICAgICB2YWx1ZXNba2V5XSA9IG5lc3RlZEZpZWxkc1N0YXRlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGZpZWxkc1N0YXRlW2tleV0pIHtcbiAgICAgICAgICAgICAgICB2YWx1ZXNba2V5XSA9IGZpZWxkVmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlcztcbn1cblxudmFyIGlzTXVsdGlwbGVTZWxlY3QgPSAoZWxlbWVudCkgPT4gZWxlbWVudC50eXBlID09PSBgc2VsZWN0LW11bHRpcGxlYDtcblxudmFyIGlzUmFkaW9PckNoZWNrYm94ID0gKHJlZikgPT4gaXNSYWRpb0lucHV0KHJlZikgfHwgaXNDaGVja0JveElucHV0KHJlZik7XG5cbnZhciBsaXZlID0gKHJlZikgPT4gaXNIVE1MRWxlbWVudChyZWYpICYmIHJlZi5pc0Nvbm5lY3RlZDtcblxudmFyIG9iamVjdEhhc0Z1bmN0aW9uID0gKGRhdGEpID0+IHtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBkYXRhKSB7XG4gICAgICAgIGlmIChpc0Z1bmN0aW9uKGRhdGFba2V5XSkpIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn07XG5cbmZ1bmN0aW9uIGlzVHJhdmVyc2FibGUodmFsdWUpIHtcbiAgICByZXR1cm4gQXJyYXkuaXNBcnJheSh2YWx1ZSkgfHwgKGlzT2JqZWN0KHZhbHVlKSAmJiAhb2JqZWN0SGFzRnVuY3Rpb24odmFsdWUpKTtcbn1cbmZ1bmN0aW9uIGlzUmVnaXN0ZXJlZExlYWYoZmllbGRSZWYpIHtcbiAgICByZXR1cm4gISEoZmllbGRSZWYgJiYgJ19mJyBpbiBmaWVsZFJlZik7XG59XG5mdW5jdGlvbiBpc0VtcHR5RGlydHlDb250YWluZXIodmFsdWUpIHtcbiAgICByZXR1cm4gQXJyYXkuaXNBcnJheSh2YWx1ZSlcbiAgICAgICAgPyAhdmFsdWUuc29tZSgoaXRlbSkgPT4gIWlzVW5kZWZpbmVkKGl0ZW0pKVxuICAgICAgICA6ICFPYmplY3Qua2V5cyh2YWx1ZSkubGVuZ3RoO1xufVxuZnVuY3Rpb24gY2xlYXJEaXJ0eUZpZWxkKGNvbnRhaW5lciwga2V5KSB7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoY29udGFpbmVyKSkge1xuICAgICAgICBjb250YWluZXJba2V5XSA9IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGRlbGV0ZSBjb250YWluZXJba2V5XTtcbiAgICB9XG59XG5mdW5jdGlvbiBtYXJrRmllbGRzRGlydHkoZGF0YSwgZmllbGRzID0ge30sIGZpZWxkUmVmcykge1xuICAgIGZvciAoY29uc3Qga2V5IGluIGRhdGEpIHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBkYXRhW2tleV07XG4gICAgICAgIGNvbnN0IGZpZWxkUmVmID0gZmllbGRSZWZzICYmIGZpZWxkUmVmc1trZXldO1xuICAgICAgICBpZiAoaXNUcmF2ZXJzYWJsZSh2YWx1ZSkgJiZcbiAgICAgICAgICAgICghQXJyYXkuaXNBcnJheSh2YWx1ZSkgfHwgIWlzUmVnaXN0ZXJlZExlYWYoZmllbGRSZWYpKSkge1xuICAgICAgICAgICAgZmllbGRzW2tleV0gPSBBcnJheS5pc0FycmF5KHZhbHVlKSA/IFtdIDoge307XG4gICAgICAgICAgICBtYXJrRmllbGRzRGlydHkodmFsdWUsIGZpZWxkc1trZXldLCBmaWVsZFJlZik7XG4gICAgICAgICAgICBpZiAoaXNFbXB0eURpcnR5Q29udGFpbmVyKGZpZWxkc1trZXldKSkge1xuICAgICAgICAgICAgICAgIGNsZWFyRGlydHlGaWVsZChmaWVsZHMsIGtleSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoIWlzVW5kZWZpbmVkKHZhbHVlKSkge1xuICAgICAgICAgICAgZmllbGRzW2tleV0gPSB0cnVlO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmaWVsZHM7XG59XG5mdW5jdGlvbiBnZXREaXJ0eUZpZWxkcyhkYXRhLCBmb3JtVmFsdWVzLCBkaXJ0eUZpZWxkc0Zyb21WYWx1ZXMsIGZpZWxkUmVmcykge1xuICAgIGlmICghZGlydHlGaWVsZHNGcm9tVmFsdWVzKSB7XG4gICAgICAgIGRpcnR5RmllbGRzRnJvbVZhbHVlcyA9IG1hcmtGaWVsZHNEaXJ0eShmb3JtVmFsdWVzLCB7fSwgZmllbGRSZWZzKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZGF0YSkge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGRhdGFba2V5XTtcbiAgICAgICAgY29uc3QgZmllbGRSZWYgPSBmaWVsZFJlZnMgJiYgZmllbGRSZWZzW2tleV07XG4gICAgICAgIGlmIChpc1RyYXZlcnNhYmxlKHZhbHVlKSAmJlxuICAgICAgICAgICAgKCFBcnJheS5pc0FycmF5KHZhbHVlKSB8fCAhaXNSZWdpc3RlcmVkTGVhZihmaWVsZFJlZikpKSB7XG4gICAgICAgICAgICBpZiAoaXNVbmRlZmluZWQoZm9ybVZhbHVlcykgfHwgaXNQcmltaXRpdmUoZGlydHlGaWVsZHNGcm9tVmFsdWVzW2tleV0pKSB7XG4gICAgICAgICAgICAgICAgZGlydHlGaWVsZHNGcm9tVmFsdWVzW2tleV0gPSBtYXJrRmllbGRzRGlydHkodmFsdWUsIEFycmF5LmlzQXJyYXkodmFsdWUpID8gW10gOiB7fSwgZmllbGRSZWYpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgZ2V0RGlydHlGaWVsZHModmFsdWUsIGlzTnVsbE9yVW5kZWZpbmVkKGZvcm1WYWx1ZXMpID8ge30gOiBmb3JtVmFsdWVzW2tleV0sIGRpcnR5RmllbGRzRnJvbVZhbHVlc1trZXldLCBmaWVsZFJlZik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaXNFbXB0eURpcnR5Q29udGFpbmVyKGRpcnR5RmllbGRzRnJvbVZhbHVlc1trZXldKSkge1xuICAgICAgICAgICAgICAgIGNsZWFyRGlydHlGaWVsZChkaXJ0eUZpZWxkc0Zyb21WYWx1ZXMsIGtleSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoZGVlcEVxdWFsKHZhbHVlLCBmb3JtVmFsdWVzW2tleV0pKSB7XG4gICAgICAgICAgICBjbGVhckRpcnR5RmllbGQoZGlydHlGaWVsZHNGcm9tVmFsdWVzLCBrZXkpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgZGlydHlGaWVsZHNGcm9tVmFsdWVzW2tleV0gPSB0cnVlO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBkaXJ0eUZpZWxkc0Zyb21WYWx1ZXM7XG59XG5cbnZhciBnZXRGaWVsZFZhbHVlQXMgPSAodmFsdWUsIHsgdmFsdWVBc051bWJlciwgdmFsdWVBc0RhdGUsIHNldFZhbHVlQXMgfSkgPT4gaXNVbmRlZmluZWQodmFsdWUpXG4gICAgPyB2YWx1ZVxuICAgIDogdmFsdWVBc051bWJlclxuICAgICAgICA/IHZhbHVlID09PSAnJ1xuICAgICAgICAgICAgPyBOYU5cbiAgICAgICAgICAgIDogdmFsdWVcbiAgICAgICAgICAgICAgICA/ICt2YWx1ZVxuICAgICAgICAgICAgICAgIDogdmFsdWVcbiAgICAgICAgOiB2YWx1ZUFzRGF0ZSAmJiBpc1N0cmluZyh2YWx1ZSlcbiAgICAgICAgICAgID8gbmV3IERhdGUodmFsdWUpXG4gICAgICAgICAgICA6IHNldFZhbHVlQXNcbiAgICAgICAgICAgICAgICA/IHNldFZhbHVlQXModmFsdWUpXG4gICAgICAgICAgICAgICAgOiB2YWx1ZTtcblxuZnVuY3Rpb24gZ2V0RmllbGRWYWx1ZShfZikge1xuICAgIGNvbnN0IHJlZiA9IF9mLnJlZjtcbiAgICBpZiAoaXNGaWxlSW5wdXQocmVmKSkge1xuICAgICAgICByZXR1cm4gcmVmLmZpbGVzO1xuICAgIH1cbiAgICBpZiAoaXNSYWRpb0lucHV0KHJlZikpIHtcbiAgICAgICAgcmV0dXJuIGdldFJhZGlvVmFsdWUoX2YucmVmcykudmFsdWU7XG4gICAgfVxuICAgIGlmIChpc011bHRpcGxlU2VsZWN0KHJlZikpIHtcbiAgICAgICAgcmV0dXJuIFsuLi5yZWYuc2VsZWN0ZWRPcHRpb25zXS5tYXAoKHsgdmFsdWUgfSkgPT4gdmFsdWUpO1xuICAgIH1cbiAgICBpZiAoaXNDaGVja0JveElucHV0KHJlZikpIHtcbiAgICAgICAgcmV0dXJuIGdldENoZWNrYm94VmFsdWUoX2YucmVmcykudmFsdWU7XG4gICAgfVxuICAgIHJldHVybiBnZXRGaWVsZFZhbHVlQXMoaXNVbmRlZmluZWQocmVmLnZhbHVlKSA/IF9mLnJlZi52YWx1ZSA6IHJlZi52YWx1ZSwgX2YpO1xufVxuXG52YXIgZ2V0UmVzb2x2ZXJPcHRpb25zID0gKGZpZWxkc05hbWVzLCBfZmllbGRzLCBjcml0ZXJpYU1vZGUsIHNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24pID0+IHtcbiAgICBjb25zdCBmaWVsZHMgPSB7fTtcbiAgICBmb3IgKGNvbnN0IG5hbWUgb2YgZmllbGRzTmFtZXMpIHtcbiAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgIGZpZWxkICYmIHNldChmaWVsZHMsIG5hbWUsIGZpZWxkLl9mKTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgY3JpdGVyaWFNb2RlLFxuICAgICAgICBuYW1lczogWy4uLmZpZWxkc05hbWVzXSxcbiAgICAgICAgZmllbGRzLFxuICAgICAgICBzaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uLFxuICAgIH07XG59O1xuXG52YXIgZ2V0UnVsZVZhbHVlID0gKHJ1bGUpID0+IGlzVW5kZWZpbmVkKHJ1bGUpXG4gICAgPyBydWxlXG4gICAgOiBpc1JlZ2V4KHJ1bGUpXG4gICAgICAgID8gcnVsZS5zb3VyY2VcbiAgICAgICAgOiBpc09iamVjdChydWxlKVxuICAgICAgICAgICAgPyBpc1JlZ2V4KHJ1bGUudmFsdWUpXG4gICAgICAgICAgICAgICAgPyBydWxlLnZhbHVlLnNvdXJjZVxuICAgICAgICAgICAgICAgIDogcnVsZS52YWx1ZVxuICAgICAgICAgICAgOiBydWxlO1xuXG5jb25zdCBBU1lOQ19GVU5DVElPTiA9ICdBc3luY0Z1bmN0aW9uJztcbnZhciBoYXNQcm9taXNlVmFsaWRhdGlvbiA9IChmaWVsZFJlZmVyZW5jZSkgPT4ge1xuICAgIGlmICghZmllbGRSZWZlcmVuY2UgfHwgIWZpZWxkUmVmZXJlbmNlLnZhbGlkYXRlKVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgaWYgKGlzRnVuY3Rpb24oZmllbGRSZWZlcmVuY2UudmFsaWRhdGUpKSB7XG4gICAgICAgIHJldHVybiBmaWVsZFJlZmVyZW5jZS52YWxpZGF0ZS5jb25zdHJ1Y3Rvci5uYW1lID09PSBBU1lOQ19GVU5DVElPTjtcbiAgICB9XG4gICAgaWYgKGlzT2JqZWN0KGZpZWxkUmVmZXJlbmNlLnZhbGlkYXRlKSkge1xuICAgICAgICBmb3IgKGNvbnN0IGtleSBpbiBmaWVsZFJlZmVyZW5jZS52YWxpZGF0ZSkge1xuICAgICAgICAgICAgaWYgKGZpZWxkUmVmZXJlbmNlLnZhbGlkYXRlW2tleV0uY29uc3RydWN0b3JcbiAgICAgICAgICAgICAgICAubmFtZSA9PT0gQVNZTkNfRlVOQ1RJT04pIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG59O1xuXG52YXIgaGFzVmFsaWRhdGlvbiA9IChvcHRpb25zKSA9PiBvcHRpb25zLm1vdW50ICYmXG4gICAgKG9wdGlvbnMucmVxdWlyZWQgfHxcbiAgICAgICAgb3B0aW9ucy5taW4gfHxcbiAgICAgICAgb3B0aW9ucy5tYXggfHxcbiAgICAgICAgb3B0aW9ucy5tYXhMZW5ndGggfHxcbiAgICAgICAgb3B0aW9ucy5taW5MZW5ndGggfHxcbiAgICAgICAgb3B0aW9ucy5wYXR0ZXJuIHx8XG4gICAgICAgIG9wdGlvbnMudmFsaWRhdGUpO1xuXG5mdW5jdGlvbiBzY2hlbWFFcnJvckxvb2t1cChlcnJvcnMsIF9maWVsZHMsIG5hbWUpIHtcbiAgICBjb25zdCBlcnJvciA9IGdldChlcnJvcnMsIG5hbWUpO1xuICAgIGlmIChlcnJvciB8fCBpc0tleShuYW1lKSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgZXJyb3IsXG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBjb25zdCBuYW1lcyA9IG5hbWUuc3BsaXQoJy4nKTtcbiAgICB3aGlsZSAobmFtZXMubGVuZ3RoKSB7XG4gICAgICAgIGNvbnN0IGZpZWxkTmFtZSA9IG5hbWVzLmpvaW4oJy4nKTtcbiAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgY29uc3QgZm91bmRFcnJvciA9IGdldChlcnJvcnMsIGZpZWxkTmFtZSk7XG4gICAgICAgIGlmIChmaWVsZCAmJiAhQXJyYXkuaXNBcnJheShmaWVsZCkgJiYgbmFtZSAhPT0gZmllbGROYW1lKSB7XG4gICAgICAgICAgICByZXR1cm4geyBuYW1lIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvdW5kRXJyb3IgJiYgZm91bmRFcnJvci50eXBlKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIG5hbWU6IGZpZWxkTmFtZSxcbiAgICAgICAgICAgICAgICBlcnJvcjogZm91bmRFcnJvcixcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvdW5kRXJyb3IgJiYgZm91bmRFcnJvci5yb290ICYmIGZvdW5kRXJyb3Iucm9vdC50eXBlKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIG5hbWU6IGAke2ZpZWxkTmFtZX0ucm9vdGAsXG4gICAgICAgICAgICAgICAgZXJyb3I6IGZvdW5kRXJyb3Iucm9vdCxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgbmFtZXMucG9wKCk7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIG5hbWUsXG4gICAgfTtcbn1cblxudmFyIHNob3VsZFJlbmRlckZvcm1TdGF0ZSA9IChmb3JtU3RhdGVEYXRhLCBfcHJveHlGb3JtU3RhdGUsIHVwZGF0ZUZvcm1TdGF0ZSwgaXNSb290KSA9PiB7XG4gICAgdXBkYXRlRm9ybVN0YXRlKGZvcm1TdGF0ZURhdGEpO1xuICAgIGNvbnN0IHsgbmFtZSwgLi4uZm9ybVN0YXRlIH0gPSBmb3JtU3RhdGVEYXRhO1xuICAgIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhmb3JtU3RhdGUpO1xuICAgIHJldHVybiAoIWtleXMubGVuZ3RoIHx8XG4gICAgICAgIChpc1Jvb3QgJiYga2V5cy5sZW5ndGggPj0gT2JqZWN0LmtleXMoX3Byb3h5Rm9ybVN0YXRlKS5sZW5ndGgpIHx8XG4gICAgICAgIGtleXMuZmluZCgoa2V5KSA9PiBfcHJveHlGb3JtU3RhdGVba2V5XSA9PT1cbiAgICAgICAgICAgICghaXNSb290IHx8IFZBTElEQVRJT05fTU9ERS5hbGwpKSk7XG59O1xuXG52YXIgc2hvdWxkU3Vic2NyaWJlQnlOYW1lID0gKG5hbWUsIHNpZ25hbE5hbWUsIGV4YWN0KSA9PiAhbmFtZSB8fFxuICAgICFzaWduYWxOYW1lIHx8XG4gICAgbmFtZSA9PT0gc2lnbmFsTmFtZSB8fFxuICAgIGNvbnZlcnRUb0FycmF5UGF5bG9hZChuYW1lKS5zb21lKChjdXJyZW50TmFtZSkgPT4gY3VycmVudE5hbWUgJiZcbiAgICAgICAgKGV4YWN0XG4gICAgICAgICAgICA/IGN1cnJlbnROYW1lID09PSBzaWduYWxOYW1lIHx8IGN1cnJlbnROYW1lLnN0YXJ0c1dpdGgoc2lnbmFsTmFtZSArICcuJylcbiAgICAgICAgICAgIDogY3VycmVudE5hbWUuc3RhcnRzV2l0aChzaWduYWxOYW1lKSB8fFxuICAgICAgICAgICAgICAgIHNpZ25hbE5hbWUuc3RhcnRzV2l0aChjdXJyZW50TmFtZSkpKTtcblxudmFyIHNraXBWYWxpZGF0aW9uID0gKGlzQmx1ckV2ZW50LCBpc1RvdWNoZWQsIGlzU3VibWl0dGVkLCByZVZhbGlkYXRlTW9kZSwgbW9kZSkgPT4ge1xuICAgIGlmIChtb2RlLmlzT25BbGwpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBlbHNlIGlmICghaXNTdWJtaXR0ZWQgJiYgbW9kZS5pc09uVG91Y2gpIHtcbiAgICAgICAgcmV0dXJuICEoaXNUb3VjaGVkIHx8IGlzQmx1ckV2ZW50KTtcbiAgICB9XG4gICAgZWxzZSBpZiAoaXNTdWJtaXR0ZWQgPyByZVZhbGlkYXRlTW9kZS5pc09uQmx1ciA6IG1vZGUuaXNPbkJsdXIpIHtcbiAgICAgICAgcmV0dXJuICFpc0JsdXJFdmVudDtcbiAgICB9XG4gICAgZWxzZSBpZiAoaXNTdWJtaXR0ZWQgPyByZVZhbGlkYXRlTW9kZS5pc09uQ2hhbmdlIDogbW9kZS5pc09uQ2hhbmdlKSB7XG4gICAgICAgIHJldHVybiBpc0JsdXJFdmVudDtcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG59O1xuXG52YXIgdW5zZXRFbXB0eUFycmF5ID0gKHJlZiwgbmFtZSkgPT4gIWNvbXBhY3QoZ2V0KHJlZiwgbmFtZSkpLmxlbmd0aCAmJiB1bnNldChyZWYsIG5hbWUpO1xuXG5jb25zdCBkZWZhdWx0T3B0aW9ucyA9IHtcbiAgICBtb2RlOiBWQUxJREFUSU9OX01PREUub25TdWJtaXQsXG4gICAgcmVWYWxpZGF0ZU1vZGU6IFZBTElEQVRJT05fTU9ERS5vbkNoYW5nZSxcbiAgICBzaG91bGRGb2N1c0Vycm9yOiB0cnVlLFxufTtcbmNvbnN0IEZPUk1fRVJST1JfVFlQRSA9ICdmb3JtJztcbmNvbnN0IERFRkFVTFRfRk9STV9TVEFURSA9IHtcbiAgICBzdWJtaXRDb3VudDogMCxcbiAgICBpc0RpcnR5OiBmYWxzZSxcbiAgICBpc1JlYWR5OiBmYWxzZSxcbiAgICBpc1ZhbGlkYXRpbmc6IGZhbHNlLFxuICAgIGlzU3VibWl0dGVkOiBmYWxzZSxcbiAgICBpc1N1Ym1pdHRpbmc6IGZhbHNlLFxuICAgIGlzU3VibWl0U3VjY2Vzc2Z1bDogZmFsc2UsXG4gICAgaXNWYWxpZDogZmFsc2UsXG4gICAgdG91Y2hlZEZpZWxkczoge30sXG4gICAgZGlydHlGaWVsZHM6IHt9LFxuICAgIHZhbGlkYXRpbmdGaWVsZHM6IHt9LFxufTtcbmZ1bmN0aW9uIGNyZWF0ZUZvcm1Db250cm9sKHByb3BzID0ge30pIHtcbiAgICBsZXQgX29wdGlvbnMgPSB7XG4gICAgICAgIC4uLmRlZmF1bHRPcHRpb25zLFxuICAgICAgICAuLi5wcm9wcyxcbiAgICB9O1xuICAgIGxldCBfZm9ybVN0YXRlID0ge1xuICAgICAgICAuLi5jbG9uZU9iamVjdChERUZBVUxUX0ZPUk1fU1RBVEUpLFxuICAgICAgICBpc0xvYWRpbmc6IGlzRnVuY3Rpb24oX29wdGlvbnMuZGVmYXVsdFZhbHVlcyksXG4gICAgICAgIGVycm9yczogX29wdGlvbnMuZXJyb3JzIHx8IHt9LFxuICAgICAgICBkaXNhYmxlZDogX29wdGlvbnMuZGlzYWJsZWQgfHwgZmFsc2UsXG4gICAgfTtcbiAgICBsZXQgX2ZpZWxkcyA9IHt9O1xuICAgIGxldCBfZGVmYXVsdFZhbHVlcyA9IGlzT2JqZWN0KF9vcHRpb25zLmRlZmF1bHRWYWx1ZXMpIHx8IGlzT2JqZWN0KF9vcHRpb25zLnZhbHVlcylcbiAgICAgICAgPyBjbG9uZU9iamVjdChfb3B0aW9ucy5kZWZhdWx0VmFsdWVzIHx8IF9vcHRpb25zLnZhbHVlcykgfHwge31cbiAgICAgICAgOiB7fTtcbiAgICBsZXQgX2Zvcm1WYWx1ZXMgPSBfb3B0aW9ucy5zaG91bGRVbnJlZ2lzdGVyXG4gICAgICAgID8ge31cbiAgICAgICAgOiBjbG9uZU9iamVjdChfZGVmYXVsdFZhbHVlcyk7XG4gICAgbGV0IF9zdGF0ZSA9IHtcbiAgICAgICAgYWN0aW9uOiBmYWxzZSxcbiAgICAgICAgbW91bnQ6IGZhbHNlLFxuICAgICAgICB3YXRjaDogZmFsc2UsXG4gICAgICAgIGtlZXBJc1ZhbGlkOiBmYWxzZSxcbiAgICB9O1xuICAgIGxldCBfbmFtZXMgPSB7XG4gICAgICAgIG1vdW50OiBuZXcgU2V0KCksXG4gICAgICAgIGRpc2FibGVkOiBuZXcgU2V0KCksXG4gICAgICAgIHVuTW91bnQ6IG5ldyBTZXQoKSxcbiAgICAgICAgYXJyYXk6IG5ldyBTZXQoKSxcbiAgICAgICAgd2F0Y2g6IG5ldyBTZXQoKSxcbiAgICAgICAgcmVnaXN0ZXJOYW1lOiBuZXcgU2V0KCksXG4gICAgfTtcbiAgICBjb25zdCBkZWxheUVycm9yQ2FsbGJhY2tzID0ge307XG4gICAgY29uc3QgdGltZXJzID0ge307XG4gICAgbGV0IF92YWx1ZXNTdWJzY3JpYmVyQ291bnQgPSAwO1xuICAgIGxldCBfdmFsaWRhdGlvbk1vZGVCZWZvcmVTdWJtaXQgPSBnZXRWYWxpZGF0aW9uTW9kZXMoX29wdGlvbnMubW9kZSk7XG4gICAgbGV0IF92YWxpZGF0aW9uTW9kZUFmdGVyU3VibWl0ID0gZ2V0VmFsaWRhdGlvbk1vZGVzKF9vcHRpb25zLnJlVmFsaWRhdGVNb2RlKTtcbiAgICBjb25zdCBkZWZhdWx0UHJveHlGb3JtU3RhdGUgPSB7XG4gICAgICAgIGlzRGlydHk6IGZhbHNlLFxuICAgICAgICBkaXJ0eUZpZWxkczogZmFsc2UsXG4gICAgICAgIHZhbGlkYXRpbmdGaWVsZHM6IGZhbHNlLFxuICAgICAgICB0b3VjaGVkRmllbGRzOiBmYWxzZSxcbiAgICAgICAgaXNWYWxpZGF0aW5nOiBmYWxzZSxcbiAgICAgICAgaXNWYWxpZDogZmFsc2UsXG4gICAgICAgIGVycm9yczogZmFsc2UsXG4gICAgfTtcbiAgICBjb25zdCBfcHJveHlGb3JtU3RhdGUgPSB7XG4gICAgICAgIC4uLmRlZmF1bHRQcm94eUZvcm1TdGF0ZSxcbiAgICB9O1xuICAgIGxldCBfcHJveHlTdWJzY3JpYmVGb3JtU3RhdGUgPSB7XG4gICAgICAgIC4uLl9wcm94eUZvcm1TdGF0ZSxcbiAgICB9O1xuICAgIGNvbnN0IF9zdWJqZWN0cyA9IHtcbiAgICAgICAgYXJyYXk6IGNyZWF0ZVN1YmplY3QoKSxcbiAgICAgICAgc3RhdGU6IGNyZWF0ZVN1YmplY3QoKSxcbiAgICB9O1xuICAgIGxldCBfc2V0VmFsaWRDYWxsSWQgPSAwO1xuICAgIGNvbnN0IHNob3VsZERpc3BsYXlBbGxBc3NvY2lhdGVkRXJyb3JzID0gX29wdGlvbnMuY3JpdGVyaWFNb2RlID09PSBWQUxJREFUSU9OX01PREUuYWxsO1xuICAgIGNvbnN0IGRlYm91bmNlID0gKG5hbWUsIGNhbGxiYWNrKSA9PiAod2FpdCkgPT4ge1xuICAgICAgICBjbGVhclRpbWVvdXQodGltZXJzW25hbWVdKTtcbiAgICAgICAgdGltZXJzW25hbWVdID0gc2V0VGltZW91dChjYWxsYmFjaywgd2FpdCk7XG4gICAgfTtcbiAgICBjb25zdCBfc2V0VmFsaWQgPSBhc3luYyAoc2hvdWxkVXBkYXRlVmFsaWQpID0+IHtcbiAgICAgICAgaWYgKF9zdGF0ZS5rZWVwSXNWYWxpZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICghX29wdGlvbnMuZGlzYWJsZWQgJiZcbiAgICAgICAgICAgIChfcHJveHlGb3JtU3RhdGUuaXNWYWxpZCB8fFxuICAgICAgICAgICAgICAgIF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZS5pc1ZhbGlkIHx8XG4gICAgICAgICAgICAgICAgc2hvdWxkVXBkYXRlVmFsaWQpKSB7XG4gICAgICAgICAgICBjb25zdCBjYWxsSWQgPSArK19zZXRWYWxpZENhbGxJZDtcbiAgICAgICAgICAgIGxldCBpc1ZhbGlkO1xuICAgICAgICAgICAgaWYgKF9vcHRpb25zLnJlc29sdmVyKSB7XG4gICAgICAgICAgICAgICAgaXNWYWxpZCA9IGlzRW1wdHlPYmplY3QoKGF3YWl0IF9ydW5TY2hlbWEoKSkuZXJyb3JzKTtcbiAgICAgICAgICAgICAgICBjYWxsSWQgPT09IF9zZXRWYWxpZENhbGxJZCAmJiBfdXBkYXRlSXNWYWxpZGF0aW5nKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBpc1ZhbGlkID0gYXdhaXQgZXhlY3V0ZUJ1aWx0SW5WYWxpZGF0aW9uKHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGRzOiBfZmllbGRzLFxuICAgICAgICAgICAgICAgICAgICBvbmx5Q2hlY2tWYWxpZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgZXZlbnRUeXBlOiBFVkVOVFMuVkFMSUQsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoY2FsbElkID09PSBfc2V0VmFsaWRDYWxsSWQgJiYgaXNWYWxpZCAhPT0gX2Zvcm1TdGF0ZS5pc1ZhbGlkKSB7XG4gICAgICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBfdXBkYXRlSXNWYWxpZGF0aW5nID0gKG5hbWVzLCBpc1ZhbGlkYXRpbmcpID0+IHtcbiAgICAgICAgaWYgKCFfb3B0aW9ucy5kaXNhYmxlZCAmJlxuICAgICAgICAgICAgKF9wcm94eUZvcm1TdGF0ZS5pc1ZhbGlkYXRpbmcgfHxcbiAgICAgICAgICAgICAgICBfcHJveHlGb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcyB8fFxuICAgICAgICAgICAgICAgIF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZS5pc1ZhbGlkYXRpbmcgfHxcbiAgICAgICAgICAgICAgICBfcHJveHlTdWJzY3JpYmVGb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcykpIHtcbiAgICAgICAgICAgIChuYW1lcyB8fCBBcnJheS5mcm9tKF9uYW1lcy5tb3VudCkpLmZvckVhY2goKG5hbWUpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAobmFtZSkge1xuICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkYXRpbmdcbiAgICAgICAgICAgICAgICAgICAgICAgID8gc2V0KF9mb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcywgbmFtZSwgaXNWYWxpZGF0aW5nKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiB1bnNldChfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIHZhbGlkYXRpbmdGaWVsZHM6IF9mb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcyxcbiAgICAgICAgICAgICAgICBpc1ZhbGlkYXRpbmc6ICFpc0VtcHR5T2JqZWN0KF9mb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcyksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgX3VwZGF0ZURpcnR5RmllbGRzID0gKCkgPT4ge1xuICAgICAgICBfZm9ybVN0YXRlLmRpcnR5RmllbGRzID0gZ2V0RGlydHlGaWVsZHMoX2RlZmF1bHRWYWx1ZXMsIF9mb3JtVmFsdWVzLCB1bmRlZmluZWQsIF9maWVsZHMpO1xuICAgIH07XG4gICAgY29uc3QgX3NldEZpZWxkQXJyYXkgPSAobmFtZSwgdmFsdWVzID0gW10sIG1ldGhvZCwgYXJncywgc2hvdWxkU2V0VmFsdWVzID0gdHJ1ZSwgc2hvdWxkVXBkYXRlRmllbGRzQW5kU3RhdGUgPSB0cnVlKSA9PiB7XG4gICAgICAgIGlmIChhcmdzICYmIG1ldGhvZCAmJiAhX29wdGlvbnMuZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIF9zdGF0ZS5hY3Rpb24gPSB0cnVlO1xuICAgICAgICAgICAgaWYgKHNob3VsZFVwZGF0ZUZpZWxkc0FuZFN0YXRlICYmIEFycmF5LmlzQXJyYXkoZ2V0KF9maWVsZHMsIG5hbWUpKSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkVmFsdWVzID0gbWV0aG9kKGdldChfZmllbGRzLCBuYW1lKSwgYXJncy5hcmdBLCBhcmdzLmFyZ0IpO1xuICAgICAgICAgICAgICAgIHNob3VsZFNldFZhbHVlcyAmJiBzZXQoX2ZpZWxkcywgbmFtZSwgZmllbGRWYWx1ZXMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHNob3VsZFVwZGF0ZUZpZWxkc0FuZFN0YXRlICYmXG4gICAgICAgICAgICAgICAgQXJyYXkuaXNBcnJheShnZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpKSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGVycm9ycyA9IG1ldGhvZChnZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpLCBhcmdzLmFyZ0EsIGFyZ3MuYXJnQik7XG4gICAgICAgICAgICAgICAgc2hvdWxkU2V0VmFsdWVzICYmIHNldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSwgZXJyb3JzKTtcbiAgICAgICAgICAgICAgICB1bnNldEVtcHR5QXJyYXkoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKChfcHJveHlGb3JtU3RhdGUudG91Y2hlZEZpZWxkcyB8fFxuICAgICAgICAgICAgICAgIF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZS50b3VjaGVkRmllbGRzKSAmJlxuICAgICAgICAgICAgICAgIHNob3VsZFVwZGF0ZUZpZWxkc0FuZFN0YXRlICYmXG4gICAgICAgICAgICAgICAgQXJyYXkuaXNBcnJheShnZXQoX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBuYW1lKSkpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB0b3VjaGVkRmllbGRzID0gbWV0aG9kKGdldChfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIG5hbWUpLCBhcmdzLmFyZ0EsIGFyZ3MuYXJnQik7XG4gICAgICAgICAgICAgICAgc2hvdWxkU2V0VmFsdWVzICYmIHNldChfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIG5hbWUsIHRvdWNoZWRGaWVsZHMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKF9wcm94eUZvcm1TdGF0ZS5kaXJ0eUZpZWxkcyB8fCBfcHJveHlTdWJzY3JpYmVGb3JtU3RhdGUuZGlydHlGaWVsZHMpIHtcbiAgICAgICAgICAgICAgICBfdXBkYXRlRGlydHlGaWVsZHMoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgIGlzRGlydHk6IF9nZXREaXJ0eShuYW1lLCB2YWx1ZXMpLFxuICAgICAgICAgICAgICAgIGRpcnR5RmllbGRzOiBfZm9ybVN0YXRlLmRpcnR5RmllbGRzLFxuICAgICAgICAgICAgICAgIGVycm9yczogX2Zvcm1TdGF0ZS5lcnJvcnMsXG4gICAgICAgICAgICAgICAgaXNWYWxpZDogX2Zvcm1TdGF0ZS5pc1ZhbGlkLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBzZXQoX2Zvcm1WYWx1ZXMsIG5hbWUsIHZhbHVlcyk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHVwZGF0ZUVycm9ycyA9IChuYW1lLCBlcnJvcikgPT4ge1xuICAgICAgICBzZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUsIGVycm9yKTtcbiAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7IC4uLl9mb3JtU3RhdGUuZXJyb3JzIH07XG4gICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgIGVycm9yczogX2Zvcm1TdGF0ZS5lcnJvcnMsXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgX3NldEVycm9ycyA9IChlcnJvcnMpID0+IHtcbiAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSBlcnJvcnM7XG4gICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgIGVycm9yczogX2Zvcm1TdGF0ZS5lcnJvcnMsXG4gICAgICAgICAgICBpc1ZhbGlkOiBmYWxzZSxcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCBoYXNFeHBsaWNpdE51bGxJbnRlcm1lZGlhdGUgPSAobmFtZSkgPT4ge1xuICAgICAgICBjb25zdCBzZWdtZW50cyA9IGlzS2V5KG5hbWUpID8gW25hbWVdIDogc3RyaW5nVG9QYXRoKG5hbWUpO1xuICAgICAgICBsZXQgZm9ybVZhbHVlcyA9IF9mb3JtVmFsdWVzO1xuICAgICAgICBsZXQgZGVmYXVsdFZhbHVlcyA9IF9kZWZhdWx0VmFsdWVzO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNlZ21lbnRzLmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgICAgICAgY29uc3Qga2V5ID0gc2VnbWVudHNbaV07XG4gICAgICAgICAgICBmb3JtVmFsdWVzID0gaXNOdWxsT3JVbmRlZmluZWQoZm9ybVZhbHVlcykgPyBmb3JtVmFsdWVzIDogZm9ybVZhbHVlc1trZXldO1xuICAgICAgICAgICAgZGVmYXVsdFZhbHVlcyA9IGlzTnVsbE9yVW5kZWZpbmVkKGRlZmF1bHRWYWx1ZXMpXG4gICAgICAgICAgICAgICAgPyBkZWZhdWx0VmFsdWVzXG4gICAgICAgICAgICAgICAgOiBkZWZhdWx0VmFsdWVzW2tleV07XG4gICAgICAgICAgICBpZiAoZm9ybVZhbHVlcyA9PT0gbnVsbCAmJiBkZWZhdWx0VmFsdWVzICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH07XG4gICAgY29uc3QgdXBkYXRlVmFsaWRBbmRWYWx1ZSA9IChuYW1lLCBzaG91bGRTa2lwU2V0VmFsdWVBcywgdmFsdWUsIHJlZikgPT4ge1xuICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgaWYgKGZpZWxkKSB7XG4gICAgICAgICAgICBpZiAoaGFzRXhwbGljaXROdWxsSW50ZXJtZWRpYXRlKG5hbWUpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3Qgd2FzVW5zZXRJbkZvcm1WYWx1ZXMgPSBpc1VuZGVmaW5lZChnZXQoX2Zvcm1WYWx1ZXMsIG5hbWUpKTtcbiAgICAgICAgICAgIGNvbnN0IGRlZmF1bHRWYWx1ZSA9IGdldChfZm9ybVZhbHVlcywgbmFtZSwgaXNVbmRlZmluZWQodmFsdWUpID8gZ2V0KF9kZWZhdWx0VmFsdWVzLCBuYW1lKSA6IHZhbHVlKTtcbiAgICAgICAgICAgIGlzVW5kZWZpbmVkKGRlZmF1bHRWYWx1ZSkgfHxcbiAgICAgICAgICAgICAgICAocmVmICYmIHJlZi5kZWZhdWx0Q2hlY2tlZCkgfHxcbiAgICAgICAgICAgICAgICBzaG91bGRTa2lwU2V0VmFsdWVBc1xuICAgICAgICAgICAgICAgID8gc2V0KF9mb3JtVmFsdWVzLCBuYW1lLCBzaG91bGRTa2lwU2V0VmFsdWVBcyA/IGRlZmF1bHRWYWx1ZSA6IGdldEZpZWxkVmFsdWUoZmllbGQuX2YpKVxuICAgICAgICAgICAgICAgIDogc2V0RmllbGRWYWx1ZShuYW1lLCBkZWZhdWx0VmFsdWUpO1xuICAgICAgICAgICAgaWYgKF9zdGF0ZS5tb3VudCAmJiAhX3N0YXRlLmFjdGlvbikge1xuICAgICAgICAgICAgICAgIF9zZXRWYWxpZCgpO1xuICAgICAgICAgICAgICAgIGlmICh3YXNVbnNldEluRm9ybVZhbHVlcyAmJlxuICAgICAgICAgICAgICAgICAgICBfZm9ybVN0YXRlLmlzRGlydHkgJiZcbiAgICAgICAgICAgICAgICAgICAgKF9wcm94eUZvcm1TdGF0ZS5pc0RpcnR5IHx8IF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZS5pc0RpcnR5KSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0RpcnR5ID0gX2dldERpcnR5KCk7XG4gICAgICAgICAgICAgICAgICAgIGlmICghaXNEaXJ0eSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgX2Zvcm1TdGF0ZS5pc0RpcnR5ID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7IC4uLl9mb3JtU3RhdGUgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHByb3BzLnNob3VsZFVucmVnaXN0ZXIgJiZcbiAgICAgICAgICAgICAgICAgICAgd2FzVW5zZXRJbkZvcm1WYWx1ZXMgJiZcbiAgICAgICAgICAgICAgICAgICAgIWlzVW5kZWZpbmVkKGdldChfZm9ybVZhbHVlcywgbmFtZSkpICYmXG4gICAgICAgICAgICAgICAgICAgIGlzV2F0Y2hlZChuYW1lLCBfbmFtZXMpKSB7XG4gICAgICAgICAgICAgICAgICAgIF9zdGF0ZS53YXRjaCA9IHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCB1cGRhdGVUb3VjaEFuZERpcnR5ID0gKG5hbWUsIGZpZWxkVmFsdWUsIGlzQmx1ckV2ZW50LCBzaG91bGREaXJ0eSwgc2hvdWxkUmVuZGVyKSA9PiB7XG4gICAgICAgIGxldCBzaG91bGRVcGRhdGVGaWVsZCA9IGZhbHNlO1xuICAgICAgICBsZXQgaXNQcmV2aW91c0RpcnR5ID0gZmFsc2U7XG4gICAgICAgIGNvbnN0IG91dHB1dCA9IHtcbiAgICAgICAgICAgIG5hbWUsXG4gICAgICAgIH07XG4gICAgICAgIC8vIGFuIGV4cGxpY2l0IHByb2dyYW1tYXRpYyB1cGRhdGUgKGUuZy4gc2V0VmFsdWUgd2l0aCBzaG91bGREaXJ0eTogdHJ1ZSlcbiAgICAgICAgLy8gb3B0cyBpbnRvIGRpcnR5IHRyYWNraW5nIGV2ZW4gd2hlbiB0aGUgZm9ybSBpcyBkaXNhYmxlZFxuICAgICAgICBpZiAoIV9vcHRpb25zLmRpc2FibGVkIHx8IHNob3VsZERpcnR5ID09PSB0cnVlKSB7XG4gICAgICAgICAgICBpZiAoIWlzQmx1ckV2ZW50IHx8IHNob3VsZERpcnR5KSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNDdXJyZW50RmllbGRQcmlzdGluZSA9IGRlZXBFcXVhbChnZXQoX2RlZmF1bHRWYWx1ZXMsIG5hbWUpLCBmaWVsZFZhbHVlKTtcbiAgICAgICAgICAgICAgICBpZiAoX3Byb3h5Rm9ybVN0YXRlLmlzRGlydHkgfHwgX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlLmlzRGlydHkpIHtcbiAgICAgICAgICAgICAgICAgICAgaXNQcmV2aW91c0RpcnR5ID0gX2Zvcm1TdGF0ZS5pc0RpcnR5O1xuICAgICAgICAgICAgICAgICAgICBfZm9ybVN0YXRlLmlzRGlydHkgPSBvdXRwdXQuaXNEaXJ0eSA9XG4gICAgICAgICAgICAgICAgICAgICAgICAhaXNDdXJyZW50RmllbGRQcmlzdGluZSB8fCBfZ2V0RGlydHkoKTtcbiAgICAgICAgICAgICAgICAgICAgc2hvdWxkVXBkYXRlRmllbGQgPSBpc1ByZXZpb3VzRGlydHkgIT09IG91dHB1dC5pc0RpcnR5O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpc1ByZXZpb3VzRGlydHkgPSAhIWdldChfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBpZiAoaXNDdXJyZW50RmllbGRQcmlzdGluZSAhPT0gX2Zvcm1TdGF0ZS5pc0RpcnR5KSB7XG4gICAgICAgICAgICAgICAgICAgIF9mb3JtU3RhdGUuZGlydHlGaWVsZHMgPSBnZXREaXJ0eUZpZWxkcyhfZGVmYXVsdFZhbHVlcywgX2Zvcm1WYWx1ZXMsIHVuZGVmaW5lZCwgX2ZpZWxkcyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBpc0N1cnJlbnRGaWVsZFByaXN0aW5lXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHVuc2V0KF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsIG5hbWUpXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHNldChfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuYW1lLCB0cnVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgb3V0cHV0LmRpcnR5RmllbGRzID0gX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcztcbiAgICAgICAgICAgICAgICBzaG91bGRVcGRhdGVGaWVsZCA9XG4gICAgICAgICAgICAgICAgICAgIHNob3VsZFVwZGF0ZUZpZWxkIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAoKF9wcm94eUZvcm1TdGF0ZS5kaXJ0eUZpZWxkcyB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZS5kaXJ0eUZpZWxkcykgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1ByZXZpb3VzRGlydHkgIT09ICFpc0N1cnJlbnRGaWVsZFByaXN0aW5lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpc0JsdXJFdmVudCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzUHJldmlvdXNGaWVsZFRvdWNoZWQgPSBnZXQoX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBpZiAoIWlzUHJldmlvdXNGaWVsZFRvdWNoZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0KF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcywgbmFtZSwgaXNCbHVyRXZlbnQpO1xuICAgICAgICAgICAgICAgICAgICBvdXRwdXQudG91Y2hlZEZpZWxkcyA9IF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcztcbiAgICAgICAgICAgICAgICAgICAgc2hvdWxkVXBkYXRlRmllbGQgPVxuICAgICAgICAgICAgICAgICAgICAgICAgc2hvdWxkVXBkYXRlRmllbGQgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoKF9wcm94eUZvcm1TdGF0ZS50b3VjaGVkRmllbGRzIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZS50b3VjaGVkRmllbGRzKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1ByZXZpb3VzRmllbGRUb3VjaGVkICE9PSBpc0JsdXJFdmVudCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2hvdWxkVXBkYXRlRmllbGQgJiYgc2hvdWxkUmVuZGVyICYmIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KG91dHB1dCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHNob3VsZFVwZGF0ZUZpZWxkID8gb3V0cHV0IDoge307XG4gICAgfTtcbiAgICBjb25zdCBzaG91bGRSZW5kZXJCeUVycm9yID0gKG5hbWUsIGlzVmFsaWQsIGVycm9yLCBmaWVsZFN0YXRlKSA9PiB7XG4gICAgICAgIGNvbnN0IHByZXZpb3VzRmllbGRFcnJvciA9IGdldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgIGNvbnN0IHNob3VsZFVwZGF0ZVZhbGlkID0gKF9wcm94eUZvcm1TdGF0ZS5pc1ZhbGlkIHx8IF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZS5pc1ZhbGlkKSAmJlxuICAgICAgICAgICAgaXNCb29sZWFuKGlzVmFsaWQpICYmXG4gICAgICAgICAgICBfZm9ybVN0YXRlLmlzVmFsaWQgIT09IGlzVmFsaWQ7XG4gICAgICAgIGlmIChfb3B0aW9ucy5kZWxheUVycm9yICYmIGVycm9yKSB7XG4gICAgICAgICAgICBkZWxheUVycm9yQ2FsbGJhY2tzW25hbWVdID0gZGVib3VuY2UobmFtZSwgKCkgPT4gdXBkYXRlRXJyb3JzKG5hbWUsIGVycm9yKSk7XG4gICAgICAgICAgICBkZWxheUVycm9yQ2FsbGJhY2tzW25hbWVdKF9vcHRpb25zLmRlbGF5RXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVyc1tuYW1lXSk7XG4gICAgICAgICAgICBkZWxldGUgZGVsYXlFcnJvckNhbGxiYWNrc1tuYW1lXTtcbiAgICAgICAgICAgIGVycm9yXG4gICAgICAgICAgICAgICAgPyBzZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUsIGVycm9yKVxuICAgICAgICAgICAgICAgIDogdW5zZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7IC4uLl9mb3JtU3RhdGUuZXJyb3JzIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKChlcnJvciA/ICFkZWVwRXF1YWwocHJldmlvdXNGaWVsZEVycm9yLCBlcnJvcikgOiBwcmV2aW91c0ZpZWxkRXJyb3IpIHx8XG4gICAgICAgICAgICAhaXNFbXB0eU9iamVjdChmaWVsZFN0YXRlKSB8fFxuICAgICAgICAgICAgc2hvdWxkVXBkYXRlVmFsaWQpIHtcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWRGb3JtU3RhdGUgPSB7XG4gICAgICAgICAgICAgICAgLi4uZmllbGRTdGF0ZSxcbiAgICAgICAgICAgICAgICAuLi4oc2hvdWxkVXBkYXRlVmFsaWQgJiYgaXNCb29sZWFuKGlzVmFsaWQpID8geyBpc1ZhbGlkIH0gOiB7fSksXG4gICAgICAgICAgICAgICAgZXJyb3JzOiBfZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIF9mb3JtU3RhdGUgPSB7XG4gICAgICAgICAgICAgICAgLi4uX2Zvcm1TdGF0ZSxcbiAgICAgICAgICAgICAgICAuLi51cGRhdGVkRm9ybVN0YXRlLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHVwZGF0ZWRGb3JtU3RhdGUpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBfcnVuU2NoZW1hID0gYXN5bmMgKG5hbWUpID0+IHtcbiAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZyhuYW1lLCB0cnVlKTtcbiAgICAgICAgcmV0dXJuIGF3YWl0IF9vcHRpb25zLnJlc29sdmVyKF9mb3JtVmFsdWVzLCBfb3B0aW9ucy5jb250ZXh0LCBnZXRSZXNvbHZlck9wdGlvbnMobmFtZSB8fCBfbmFtZXMubW91bnQsIF9maWVsZHMsIF9vcHRpb25zLmNyaXRlcmlhTW9kZSwgX29wdGlvbnMuc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbikpO1xuICAgIH07XG4gICAgY29uc3QgZXhlY3V0ZVNjaGVtYUFuZFVwZGF0ZVN0YXRlID0gYXN5bmMgKG5hbWVzKSA9PiB7XG4gICAgICAgIGNvbnN0IHsgZXJyb3JzIH0gPSBhd2FpdCBfcnVuU2NoZW1hKG5hbWVzKTtcbiAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZyhuYW1lcyk7XG4gICAgICAgIGlmIChuYW1lcykge1xuICAgICAgICAgICAgZm9yIChjb25zdCBuYW1lIG9mIG5hbWVzKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZXJyb3IgPSBnZXQoZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBlcnJvclxuICAgICAgICAgICAgICAgICAgICA/IF9uYW1lcy5hcnJheS5oYXMobmFtZSkgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzT2JqZWN0KGVycm9yKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgIU9iamVjdC5rZXlzKGVycm9yKS5zb21lKChrZXkpID0+ICFOdW1iZXIuaXNOYU4oTnVtYmVyKGtleSkpKVxuICAgICAgICAgICAgICAgICAgICAgICAgPyB1cGRhdGVGaWVsZEFycmF5Um9vdEVycm9yKF9mb3JtU3RhdGUuZXJyb3JzLCB7IFtuYW1lXTogZXJyb3IgfSwgbmFtZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIDogc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lLCBlcnJvcilcbiAgICAgICAgICAgICAgICAgICAgOiB1bnNldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0gZXJyb3JzO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBlcnJvcnM7XG4gICAgfTtcbiAgICBjb25zdCB2YWxpZGF0ZUZvcm0gPSBhc3luYyAoeyBuYW1lLCBldmVudFR5cGUsIH0pID0+IHtcbiAgICAgICAgaWYgKHByb3BzLnZhbGlkYXRlKSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBwcm9wcy52YWxpZGF0ZSh7XG4gICAgICAgICAgICAgICAgZm9ybVZhbHVlczogX2Zvcm1WYWx1ZXMsXG4gICAgICAgICAgICAgICAgZm9ybVN0YXRlOiBfZm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgZXZlbnRUeXBlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAoaXNPYmplY3QocmVzdWx0KSkge1xuICAgICAgICAgICAgICAgIGZvciAoY29uc3Qga2V5IGluIHJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBlcnJvciA9IHJlc3VsdFtrZXldO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEVycm9yKGAke0ZPUk1fRVJST1JfVFlQRX0uJHtrZXl9YCwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGlzU3RyaW5nKGVycm9yLm1lc3NhZ2UpID8gZXJyb3IubWVzc2FnZSA6ICcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IGVycm9yLnR5cGUgfHwgSU5QVVRfVkFMSURBVElPTl9SVUxFUy52YWxpZGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoaXNTdHJpbmcocmVzdWx0KSB8fCAhcmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgc2V0RXJyb3IoRk9STV9FUlJPUl9UWVBFLCB7XG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHJlc3VsdCB8fCAnJyxcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogSU5QVVRfVkFMSURBVElPTl9SVUxFUy52YWxpZGF0ZSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGNsZWFyRXJyb3JzKEZPUk1fRVJST1JfVFlQRSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH07XG4gICAgY29uc3QgZXhlY3V0ZUJ1aWx0SW5WYWxpZGF0aW9uID0gYXN5bmMgKHsgZmllbGRzLCBvbmx5Q2hlY2tWYWxpZCwgbmFtZSwgZXZlbnRUeXBlLCBjb250ZXh0ID0ge1xuICAgICAgICB2YWxpZDogdHJ1ZSxcbiAgICAgICAgcnVuUm9vdFZhbGlkYXRpb246IGZhbHNlLFxuICAgIH0sIH0pID0+IHtcbiAgICAgICAgaWYgKHByb3BzLnZhbGlkYXRlKSB7XG4gICAgICAgICAgICBjb250ZXh0LnJ1blJvb3RWYWxpZGF0aW9uID0gdHJ1ZTtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHZhbGlkYXRlRm9ybSh7XG4gICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICBldmVudFR5cGUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmICghcmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgY29udGV4dC52YWxpZCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIGlmIChvbmx5Q2hlY2tWYWxpZCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY29udGV4dC52YWxpZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChjb25zdCBuYW1lIGluIGZpZWxkcykge1xuICAgICAgICAgICAgY29uc3QgZmllbGQgPSBmaWVsZHNbbmFtZV07XG4gICAgICAgICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB7IF9mLCAuLi5maWVsZFZhbHVlIH0gPSBmaWVsZDtcbiAgICAgICAgICAgICAgICBpZiAoX2YpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNGaWVsZEFycmF5Um9vdCA9IF9uYW1lcy5hcnJheS5oYXMoX2YubmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzUHJvbWlzZUZ1bmN0aW9uID0gZmllbGQuX2YgJiYgaGFzUHJvbWlzZVZhbGlkYXRpb24oZmllbGQuX2YpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBzaG91bGRUcmFja0lzVmFsaWRhdGluZ1N0YXRlID0gX3Byb3h5Rm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIF9wcm94eUZvcm1TdGF0ZS5pc1ZhbGlkYXRpbmcgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZS52YWxpZGF0aW5nRmllbGRzIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICBfcHJveHlTdWJzY3JpYmVGb3JtU3RhdGUuaXNWYWxpZGF0aW5nO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXNQcm9taXNlRnVuY3Rpb24gJiYgc2hvdWxkVHJhY2tJc1ZhbGlkYXRpbmdTdGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZyhbX2YubmFtZV0sIHRydWUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkRXJyb3IgPSBhd2FpdCB2YWxpZGF0ZUZpZWxkKGZpZWxkLCBfbmFtZXMuZGlzYWJsZWQsIF9mb3JtVmFsdWVzLCBzaG91bGREaXNwbGF5QWxsQXNzb2NpYXRlZEVycm9ycywgX29wdGlvbnMuc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbiAmJiAhb25seUNoZWNrVmFsaWQsIGlzRmllbGRBcnJheVJvb3QpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXNQcm9taXNlRnVuY3Rpb24gJiYgc2hvdWxkVHJhY2tJc1ZhbGlkYXRpbmdTdGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZyhbX2YubmFtZV0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChmaWVsZEVycm9yW19mLm5hbWVdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb250ZXh0LnZhbGlkID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAob25seUNoZWNrVmFsaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAhb25seUNoZWNrVmFsaWQgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIChnZXQoZmllbGRFcnJvciwgX2YubmFtZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGlzRmllbGRBcnJheVJvb3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB1cGRhdGVGaWVsZEFycmF5Um9vdEVycm9yKF9mb3JtU3RhdGUuZXJyb3JzLCBmaWVsZEVycm9yLCBfZi5uYW1lKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHNldChfZm9ybVN0YXRlLmVycm9ycywgX2YubmFtZSwgZmllbGRFcnJvcltfZi5uYW1lXSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHVuc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBfZi5uYW1lKSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwcm9wcy5zaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uICYmIGZpZWxkRXJyb3JbX2YubmFtZV0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICFpc0VtcHR5T2JqZWN0KGZpZWxkVmFsdWUpICYmXG4gICAgICAgICAgICAgICAgICAgIChhd2FpdCBleGVjdXRlQnVpbHRJblZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICAgICAgICAgICAgICAgIG9ubHlDaGVja1ZhbGlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRzOiBmaWVsZFZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogbmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50VHlwZSxcbiAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjb250ZXh0LnZhbGlkO1xuICAgIH07XG4gICAgY29uc3QgX3JlbW92ZVVubW91bnRlZCA9ICgpID0+IHtcbiAgICAgICAgZm9yIChjb25zdCBuYW1lIG9mIF9uYW1lcy51bk1vdW50KSB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgIGZpZWxkICYmXG4gICAgICAgICAgICAgICAgKGZpZWxkLl9mLnJlZnNcbiAgICAgICAgICAgICAgICAgICAgPyBmaWVsZC5fZi5yZWZzLmV2ZXJ5KChyZWYpID0+ICFsaXZlKHJlZikpXG4gICAgICAgICAgICAgICAgICAgIDogIWxpdmUoZmllbGQuX2YucmVmKSkgJiZcbiAgICAgICAgICAgICAgICB1bnJlZ2lzdGVyKG5hbWUpO1xuICAgICAgICB9XG4gICAgICAgIF9uYW1lcy51bk1vdW50ID0gbmV3IFNldCgpO1xuICAgIH07XG4gICAgY29uc3QgX2dldERpcnR5ID0gKG5hbWUsIGRhdGEpID0+IChuYW1lICYmIGRhdGEgJiYgc2V0KF9mb3JtVmFsdWVzLCBuYW1lLCBkYXRhKSxcbiAgICAgICAgIWRlZXBFcXVhbChfc3RhdGUubW91bnQgPyBfZm9ybVZhbHVlcyA6IF9kZWZhdWx0VmFsdWVzLCBfZGVmYXVsdFZhbHVlcykpO1xuICAgIGNvbnN0IF9nZXRXYXRjaCA9IChuYW1lcywgZGVmYXVsdFZhbHVlLCBpc0dsb2JhbCkgPT4gZ2VuZXJhdGVXYXRjaE91dHB1dChuYW1lcywgX25hbWVzLCB7XG4gICAgICAgIC4uLihfc3RhdGUubW91bnRcbiAgICAgICAgICAgID8gX2Zvcm1WYWx1ZXNcbiAgICAgICAgICAgIDogaXNVbmRlZmluZWQoZGVmYXVsdFZhbHVlKVxuICAgICAgICAgICAgICAgID8gX2RlZmF1bHRWYWx1ZXNcbiAgICAgICAgICAgICAgICA6IGlzU3RyaW5nKG5hbWVzKVxuICAgICAgICAgICAgICAgICAgICA/IHsgW25hbWVzXTogZGVmYXVsdFZhbHVlIH1cbiAgICAgICAgICAgICAgICAgICAgOiBkZWZhdWx0VmFsdWUpLFxuICAgIH0sIGlzR2xvYmFsLCBkZWZhdWx0VmFsdWUpO1xuICAgIGNvbnN0IF9nZXRGaWVsZEFycmF5ID0gKG5hbWUpID0+IGNvbXBhY3QoZ2V0KF9zdGF0ZS5tb3VudCA/IF9mb3JtVmFsdWVzIDogX2RlZmF1bHRWYWx1ZXMsIG5hbWUsIF9vcHRpb25zLnNob3VsZFVucmVnaXN0ZXIgPyBnZXQoX2RlZmF1bHRWYWx1ZXMsIG5hbWUsIFtdKSA6IFtdKSk7XG4gICAgY29uc3Qgc2V0RmllbGRWYWx1ZSA9IChuYW1lLCB2YWx1ZSwgb3B0aW9ucyA9IHt9LCBza2lwQ2xvbmUgPSBmYWxzZSwgc2tpcFJlbmRlciA9IGZhbHNlKSA9PiB7XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICBsZXQgZmllbGRWYWx1ZSA9IHZhbHVlO1xuICAgICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkUmVmZXJlbmNlID0gZmllbGQuX2Y7XG4gICAgICAgICAgICBpZiAoZmllbGRSZWZlcmVuY2UpIHtcbiAgICAgICAgICAgICAgICAhZmllbGRSZWZlcmVuY2UuZGlzYWJsZWQgJiZcbiAgICAgICAgICAgICAgICAgICAgc2V0KF9mb3JtVmFsdWVzLCBuYW1lLCBnZXRGaWVsZFZhbHVlQXModmFsdWUsIGZpZWxkUmVmZXJlbmNlKSk7XG4gICAgICAgICAgICAgICAgZmllbGRWYWx1ZSA9XG4gICAgICAgICAgICAgICAgICAgIGlzSFRNTEVsZW1lbnQoZmllbGRSZWZlcmVuY2UucmVmKSAmJiBpc051bGxPclVuZGVmaW5lZCh2YWx1ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJydcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdmFsdWU7XG4gICAgICAgICAgICAgICAgaWYgKGlzTXVsdGlwbGVTZWxlY3QoZmllbGRSZWZlcmVuY2UucmVmKSkge1xuICAgICAgICAgICAgICAgICAgICBbLi4uZmllbGRSZWZlcmVuY2UucmVmLm9wdGlvbnNdLmZvckVhY2goKG9wdGlvblJlZikgPT4gKG9wdGlvblJlZi5zZWxlY3RlZCA9IGZpZWxkVmFsdWUuaW5jbHVkZXMob3B0aW9uUmVmLnZhbHVlKSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChmaWVsZFJlZmVyZW5jZS5yZWZzKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc0NoZWNrQm94SW5wdXQoZmllbGRSZWZlcmVuY2UucmVmKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRSZWZlcmVuY2UucmVmcy5mb3JFYWNoKChjaGVja2JveFJlZikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghY2hlY2tib3hSZWYuZGVmYXVsdENoZWNrZWQgfHwgIWNoZWNrYm94UmVmLmRpc2FibGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGZpZWxkVmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2JveFJlZi5jaGVja2VkID0gISFmaWVsZFZhbHVlLmZpbmQoKGRhdGEpID0+IGRhdGEgPT09IGNoZWNrYm94UmVmLnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrYm94UmVmLmNoZWNrZWQgPVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkVmFsdWUgPT09IGNoZWNrYm94UmVmLnZhbHVlIHx8ICEhZmllbGRWYWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRSZWZlcmVuY2UucmVmcy5mb3JFYWNoKChyYWRpb1JlZikgPT4gKHJhZGlvUmVmLmNoZWNrZWQgPSByYWRpb1JlZi52YWx1ZSA9PT0gZmllbGRWYWx1ZSkpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGlzRmlsZUlucHV0KGZpZWxkUmVmZXJlbmNlLnJlZikpIHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGRSZWZlcmVuY2UucmVmLnZhbHVlID0gJyc7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBmaWVsZFJlZmVyZW5jZS5yZWYudmFsdWUgPSBmaWVsZFZhbHVlO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWZpZWxkUmVmZXJlbmNlLnJlZi50eXBlICYmICFza2lwUmVuZGVyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZXM6IHNraXBDbG9uZSA/IF9mb3JtVmFsdWVzIDogY2xvbmVPYmplY3QoX2Zvcm1WYWx1ZXMpLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgKG9wdGlvbnMuc2hvdWxkRGlydHkgfHwgb3B0aW9ucy5zaG91bGRUb3VjaCkgJiZcbiAgICAgICAgICAgIHVwZGF0ZVRvdWNoQW5kRGlydHkobmFtZSwgZmllbGRWYWx1ZSwgb3B0aW9ucy5zaG91bGRUb3VjaCwgb3B0aW9ucy5zaG91bGREaXJ0eSwgIXNraXBSZW5kZXIpO1xuICAgICAgICBvcHRpb25zLnNob3VsZFZhbGlkYXRlICYmXG4gICAgICAgICAgICB0cmlnZ2VyKG5hbWUsIHtcbiAgICAgICAgICAgICAgICBkZWxheUVycm9yOiBvcHRpb25zLmRlbGF5RXJyb3IsXG4gICAgICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IHNldEZpZWxkVmFsdWVzID0gKG5hbWUsIHZhbHVlLCBvcHRpb25zLCBza2lwQ2xvbmUgPSBmYWxzZSwgc2tpcFJlbmRlciA9IGZhbHNlKSA9PiB7XG4gICAgICAgIGZvciAoY29uc3QgZmllbGRLZXkgaW4gdmFsdWUpIHtcbiAgICAgICAgICAgIGlmICghdmFsdWUuaGFzT3duUHJvcGVydHkoZmllbGRLZXkpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgZmllbGRWYWx1ZSA9IHZhbHVlW2ZpZWxkS2V5XTtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkTmFtZSA9IG5hbWUgKyAnLicgKyBmaWVsZEtleTtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIGZpZWxkTmFtZSk7XG4gICAgICAgICAgICAoX25hbWVzLmFycmF5LmhhcyhuYW1lKSB8fFxuICAgICAgICAgICAgICAgIGlzT2JqZWN0KGZpZWxkVmFsdWUpIHx8XG4gICAgICAgICAgICAgICAgKGZpZWxkICYmICFmaWVsZC5fZikpICYmXG4gICAgICAgICAgICAgICAgIWlzRGF0ZU9iamVjdChmaWVsZFZhbHVlKVxuICAgICAgICAgICAgICAgID8gc2V0RmllbGRWYWx1ZXMoZmllbGROYW1lLCBmaWVsZFZhbHVlLCBvcHRpb25zLCBza2lwQ2xvbmUsIHNraXBSZW5kZXIpXG4gICAgICAgICAgICAgICAgOiBzZXRGaWVsZFZhbHVlKGZpZWxkTmFtZSwgZmllbGRWYWx1ZSwgb3B0aW9ucywgc2tpcENsb25lLCBza2lwUmVuZGVyKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgX3NldFZhbHVlID0gKG5hbWUsIHZhbHVlLCBvcHRpb25zLCBza2lwQ2xvbmUsIHNraXBTdGF0ZUVtaXQgPSBmYWxzZSkgPT4ge1xuICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgY29uc3QgaXNGaWVsZEFycmF5ID0gX25hbWVzLmFycmF5LmhhcyhuYW1lKTtcbiAgICAgICAgY29uc3QgY2xvbmVWYWx1ZSA9IHNraXBDbG9uZSA/IHZhbHVlIDogY2xvbmVPYmplY3QodmFsdWUpO1xuICAgICAgICBjb25zdCBwcmV2aW91c1ZhbHVlID0gZ2V0KF9mb3JtVmFsdWVzLCBuYW1lKTtcbiAgICAgICAgY29uc3QgaXNWYWx1ZVVuY2hhbmdlZCA9IGRlZXBFcXVhbChwcmV2aW91c1ZhbHVlLCBjbG9uZVZhbHVlKTtcbiAgICAgICAgaWYgKCFpc1ZhbHVlVW5jaGFuZ2VkKSB7XG4gICAgICAgICAgICBzZXQoX2Zvcm1WYWx1ZXMsIG5hbWUsIGNsb25lVmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0ZpZWxkQXJyYXkpIHtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5hcnJheS5uZXh0KHtcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgIHZhbHVlczogc2tpcENsb25lID8gX2Zvcm1WYWx1ZXMgOiBjbG9uZU9iamVjdChfZm9ybVZhbHVlcyksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmICgoX3Byb3h5Rm9ybVN0YXRlLmlzRGlydHkgfHxcbiAgICAgICAgICAgICAgICBfcHJveHlGb3JtU3RhdGUuZGlydHlGaWVsZHMgfHxcbiAgICAgICAgICAgICAgICBfcHJveHlTdWJzY3JpYmVGb3JtU3RhdGUuaXNEaXJ0eSB8fFxuICAgICAgICAgICAgICAgIF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZS5kaXJ0eUZpZWxkcykgJiZcbiAgICAgICAgICAgICAgICBvcHRpb25zLnNob3VsZERpcnR5KSB7XG4gICAgICAgICAgICAgICAgX3VwZGF0ZURpcnR5RmllbGRzKCk7XG4gICAgICAgICAgICAgICAgaWYgKCFza2lwU3RhdGVFbWl0KSB7XG4gICAgICAgICAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXJ0eUZpZWxkczogX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzRGlydHk6IF9nZXREaXJ0eShuYW1lLCBjbG9uZVZhbHVlKSxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgaXNFbXB0eSA9IChBcnJheS5pc0FycmF5KGNsb25lVmFsdWUpICYmICFjbG9uZVZhbHVlLmxlbmd0aCkgfHxcbiAgICAgICAgICAgICAgICBpc0VtcHR5T2JqZWN0KGNsb25lVmFsdWUpO1xuICAgICAgICAgICAgaWYgKCFmaWVsZCB8fCBmaWVsZC5fZiB8fCBpc051bGxPclVuZGVmaW5lZChjbG9uZVZhbHVlKSB8fCBpc0VtcHR5KSB7XG4gICAgICAgICAgICAgICAgc2V0RmllbGRWYWx1ZShuYW1lLCBjbG9uZVZhbHVlLCBvcHRpb25zLCBza2lwQ2xvbmUsIHNraXBTdGF0ZUVtaXQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgc2V0RmllbGRWYWx1ZXMobmFtZSwgY2xvbmVWYWx1ZSwgb3B0aW9ucywgc2tpcENsb25lLCBza2lwU3RhdGVFbWl0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIWlzVmFsdWVVbmNoYW5nZWQgJiYgIXNraXBTdGF0ZUVtaXQpIHtcbiAgICAgICAgICAgIGNvbnN0IHdhdGNoZWQgPSBpc1dhdGNoZWQobmFtZSwgX25hbWVzKTtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlcyA9IHNraXBDbG9uZSA/IF9mb3JtVmFsdWVzIDogY2xvbmVPYmplY3QoX2Zvcm1WYWx1ZXMpO1xuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIC4uLih3YXRjaGVkICYmIF9mb3JtU3RhdGUpLFxuICAgICAgICAgICAgICAgIG5hbWU6IF9zdGF0ZS5tb3VudCB8fCB3YXRjaGVkID8gbmFtZSA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICB2YWx1ZXMsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3Qgc2V0VmFsdWUgPSAobmFtZSwgdmFsdWUsIG9wdGlvbnMgPSB7fSkgPT4gX3NldFZhbHVlKG5hbWUsIHZhbHVlLCBvcHRpb25zLCBmYWxzZSk7XG4gICAgY29uc3Qgc2V0VmFsdWVzID0gKGZvcm1WYWx1ZXMsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBjb25zdCB1cGRhdGVkRm9ybVZhbHVlcyA9IGlzRnVuY3Rpb24oZm9ybVZhbHVlcylcbiAgICAgICAgICAgID8gZm9ybVZhbHVlcyhfZm9ybVZhbHVlcylcbiAgICAgICAgICAgIDogZm9ybVZhbHVlcztcbiAgICAgICAgaWYgKCFkZWVwRXF1YWwoX2Zvcm1WYWx1ZXMsIHVwZGF0ZWRGb3JtVmFsdWVzKSkge1xuICAgICAgICAgICAgX2Zvcm1WYWx1ZXMgPSB7XG4gICAgICAgICAgICAgICAgLi4uX2Zvcm1WYWx1ZXMsXG4gICAgICAgICAgICAgICAgLi4udXBkYXRlZEZvcm1WYWx1ZXMsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgY29uc3QgZmxhdHRlbmVkVXBkYXRlcyA9IGZsYXR0ZW4odXBkYXRlZEZvcm1WYWx1ZXMpO1xuICAgICAgICAgICAgZm9yIChjb25zdCBmaWVsZE5hbWUgb2YgX25hbWVzLm1vdW50KSB7XG4gICAgICAgICAgICAgICAgaWYgKGZpZWxkTmFtZSBpbiBmbGF0dGVuZWRVcGRhdGVzKSB7XG4gICAgICAgICAgICAgICAgICAgIF9zZXRWYWx1ZShmaWVsZE5hbWUsIGZsYXR0ZW5lZFVwZGF0ZXNbZmllbGROYW1lXSwgb3B0aW9ucywgdHJ1ZSwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIC4uLl9mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgbmFtZTogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAuLi4oX3ZhbHVlc1N1YnNjcmliZXJDb3VudCA/IHsgdmFsdWVzOiBfZm9ybVZhbHVlcyB9IDoge30pLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAob3B0aW9ucy5zaG91bGRWYWxpZGF0ZSkge1xuICAgICAgICAgICAgICAgIF9zZXRWYWxpZCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBvbkNoYW5nZSA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgICAgICBfc3RhdGUubW91bnQgPSB0cnVlO1xuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC50YXJnZXQ7XG4gICAgICAgIGxldCBuYW1lID0gdGFyZ2V0Lm5hbWU7XG4gICAgICAgIGxldCBpc0ZpZWxkVmFsdWVVcGRhdGVkID0gdHJ1ZTtcbiAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgIGNvbnN0IF91cGRhdGVJc0ZpZWxkVmFsdWVVcGRhdGVkID0gKGZpZWxkVmFsdWUpID0+IHtcbiAgICAgICAgICAgIGlzRmllbGRWYWx1ZVVwZGF0ZWQgPVxuICAgICAgICAgICAgICAgIE51bWJlci5pc05hTihmaWVsZFZhbHVlKSB8fFxuICAgICAgICAgICAgICAgICAgICAoaXNEYXRlT2JqZWN0KGZpZWxkVmFsdWUpICYmIGlzTmFOKGZpZWxkVmFsdWUuZ2V0VGltZSgpKSkgfHxcbiAgICAgICAgICAgICAgICAgICAgZGVlcEVxdWFsKGZpZWxkVmFsdWUsIGdldChfZm9ybVZhbHVlcywgbmFtZSwgZmllbGRWYWx1ZSkpO1xuICAgICAgICB9O1xuICAgICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgICAgIGxldCBlcnJvcjtcbiAgICAgICAgICAgIGxldCBpc1ZhbGlkO1xuICAgICAgICAgICAgY29uc3QgZmllbGRWYWx1ZSA9IHRhcmdldC50eXBlXG4gICAgICAgICAgICAgICAgPyBnZXRGaWVsZFZhbHVlKGZpZWxkLl9mKVxuICAgICAgICAgICAgICAgIDogZ2V0RXZlbnRWYWx1ZShldmVudCk7XG4gICAgICAgICAgICBjb25zdCBpc0JsdXJFdmVudCA9IGV2ZW50LnR5cGUgPT09IEVWRU5UUy5CTFVSIHx8IGV2ZW50LnR5cGUgPT09IEVWRU5UUy5GT0NVU19PVVQ7XG4gICAgICAgICAgICBjb25zdCBoYXNOb1ZhbGlkYXRpb25FZmZlY3QgPSAhaGFzVmFsaWRhdGlvbihmaWVsZC5fZikgJiZcbiAgICAgICAgICAgICAgICAhcHJvcHMudmFsaWRhdGUgJiZcbiAgICAgICAgICAgICAgICAhX29wdGlvbnMucmVzb2x2ZXIgJiZcbiAgICAgICAgICAgICAgICAhZ2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKSAmJlxuICAgICAgICAgICAgICAgICFmaWVsZC5fZi5kZXBzO1xuICAgICAgICAgICAgY29uc3Qgc2hvdWxkU2tpcFZhbGlkYXRpb24gPSBoYXNOb1ZhbGlkYXRpb25FZmZlY3QgfHxcbiAgICAgICAgICAgICAgICBza2lwVmFsaWRhdGlvbihpc0JsdXJFdmVudCwgZ2V0KF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcywgbmFtZSksIF9mb3JtU3RhdGUuaXNTdWJtaXR0ZWQsIF92YWxpZGF0aW9uTW9kZUFmdGVyU3VibWl0LCBfdmFsaWRhdGlvbk1vZGVCZWZvcmVTdWJtaXQpO1xuICAgICAgICAgICAgY29uc3Qgd2F0Y2hlZCA9IGlzV2F0Y2hlZChuYW1lLCBfbmFtZXMsIGlzQmx1ckV2ZW50KTtcbiAgICAgICAgICAgIHNldChfZm9ybVZhbHVlcywgbmFtZSwgZmllbGRWYWx1ZSk7XG4gICAgICAgICAgICBpZiAoaXNCbHVyRXZlbnQpIHtcbiAgICAgICAgICAgICAgICBpZiAoIXRhcmdldCB8fCAhdGFyZ2V0LnJlYWRPbmx5KSB7XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkLl9mLm9uQmx1ciAmJiBmaWVsZC5fZi5vbkJsdXIoZXZlbnQpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwZW5kaW5nRGVsYXlFcnJvciA9IGRlbGF5RXJyb3JDYWxsYmFja3NbbmFtZV07XG4gICAgICAgICAgICAgICAgICAgIHBlbmRpbmdEZWxheUVycm9yICYmIHBlbmRpbmdEZWxheUVycm9yKDApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGZpZWxkLl9mLm9uQ2hhbmdlKSB7XG4gICAgICAgICAgICAgICAgZmllbGQuX2Yub25DaGFuZ2UoZXZlbnQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgZmllbGRTdGF0ZSA9IHVwZGF0ZVRvdWNoQW5kRGlydHkobmFtZSwgZmllbGRWYWx1ZSwgaXNCbHVyRXZlbnQpO1xuICAgICAgICAgICAgY29uc3Qgc2hvdWxkUmVuZGVyID0gIWlzRW1wdHlPYmplY3QoZmllbGRTdGF0ZSkgfHwgd2F0Y2hlZDtcbiAgICAgICAgICAgICFpc0JsdXJFdmVudCAmJlxuICAgICAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogZXZlbnQudHlwZSxcbiAgICAgICAgICAgICAgICAgICAgLi4uKF92YWx1ZXNTdWJzY3JpYmVyQ291bnRcbiAgICAgICAgICAgICAgICAgICAgICAgID8geyB2YWx1ZXM6IGNsb25lT2JqZWN0KF9mb3JtVmFsdWVzKSB9XG4gICAgICAgICAgICAgICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmIChzaG91bGRTa2lwVmFsaWRhdGlvbikge1xuICAgICAgICAgICAgICAgIGlmICgoIWhhc05vVmFsaWRhdGlvbkVmZmVjdCB8fCAhX2Zvcm1TdGF0ZS5pc1ZhbGlkKSAmJlxuICAgICAgICAgICAgICAgICAgICAoX3Byb3h5Rm9ybVN0YXRlLmlzVmFsaWQgfHwgX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlLmlzVmFsaWQpKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChfb3B0aW9ucy5tb2RlID09PSAnb25CbHVyJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzQmx1ckV2ZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3NldFZhbGlkKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoIWlzQmx1ckV2ZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBfc2V0VmFsaWQoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gKHNob3VsZFJlbmRlciAmJlxuICAgICAgICAgICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7IG5hbWUsIC4uLih3YXRjaGVkID8ge30gOiBmaWVsZFN0YXRlKSB9KSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIV9vcHRpb25zLnJlc29sdmVyICYmIHByb3BzLnZhbGlkYXRlKSB7XG4gICAgICAgICAgICAgICAgYXdhaXQgdmFsaWRhdGVGb3JtKHtcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogbmFtZSxcbiAgICAgICAgICAgICAgICAgICAgZXZlbnRUeXBlOiBldmVudC50eXBlLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgIWlzQmx1ckV2ZW50ICYmIHdhdGNoZWQgJiYgX3N1YmplY3RzLnN0YXRlLm5leHQoeyAuLi5fZm9ybVN0YXRlIH0pO1xuICAgICAgICAgICAgaWYgKF9vcHRpb25zLnJlc29sdmVyKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgeyBlcnJvcnMgfSA9IGF3YWl0IF9ydW5TY2hlbWEoW25hbWVdKTtcbiAgICAgICAgICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKFtuYW1lXSk7XG4gICAgICAgICAgICAgICAgX3VwZGF0ZUlzRmllbGRWYWx1ZVVwZGF0ZWQoZmllbGRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgaWYgKCFpc0ZpZWxkVmFsdWVVcGRhdGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICFpc0VtcHR5T2JqZWN0KGZpZWxkU3RhdGUpICYmIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KGZpZWxkU3RhdGUpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IHByZXZpb3VzRXJyb3JMb29rdXBSZXN1bHQgPSBzY2hlbWFFcnJvckxvb2t1cChfZm9ybVN0YXRlLmVycm9ycywgX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgY29uc3QgZXJyb3JMb29rdXBSZXN1bHQgPSBzY2hlbWFFcnJvckxvb2t1cChlcnJvcnMsIF9maWVsZHMsIHByZXZpb3VzRXJyb3JMb29rdXBSZXN1bHQubmFtZSB8fCBuYW1lKTtcbiAgICAgICAgICAgICAgICBlcnJvciA9IGVycm9yTG9va3VwUmVzdWx0LmVycm9yO1xuICAgICAgICAgICAgICAgIG5hbWUgPSBlcnJvckxvb2t1cFJlc3VsdC5uYW1lO1xuICAgICAgICAgICAgICAgIGlzVmFsaWQgPSBpc0VtcHR5T2JqZWN0KGVycm9ycyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKFtuYW1lXSwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgZXJyb3IgPSAoYXdhaXQgdmFsaWRhdGVGaWVsZChmaWVsZCwgX25hbWVzLmRpc2FibGVkLCBfZm9ybVZhbHVlcywgc2hvdWxkRGlzcGxheUFsbEFzc29jaWF0ZWRFcnJvcnMsIF9vcHRpb25zLnNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24pKVtuYW1lXTtcbiAgICAgICAgICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKFtuYW1lXSk7XG4gICAgICAgICAgICAgICAgX3VwZGF0ZUlzRmllbGRWYWx1ZVVwZGF0ZWQoZmllbGRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgaWYgKGlzRmllbGRWYWx1ZVVwZGF0ZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoX3Byb3h5Rm9ybVN0YXRlLmlzVmFsaWQgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZS5pc1ZhbGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkID0gYXdhaXQgZXhlY3V0ZUJ1aWx0SW5WYWxpZGF0aW9uKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWVsZHM6IF9maWVsZHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25seUNoZWNrVmFsaWQ6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogbmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBldmVudFR5cGU6IGV2ZW50LnR5cGUsXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpc0ZpZWxkVmFsdWVVcGRhdGVkKSB7XG4gICAgICAgICAgICAgICAgZmllbGQuX2YuZGVwcyAmJlxuICAgICAgICAgICAgICAgICAgICAoIUFycmF5LmlzQXJyYXkoZmllbGQuX2YuZGVwcykgfHwgZmllbGQuX2YuZGVwcy5sZW5ndGggPiAwKSAmJlxuICAgICAgICAgICAgICAgICAgICB0cmlnZ2VyKGZpZWxkLl9mLmRlcHMpO1xuICAgICAgICAgICAgICAgIHNob3VsZFJlbmRlckJ5RXJyb3IobmFtZSwgaXNWYWxpZCwgZXJyb3IsIGZpZWxkU3RhdGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBfZm9jdXNJbnB1dCA9IChyZWYsIGtleSkgPT4ge1xuICAgICAgICBpZiAoZ2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBrZXkpICYmIHJlZi5mb2N1cykge1xuICAgICAgICAgICAgcmVmLmZvY3VzKCk7XG4gICAgICAgICAgICByZXR1cm4gMTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm47XG4gICAgfTtcbiAgICBjb25zdCB0cmlnZ2VyID0gYXN5bmMgKG5hbWUsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBsZXQgaXNWYWxpZDtcbiAgICAgICAgbGV0IHZhbGlkYXRpb25SZXN1bHQ7XG4gICAgICAgIGNvbnN0IGZpZWxkTmFtZXMgPSBjb252ZXJ0VG9BcnJheVBheWxvYWQobmFtZSk7XG4gICAgICAgIGlmIChfb3B0aW9ucy5yZXNvbHZlcikge1xuICAgICAgICAgICAgY29uc3QgZXJyb3JzID0gYXdhaXQgZXhlY3V0ZVNjaGVtYUFuZFVwZGF0ZVN0YXRlKGlzVW5kZWZpbmVkKG5hbWUpID8gbmFtZSA6IGZpZWxkTmFtZXMpO1xuICAgICAgICAgICAgaXNWYWxpZCA9IGlzRW1wdHlPYmplY3QoZXJyb3JzKTtcbiAgICAgICAgICAgIHZhbGlkYXRpb25SZXN1bHQgPSBuYW1lXG4gICAgICAgICAgICAgICAgPyAhZmllbGROYW1lcy5zb21lKChuYW1lKSA9PiBnZXQoZXJyb3JzLCBuYW1lKSlcbiAgICAgICAgICAgICAgICA6IGlzVmFsaWQ7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAobmFtZSkge1xuICAgICAgICAgICAgdmFsaWRhdGlvblJlc3VsdCA9IChhd2FpdCBQcm9taXNlLmFsbChmaWVsZE5hbWVzLm1hcChhc3luYyAoZmllbGROYW1lKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gYXdhaXQgZXhlY3V0ZUJ1aWx0SW5WYWxpZGF0aW9uKHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGRzOiBmaWVsZCAmJiBmaWVsZC5fZiA/IHsgW2ZpZWxkTmFtZV06IGZpZWxkIH0gOiBmaWVsZCxcbiAgICAgICAgICAgICAgICAgICAgZXZlbnRUeXBlOiBFVkVOVFMuVFJJR0dFUixcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pKSkuZXZlcnkoQm9vbGVhbik7XG4gICAgICAgICAgICAhKCF2YWxpZGF0aW9uUmVzdWx0ICYmICFfZm9ybVN0YXRlLmlzVmFsaWQpICYmIF9zZXRWYWxpZCgpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdmFsaWRhdGlvblJlc3VsdCA9IGlzVmFsaWQgPSBhd2FpdCBleGVjdXRlQnVpbHRJblZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgIGZpZWxkczogX2ZpZWxkcyxcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgIGV2ZW50VHlwZTogRVZFTlRTLlRSSUdHRVIsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAob3B0aW9ucy5kZWxheUVycm9yICYmIF9vcHRpb25zLmRlbGF5RXJyb3IgJiYgaXNTdHJpbmcobmFtZSkpIHtcbiAgICAgICAgICAgIGNvbnN0IGVycm9yID0gZ2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgICAgIHVuc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBkZWxheUVycm9yQ2FsbGJhY2tzW25hbWVdID0gZGVib3VuY2UobmFtZSwgKCkgPT4gdXBkYXRlRXJyb3JzKG5hbWUsIGVycm9yKSk7XG4gICAgICAgICAgICAgICAgZGVsYXlFcnJvckNhbGxiYWNrc1tuYW1lXShfb3B0aW9ucy5kZWxheUVycm9yKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lcnNbbmFtZV0pO1xuICAgICAgICAgICAgICAgIGRlbGV0ZSBkZWxheUVycm9yQ2FsbGJhY2tzW25hbWVdO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgIC4uLighaXNTdHJpbmcobmFtZSkgfHxcbiAgICAgICAgICAgICAgICAoKF9wcm94eUZvcm1TdGF0ZS5pc1ZhbGlkIHx8IF9wcm94eVN1YnNjcmliZUZvcm1TdGF0ZS5pc1ZhbGlkKSAmJlxuICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkICE9PSBfZm9ybVN0YXRlLmlzVmFsaWQpXG4gICAgICAgICAgICAgICAgPyB7fVxuICAgICAgICAgICAgICAgIDogeyBuYW1lIH0pLFxuICAgICAgICAgICAgLi4uKF9vcHRpb25zLnJlc29sdmVyIHx8ICFuYW1lID8geyBpc1ZhbGlkIH0gOiB7fSksXG4gICAgICAgICAgICBlcnJvcnM6IF9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICB9KTtcbiAgICAgICAgb3B0aW9ucy5zaG91bGRGb2N1cyAmJlxuICAgICAgICAgICAgIXZhbGlkYXRpb25SZXN1bHQgJiZcbiAgICAgICAgICAgIGl0ZXJhdGVGaWVsZHNCeUFjdGlvbihfZmllbGRzLCBfZm9jdXNJbnB1dCwgbmFtZSA/IGZpZWxkTmFtZXMgOiBfbmFtZXMubW91bnQpO1xuICAgICAgICByZXR1cm4gdmFsaWRhdGlvblJlc3VsdDtcbiAgICB9O1xuICAgIGNvbnN0IGdldFZhbHVlcyA9IChmaWVsZE5hbWVzLCBjb25maWcpID0+IHtcbiAgICAgICAgbGV0IHZhbHVlcyA9IHtcbiAgICAgICAgICAgIC4uLihfc3RhdGUubW91bnQgPyBfZm9ybVZhbHVlcyA6IF9kZWZhdWx0VmFsdWVzKSxcbiAgICAgICAgfTtcbiAgICAgICAgaWYgKGNvbmZpZykge1xuICAgICAgICAgICAgdmFsdWVzID0gZXh0cmFjdEZvcm1WYWx1ZXMoY29uZmlnLmRpcnR5RmllbGRzID8gX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcyA6IF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcywgdmFsdWVzKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gaXNVbmRlZmluZWQoZmllbGROYW1lcylcbiAgICAgICAgICAgID8gdmFsdWVzXG4gICAgICAgICAgICA6IGlzU3RyaW5nKGZpZWxkTmFtZXMpXG4gICAgICAgICAgICAgICAgPyBnZXQodmFsdWVzLCBmaWVsZE5hbWVzKVxuICAgICAgICAgICAgICAgIDogZmllbGROYW1lcy5tYXAoKG5hbWUpID0+IGdldCh2YWx1ZXMsIG5hbWUpKTtcbiAgICB9O1xuICAgIGNvbnN0IGdldEZpZWxkU3RhdGUgPSAobmFtZSwgZm9ybVN0YXRlKSA9PiAoe1xuICAgICAgICBpbnZhbGlkOiAhIWdldCgoZm9ybVN0YXRlIHx8IF9mb3JtU3RhdGUpLmVycm9ycywgbmFtZSksXG4gICAgICAgIGlzRGlydHk6ICEhZ2V0KChmb3JtU3RhdGUgfHwgX2Zvcm1TdGF0ZSkuZGlydHlGaWVsZHMsIG5hbWUpLFxuICAgICAgICBlcnJvcjogZ2V0KChmb3JtU3RhdGUgfHwgX2Zvcm1TdGF0ZSkuZXJyb3JzLCBuYW1lKSxcbiAgICAgICAgaXNWYWxpZGF0aW5nOiAhIWdldChfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMsIG5hbWUpLFxuICAgICAgICBpc1RvdWNoZWQ6ICEhZ2V0KChmb3JtU3RhdGUgfHwgX2Zvcm1TdGF0ZSkudG91Y2hlZEZpZWxkcywgbmFtZSksXG4gICAgfSk7XG4gICAgY29uc3QgY2xlYXJFcnJvcnMgPSAobmFtZSkgPT4ge1xuICAgICAgICBjb25zdCBuYW1lcyA9IG5hbWUgPyBjb252ZXJ0VG9BcnJheVBheWxvYWQobmFtZSkgOiB1bmRlZmluZWQ7XG4gICAgICAgIG5hbWVzID09PSBudWxsIHx8IG5hbWVzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBuYW1lcy5mb3JFYWNoKChpbnB1dE5hbWUpID0+IHVuc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBpbnB1dE5hbWUpKTtcbiAgICAgICAgaWYgKG5hbWVzKSB7XG4gICAgICAgICAgICBuYW1lcy5mb3JFYWNoKChpbnB1dE5hbWUpID0+IHtcbiAgICAgICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgIG5hbWU6IGlucHV0TmFtZSxcbiAgICAgICAgICAgICAgICAgICAgZXJyb3JzOiBfZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIGVycm9yczoge30sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3Qgc2V0RXJyb3IgPSAobmFtZSwgZXJyb3IsIG9wdGlvbnMpID0+IHtcbiAgICAgICAgY29uc3QgcmVmID0gKGdldChfZmllbGRzLCBuYW1lLCB7IF9mOiB7fSB9KS5fZiB8fCB7fSkucmVmO1xuICAgICAgICBjb25zdCBjdXJyZW50RXJyb3IgPSBnZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpIHx8IHt9O1xuICAgICAgICBjb25zdCB7IHJlZjogY3VycmVudFJlZiwgbWVzc2FnZSwgdHlwZSwgLi4ucmVzdE9mRXJyb3JUcmVlIH0gPSBjdXJyZW50RXJyb3I7XG4gICAgICAgIHNldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSwge1xuICAgICAgICAgICAgLi4ucmVzdE9mRXJyb3JUcmVlLFxuICAgICAgICAgICAgLi4uZXJyb3IsXG4gICAgICAgICAgICByZWYsXG4gICAgICAgIH0pO1xuICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgZXJyb3JzOiBfZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgICAgIGlzVmFsaWQ6IGZhbHNlLFxuICAgICAgICB9KTtcbiAgICAgICAgb3B0aW9ucyAmJiBvcHRpb25zLnNob3VsZEZvY3VzICYmIHJlZiAmJiByZWYuZm9jdXMgJiYgcmVmLmZvY3VzKCk7XG4gICAgfTtcbiAgICBjb25zdCB3YXRjaCA9IChuYW1lLCBkZWZhdWx0VmFsdWUpID0+IHtcbiAgICAgICAgaWYgKGlzRnVuY3Rpb24obmFtZSkpIHtcbiAgICAgICAgICAgIF92YWx1ZXNTdWJzY3JpYmVyQ291bnQrKztcbiAgICAgICAgICAgIGNvbnN0IHsgdW5zdWJzY3JpYmUgfSA9IF9zdWJqZWN0cy5zdGF0ZS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgICAgIG5leHQ6IChwYXlsb2FkKSA9PiAndmFsdWVzJyBpbiBwYXlsb2FkICYmXG4gICAgICAgICAgICAgICAgICAgIG5hbWUocGF5bG9hZC52YWx1ZXMgfHwgX2dldFdhdGNoKHVuZGVmaW5lZCwgZGVmYXVsdFZhbHVlKSwgcGF5bG9hZCksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGxldCBjYWxsZWQgPSBmYWxzZTtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgdW5zdWJzY3JpYmU6ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGNhbGxlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNhbGxlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIF92YWx1ZXNTdWJzY3JpYmVyQ291bnQtLTtcbiAgICAgICAgICAgICAgICAgICAgdW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gX2dldFdhdGNoKG5hbWUsIGRlZmF1bHRWYWx1ZSwgdHJ1ZSk7XG4gICAgfTtcbiAgICBjb25zdCBfc3Vic2NyaWJlID0gKHByb3BzKSA9PiB7XG4gICAgICAgIHZhciBfYTtcbiAgICAgICAgY29uc3QgbmVlZHNWYWx1ZXMgPSAhISgoX2EgPSBwcm9wcy5mb3JtU3RhdGUpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS52YWx1ZXMpO1xuICAgICAgICBpZiAobmVlZHNWYWx1ZXMpIHtcbiAgICAgICAgICAgIF92YWx1ZXNTdWJzY3JpYmVyQ291bnQrKztcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB7IHVuc3Vic2NyaWJlIH0gPSBfc3ViamVjdHMuc3RhdGUuc3Vic2NyaWJlKHtcbiAgICAgICAgICAgIG5leHQ6IChmb3JtU3RhdGUpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoc2hvdWxkU3Vic2NyaWJlQnlOYW1lKHByb3BzLm5hbWUsIGZvcm1TdGF0ZS5uYW1lLCBwcm9wcy5leGFjdCkgJiZcbiAgICAgICAgICAgICAgICAgICAgc2hvdWxkUmVuZGVyRm9ybVN0YXRlKGZvcm1TdGF0ZSwgcHJvcHMuZm9ybVN0YXRlIHx8IF9wcm94eUZvcm1TdGF0ZSwgX3NldEZvcm1TdGF0ZSwgcHJvcHMucmVSZW5kZXJSb290KSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBzbmFwc2hvdCA9IHsgLi4uX2Zvcm1WYWx1ZXMgfTtcbiAgICAgICAgICAgICAgICAgICAgcHJvcHMuY2FsbGJhY2soe1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVzOiBzbmFwc2hvdCxcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLl9mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWVzOiBfZGVmYXVsdFZhbHVlcyxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIGlmICghbmVlZHNWYWx1ZXMpIHtcbiAgICAgICAgICAgIHJldHVybiB1bnN1YnNjcmliZTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgY2FsbGVkID0gZmFsc2U7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBpZiAoY2FsbGVkKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FsbGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIF92YWx1ZXNTdWJzY3JpYmVyQ291bnQtLTtcbiAgICAgICAgICAgIHVuc3Vic2NyaWJlKCk7XG4gICAgICAgIH07XG4gICAgfTtcbiAgICBjb25zdCBzdWJzY3JpYmUgPSAocHJvcHMpID0+IHtcbiAgICAgICAgX3N0YXRlLm1vdW50ID0gdHJ1ZTtcbiAgICAgICAgX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlID0ge1xuICAgICAgICAgICAgLi4uX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlLFxuICAgICAgICAgICAgLi4ucHJvcHMuZm9ybVN0YXRlLFxuICAgICAgICB9O1xuICAgICAgICByZXR1cm4gX3N1YnNjcmliZSh7XG4gICAgICAgICAgICAuLi5wcm9wcyxcbiAgICAgICAgICAgIGZvcm1TdGF0ZToge1xuICAgICAgICAgICAgICAgIC4uLmRlZmF1bHRQcm94eUZvcm1TdGF0ZSxcbiAgICAgICAgICAgICAgICAuLi5wcm9wcy5mb3JtU3RhdGUsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IHVucmVnaXN0ZXIgPSAobmFtZSwgb3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgICAgIGZvciAoY29uc3QgZmllbGROYW1lIG9mIG5hbWUgPyBjb252ZXJ0VG9BcnJheVBheWxvYWQobmFtZSkgOiBfbmFtZXMubW91bnQpIHtcbiAgICAgICAgICAgIF9uYW1lcy5tb3VudC5kZWxldGUoZmllbGROYW1lKTtcbiAgICAgICAgICAgIF9uYW1lcy5hcnJheS5kZWxldGUoZmllbGROYW1lKTtcbiAgICAgICAgICAgIGlmICghb3B0aW9ucy5rZWVwVmFsdWUpIHtcbiAgICAgICAgICAgICAgICB1bnNldChfZmllbGRzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgICAgIHVuc2V0KF9mb3JtVmFsdWVzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgIW9wdGlvbnMua2VlcEVycm9yICYmIHVuc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgIW9wdGlvbnMua2VlcERpcnR5ICYmIHVuc2V0KF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsIGZpZWxkTmFtZSk7XG4gICAgICAgICAgICAhb3B0aW9ucy5rZWVwVG91Y2hlZCAmJiB1bnNldChfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIGZpZWxkTmFtZSk7XG4gICAgICAgICAgICAhb3B0aW9ucy5rZWVwSXNWYWxpZGF0aW5nICYmXG4gICAgICAgICAgICAgICAgdW5zZXQoX2Zvcm1TdGF0ZS52YWxpZGF0aW5nRmllbGRzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgIV9vcHRpb25zLnNob3VsZFVucmVnaXN0ZXIgJiZcbiAgICAgICAgICAgICAgICAhb3B0aW9ucy5rZWVwRGVmYXVsdFZhbHVlICYmXG4gICAgICAgICAgICAgICAgdW5zZXQoX2RlZmF1bHRWYWx1ZXMsIGZpZWxkTmFtZSk7XG4gICAgICAgIH1cbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgdmFsdWVzOiBjbG9uZU9iamVjdChfZm9ybVZhbHVlcyksXG4gICAgICAgIH0pO1xuICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAuLi5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgLi4uKCFvcHRpb25zLmtlZXBEaXJ0eSA/IHt9IDogeyBpc0RpcnR5OiBfZ2V0RGlydHkoKSB9KSxcbiAgICAgICAgfSk7XG4gICAgICAgICFvcHRpb25zLmtlZXBJc1ZhbGlkICYmIF9zZXRWYWxpZCgpO1xuICAgIH07XG4gICAgY29uc3QgX3NldERpc2FibGVkRmllbGQgPSAoeyBkaXNhYmxlZCwgbmFtZSwgfSkgPT4ge1xuICAgICAgICBpZiAoKGlzQm9vbGVhbihkaXNhYmxlZCkgJiYgX3N0YXRlLm1vdW50KSB8fFxuICAgICAgICAgICAgISFkaXNhYmxlZCB8fFxuICAgICAgICAgICAgX25hbWVzLmRpc2FibGVkLmhhcyhuYW1lKSkge1xuICAgICAgICAgICAgY29uc3Qgd2FzRGlzYWJsZWQgPSBfbmFtZXMuZGlzYWJsZWQuaGFzKG5hbWUpO1xuICAgICAgICAgICAgY29uc3QgaXNEaXNhYmxlZCA9ICEhZGlzYWJsZWQ7XG4gICAgICAgICAgICBjb25zdCBkaXNhYmxlZFN0YXRlQ2hhbmdlZCA9IHdhc0Rpc2FibGVkICE9PSBpc0Rpc2FibGVkO1xuICAgICAgICAgICAgZGlzYWJsZWQgPyBfbmFtZXMuZGlzYWJsZWQuYWRkKG5hbWUpIDogX25hbWVzLmRpc2FibGVkLmRlbGV0ZShuYW1lKTtcbiAgICAgICAgICAgIGRpc2FibGVkU3RhdGVDaGFuZ2VkICYmIF9zdGF0ZS5tb3VudCAmJiAhX3N0YXRlLmFjdGlvbiAmJiBfc2V0VmFsaWQoKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgcmVnaXN0ZXIgPSAobmFtZSwgb3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgICAgIGxldCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgY29uc3QgZGlzYWJsZWRJc0RlZmluZWQgPSBpc0Jvb2xlYW4ob3B0aW9ucy5kaXNhYmxlZCkgfHwgaXNCb29sZWFuKF9vcHRpb25zLmRpc2FibGVkKTtcbiAgICAgICAgY29uc3Qgc2hvdWxkUmV2YWxpZGF0ZVJlbW91bnQgPSAhX25hbWVzLnJlZ2lzdGVyTmFtZS5oYXMobmFtZSkgJiYgZmllbGQgJiYgZmllbGQuX2YgJiYgIWZpZWxkLl9mLm1vdW50O1xuICAgICAgICBzZXQoX2ZpZWxkcywgbmFtZSwge1xuICAgICAgICAgICAgLi4uKGZpZWxkIHx8IHt9KSxcbiAgICAgICAgICAgIF9mOiB7XG4gICAgICAgICAgICAgICAgLi4uKGZpZWxkICYmIGZpZWxkLl9mID8gZmllbGQuX2YgOiB7IHJlZjogeyBuYW1lIH0gfSksXG4gICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICBtb3VudDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIF9uYW1lcy5tb3VudC5hZGQobmFtZSk7XG4gICAgICAgIGlmIChmaWVsZCAmJiAhc2hvdWxkUmV2YWxpZGF0ZVJlbW91bnQpIHtcbiAgICAgICAgICAgIF9zZXREaXNhYmxlZEZpZWxkKHtcbiAgICAgICAgICAgICAgICBkaXNhYmxlZDogaXNCb29sZWFuKG9wdGlvbnMuZGlzYWJsZWQpXG4gICAgICAgICAgICAgICAgICAgID8gb3B0aW9ucy5kaXNhYmxlZFxuICAgICAgICAgICAgICAgICAgICA6IF9vcHRpb25zLmRpc2FibGVkLFxuICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHVwZGF0ZVZhbGlkQW5kVmFsdWUobmFtZSwgdHJ1ZSwgb3B0aW9ucy52YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLihkaXNhYmxlZElzRGVmaW5lZFxuICAgICAgICAgICAgICAgID8geyBkaXNhYmxlZDogb3B0aW9ucy5kaXNhYmxlZCB8fCBfb3B0aW9ucy5kaXNhYmxlZCB9XG4gICAgICAgICAgICAgICAgOiB7fSksXG4gICAgICAgICAgICAuLi4oX29wdGlvbnMucHJvZ3Jlc3NpdmVcbiAgICAgICAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6ICEhb3B0aW9ucy5yZXF1aXJlZCxcbiAgICAgICAgICAgICAgICAgICAgbWluOiBnZXRSdWxlVmFsdWUob3B0aW9ucy5taW4pLFxuICAgICAgICAgICAgICAgICAgICBtYXg6IGdldFJ1bGVWYWx1ZShvcHRpb25zLm1heCksXG4gICAgICAgICAgICAgICAgICAgIG1pbkxlbmd0aDogZ2V0UnVsZVZhbHVlKG9wdGlvbnMubWluTGVuZ3RoKSxcbiAgICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoOiBnZXRSdWxlVmFsdWUob3B0aW9ucy5tYXhMZW5ndGgpLFxuICAgICAgICAgICAgICAgICAgICBwYXR0ZXJuOiBnZXRSdWxlVmFsdWUob3B0aW9ucy5wYXR0ZXJuKSxcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgOiB7fSksXG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgb25DaGFuZ2UsXG4gICAgICAgICAgICBvbkJsdXI6IG9uQ2hhbmdlLFxuICAgICAgICAgICAgcmVmOiAocmVmKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHJlZikge1xuICAgICAgICAgICAgICAgICAgICBfbmFtZXMucmVnaXN0ZXJOYW1lLmFkZChuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgcmVnaXN0ZXIobmFtZSwgb3B0aW9ucyk7XG4gICAgICAgICAgICAgICAgICAgIF9uYW1lcy5yZWdpc3Rlck5hbWUuZGVsZXRlKG5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZmllbGRSZWYgPSBpc1VuZGVmaW5lZChyZWYudmFsdWUpXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHJlZi5xdWVyeVNlbGVjdG9yQWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyByZWYucXVlcnlTZWxlY3RvckFsbCgnaW5wdXQsc2VsZWN0LHRleHRhcmVhJylbMF0gfHwgcmVmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiByZWZcbiAgICAgICAgICAgICAgICAgICAgICAgIDogcmVmO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCByYWRpb09yQ2hlY2tib3ggPSBpc1JhZGlvT3JDaGVja2JveChmaWVsZFJlZik7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlZnMgPSBmaWVsZC5fZi5yZWZzIHx8IFtdO1xuICAgICAgICAgICAgICAgICAgICBpZiAocmFkaW9PckNoZWNrYm94XG4gICAgICAgICAgICAgICAgICAgICAgICA/IHJlZnMuZmluZCgob3B0aW9uKSA9PiBvcHRpb24gPT09IGZpZWxkUmVmKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBmaWVsZFJlZiA9PT0gZmllbGQuX2YucmVmKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgc2V0KF9maWVsZHMsIG5hbWUsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9mOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZmllbGQuX2YsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uKHJhZGlvT3JDaGVja2JveFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlZnM6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5yZWZzLmZpbHRlcihsaXZlKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWVsZFJlZixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi4oQXJyYXkuaXNBcnJheShnZXQoX2RlZmF1bHRWYWx1ZXMsIG5hbWUpKSA/IFt7fV0gOiBbXSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVmOiB7IHR5cGU6IGZpZWxkUmVmLnR5cGUsIG5hbWUgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHsgcmVmOiBmaWVsZFJlZiB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVWYWxpZEFuZFZhbHVlKG5hbWUsIGZhbHNlLCB1bmRlZmluZWQsIGZpZWxkUmVmKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUsIHt9KTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGZpZWxkLl9mKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmaWVsZC5fZi5tb3VudCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIChfb3B0aW9ucy5zaG91bGRVbnJlZ2lzdGVyIHx8IG9wdGlvbnMuc2hvdWxkVW5yZWdpc3RlcikgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICEoaXNOYW1lSW5GaWVsZEFycmF5KF9uYW1lcy5hcnJheSwgbmFtZSkgJiYgX3N0YXRlLmFjdGlvbikgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIF9uYW1lcy51bk1vdW50LmFkZChuYW1lKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgIH07XG4gICAgY29uc3QgX2ZvY3VzRXJyb3IgPSAoKSA9PiBfb3B0aW9ucy5zaG91bGRGb2N1c0Vycm9yICYmXG4gICAgICAgICFfb3B0aW9ucy5zaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uICYmXG4gICAgICAgIGl0ZXJhdGVGaWVsZHNCeUFjdGlvbihfZmllbGRzLCBfZm9jdXNJbnB1dCwgX25hbWVzLm1vdW50KTtcbiAgICBjb25zdCBfZGlzYWJsZUZvcm0gPSAoZGlzYWJsZWQpID0+IHtcbiAgICAgICAgaWYgKGlzQm9vbGVhbihkaXNhYmxlZCkpIHtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHsgZGlzYWJsZWQgfSk7XG4gICAgICAgICAgICBpdGVyYXRlRmllbGRzQnlBY3Rpb24oX2ZpZWxkcywgKHJlZiwgbmFtZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRGaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBpZiAoY3VycmVudEZpZWxkKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlZi5kaXNhYmxlZCA9IGN1cnJlbnRGaWVsZC5fZi5kaXNhYmxlZCB8fCBkaXNhYmxlZDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoY3VycmVudEZpZWxkLl9mLnJlZnMpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50RmllbGQuX2YucmVmcy5mb3JFYWNoKChpbnB1dFJlZikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0UmVmLmRpc2FibGVkID0gY3VycmVudEZpZWxkLl9mLmRpc2FibGVkIHx8IGRpc2FibGVkO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LCAwLCBmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IChvblZhbGlkLCBvbkludmFsaWQpID0+IGFzeW5jIChlKSA9PiB7XG4gICAgICAgIGxldCBvblZhbGlkRXJyb3IgPSB1bmRlZmluZWQ7XG4gICAgICAgIGlmIChlKSB7XG4gICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0ICYmIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgIGUucGVyc2lzdCAmJlxuICAgICAgICAgICAgICAgIGUucGVyc2lzdCgpO1xuICAgICAgICB9XG4gICAgICAgIGxldCBmaWVsZFZhbHVlcyA9IGNsb25lT2JqZWN0KF9mb3JtVmFsdWVzKTtcbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgaXNTdWJtaXR0aW5nOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKF9vcHRpb25zLnJlc29sdmVyKSB7XG4gICAgICAgICAgICBjb25zdCB7IGVycm9ycywgdmFsdWVzIH0gPSBhd2FpdCBfcnVuU2NoZW1hKCk7XG4gICAgICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKCk7XG4gICAgICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IGVycm9ycztcbiAgICAgICAgICAgIGZpZWxkVmFsdWVzID0gY2xvbmVPYmplY3QodmFsdWVzKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGF3YWl0IGV4ZWN1dGVCdWlsdEluVmFsaWRhdGlvbih7XG4gICAgICAgICAgICAgICAgZmllbGRzOiBfZmllbGRzLFxuICAgICAgICAgICAgICAgIGV2ZW50VHlwZTogRVZFTlRTLlNVQk1JVCxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGlmIChfbmFtZXMuZGlzYWJsZWQuc2l6ZSkge1xuICAgICAgICAgICAgZm9yIChjb25zdCBuYW1lIG9mIF9uYW1lcy5kaXNhYmxlZCkge1xuICAgICAgICAgICAgICAgIHVuc2V0KGZpZWxkVmFsdWVzLCBuYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB1bnNldChfZm9ybVN0YXRlLmVycm9ycywgUk9PVF9FUlJPUl9UWVBFKTtcbiAgICAgICAgaWYgKGlzRW1wdHlPYmplY3QoX2Zvcm1TdGF0ZS5lcnJvcnMpKSB7XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgZXJyb3JzOiB7fSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBhd2FpdCBvblZhbGlkKGZpZWxkVmFsdWVzLCBlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIG9uVmFsaWRFcnJvciA9IGVycm9yO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgaWYgKG9uSW52YWxpZCkge1xuICAgICAgICAgICAgICAgIGF3YWl0IG9uSW52YWxpZCh7IC4uLl9mb3JtU3RhdGUuZXJyb3JzIH0sIGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX2ZvY3VzRXJyb3IoKTtcbiAgICAgICAgICAgIHNldFRpbWVvdXQoX2ZvY3VzRXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgIGlzU3VibWl0dGVkOiB0cnVlLFxuICAgICAgICAgICAgaXNTdWJtaXR0aW5nOiBmYWxzZSxcbiAgICAgICAgICAgIGlzU3VibWl0U3VjY2Vzc2Z1bDogaXNFbXB0eU9iamVjdChfZm9ybVN0YXRlLmVycm9ycykgJiYgIW9uVmFsaWRFcnJvcixcbiAgICAgICAgICAgIHN1Ym1pdENvdW50OiBfZm9ybVN0YXRlLnN1Ym1pdENvdW50ICsgMSxcbiAgICAgICAgICAgIGVycm9yczogX2Zvcm1TdGF0ZS5lcnJvcnMsXG4gICAgICAgIH0pO1xuICAgICAgICBpZiAob25WYWxpZEVycm9yKSB7XG4gICAgICAgICAgICB0aHJvdyBvblZhbGlkRXJyb3I7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHJlc2V0RmllbGQgPSAobmFtZSwgb3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgICAgIGlmIChnZXQoX2ZpZWxkcywgbmFtZSkpIHtcbiAgICAgICAgICAgIGlmIChpc1VuZGVmaW5lZChvcHRpb25zLmRlZmF1bHRWYWx1ZSkpIHtcbiAgICAgICAgICAgICAgICBzZXRWYWx1ZShuYW1lLCBjbG9uZU9iamVjdChnZXQoX2RlZmF1bHRWYWx1ZXMsIG5hbWUpKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBzZXRWYWx1ZShuYW1lLCBvcHRpb25zLmRlZmF1bHRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgc2V0KF9kZWZhdWx0VmFsdWVzLCBuYW1lLCBjbG9uZU9iamVjdChvcHRpb25zLmRlZmF1bHRWYWx1ZSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFvcHRpb25zLmtlZXBUb3VjaGVkKSB7XG4gICAgICAgICAgICAgICAgdW5zZXQoX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghb3B0aW9ucy5rZWVwRGlydHkpIHtcbiAgICAgICAgICAgICAgICB1bnNldChfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBfZm9ybVN0YXRlLmlzRGlydHkgPSBvcHRpb25zLmRlZmF1bHRWYWx1ZVxuICAgICAgICAgICAgICAgICAgICA/IF9nZXREaXJ0eShuYW1lLCBjbG9uZU9iamVjdChnZXQoX2RlZmF1bHRWYWx1ZXMsIG5hbWUpKSlcbiAgICAgICAgICAgICAgICAgICAgOiBfZ2V0RGlydHkoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghb3B0aW9ucy5rZWVwRXJyb3IpIHtcbiAgICAgICAgICAgICAgICB1bnNldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICAgICAgX3Byb3h5Rm9ybVN0YXRlLmlzVmFsaWQgJiYgX3NldFZhbGlkKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7IC4uLl9mb3JtU3RhdGUgfSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IF9yZXNldCA9IChmb3JtVmFsdWVzLCBrZWVwU3RhdGVPcHRpb25zID0ge30pID0+IHtcbiAgICAgICAgY29uc3QgdXBkYXRlZFZhbHVlcyA9IGZvcm1WYWx1ZXMgPyBjbG9uZU9iamVjdChmb3JtVmFsdWVzKSA6IF9kZWZhdWx0VmFsdWVzO1xuICAgICAgICBjb25zdCBjbG9uZVVwZGF0ZWRWYWx1ZXMgPSBjbG9uZU9iamVjdCh1cGRhdGVkVmFsdWVzKTtcbiAgICAgICAgY29uc3QgaXNFbXB0eVJlc2V0VmFsdWVzID0gaXNFbXB0eU9iamVjdChmb3JtVmFsdWVzKTtcbiAgICAgICAgY29uc3QgdmFsdWVzID0gY2xvbmVVcGRhdGVkVmFsdWVzO1xuICAgICAgICBjb25zdCBmaWVsZFJlZnMgPSBfZmllbGRzO1xuICAgICAgICBpZiAoIWtlZXBTdGF0ZU9wdGlvbnMua2VlcERlZmF1bHRWYWx1ZXMpIHtcbiAgICAgICAgICAgIF9kZWZhdWx0VmFsdWVzID0gdXBkYXRlZFZhbHVlcztcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWtlZXBTdGF0ZU9wdGlvbnMua2VlcFZhbHVlcykge1xuICAgICAgICAgICAgaWYgKGtlZXBTdGF0ZU9wdGlvbnMua2VlcERpcnR5VmFsdWVzKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGRzVG9DaGVjayA9IG5ldyBTZXQoW1xuICAgICAgICAgICAgICAgICAgICAuLi5fbmFtZXMubW91bnQsXG4gICAgICAgICAgICAgICAgICAgIC4uLk9iamVjdC5rZXlzKGdldERpcnR5RmllbGRzKF9kZWZhdWx0VmFsdWVzLCBfZm9ybVZhbHVlcywgdW5kZWZpbmVkLCBmaWVsZFJlZnMpKSxcbiAgICAgICAgICAgICAgICBdKTtcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGZpZWxkTmFtZSBvZiBBcnJheS5mcm9tKGZpZWxkc1RvQ2hlY2spKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzRGlydHkgPSBnZXQoX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdWYWx1ZSA9IGdldChfZm9ybVZhbHVlcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV3VmFsdWUgPSBnZXQodmFsdWVzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXNEaXJ0eSAmJiAhaXNVbmRlZmluZWQoZXhpc3RpbmdWYWx1ZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldCh2YWx1ZXMsIGZpZWxkTmFtZSwgZXhpc3RpbmdWYWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoIWlzRGlydHkgJiYgIWlzVW5kZWZpbmVkKG5ld1ZhbHVlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VmFsdWUoZmllbGROYW1lLCBuZXdWYWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBpZiAoaXNXZWIgJiYgaXNVbmRlZmluZWQoZm9ybVZhbHVlcykpIHtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChjb25zdCBuYW1lIG9mIF9uYW1lcy5tb3VudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmllbGQgJiYgZmllbGQuX2YpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWVsZFJlZmVyZW5jZSA9IEFycmF5LmlzQXJyYXkoZmllbGQuX2YucmVmcylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBmaWVsZC5fZi5yZWZzWzBdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogZmllbGQuX2YucmVmO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpc0hUTUxFbGVtZW50KGZpZWxkUmVmZXJlbmNlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmb3JtID0gZmllbGRSZWZlcmVuY2UuY2xvc2VzdCgnZm9ybScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZm9ybSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybS5yZXNldCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGtlZXBTdGF0ZU9wdGlvbnMua2VlcEZpZWxkc1JlZikge1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGZpZWxkTmFtZSBvZiBfbmFtZXMubW91bnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFZhbHVlKGZpZWxkTmFtZSwgZ2V0KHZhbHVlcywgZmllbGROYW1lKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIF9maWVsZHMgPSB7fTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoX29wdGlvbnMuc2hvdWxkVW5yZWdpc3Rlcikge1xuICAgICAgICAgICAgICAgIF9mb3JtVmFsdWVzID0ga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGVmYXVsdFZhbHVlc1xuICAgICAgICAgICAgICAgICAgICA/IGNsb25lT2JqZWN0KF9kZWZhdWx0VmFsdWVzKVxuICAgICAgICAgICAgICAgICAgICA6IHt9O1xuICAgICAgICAgICAgICAgIGlmIChrZWVwU3RhdGVPcHRpb25zLmtlZXBGaWVsZHNSZWYpIHtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChjb25zdCBmaWVsZE5hbWUgb2YgX25hbWVzLm1vdW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXQoX2Zvcm1WYWx1ZXMsIGZpZWxkTmFtZSwgZ2V0KHZhbHVlcywgZmllbGROYW1lKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBfZm9ybVZhbHVlcyA9IGNsb25lT2JqZWN0KHZhbHVlcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfc3ViamVjdHMuYXJyYXkubmV4dCh7XG4gICAgICAgICAgICAgICAgdmFsdWVzOiB7IC4uLnZhbHVlcyB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgbmFtZTogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICB2YWx1ZXM6IHsgLi4udmFsdWVzIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBfbmFtZXMgPSB7XG4gICAgICAgICAgICBtb3VudDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGlydHlWYWx1ZXMgPyBfbmFtZXMubW91bnQgOiBuZXcgU2V0KCksXG4gICAgICAgICAgICB1bk1vdW50OiBuZXcgU2V0KCksXG4gICAgICAgICAgICBhcnJheTogbmV3IFNldCgpLFxuICAgICAgICAgICAgcmVnaXN0ZXJOYW1lOiBuZXcgU2V0KCksXG4gICAgICAgICAgICBkaXNhYmxlZDogbmV3IFNldCgpLFxuICAgICAgICAgICAgd2F0Y2g6IG5ldyBTZXQoKSxcbiAgICAgICAgICAgIHdhdGNoQWxsOiBmYWxzZSxcbiAgICAgICAgICAgIGZvY3VzOiAnJyxcbiAgICAgICAgfTtcbiAgICAgICAgX3N0YXRlLm1vdW50ID1cbiAgICAgICAgICAgICFfcHJveHlGb3JtU3RhdGUuaXNWYWxpZCB8fFxuICAgICAgICAgICAgICAgICEha2VlcFN0YXRlT3B0aW9ucy5rZWVwSXNWYWxpZCB8fFxuICAgICAgICAgICAgICAgICEha2VlcFN0YXRlT3B0aW9ucy5rZWVwRGlydHlWYWx1ZXMgfHxcbiAgICAgICAgICAgICAgICAoIV9vcHRpb25zLnNob3VsZFVucmVnaXN0ZXIgJiYgIWlzRW1wdHlPYmplY3QodmFsdWVzKSk7XG4gICAgICAgIF9zdGF0ZS53YXRjaCA9ICEhX29wdGlvbnMuc2hvdWxkVW5yZWdpc3RlcjtcbiAgICAgICAgX3N0YXRlLmtlZXBJc1ZhbGlkID0gISFrZWVwU3RhdGVPcHRpb25zLmtlZXBJc1ZhbGlkO1xuICAgICAgICBfc3RhdGUuYWN0aW9uID0gZmFsc2U7XG4gICAgICAgIGlmICgha2VlcFN0YXRlT3B0aW9ucy5rZWVwRXJyb3JzKSB7XG4gICAgICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHt9O1xuICAgICAgICB9XG4gICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgIHN1Ym1pdENvdW50OiBrZWVwU3RhdGVPcHRpb25zLmtlZXBTdWJtaXRDb3VudFxuICAgICAgICAgICAgICAgID8gX2Zvcm1TdGF0ZS5zdWJtaXRDb3VudFxuICAgICAgICAgICAgICAgIDogMCxcbiAgICAgICAgICAgIGlzRGlydHk6IGlzRW1wdHlSZXNldFZhbHVlc1xuICAgICAgICAgICAgICAgID8gZmFsc2VcbiAgICAgICAgICAgICAgICA6IGtlZXBTdGF0ZU9wdGlvbnMua2VlcERpcnR5XG4gICAgICAgICAgICAgICAgICAgID8gX2Zvcm1TdGF0ZS5pc0RpcnR5XG4gICAgICAgICAgICAgICAgICAgIDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwVmFsdWVzXG4gICAgICAgICAgICAgICAgICAgICAgICA/IF9nZXREaXJ0eSgpXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICEhKGtlZXBTdGF0ZU9wdGlvbnMua2VlcERlZmF1bHRWYWx1ZXMgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAhZGVlcEVxdWFsKGZvcm1WYWx1ZXMsIF9kZWZhdWx0VmFsdWVzKSksXG4gICAgICAgICAgICBpc1N1Ym1pdHRlZDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwSXNTdWJtaXR0ZWRcbiAgICAgICAgICAgICAgICA/IF9mb3JtU3RhdGUuaXNTdWJtaXR0ZWRcbiAgICAgICAgICAgICAgICA6IGZhbHNlLFxuICAgICAgICAgICAgZGlydHlGaWVsZHM6IGlzRW1wdHlSZXNldFZhbHVlc1xuICAgICAgICAgICAgICAgID8ge31cbiAgICAgICAgICAgICAgICA6IGtlZXBTdGF0ZU9wdGlvbnMua2VlcERpcnR5VmFsdWVzXG4gICAgICAgICAgICAgICAgICAgID8ga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGVmYXVsdFZhbHVlcyAmJiBfZm9ybVZhbHVlc1xuICAgICAgICAgICAgICAgICAgICAgICAgPyBnZXREaXJ0eUZpZWxkcyhfZGVmYXVsdFZhbHVlcywgX2Zvcm1WYWx1ZXMsIHVuZGVmaW5lZCwgZmllbGRSZWZzKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBfZm9ybVN0YXRlLmRpcnR5RmllbGRzXG4gICAgICAgICAgICAgICAgICAgIDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGVmYXVsdFZhbHVlcyAmJiBmb3JtVmFsdWVzXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGdldERpcnR5RmllbGRzKF9kZWZhdWx0VmFsdWVzLCBmb3JtVmFsdWVzLCB1bmRlZmluZWQsIGZpZWxkUmVmcylcbiAgICAgICAgICAgICAgICAgICAgICAgIDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGlydHlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IF9mb3JtU3RhdGUuZGlydHlGaWVsZHNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHt9LFxuICAgICAgICAgICAgdG91Y2hlZEZpZWxkczoga2VlcFN0YXRlT3B0aW9ucy5rZWVwVG91Y2hlZFxuICAgICAgICAgICAgICAgID8gX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzXG4gICAgICAgICAgICAgICAgOiB7fSxcbiAgICAgICAgICAgIGVycm9yczoga2VlcFN0YXRlT3B0aW9ucy5rZWVwRXJyb3JzID8gX2Zvcm1TdGF0ZS5lcnJvcnMgOiB7fSxcbiAgICAgICAgICAgIGlzU3VibWl0U3VjY2Vzc2Z1bDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwSXNTdWJtaXRTdWNjZXNzZnVsXG4gICAgICAgICAgICAgICAgPyBfZm9ybVN0YXRlLmlzU3VibWl0U3VjY2Vzc2Z1bFxuICAgICAgICAgICAgICAgIDogZmFsc2UsXG4gICAgICAgICAgICBpc1N1Ym1pdHRpbmc6IGZhbHNlLFxuICAgICAgICAgICAgZGVmYXVsdFZhbHVlczogX2RlZmF1bHRWYWx1ZXMsXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgcmVzZXQgPSAoZm9ybVZhbHVlcywga2VlcFN0YXRlT3B0aW9ucykgPT4gX3Jlc2V0KGlzRnVuY3Rpb24oZm9ybVZhbHVlcylcbiAgICAgICAgPyBmb3JtVmFsdWVzKF9mb3JtVmFsdWVzKVxuICAgICAgICA6IGZvcm1WYWx1ZXMsIHsgLi4uX29wdGlvbnMucmVzZXRPcHRpb25zLCAuLi5rZWVwU3RhdGVPcHRpb25zIH0pO1xuICAgIGNvbnN0IHNldEZvY3VzID0gKG5hbWUsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgY29uc3QgZmllbGRSZWZlcmVuY2UgPSBmaWVsZCAmJiBmaWVsZC5fZjtcbiAgICAgICAgaWYgKGZpZWxkUmVmZXJlbmNlKSB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZFJlZiA9IGZpZWxkUmVmZXJlbmNlLnJlZnNcbiAgICAgICAgICAgICAgICA/IGZpZWxkUmVmZXJlbmNlLnJlZnNbMF1cbiAgICAgICAgICAgICAgICA6IGZpZWxkUmVmZXJlbmNlLnJlZjtcbiAgICAgICAgICAgIGlmIChmaWVsZFJlZi5mb2N1cykge1xuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBmaWVsZFJlZi5mb2N1cygpO1xuICAgICAgICAgICAgICAgICAgICBvcHRpb25zLnNob3VsZFNlbGVjdCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgaXNGdW5jdGlvbihmaWVsZFJlZi5zZWxlY3QpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWVsZFJlZi5zZWxlY3QoKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgX3NldEZvcm1TdGF0ZSA9ICh1cGRhdGVkRm9ybVN0YXRlKSA9PiB7XG4gICAgICAgIC8vIGBuYW1lYCwgYHR5cGVgLCBhbmQgYHZhbHVlc2AgZGVzY3JpYmUgdGhlIGV2ZW50IHRoYXQgcHJvZHVjZWQgdGhpc1xuICAgICAgICAvLyB1cGRhdGUsIG5vdCB0aGUgZm9ybSdzIHBlcnNpc3RlZCBzdGF0ZSAodGhleSBhcmVuJ3QgcGFydCBvZlxuICAgICAgICAvLyBgRm9ybVN0YXRlYCkuIE1lcmdpbmcgdGhlbSBpbiB3b3VsZCBsZWFrIGEgc3RhbGUgYG5hbWVgL2B0eXBlYCBmcm9tXG4gICAgICAgIC8vIG9uZSBldmVudCBpbnRvIGEgbGF0ZXIsIHVucmVsYXRlZCBub3RpZmljYXRpb24gdGhhdCBkb2Vzbid0IHNwZWNpZnlcbiAgICAgICAgLy8gaXRzIG93bi5cbiAgICAgICAgY29uc3QgeyBuYW1lLCB0eXBlLCB2YWx1ZXMsIC4uLmZvcm1TdGF0ZSB9ID0gdXBkYXRlZEZvcm1TdGF0ZTtcbiAgICAgICAgX2Zvcm1TdGF0ZSA9IHtcbiAgICAgICAgICAgIC4uLl9mb3JtU3RhdGUsXG4gICAgICAgICAgICAuLi5mb3JtU3RhdGUsXG4gICAgICAgIH07XG4gICAgfTtcbiAgICBjb25zdCBfcmVzZXREZWZhdWx0VmFsdWVzID0gKCkgPT4gaXNGdW5jdGlvbihfb3B0aW9ucy5kZWZhdWx0VmFsdWVzKSAmJlxuICAgICAgICBfb3B0aW9ucy5kZWZhdWx0VmFsdWVzKCkudGhlbigodmFsdWVzKSA9PiB7XG4gICAgICAgICAgICByZXNldCh2YWx1ZXMsIF9vcHRpb25zLnJlc2V0T3B0aW9ucyk7XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgaXNMb2FkaW5nOiBmYWxzZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICBjb25zdCByZXNldERlZmF1bHRWYWx1ZXMgPSAodmFsdWVzLCBvcHRpb25zID0ge30pID0+IHtcbiAgICAgICAgX2RlZmF1bHRWYWx1ZXMgPSBjbG9uZU9iamVjdCh2YWx1ZXMpO1xuICAgICAgICBpZiAoIW9wdGlvbnMua2VlcERpcnR5KSB7XG4gICAgICAgICAgICBjb25zdCBuZXdEaXJ0eUZpZWxkcyA9IGdldERpcnR5RmllbGRzKF9kZWZhdWx0VmFsdWVzLCBfZm9ybVZhbHVlcywgdW5kZWZpbmVkLCBfZmllbGRzKTtcbiAgICAgICAgICAgIF9mb3JtU3RhdGUuZGlydHlGaWVsZHMgPSBuZXdEaXJ0eUZpZWxkcztcbiAgICAgICAgICAgIF9mb3JtU3RhdGUuaXNEaXJ0eSA9ICFpc0VtcHR5T2JqZWN0KG5ld0RpcnR5RmllbGRzKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIW9wdGlvbnMua2VlcElzVmFsaWQpIHtcbiAgICAgICAgICAgIF9zZXRWYWxpZCgpO1xuICAgICAgICB9XG4gICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgIC4uLl9mb3JtU3RhdGUsXG4gICAgICAgICAgICBkZWZhdWx0VmFsdWVzOiBfZGVmYXVsdFZhbHVlcyxcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCBtZXRob2RzID0ge1xuICAgICAgICBjb250cm9sOiB7XG4gICAgICAgICAgICByZWdpc3RlcixcbiAgICAgICAgICAgIHVucmVnaXN0ZXIsXG4gICAgICAgICAgICBnZXRGaWVsZFN0YXRlLFxuICAgICAgICAgICAgaGFuZGxlU3VibWl0LFxuICAgICAgICAgICAgc2V0RXJyb3IsXG4gICAgICAgICAgICBfc3Vic2NyaWJlLFxuICAgICAgICAgICAgX3J1blNjaGVtYSxcbiAgICAgICAgICAgIF91cGRhdGVJc1ZhbGlkYXRpbmcsXG4gICAgICAgICAgICBfZm9jdXNFcnJvcixcbiAgICAgICAgICAgIF9nZXRXYXRjaCxcbiAgICAgICAgICAgIF9nZXREaXJ0eSxcbiAgICAgICAgICAgIF9zZXRWYWxpZCxcbiAgICAgICAgICAgIF9zZXRGaWVsZEFycmF5LFxuICAgICAgICAgICAgX3NldERpc2FibGVkRmllbGQsXG4gICAgICAgICAgICBfc2V0RXJyb3JzLFxuICAgICAgICAgICAgX2dldEZpZWxkQXJyYXksXG4gICAgICAgICAgICBfcmVzZXQsXG4gICAgICAgICAgICBfcmVzZXREZWZhdWx0VmFsdWVzLFxuICAgICAgICAgICAgX3JlbW92ZVVubW91bnRlZCxcbiAgICAgICAgICAgIF9kaXNhYmxlRm9ybSxcbiAgICAgICAgICAgIF9zdWJqZWN0cyxcbiAgICAgICAgICAgIF9wcm94eUZvcm1TdGF0ZSxcbiAgICAgICAgICAgIGdldCBfZmllbGRzKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBfZmllbGRzO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGdldCBfZm9ybVZhbHVlcygpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX2Zvcm1WYWx1ZXM7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZ2V0IF9zdGF0ZSgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX3N0YXRlO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNldCBfc3RhdGUodmFsdWUpIHtcbiAgICAgICAgICAgICAgICBfc3RhdGUgPSB2YWx1ZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBnZXQgX2RlZmF1bHRWYWx1ZXMoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF9kZWZhdWx0VmFsdWVzO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGdldCBfbmFtZXMoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF9uYW1lcztcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzZXQgX25hbWVzKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgX25hbWVzID0gdmFsdWU7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZ2V0IF9mb3JtU3RhdGUoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF9mb3JtU3RhdGU7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZ2V0IF9vcHRpb25zKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBfb3B0aW9ucztcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzZXQgX29wdGlvbnModmFsdWUpIHtcbiAgICAgICAgICAgICAgICBfb3B0aW9ucyA9IHtcbiAgICAgICAgICAgICAgICAgICAgLi4uX29wdGlvbnMsXG4gICAgICAgICAgICAgICAgICAgIC4uLnZhbHVlLFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgX3ZhbGlkYXRpb25Nb2RlQmVmb3JlU3VibWl0ID0gZ2V0VmFsaWRhdGlvbk1vZGVzKF9vcHRpb25zLm1vZGUpO1xuICAgICAgICAgICAgICAgIF92YWxpZGF0aW9uTW9kZUFmdGVyU3VibWl0ID0gZ2V0VmFsaWRhdGlvbk1vZGVzKF9vcHRpb25zLnJlVmFsaWRhdGVNb2RlKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHN1YnNjcmliZSxcbiAgICAgICAgdHJpZ2dlcixcbiAgICAgICAgcmVnaXN0ZXIsXG4gICAgICAgIGhhbmRsZVN1Ym1pdCxcbiAgICAgICAgd2F0Y2gsXG4gICAgICAgIHNldFZhbHVlLFxuICAgICAgICBzZXRWYWx1ZXMsXG4gICAgICAgIGdldFZhbHVlcyxcbiAgICAgICAgcmVzZXQsXG4gICAgICAgIHJlc2V0RmllbGQsXG4gICAgICAgIHJlc2V0RGVmYXVsdFZhbHVlcyxcbiAgICAgICAgY2xlYXJFcnJvcnMsXG4gICAgICAgIHVucmVnaXN0ZXIsXG4gICAgICAgIHNldEVycm9yLFxuICAgICAgICBzZXRGb2N1cyxcbiAgICAgICAgZ2V0RmllbGRTdGF0ZSxcbiAgICB9O1xuICAgIHJldHVybiB7XG4gICAgICAgIC4uLm1ldGhvZHMsXG4gICAgICAgIGZvcm1Db250cm9sOiBtZXRob2RzLFxuICAgIH07XG59XG5cbi8qKlxuICogQ3VzdG9tIGhvb2sgdG8gbWFuYWdlIHRoZSBlbnRpcmUgZm9ybS5cbiAqXG4gKiBAcmVtYXJrc1xuICogW0FQSV0oaHR0cHM6Ly9yZWFjdC1ob29rLWZvcm0uY29tL2RvY3MvdXNlZm9ybSkg4oCiIFtEZW1vXShodHRwczovL2NvZGVzYW5kYm94LmlvL3MvcmVhY3QtaG9vay1mb3JtLWdldC1zdGFydGVkLXRzLTVrc21tKSDigKIgW1ZpZGVvXShodHRwczovL3d3dy55b3V0dWJlLmNvbS93YXRjaD92PVJrWHY0QVhYQ180KVxuICpcbiAqIEBwYXJhbSBwcm9wcyAtIGZvcm0gY29uZmlndXJhdGlvbiBhbmQgdmFsaWRhdGlvbiBwYXJhbWV0ZXJzLlxuICpcbiAqIEByZXR1cm5zIG1ldGhvZHMgLSBpbmRpdmlkdWFsIGZ1bmN0aW9ucyB0byBtYW5hZ2UgdGhlIGZvcm0gc3RhdGUuIHtAbGluayBVc2VGb3JtUmV0dXJufVxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c3hcbiAqIGZ1bmN0aW9uIEFwcCgpIHtcbiAqICAgY29uc3QgeyByZWdpc3RlciwgaGFuZGxlU3VibWl0LCB3YXRjaCwgZm9ybVN0YXRlOiB7IGVycm9ycyB9IH0gPSB1c2VGb3JtKCk7XG4gKiAgIGNvbnN0IG9uU3VibWl0ID0gZGF0YSA9PiBjb25zb2xlLmxvZyhkYXRhKTtcbiAqXG4gKiAgIGNvbnNvbGUubG9nKHdhdGNoKFwiZXhhbXBsZVwiKSk7XG4gKlxuICogICByZXR1cm4gKFxuICogICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXQob25TdWJtaXQpfT5cbiAqICAgICAgIDxpbnB1dCBkZWZhdWx0VmFsdWU9XCJ0ZXN0XCIgey4uLnJlZ2lzdGVyKFwiZXhhbXBsZVwiKX0gLz5cbiAqICAgICAgIDxpbnB1dCB7Li4ucmVnaXN0ZXIoXCJleGFtcGxlUmVxdWlyZWRcIiwgeyByZXF1aXJlZDogdHJ1ZSB9KX0gLz5cbiAqICAgICAgIHtlcnJvcnMuZXhhbXBsZVJlcXVpcmVkICYmIDxzcGFuPlRoaXMgZmllbGQgaXMgcmVxdWlyZWQ8L3NwYW4+fVxuICogICAgICAgPGJ1dHRvbj5TdWJtaXQ8L2J1dHRvbj5cbiAqICAgICA8L2Zvcm0+XG4gKiAgICk7XG4gKiB9XG4gKiBgYGBcbiAqL1xuZnVuY3Rpb24gdXNlRm9ybShwcm9wcyA9IHt9KSB7XG4gICAgY29uc3QgX2Zvcm1Db250cm9sID0gUmVhY3QudXNlUmVmKHVuZGVmaW5lZCk7XG4gICAgY29uc3QgX3ZhbHVlcyA9IFJlYWN0LnVzZVJlZih1bmRlZmluZWQpO1xuICAgIGNvbnN0IF9mb3JtQ29udHJvbFByb3AgPSBSZWFjdC51c2VSZWYocHJvcHMuZm9ybUNvbnRyb2wpO1xuICAgIGNvbnN0IFtmb3JtU3RhdGUsIHVwZGF0ZUZvcm1TdGF0ZV0gPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiAoe1xuICAgICAgICAuLi5jbG9uZU9iamVjdChERUZBVUxUX0ZPUk1fU1RBVEUpLFxuICAgICAgICBpc0xvYWRpbmc6IGlzRnVuY3Rpb24ocHJvcHMuZGVmYXVsdFZhbHVlcyksXG4gICAgICAgIGVycm9yczogcHJvcHMuZXJyb3JzIHx8IHt9LFxuICAgICAgICBkaXNhYmxlZDogcHJvcHMuZGlzYWJsZWQgfHwgZmFsc2UsXG4gICAgICAgIGRlZmF1bHRWYWx1ZXM6IGlzRnVuY3Rpb24ocHJvcHMuZGVmYXVsdFZhbHVlcylcbiAgICAgICAgICAgID8gdW5kZWZpbmVkXG4gICAgICAgICAgICA6IHByb3BzLmRlZmF1bHRWYWx1ZXMsXG4gICAgfSkpO1xuICAgIGlmICghX2Zvcm1Db250cm9sLmN1cnJlbnQgfHxcbiAgICAgICAgKHByb3BzLmZvcm1Db250cm9sICYmIF9mb3JtQ29udHJvbFByb3AuY3VycmVudCAhPT0gcHJvcHMuZm9ybUNvbnRyb2wpKSB7XG4gICAgICAgIF9mb3JtQ29udHJvbFByb3AuY3VycmVudCA9IHByb3BzLmZvcm1Db250cm9sO1xuICAgICAgICBpZiAocHJvcHMuZm9ybUNvbnRyb2wpIHtcbiAgICAgICAgICAgIF9mb3JtQ29udHJvbC5jdXJyZW50ID0ge1xuICAgICAgICAgICAgICAgIC4uLnByb3BzLmZvcm1Db250cm9sLFxuICAgICAgICAgICAgICAgIGZvcm1TdGF0ZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBpZiAocHJvcHMuZGVmYXVsdFZhbHVlcyAmJiAhaXNGdW5jdGlvbihwcm9wcy5kZWZhdWx0VmFsdWVzKSkge1xuICAgICAgICAgICAgICAgIHByb3BzLmZvcm1Db250cm9sLnJlc2V0KHByb3BzLmRlZmF1bHRWYWx1ZXMsIHByb3BzLnJlc2V0T3B0aW9ucyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjb25zdCB7IGZvcm1Db250cm9sLCAuLi5yZXN0IH0gPSBjcmVhdGVGb3JtQ29udHJvbChwcm9wcyk7XG4gICAgICAgICAgICBfZm9ybUNvbnRyb2wuY3VycmVudCA9IHtcbiAgICAgICAgICAgICAgICAuLi5yZXN0LFxuICAgICAgICAgICAgICAgIGZvcm1TdGF0ZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgY29udHJvbCA9IF9mb3JtQ29udHJvbC5jdXJyZW50LmNvbnRyb2w7XG4gICAgY29udHJvbC5fb3B0aW9ucyA9IHByb3BzO1xuICAgIHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgICBjb25zdCBzdWIgPSBjb250cm9sLl9zdWJzY3JpYmUoe1xuICAgICAgICAgICAgZm9ybVN0YXRlOiBjb250cm9sLl9wcm94eUZvcm1TdGF0ZSxcbiAgICAgICAgICAgIGNhbGxiYWNrOiAoKSA9PiB1cGRhdGVGb3JtU3RhdGUoe1xuICAgICAgICAgICAgICAgIC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZSxcbiAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWVzOiBjb250cm9sLl9kZWZhdWx0VmFsdWVzLFxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICByZVJlbmRlclJvb3Q6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICB1cGRhdGVGb3JtU3RhdGUoKGRhdGEpID0+ICh7XG4gICAgICAgICAgICAuLi5kYXRhLFxuICAgICAgICAgICAgaXNSZWFkeTogdHJ1ZSxcbiAgICAgICAgfSkpO1xuICAgICAgICBjb250cm9sLl9mb3JtU3RhdGUuaXNSZWFkeSA9IHRydWU7XG4gICAgICAgIHJldHVybiBzdWI7XG4gICAgfSwgW2NvbnRyb2xdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4gY29udHJvbC5fZGlzYWJsZUZvcm0ocHJvcHMuZGlzYWJsZWQpLCBbY29udHJvbCwgcHJvcHMuZGlzYWJsZWRdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAocHJvcHMubW9kZSkge1xuICAgICAgICAgICAgY29udHJvbC5fb3B0aW9ucy5tb2RlID0gcHJvcHMubW9kZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocHJvcHMucmVWYWxpZGF0ZU1vZGUpIHtcbiAgICAgICAgICAgIGNvbnRyb2wuX29wdGlvbnMucmVWYWxpZGF0ZU1vZGUgPSBwcm9wcy5yZVZhbGlkYXRlTW9kZTtcbiAgICAgICAgfVxuICAgIH0sIFtjb250cm9sLCBwcm9wcy5tb2RlLCBwcm9wcy5yZVZhbGlkYXRlTW9kZV0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChwcm9wcy5lcnJvcnMpIHtcbiAgICAgICAgICAgIGNvbnRyb2wuX3NldEVycm9ycyhwcm9wcy5lcnJvcnMpO1xuICAgICAgICAgICAgY29udHJvbC5fZm9jdXNFcnJvcigpO1xuICAgICAgICB9XG4gICAgfSwgW2NvbnRyb2wsIHByb3BzLmVycm9yc10pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHByb3BzLnNob3VsZFVucmVnaXN0ZXIgJiZcbiAgICAgICAgICAgIGNvbnRyb2wuX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIHZhbHVlczogY29udHJvbC5fZ2V0V2F0Y2goKSxcbiAgICAgICAgICAgIH0pO1xuICAgIH0sIFtjb250cm9sLCBwcm9wcy5zaG91bGRVbnJlZ2lzdGVyXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGNvbnRyb2wuX3Byb3h5Rm9ybVN0YXRlLmlzRGlydHkpIHtcbiAgICAgICAgICAgIGNvbnN0IGlzRGlydHkgPSBjb250cm9sLl9nZXREaXJ0eSgpO1xuICAgICAgICAgICAgaWYgKGlzRGlydHkgIT09IGZvcm1TdGF0ZS5pc0RpcnR5KSB7XG4gICAgICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgIGlzRGlydHksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbY29udHJvbCwgZm9ybVN0YXRlLmlzRGlydHldKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIGlmIChwcm9wcy52YWx1ZXMgJiYgIWRlZXBFcXVhbChwcm9wcy52YWx1ZXMsIF92YWx1ZXMuY3VycmVudCkpIHtcbiAgICAgICAgICAgIGNvbnRyb2wuX3Jlc2V0KHByb3BzLnZhbHVlcywge1xuICAgICAgICAgICAgICAgIGtlZXBGaWVsZHNSZWY6IHRydWUsXG4gICAgICAgICAgICAgICAgLi4uY29udHJvbC5fb3B0aW9ucy5yZXNldE9wdGlvbnMsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmICghKChfYSA9IGNvbnRyb2wuX29wdGlvbnMucmVzZXRPcHRpb25zKSA9PT0gbnVsbCB8fCBfYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2Eua2VlcElzVmFsaWQpKSB7XG4gICAgICAgICAgICAgICAgY29udHJvbC5fc2V0VmFsaWQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF92YWx1ZXMuY3VycmVudCA9IHByb3BzLnZhbHVlcztcbiAgICAgICAgICAgIHVwZGF0ZUZvcm1TdGF0ZSgoc3RhdGUpID0+ICh7IC4uLnN0YXRlIH0pKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnRyb2wuX3Jlc2V0RGVmYXVsdFZhbHVlcygpO1xuICAgICAgICB9XG4gICAgfSwgW2NvbnRyb2wsIHByb3BzLnZhbHVlc10pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmICghY29udHJvbC5fc3RhdGUubW91bnQpIHtcbiAgICAgICAgICAgIGNvbnRyb2wuX3NldFZhbGlkKCk7XG4gICAgICAgICAgICBjb250cm9sLl9zdGF0ZS5tb3VudCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNvbnRyb2wuX3N0YXRlLndhdGNoKSB7XG4gICAgICAgICAgICBjb250cm9sLl9zdGF0ZS53YXRjaCA9IGZhbHNlO1xuICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7IC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZSB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb250cm9sLl9yZW1vdmVVbm1vdW50ZWQoKTtcbiAgICB9KTtcbiAgICBfZm9ybUNvbnRyb2wuY3VycmVudC5mb3JtU3RhdGUgPSBSZWFjdC51c2VNZW1vKCgpID0+IGdldFByb3h5Rm9ybVN0YXRlKGZvcm1TdGF0ZSwgY29udHJvbCksIFtjb250cm9sLCBmb3JtU3RhdGVdKTtcbiAgICByZXR1cm4gX2Zvcm1Db250cm9sLmN1cnJlbnQ7XG59XG5cbi8qKlxuICogV2F0Y2ggY29tcG9uZW50IHRoYXQgc3Vic2NyaWJlcyB0byBmb3JtIGZpZWxkIGNoYW5nZXMgYW5kIHJlLXJlbmRlcnMgd2hlbiB3YXRjaGVkIGZpZWxkcyB1cGRhdGUuXG4gKlxuICogQHBhcmFtIGNvbnRyb2wgLSBUaGUgZm9ybSBjb250cm9sIG9iamVjdCBmcm9tIHVzZUZvcm1cbiAqIEBwYXJhbSBuYW1lIC0gQ2FuIGJlIGZpZWxkIG5hbWUsIGFycmF5IG9mIGZpZWxkIG5hbWVzLCBvciB1bmRlZmluZWQgdG8gd2F0Y2ggdGhlIGVudGlyZSBmb3JtXG4gKiBAcGFyYW0gZGlzYWJsZWQgLSBEaXNhYmxlIHN1YnNjcmlwdGlvblxuICogQHBhcmFtIGV4YWN0IC0gV2hldGhlciB0byB3YXRjaCBleGFjdCBmaWVsZCBuYW1lcyBvciBub3RcbiAqIEBwYXJhbSBkZWZhdWx0VmFsdWUgLSBUaGUgZGVmYXVsdCB2YWx1ZSB0byB1c2UgaWYgdGhlIGZpZWxkIGlzIG5vdCB5ZXQgc2V0XG4gKiBAcGFyYW0gY29tcHV0ZSAtIEZ1bmN0aW9uIHRvIGNvbXB1dGUgZGVyaXZlZCB2YWx1ZXMgZnJvbSB3YXRjaGVkIGZpZWxkc1xuICogQHBhcmFtIHJlbmRlciAtIFRoZSBmdW5jdGlvbiB0aGF0IHJlY2VpdmVzIHdhdGNoZWQgdmFsdWVzIGFuZCByZXR1cm5zIFJlYWN0Tm9kZVxuICogQHJldHVybnMgVGhlIHJlc3VsdCBvZiBjYWxsaW5nIHJlbmRlciBmdW5jdGlvbiB3aXRoIHdhdGNoZWQgdmFsdWVzXG4gKlxuICogQGV4YW1wbGVcbiAqIFRoZSBgV2F0Y2hgIGNvbXBvbmVudCBvbmx5IHJlLXJlbmRlciB3aGVuIHRoZSB2YWx1ZXMgb2YgYGZvb2AsIGBiYXJgLCBhbmQgYGJhei5xdXhgIGNoYW5nZS5cbiAqIFRoZSB0eXBlcyBvZiBgZm9vYCwgYGJhcmAsIGFuZCBgYmF6LnF1eGAgYXJlIHByZWNpc2VseSBpbmZlcnJlZC5cbiAqXG4gKiBgYGB0c3hcbiAqIGNvbnN0IHsgY29udHJvbCB9ID0gdXNlRm9ybSgpO1xuICpcbiAqIDxXYXRjaFxuICogICBjb250cm9sPXtjb250cm9sfVxuICogICBuYW1lcz17Wydmb28nLCAnYmFyJywgJ2Jhei5xdXgnXX1cbiAqICAgcmVuZGVyPXsoW2ZvbywgYmFyLCBiYXpfcXV4XSkgPT4gPGRpdj57Zm9vfXtiYXJ9e2Jhel9xdXh9PC9kaXY+fVxuICogLz5cbiAqIGBgYFxuICovXG5jb25zdCBXYXRjaCA9IChwcm9wcykgPT4gcHJvcHMucmVuZGVyKHVzZVdhdGNoKHsgbmFtZTogcHJvcHMubmFtZXMsIC4uLnByb3BzIH0pKTtcblxuZXhwb3J0IHsgQ29udHJvbGxlciwgRmllbGRBcnJheSwgRm9ybSwgRm9ybVByb3ZpZGVyLCBGb3JtU3RhdGVTdWJzY3JpYmUsIFdhdGNoLCBhcHBlbmRFcnJvcnMsIGNyZWF0ZUZvcm1Db250cm9sLCBnZXQsIHNldCwgdXNlQ29udHJvbGxlciwgdXNlRmllbGRBcnJheSwgdXNlRm9ybSwgdXNlRm9ybUNvbnRleHQsIHVzZUZvcm1TdGF0ZSwgdXNlV2F0Y2ggfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmVzbS5tanMubWFwXG4iXSwibWFwcGluZ3MiOiI7Ozs7QUFFQSxJQUFJLG1CQUFtQixZQUFZLFFBQVEsU0FBUztBQUVwRCxJQUFJLGdCQUFnQixVQUFVLGlCQUFpQjtBQUUvQyxJQUFJLHFCQUFxQixVQUFVLFNBQVM7QUFFNUMsSUFBTSxnQkFBZ0IsVUFBVSxPQUFPLFVBQVU7QUFDakQsSUFBSSxZQUFZLFVBQVUsQ0FBQyxrQkFBa0IsS0FBSyxLQUM5QyxDQUFDLE1BQU0sUUFBUSxLQUFLLEtBQ3BCLGFBQWEsS0FBSyxLQUNsQixDQUFDLGFBQWEsS0FBSztBQUV2QixJQUFJLGlCQUFpQixVQUFVLFNBQVMsS0FBSyxLQUFLLE1BQU0sU0FDbEQsZ0JBQWdCLE1BQU0sTUFBTSxJQUN4QixNQUFNLE9BQU8sVUFDYixNQUFNLE9BQU8sUUFDakI7QUFFTixJQUFJLHNCQUFzQixPQUFPLFNBQVMsS0FDckMsTUFBTSxHQUFHLENBQUMsQ0FDVixNQUFNLE1BQU0sT0FBTyxRQUFRLENBQUMsTUFBTSxPQUFPLElBQUksQ0FBQyxLQUFLLE1BQU0sSUFBSSxJQUFJLE1BQU0sR0FBRyxLQUFLLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0FBRWhHLElBQUksaUJBQWlCLGVBQWU7Q0FDaEMsTUFBTSxnQkFBZ0IsV0FBVyxlQUFlLFdBQVcsWUFBWTtDQUN2RSxPQUFRLFNBQVMsYUFBYSxLQUFLLGNBQWMsZUFBZSxlQUFlO0FBQ25GO0FBRUEsSUFBSSxRQUFRLE9BQU8sV0FBVyxlQUMxQixPQUFPLE9BQU8sZ0JBQWdCLGVBQzlCLE9BQU8sYUFBYTtBQUV4QixTQUFTLFlBQVksTUFBTTtDQUN2QixJQUFJLGdCQUFnQixNQUNoQixPQUFPLElBQUksS0FBSyxJQUFJO0NBRXhCLE1BQU0scUJBQXFCLE9BQU8sYUFBYSxlQUFlLGdCQUFnQjtDQUM5RSxJQUFJLFVBQVUsZ0JBQWdCLFFBQVEscUJBQ2xDLE9BQU87Q0FFWCxNQUFNLFVBQVUsTUFBTSxRQUFRLElBQUk7Q0FDbEMsSUFBSSxDQUFDLFdBQVcsRUFBRSxTQUFTLElBQUksS0FBSyxjQUFjLElBQUksSUFDbEQsT0FBTztDQUVYLE1BQU0sT0FBTyxVQUFVLENBQUMsSUFBSSxPQUFPLE9BQU8sT0FBTyxlQUFlLElBQUksQ0FBQztDQUNyRSxLQUFLLE1BQU0sT0FBTyxNQUNkLElBQUksT0FBTyxVQUFVLGVBQWUsS0FBSyxNQUFNLEdBQUcsR0FDOUMsS0FBSyxPQUFPLFlBQVksS0FBSyxJQUFJO0NBR3pDLE9BQU87QUFDWDtBQUVBLElBQU0sU0FBUztDQUNYLE1BQU07Q0FDTixXQUFXO0NBQ1gsUUFBUTtDQUNSLFFBQVE7Q0FDUixTQUFTO0NBQ1QsT0FBTztBQUNYO0FBQ0EsSUFBTSxrQkFBa0I7Q0FDcEIsUUFBUTtDQUNSLFVBQVU7Q0FDVixVQUFVO0NBQ1YsV0FBVztDQUNYLEtBQUs7QUFDVDtBQUNBLElBQU0seUJBQXlCO0NBQzNCLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsV0FBVztDQUNYLFdBQVc7Q0FDWCxTQUFTO0NBQ1QsVUFBVTtDQUNWLFVBQVU7QUFDZDtBQUNBLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0scUJBQXFCO0NBQUM7Q0FBYTtDQUFlO0FBQVc7QUFFbkUsSUFBTSxZQUFZO0FBQ2xCLElBQUksU0FBUyxVQUFVLFVBQVUsS0FBSyxLQUFLO0FBRTNDLElBQUksZUFBZSxRQUFRLFFBQVEsS0FBQTtBQUVuQyxJQUFNLGdCQUFnQjtBQUN0QixJQUFJLGdCQUFnQixVQUFVLE1BQU0sTUFBTSxhQUFhLENBQUMsQ0FBQyxPQUFPLE9BQU87QUFFdkUsSUFBSSxPQUFPLFFBQVEsTUFBTSxpQkFBaUI7Q0FDdEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLE1BQU0sR0FDekIsT0FBTztDQUVYLE1BQU0sUUFBUSxNQUFNLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxhQUFhLElBQUk7Q0FDdEQsSUFBSSxNQUFNLE1BQU0sUUFBUSxtQkFBbUIsU0FBUyxHQUFHLENBQUMsR0FDcEQsT0FBTztDQUVYLE1BQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxRQUFRO0VBQ3pDLE9BQU8sa0JBQWtCLE1BQU0sSUFBSSxLQUFBLElBQVksT0FBTztDQUMxRCxHQUFHLE1BQU07Q0FDVCxPQUFPLFlBQVksTUFBTSxLQUFLLFdBQVcsU0FDbkMsWUFBWSxPQUFPLEtBQUssSUFDcEIsZUFDQSxPQUFPLFFBQ1g7QUFDVjtBQUVBLElBQUksYUFBYSxVQUFVLE9BQU8sVUFBVTtBQUU1QyxJQUFJLGNBQWMsVUFBVSxPQUFPLFVBQVU7QUFFN0MsSUFBSSxPQUFPLFFBQVEsTUFBTSxVQUFVO0NBQy9CLElBQUksUUFBUTtDQUNaLE1BQU0sV0FBVyxNQUFNLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxhQUFhLElBQUk7Q0FDekQsTUFBTSxTQUFTLFNBQVM7Q0FDeEIsTUFBTSxZQUFZLFNBQVM7Q0FDM0IsT0FBTyxFQUFFLFFBQVEsUUFBUTtFQUNyQixNQUFNLE1BQU0sU0FBUztFQUNyQixJQUFJLFdBQVc7RUFDZixJQUFJLFVBQVUsV0FBVztHQUNyQixNQUFNLFdBQVcsT0FBTztHQUN4QixXQUNJLFNBQVMsUUFBUSxLQUFLLE1BQU0sUUFBUSxRQUFRLElBQ3RDLFdBQ0EsQ0FBQyxNQUFNLENBQUMsU0FBUyxRQUFRLEVBQUUsSUFDdkIsQ0FBQyxJQUNELENBQUM7RUFDbkI7RUFDQSxJQUFJLG1CQUFtQixTQUFTLEdBQUcsR0FDL0I7RUFFSixPQUFPLE9BQU87RUFDZCxTQUFTLE9BQU87Q0FDcEI7QUFDSjs7Ozs7QUFNQSxJQUFNLHlCQUFBLGFBQStCLGNBQWMsSUFBSTtBQUN2RCx1QkFBdUIsY0FBYzs7OztBQUlyQyxJQUFNLDhCQUFBLGFBQW9DLFdBQVcsc0JBQXNCO0FBRTNFLElBQUkscUJBQXFCLFdBQVcsU0FBUyxxQkFBcUIsU0FBUyxTQUFTO0NBQ2hGLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLEtBQUssTUFBTSxPQUFPLFdBQ2QsT0FBTyxlQUFlLFFBQVEsS0FBSyxFQUMvQixXQUFXO0VBQ1AsTUFBTSxPQUFPO0VBQ2IsSUFBSSxRQUFRLGdCQUFnQixVQUFVLGdCQUFnQixLQUNsRCxRQUFRLGdCQUFnQixRQUFRLENBQUMsVUFBVSxnQkFBZ0I7RUFFL0Qsd0JBQXdCLG9CQUFvQixRQUFRO0VBQ3BELE9BQU8sVUFBVTtDQUNyQixFQUNKLENBQUM7Q0FFTCxPQUFPO0FBQ1g7QUFFQSxJQUFNLDRCQUE0QixRQUFBLGFBQ3RCLGtCQUFBLGFBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFnQ1osU0FBUyxhQUFhLE9BQU87Q0FDekIsTUFBTSxjQUFjLHNCQUFzQjtDQUMxQyxNQUFNLEVBQUUsVUFBVSxhQUFhLFVBQVUsTUFBTSxVQUFVLFNBQVMsQ0FBQztDQUNuRSxNQUFNLENBQUMsV0FBVyxtQkFBQSxhQUF5QixnQkFBZ0I7RUFDdkQsR0FBRyxRQUFRO0VBQ1gsZUFBZSxRQUFRO0NBQzNCLEVBQUU7Q0FDRixNQUFNLHVCQUFBLGFBQTZCLE9BQU87RUFDdEMsU0FBUztFQUNULFdBQVc7RUFDWCxhQUFhO0VBQ2IsZUFBZTtFQUNmLGtCQUFrQjtFQUNsQixjQUFjO0VBQ2QsU0FBUztFQUNULFFBQVE7Q0FDWixDQUFDO0NBQ0QsZ0NBQWdDLFFBQVEsV0FBVztFQUMvQztFQUNBLFdBQVcscUJBQXFCO0VBQ2hDO0VBQ0EsV0FBVyxjQUFjO0dBQ3JCLENBQUMsWUFDRyxnQkFBZ0I7SUFDWixHQUFHLFFBQVE7SUFDWCxHQUFHO0lBQ0gsZUFBZSxRQUFRO0dBQzNCLENBQUM7RUFDVDtDQUNKLENBQUMsR0FBRztFQUFDO0VBQU07RUFBVTtDQUFLLENBQUM7Q0FDM0IsYUFBTSxnQkFBZ0I7RUFDbEIscUJBQXFCLFFBQVEsV0FBVyxRQUFRLFVBQVUsSUFBSTtDQUNsRSxHQUFHLENBQUMsT0FBTyxDQUFDO0NBQ1osT0FBQSxhQUFhLGNBQWMsa0JBQWtCLFdBQVcsU0FBUyxxQkFBcUIsU0FBUyxLQUFLLEdBQUcsQ0FBQyxXQUFXLE9BQU8sQ0FBQztBQUMvSDtBQUVBLElBQUksWUFBWSxVQUFVLE9BQU8sVUFBVTtBQUUzQyxJQUFJLHVCQUF1QixPQUFPLFFBQVEsWUFBWSxVQUFVLGlCQUFpQjtDQUM3RSxJQUFJLFNBQVMsS0FBSyxHQUFHO0VBQ2pCLFlBQVksT0FBTyxNQUFNLElBQUksS0FBSztFQUNsQyxPQUFPLElBQUksWUFBWSxPQUFPLFlBQVk7Q0FDOUM7Q0FDQSxJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQ25CLE9BQU8sTUFBTSxLQUFLLGVBQWUsWUFBWSxPQUFPLE1BQU0sSUFBSSxTQUFTLEdBQ25FLElBQUksWUFBWSxTQUFTLEVBQUU7Q0FFbkMsYUFBYSxPQUFPLFdBQVc7Q0FDL0IsT0FBTztBQUNYO0FBRUEsSUFBSSxlQUFlLFVBQVUsa0JBQWtCLEtBQUssS0FBSyxDQUFDLGFBQWEsS0FBSztBQUU1RSxJQUFNLG9DQUFvQyxRQUFRLFNBQVMsS0FBSyxXQUFXLEtBQUssQ0FBQyxNQUFNLFFBQVEsTUFBTSxLQUFLLENBQUMsY0FBYyxNQUFNO0FBQy9ILFNBQVMsVUFBVSxTQUFTLFNBQVMsMEJBQVUsSUFBSSxRQUFRLEdBQUc7Q0FDMUQsSUFBSSxZQUFZLFNBQ1osT0FBTztDQUVYLElBQUksWUFBWSxPQUFPLEtBQUssWUFBWSxPQUFPLEdBQzNDLE9BQU8sT0FBTyxHQUFHLFNBQVMsT0FBTztDQUVyQyxJQUFJLGFBQWEsT0FBTyxLQUFLLGFBQWEsT0FBTyxHQUM3QyxPQUFPLE9BQU8sR0FBRyxRQUFRLFFBQVEsR0FBRyxRQUFRLFFBQVEsQ0FBQztDQUV6RCxNQUFNLFFBQVEsT0FBTyxLQUFLLE9BQU87Q0FDakMsTUFBTSxRQUFRLE9BQU8sS0FBSyxPQUFPO0NBQ2pDLElBQUksTUFBTSxXQUFXLE1BQU0sUUFDdkIsT0FBTztDQUVYLElBQUksaUNBQWlDLFNBQVMsS0FBSyxLQUMvQyxpQ0FBaUMsU0FBUyxLQUFLLEdBQy9DLE9BQU8sT0FBTyxHQUFHLFNBQVMsT0FBTztDQUVyQyxJQUFJLENBQUMsTUFBTSxVQUFVLE1BQU0sUUFBUSxPQUFPLE1BQU0sTUFBTSxRQUFRLE9BQU8sR0FDakUsT0FBTztDQUVYLE1BQU0sZUFBZSxRQUFRLElBQUksT0FBTztDQUN4QyxJQUFJLGdCQUFnQixhQUFhLElBQUksT0FBTyxHQUN4QyxPQUFPO0NBRVgsSUFBSSxjQUNBLGFBQWEsSUFBSSxPQUFPO01BRXZCO0VBQ0QsTUFBTSxxQkFBSyxJQUFJLFFBQVE7RUFDdkIsR0FBRyxJQUFJLE9BQU87RUFDZCxRQUFRLElBQUksU0FBUyxFQUFFO0NBQzNCO0NBQ0EsS0FBSyxNQUFNLE9BQU8sT0FBTztFQUNyQixNQUFNLE9BQU8sUUFBUTtFQUNyQixJQUFJLEVBQUUsT0FBTyxVQUNULE9BQU87RUFFWCxJQUFJLFFBQVEsT0FBTztHQUNmLE1BQU0sT0FBTyxRQUFRO0dBQ3JCLElBQUssYUFBYSxJQUFJLEtBQUssYUFBYSxJQUFJLE1BQ3RDLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUSxJQUFJLE9BQ2pDLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUSxJQUFJLEtBQ3ZDLENBQUMsVUFBVSxNQUFNLE1BQU0sT0FBTyxJQUM5QixDQUFDLE9BQU8sR0FBRyxNQUFNLElBQUksR0FDdkIsT0FBTztFQUVmO0NBQ0o7Q0FDQSxPQUFPO0FBQ1g7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBa0JBLFNBQVMsU0FBUyxPQUFPO0NBQ3JCLE1BQU0sY0FBYyxzQkFBc0I7Q0FDMUMsTUFBTSxFQUFFLFVBQVUsYUFBYSxNQUFNLGNBQWMsVUFBVSxPQUFPLFlBQWEsU0FBUyxDQUFDO0NBQzNGLE1BQU0sZ0JBQUEsYUFBc0IsT0FBTyxZQUFZO0NBQy9DLE1BQU0sV0FBQSxhQUFpQixPQUFPLE9BQU87Q0FDckMsTUFBTSxxQkFBQSxhQUEyQixPQUFPLEtBQUEsQ0FBUztDQUNqRCxNQUFNLGVBQUEsYUFBcUIsT0FBTyxPQUFPO0NBQ3pDLE1BQU0sWUFBQSxhQUFrQixPQUFPLElBQUk7Q0FDbkMsU0FBUyxVQUFVO0NBQ25CLE1BQU0sQ0FBQyxPQUFPLGVBQUEsYUFBcUIsZUFBZTtFQUM5QyxNQUFNLGVBQWUsUUFBUSxVQUFVLE1BQU0sY0FBYyxPQUFPO0VBQ2xFLE9BQU8sU0FBUyxVQUFVLFNBQVMsUUFBUSxZQUFZLElBQUk7Q0FDL0QsQ0FBQztDQUNELE1BQU0sbUJBQUEsYUFBeUIsYUFBYSxXQUFXO0VBQ25ELE1BQU0sYUFBYSxvQkFBb0IsTUFBTSxRQUFRLFFBQVEsVUFBVSxRQUFRLGFBQWEsT0FBTyxjQUFjLE9BQU87RUFDeEgsT0FBTyxTQUFTLFVBQVUsU0FBUyxRQUFRLFVBQVUsSUFBSTtDQUM3RCxHQUFHO0VBQUMsUUFBUTtFQUFhLFFBQVE7RUFBUTtDQUFJLENBQUM7Q0FDOUMsTUFBTSxlQUFBLGFBQXFCLGFBQWEsV0FBVztFQUMvQyxJQUFJLENBQUMsVUFBVTtHQUNYLE1BQU0sYUFBYSxvQkFBb0IsTUFBTSxRQUFRLFFBQVEsVUFBVSxRQUFRLGFBQWEsT0FBTyxjQUFjLE9BQU87R0FDeEgsSUFBSSxTQUFTLFNBQVM7SUFDbEIsTUFBTSxxQkFBcUIsU0FBUyxRQUFRLFVBQVU7SUFDdEQsSUFBSSxDQUFDLFVBQVUsb0JBQW9CLG1CQUFtQixPQUFPLEdBQUc7S0FDNUQsWUFBWSxrQkFBa0I7S0FDOUIsbUJBQW1CLFVBQVU7SUFDakM7R0FDSixPQUVJLFlBQVksVUFBVTtFQUU5QjtDQUNKLEdBQUc7RUFBQyxRQUFRO0VBQWEsUUFBUTtFQUFRO0VBQVU7Q0FBSSxDQUFDO0NBQ3hELGdDQUFnQztFQUM1QixJQUFJLGFBQWEsWUFBWSxXQUN6QixDQUFDLFVBQVUsVUFBVSxTQUFTLElBQUksR0FBRztHQUNyQyxhQUFhLFVBQVU7R0FDdkIsVUFBVSxVQUFVO0dBQ3BCLGFBQWE7RUFDakI7RUFDQSxPQUFPLFFBQVEsV0FBVztHQUN0QjtHQUNBLFdBQVcsRUFDUCxRQUFRLEtBQ1o7R0FDQTtHQUNBLFdBQVcsY0FBYztJQUNyQixhQUFhLFVBQVUsTUFBTTtHQUNqQztFQUNKLENBQUM7Q0FDTCxHQUFHO0VBQUM7RUFBUztFQUFPO0VBQU07Q0FBWSxDQUFDO0NBQ3ZDLGFBQU0sZ0JBQWdCLFFBQVEsaUJBQWlCLENBQUM7Q0FLaEQsTUFBTSxpQkFBaUIsYUFBYSxZQUFZO0NBQ2hELE1BQU0sV0FBVyxVQUFVO0NBRzNCLE1BQU0saUJBQUEsYUFBdUIsY0FBYztFQUN2QyxJQUFJLFVBQ0EsT0FBTztFQUVYLE1BQU0sY0FBYyxDQUFDLGtCQUFrQixDQUFDLFVBQVUsVUFBVSxJQUFJO0VBRWhFLE9BRDhCLGtCQUFrQixjQUNqQixpQkFBaUIsSUFBSTtDQUN4RCxHQUFHO0VBQUM7RUFBVTtFQUFnQjtFQUFNO0VBQVU7Q0FBZ0IsQ0FBQztDQUMvRCxPQUFPLG1CQUFtQixPQUFPLGlCQUFpQjtBQUN0RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQTBCQSxTQUFTLGNBQWMsT0FBTztDQUMxQixNQUFNLGNBQWMsc0JBQXNCO0NBQzFDLE1BQU0sRUFBRSxNQUFNLFVBQVUsVUFBVSxhQUFhLGtCQUFrQixjQUFjLFFBQVEsU0FBVTtDQUNqRyxNQUFNLGVBQWUsbUJBQW1CLFFBQVEsT0FBTyxPQUFPLElBQUk7Q0FFbEUsTUFBTSxRQUFRLFNBQVM7RUFDbkI7RUFDQTtFQUNBLGNBQUEsYUFKMkIsY0FBYyxJQUFJLFFBQVEsYUFBYSxNQUFNLElBQUksUUFBUSxnQkFBZ0IsTUFBTSxZQUFZLENBQUMsR0FBRztHQUFDO0dBQVM7R0FBTTtFQUFZLENBSXpIO0VBQzdCO0NBQ0osQ0FBQztDQUNELE1BQU0sWUFBWSxhQUFhO0VBQzNCO0VBQ0E7RUFDQTtDQUNKLENBQUM7Q0FDRCxNQUFNLFNBQUEsYUFBZSxPQUFPLEtBQUs7Q0FDakMsTUFBTSxZQUFBLGFBQWtCLE9BQU8sSUFBSTtDQUNuQyxNQUFNLGlCQUFBLGFBQXVCLE9BQU8sUUFBUSxTQUFTLE1BQU07RUFDdkQsR0FBRyxNQUFNO0VBQ1Q7RUFDQSxHQUFJLFVBQVUsTUFBTSxRQUFRLElBQUksRUFBRSxVQUFVLE1BQU0sU0FBUyxJQUFJLENBQUM7Q0FDcEUsQ0FBQyxDQUFDO0NBQ0YsT0FBTyxVQUFVO0NBQ2pCLE1BQU0sYUFBQSxhQUFtQixjQUFjLE9BQU8saUJBQWlCLENBQUMsR0FBRztFQUMvRCxTQUFTO0dBQ0wsWUFBWTtHQUNaLFdBQVcsQ0FBQyxDQUFDLElBQUksVUFBVSxRQUFRLElBQUk7RUFDM0M7RUFDQSxTQUFTO0dBQ0wsWUFBWTtHQUNaLFdBQVcsQ0FBQyxDQUFDLElBQUksVUFBVSxhQUFhLElBQUk7RUFDaEQ7RUFDQSxXQUFXO0dBQ1AsWUFBWTtHQUNaLFdBQVcsQ0FBQyxDQUFDLElBQUksVUFBVSxlQUFlLElBQUk7RUFDbEQ7RUFDQSxjQUFjO0dBQ1YsWUFBWTtHQUNaLFdBQVcsQ0FBQyxDQUFDLElBQUksVUFBVSxrQkFBa0IsSUFBSTtFQUNyRDtFQUNBLE9BQU87R0FDSCxZQUFZO0dBQ1osV0FBVyxJQUFJLFVBQVUsUUFBUSxJQUFJO0VBQ3pDO0NBQ0osQ0FBQyxHQUFHLENBQUMsV0FBVyxJQUFJLENBQUM7Q0FDckIsTUFBTSxXQUFBLGFBQWlCLGFBQWEsVUFBVTtFQUMxQyxNQUFNLFFBQVEsY0FBYyxLQUFLO0VBQ2pDLElBQUksQ0FBQyxJQUFJLFFBQVEsU0FBUyxJQUFJLEdBQzFCLGVBQWUsVUFBVSxRQUFRLFNBQVMsTUFBTTtHQUM1QyxHQUFHLE9BQU8sUUFBUTtHQUNsQjtFQUNKLENBQUM7RUFFTCxPQUFPLGVBQWUsUUFBUSxTQUFTO0dBQ25DLFFBQVE7SUFDSixPQUFPLGNBQWMsS0FBSztJQUNwQjtHQUNWO0dBQ0EsTUFBTSxPQUFPO0VBQ2pCLENBQUM7Q0FDTCxHQUFHLENBQUMsTUFBTSxPQUFPLENBQUM7Q0FDbEIsTUFBTSxTQUFBLGFBQWUsa0JBQWtCLGVBQWUsUUFBUSxPQUFPO0VBQ2pFLFFBQVE7R0FDSixPQUFPLElBQUksUUFBUSxhQUFhLElBQUk7R0FDOUI7RUFDVjtFQUNBLE1BQU0sT0FBTztDQUNqQixDQUFDLEdBQUcsQ0FBQyxNQUFNLFFBQVEsV0FBVyxDQUFDO0NBQy9CLE1BQU0sTUFBQSxhQUFZLGFBQWEsUUFBUTtFQUNuQyxJQUFJLEtBQ0EsVUFBVSxVQUFVO0dBQ2hCLGFBQWEsV0FBVyxJQUFJLEtBQUssS0FBSyxJQUFJLE1BQU07R0FDaEQsY0FBYyxXQUFXLElBQUksTUFBTSxLQUFLLElBQUksT0FBTztHQUNuRCxvQkFBb0IsWUFBWSxXQUFXLElBQUksaUJBQWlCLEtBQUssSUFBSSxrQkFBa0IsT0FBTztHQUNsRyxzQkFBc0IsV0FBVyxJQUFJLGNBQWMsS0FBSyxJQUFJLGVBQWU7RUFDL0U7RUFFSixNQUFNLFFBQVEsSUFBSSxRQUFRLFNBQVMsSUFBSTtFQUN2QyxJQUFJLFNBQVMsTUFBTSxNQUFNLEtBQ3JCLE1BQU0sR0FBRyxNQUFNLFVBQVU7Q0FFakMsR0FBRyxDQUFDLFFBQVEsU0FBUyxJQUFJLENBQUM7Q0FDMUIsTUFBTSxRQUFBLGFBQWMsZUFBZTtFQUMvQjtFQUNBO0VBQ0EsR0FBSSxVQUFVLFFBQVEsS0FBSyxVQUFVLFdBQy9CLEVBQUUsVUFBVSxVQUFVLFlBQVksU0FBUyxJQUMzQyxDQUFDO0VBQ1A7RUFDQTtFQUNBO0NBQ0osSUFBSTtFQUFDO0VBQU07RUFBVSxVQUFVO0VBQVU7RUFBVTtFQUFRO0VBQUs7Q0FBSyxDQUFDO0NBQ3RFLGFBQU0sZ0JBQWdCO0VBQ2xCLE1BQU0seUJBQXlCLFFBQVEsU0FBUyxvQkFBb0I7RUFDcEUsUUFBUSxTQUFTLE1BQU07R0FDbkIsR0FBRyxPQUFPLFFBQVE7R0FDbEIsR0FBSSxVQUFVLE9BQU8sUUFBUSxRQUFRLElBQy9CLEVBQUUsVUFBVSxPQUFPLFFBQVEsU0FBUyxJQUNwQyxDQUFDO0VBQ1gsQ0FBQztFQUNELE1BQU0saUJBQWlCLE1BQU0sVUFBVTtHQUNuQyxNQUFNLFFBQVEsSUFBSSxRQUFRLFNBQVMsSUFBSTtHQUN2QyxJQUFJLFNBQVMsTUFBTSxJQUNmLE1BQU0sR0FBRyxRQUFRO0VBRXpCO0VBQ0EsY0FBYyxNQUFNLElBQUk7RUFDeEIsSUFBSSx3QkFBd0I7R0FDeEIsTUFBTSxRQUFRLFlBQVksSUFBSSxtQkFDeEIsUUFBUSxpQkFDUixRQUFRLFNBQVMsVUFBVSxRQUFRLGdCQUFnQixNQUFNLElBQUksUUFBUSxTQUFTLGVBQWUsTUFBTSxPQUFPLFFBQVEsWUFBWSxDQUFDLENBQUM7R0FDdEksSUFBSSxRQUFRLGdCQUFnQixNQUFNLEtBQUs7R0FDdkMsSUFBSSxZQUFZLElBQUksUUFBUSxhQUFhLElBQUksQ0FBQyxHQUMxQyxJQUFJLFFBQVEsYUFBYSxNQUFNLEtBQUs7RUFFNUM7RUFDQSxDQUFDLGdCQUFnQixRQUFRLFNBQVMsSUFBSTtFQUN0QyxJQUFJLFVBQVUsU0FBUztHQUNuQixNQUFNLFFBQVEsSUFBSSxRQUFRLFNBQVMsSUFBSTtHQUN2QyxJQUFJLFNBQVMsTUFBTSxJQUNmLE1BQU0sR0FBRyxNQUFNLFVBQVU7RUFFakM7RUFDQSxhQUFhO0dBQ1QsQ0FBQyxlQUNLLDBCQUEwQixDQUFDLFFBQVEsT0FBTyxTQUMxQywwQkFDQSxRQUFRLFdBQVcsSUFBSSxJQUN2QixjQUFjLE1BQU0sS0FBSztFQUNuQztDQUNKLEdBQUc7RUFBQztFQUFNO0VBQVM7RUFBYztDQUFnQixDQUFDO0NBQ2xELGFBQU0sZ0JBQWdCO0VBQ2xCLFFBQVEsa0JBQWtCO0dBQ3RCO0dBQ0E7RUFDSixDQUFDO0NBQ0wsR0FBRztFQUFDO0VBQVU7RUFBTTtDQUFPLENBQUM7Q0FDNUIsT0FBQSxhQUFhLGVBQWU7RUFDeEI7RUFDQTtFQUNBO0NBQ0osSUFBSTtFQUFDO0VBQU87RUFBVztDQUFVLENBQUM7QUFDdEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE0Q0EsSUFBTSxjQUFjLFVBQVUsTUFBTSxPQUFPLGNBQWMsS0FBSyxDQUFDO0FBRS9ELElBQUksbUJBQW1CO0NBQ25CLElBQUksT0FBTyxXQUFXLGVBQWUsT0FBTyxZQUN4QyxPQUFPLE9BQU8sV0FBVztDQUU3QixNQUFNLElBQUksT0FBTyxnQkFBZ0IsY0FBYyxLQUFLLElBQUksSUFBSSxZQUFZLElBQUksSUFBSTtDQUNoRixPQUFPLHVDQUF1QyxRQUFRLFVBQVUsTUFBTTtFQUNsRSxNQUFNLEtBQU0sS0FBSyxPQUFPLElBQUksS0FBSyxLQUFLLEtBQU07RUFDNUMsUUFBUSxLQUFLLE1BQU0sSUFBSyxJQUFJLElBQU8sRUFBQSxDQUFLLFNBQVMsRUFBRTtDQUN2RCxDQUFDO0FBQ0w7QUFFQSxJQUFJLHFCQUFxQixNQUFNLE9BQU8sVUFBVSxDQUFDLE1BQU0sUUFBUSxlQUFlLFlBQVksUUFBUSxXQUFXLElBQ3ZHLFFBQVEsYUFDTixHQUFHLEtBQUssR0FBRyxZQUFZLFFBQVEsVUFBVSxJQUFJLFFBQVEsUUFBUSxXQUFXLEtBQzFFO0FBRU4sSUFBSSxzQkFBc0IsVUFBVTtDQUNoQyxZQUFZLENBQUMsUUFBUSxTQUFTLGdCQUFnQjtDQUM5QyxVQUFVLFNBQVMsZ0JBQWdCO0NBQ25DLFlBQVksU0FBUyxnQkFBZ0I7Q0FDckMsU0FBUyxTQUFTLGdCQUFnQjtDQUNsQyxXQUFXLFNBQVMsZ0JBQWdCO0FBQ3hDO0FBRUEsSUFBSSxhQUFhLE1BQU0sUUFBUSxnQkFBZ0I7Q0FDM0MsSUFBSSxhQUNBLE9BQU87Q0FDWCxJQUFJLE9BQU8sWUFBWSxPQUFPLE1BQU0sSUFBSSxJQUFJLEdBQ3hDLE9BQU87Q0FDWCxLQUFLLE1BQU0sYUFBYSxPQUFPLE9BQzNCLElBQUksS0FBSyxXQUFXLFNBQVMsS0FBSyxLQUFLLE9BQU8sVUFBVSxNQUFNLE1BQU0sS0FDaEUsT0FBTztDQUVmLE9BQU87QUFDWDtBQUVBLElBQU0seUJBQXlCLFFBQVEsUUFBUSxhQUFhLGVBQWU7Q0FDdkUsS0FBSyxNQUFNLE9BQU8sZUFBZSxPQUFPLEtBQUssTUFBTSxHQUFHO0VBQ2xELE1BQU0sUUFBUSxJQUFJLFFBQVEsR0FBRztFQUM3QixJQUFJLE9BQU87R0FDUCxNQUFNLEVBQUUsSUFBSSxHQUFHLGlCQUFpQjtHQUNoQyxJQUFJO1FBQ0ksR0FBRyxRQUFRLEdBQUcsS0FBSyxNQUFNLE9BQU8sR0FBRyxLQUFLLElBQUksR0FBRyxLQUFLLENBQUMsWUFDckQsT0FBTztTQUVOLElBQUksR0FBRyxPQUFPLE9BQU8sR0FBRyxLQUFLLEdBQUcsSUFBSSxLQUFLLENBQUMsWUFDM0MsT0FBTztTQUdQLElBQUksc0JBQXNCLGNBQWMsTUFBTSxHQUMxQztHQUFBLE9BSVAsSUFBSSxTQUFTLFlBQVk7UUFDdEIsc0JBQXNCLGNBQWMsTUFBTSxHQUMxQztHQUFBO0VBR1o7Q0FDSjtBQUVKO0FBRUEsSUFBSSw2QkFBNkIsUUFBUSxPQUFPLFNBQVM7Q0FDckQsTUFBTSxpQkFBaUIsSUFBSSxRQUFRLElBQUk7Q0FDdkMsTUFBTSxtQkFBbUIsTUFBTSxRQUFRLGNBQWMsSUFBSSxpQkFBaUIsQ0FBQztDQUMzRSxJQUFJLGtCQUFrQixpQkFBaUIsTUFBTSxLQUFLO0NBQ2xELElBQUksUUFBUSxNQUFNLGdCQUFnQjtDQUNsQyxPQUFPO0FBQ1g7QUFFQSxJQUFJLGlCQUFpQixVQUFVLFNBQVMsS0FBSyxLQUFLLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDO0FBRXRFLElBQUksZUFBZSxZQUFZLFFBQVEsU0FBUztBQUVoRCxJQUFJLGlCQUFpQixVQUFVO0NBQzNCLElBQUksQ0FBQyxPQUNELE9BQU87Q0FFWCxNQUFNLFFBQVEsUUFBUSxNQUFNLGdCQUFnQjtDQUM1QyxPQUFRLGtCQUNILFNBQVMsTUFBTSxjQUFjLE1BQU0sWUFBWSxjQUFjO0FBQ3RFO0FBRUEsSUFBSSxnQkFBZ0IsWUFBWSxRQUFRLFNBQVM7QUFFakQsSUFBSSxXQUFXLFVBQVUsaUJBQWlCO0FBRTFDLElBQUksZ0JBQWdCLE1BQU0sMEJBQTBCLFFBQVEsTUFBTSxZQUFZLDJCQUN4RTtDQUNFLEdBQUcsT0FBTztDQUNWLE9BQU87RUFDSCxHQUFJLE9BQU8sU0FBUyxPQUFPLEtBQUssQ0FBQyxRQUFRLE9BQU8sS0FBSyxDQUFDLFFBQVEsQ0FBQztHQUM5RCxPQUFPLFdBQVc7Q0FDdkI7QUFDSixJQUNFLENBQUM7QUFFUCxJQUFNLGdCQUFnQjtDQUNsQixPQUFPO0NBQ1AsU0FBUztBQUNiO0FBQ0EsSUFBTSxjQUFjO0NBQUUsT0FBTztDQUFNLFNBQVM7QUFBSztBQUNqRCxJQUFJLG9CQUFvQixZQUFZO0NBQ2hDLElBQUksTUFBTSxRQUFRLE9BQU8sR0FBRztFQUN4QixJQUFJLFFBQVEsU0FBUyxHQUFHO0dBQ3BCLE1BQU0sU0FBUyxRQUNWLFFBQVEsV0FBVyxVQUFVLE9BQU8sV0FBVyxDQUFDLE9BQU8sUUFBUSxDQUFDLENBQ2hFLEtBQUssV0FBVyxPQUFPLEtBQUs7R0FDakMsT0FBTztJQUFFLE9BQU87SUFBUSxTQUFTLENBQUMsQ0FBQyxPQUFPO0dBQU87RUFDckQ7RUFDQSxPQUFPLFFBQVEsRUFBRSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxXQUVqQyxRQUFRLEVBQUUsQ0FBQyxjQUFjLENBQUMsWUFBWSxRQUFRLEVBQUUsQ0FBQyxXQUFXLEtBQUssSUFDM0QsWUFBWSxRQUFRLEVBQUUsQ0FBQyxLQUFLLEtBQUssUUFBUSxFQUFFLENBQUMsVUFBVSxLQUNsRCxjQUNBO0dBQUUsT0FBTyxRQUFRLEVBQUUsQ0FBQztHQUFPLFNBQVM7RUFBSyxJQUM3QyxjQUNSO0NBQ1Y7Q0FDQSxPQUFPO0FBQ1g7QUFFQSxJQUFNLGdCQUFnQjtDQUNsQixTQUFTO0NBQ1QsT0FBTztBQUNYO0FBQ0EsSUFBSSxpQkFBaUIsWUFBWSxNQUFNLFFBQVEsT0FBTyxJQUNoRCxRQUFRLFFBQVEsVUFBVSxXQUFXLFVBQVUsT0FBTyxXQUFXLENBQUMsT0FBTyxXQUNyRTtDQUNFLFNBQVM7Q0FDVCxPQUFPLE9BQU87QUFDbEIsSUFDRSxVQUFVLGFBQWEsSUFDM0I7QUFFTixTQUFTLGlCQUFpQixRQUFRLEtBQUssT0FBTyxZQUFZO0NBQ3RELElBQUksU0FBUyxNQUFNLEtBQ2QsTUFBTSxRQUFRLE1BQU0sS0FBSyxPQUFPLE1BQU0sUUFBUSxLQUM5QyxVQUFVLE1BQU0sS0FBSyxDQUFDLFFBQ3ZCLE9BQU87RUFDSDtFQUNBLFNBQVMsU0FBUyxNQUFNLElBQUksU0FBUztFQUNyQztDQUNKO0FBRVI7QUFFQSxJQUFJLHNCQUFzQixtQkFBbUIsU0FBUyxjQUFjLEtBQUssQ0FBQyxRQUFRLGNBQWMsSUFDMUYsaUJBQ0E7Q0FDRSxPQUFPO0NBQ1AsU0FBUztBQUNiO0FBRUosSUFBSSxnQkFBZ0IsT0FBTyxPQUFPLG9CQUFvQixZQUFZLDBCQUEwQiwyQkFBMkIsaUJBQWlCO0NBQ3BJLE1BQU0sRUFBRSxLQUFLLE1BQU0sVUFBVSxXQUFXLFdBQVcsS0FBSyxLQUFLLFNBQVMsVUFBVSxNQUFNLGVBQWUsVUFBVyxNQUFNO0NBQ3RILE1BQU0sYUFBYSxJQUFJLFlBQVksSUFBSTtDQUN2QyxJQUFJLENBQUMsU0FBUyxtQkFBbUIsSUFBSSxJQUFJLEdBQ3JDLE9BQU8sQ0FBQztDQUVaLE1BQU0sV0FBVyxPQUFPLEtBQUssS0FBSztDQUNsQyxNQUFNLHFCQUFxQixZQUFZO0VBQ25DLElBQUksNkJBQTZCLFNBQVMsZ0JBQWdCO0dBQ3RELE1BQU0sa0JBQWtCLFVBQVUsT0FBTyxJQUFJLEtBQUssV0FBVztHQUM3RCxJQUFJLE1BQ0EsS0FBSyxTQUFTLFFBQVEsSUFBSSxrQkFBa0IsZUFBZSxDQUFDO1FBRzVELFNBQVMsa0JBQWtCLGVBQWU7R0FFOUMsU0FBUyxlQUFlO0VBQzVCO0NBQ0o7Q0FDQSxNQUFNLFFBQVEsQ0FBQztDQUNmLE1BQU0sVUFBVSxhQUFhLEdBQUc7Q0FDaEMsTUFBTSxhQUFhLGdCQUFnQixHQUFHO0NBQ3RDLE1BQU0sb0JBQW9CLFdBQVc7Q0FDckMsTUFBTSxXQUFZLGlCQUFpQixZQUFZLEdBQUcsTUFDOUMsWUFBWSxJQUFJLEtBQUssS0FDckIsWUFBWSxVQUFVLEtBQ3JCLGNBQWMsR0FBRyxLQUFLLElBQUksVUFBVSxNQUNyQyxlQUFlLE1BQ2QsTUFBTSxRQUFRLFVBQVUsS0FBSyxDQUFDLFdBQVc7Q0FDOUMsTUFBTSxvQkFBb0IsYUFBYSxLQUFLLE1BQU0sTUFBTSwwQkFBMEIsS0FBSztDQUN2RixNQUFNLG9CQUFvQixXQUFXLGtCQUFrQixrQkFBa0IsVUFBVSx1QkFBdUIsV0FBVyxVQUFVLHVCQUF1QixjQUFjO0VBQ2hLLE1BQU0sVUFBVSxZQUFZLG1CQUFtQjtFQUMvQyxNQUFNLFFBQVE7R0FDVixNQUFNLFlBQVksVUFBVTtHQUM1QjtHQUNBO0dBQ0EsR0FBRyxrQkFBa0IsWUFBWSxVQUFVLFNBQVMsT0FBTztFQUMvRDtDQUNKO0NBQ0EsSUFBSSxlQUNFLENBQUMsTUFBTSxRQUFRLFVBQVUsS0FBSyxDQUFDLFdBQVcsU0FDMUMsYUFDSSxDQUFDLHNCQUFzQixXQUFXLGtCQUFrQixVQUFVLE1BQzNELFVBQVUsVUFBVSxLQUFLLENBQUMsY0FDMUIsY0FBYyxDQUFDLGlCQUFpQixJQUFJLENBQUMsQ0FBQyxXQUN0QyxXQUFXLENBQUMsY0FBYyxJQUFJLENBQUMsQ0FBQyxVQUFXO0VBQ3BELE1BQU0sRUFBRSxPQUFPLFlBQVksU0FBUyxRQUFRLElBQ3RDO0dBQUUsT0FBTyxDQUFDLENBQUM7R0FBVSxTQUFTO0VBQVMsSUFDdkMsbUJBQW1CLFFBQVE7RUFDakMsSUFBSSxPQUFPO0dBQ1AsTUFBTSxRQUFRO0lBQ1YsTUFBTSx1QkFBdUI7SUFDN0I7SUFDQSxLQUFLO0lBQ0wsR0FBRyxrQkFBa0IsdUJBQXVCLFVBQVUsT0FBTztHQUNqRTtHQUNBLElBQUksQ0FBQywwQkFBMEI7SUFDM0Isa0JBQWtCLE9BQU87SUFDekIsT0FBTztHQUNYO0VBQ0o7Q0FDSjtDQUNBLElBQUksQ0FBQyxZQUFZLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDLGtCQUFrQixHQUFHLElBQUk7RUFDbEUsSUFBSTtFQUNKLElBQUk7RUFDSixNQUFNLFlBQVksbUJBQW1CLEdBQUc7RUFDeEMsTUFBTSxZQUFZLG1CQUFtQixHQUFHO0VBQ3hDLElBQUksQ0FBQyxrQkFBa0IsVUFBVSxLQUFLLENBQUMsTUFBTSxVQUFVLEdBQUc7R0FDdEQsTUFBTSxjQUFjLElBQUksa0JBQ25CLGFBQWEsQ0FBQyxhQUFhO0dBQ2hDLElBQUksQ0FBQyxrQkFBa0IsVUFBVSxLQUFLLEdBQ2xDLFlBQVksY0FBYyxVQUFVO0dBRXhDLElBQUksQ0FBQyxrQkFBa0IsVUFBVSxLQUFLLEdBQ2xDLFlBQVksY0FBYyxVQUFVO0VBRTVDLE9BQ0s7R0FDRCxNQUFNLFlBQVksSUFBSSxlQUFlLElBQUksS0FBSyxVQUFVO0dBQ3hELE1BQU0scUJBQXFCLHlCQUFTLElBQUksc0JBQUssSUFBSSxLQUFLLEVBQUEsQ0FBRSxhQUFhLElBQUksTUFBTSxJQUFJO0dBQ25GLE1BQU0sU0FBUyxJQUFJLFFBQVE7R0FDM0IsTUFBTSxTQUFTLElBQUksUUFBUTtHQUMzQixJQUFJLFNBQVMsVUFBVSxLQUFLLEtBQUssWUFDN0IsWUFBWSxTQUNOLGtCQUFrQixVQUFVLElBQUksa0JBQWtCLFVBQVUsS0FBSyxJQUNqRSxTQUNJLGFBQWEsVUFBVSxRQUN2QixZQUFZLElBQUksS0FBSyxVQUFVLEtBQUs7R0FFbEQsSUFBSSxTQUFTLFVBQVUsS0FBSyxLQUFLLFlBQzdCLFlBQVksU0FDTixrQkFBa0IsVUFBVSxJQUFJLGtCQUFrQixVQUFVLEtBQUssSUFDakUsU0FDSSxhQUFhLFVBQVUsUUFDdkIsWUFBWSxJQUFJLEtBQUssVUFBVSxLQUFLO0VBRXREO0VBQ0EsSUFBSSxhQUFhLFdBQVc7R0FDeEIsaUJBQWlCLENBQUMsQ0FBQyxXQUFXLFVBQVUsU0FBUyxVQUFVLFNBQVMsdUJBQXVCLEtBQUssdUJBQXVCLEdBQUc7R0FDMUgsSUFBSSxDQUFDLDBCQUEwQjtJQUMzQixrQkFBa0IsTUFBTSxLQUFLLENBQUMsT0FBTztJQUNyQyxPQUFPO0dBQ1g7RUFDSjtDQUNKO0NBQ0EsS0FBSyxhQUFhLGNBQ2QsQ0FBQyxZQUNBLFNBQVMsVUFBVSxLQUFNLGdCQUFnQixNQUFNLFFBQVEsVUFBVSxJQUFLO0VBQ3ZFLE1BQU0sa0JBQWtCLG1CQUFtQixTQUFTO0VBQ3BELE1BQU0sa0JBQWtCLG1CQUFtQixTQUFTO0VBQ3BELE1BQU0sWUFBWSxDQUFDLGtCQUFrQixnQkFBZ0IsS0FBSyxLQUN0RCxXQUFXLFNBQVMsQ0FBQyxnQkFBZ0I7RUFDekMsTUFBTSxZQUFZLENBQUMsa0JBQWtCLGdCQUFnQixLQUFLLEtBQ3RELFdBQVcsU0FBUyxDQUFDLGdCQUFnQjtFQUN6QyxJQUFJLGFBQWEsV0FBVztHQUN4QixpQkFBaUIsV0FBVyxnQkFBZ0IsU0FBUyxnQkFBZ0IsT0FBTztHQUM1RSxJQUFJLENBQUMsMEJBQTBCO0lBQzNCLGtCQUFrQixNQUFNLEtBQUssQ0FBQyxPQUFPO0lBQ3JDLE9BQU87R0FDWDtFQUNKO0NBQ0o7Q0FDQSxJQUFJLFdBQVcsQ0FBQyxXQUFXLFNBQVMsVUFBVSxHQUFHO0VBQzdDLE1BQU0sRUFBRSxPQUFPLGNBQWMsWUFBWSxtQkFBbUIsT0FBTztFQUNuRSxJQUFJLFFBQVEsWUFBWSxLQUFLLENBQUMsV0FBVyxNQUFNLFlBQVksR0FBRztHQUMxRCxNQUFNLFFBQVE7SUFDVixNQUFNLHVCQUF1QjtJQUM3QjtJQUNBO0lBQ0EsR0FBRyxrQkFBa0IsdUJBQXVCLFNBQVMsT0FBTztHQUNoRTtHQUNBLElBQUksQ0FBQywwQkFBMEI7SUFDM0Isa0JBQWtCLE9BQU87SUFDekIsT0FBTztHQUNYO0VBQ0o7Q0FDSjtDQUNBLElBQUk7TUFDSSxXQUFXLFFBQVEsR0FBRztHQUV0QixNQUFNLGdCQUFnQixpQkFBaUIsTUFEbEIsU0FBUyxZQUFZLFVBQVUsR0FDTCxRQUFRO0dBQ3ZELElBQUksZUFBZTtJQUNmLE1BQU0sUUFBUTtLQUNWLEdBQUc7S0FDSCxHQUFHLGtCQUFrQix1QkFBdUIsVUFBVSxjQUFjLE9BQU87SUFDL0U7SUFDQSxJQUFJLENBQUMsMEJBQTBCO0tBQzNCLGtCQUFrQixjQUFjLE9BQU87S0FDdkMsT0FBTztJQUNYO0dBQ0o7RUFDSixPQUNLLElBQUksU0FBUyxRQUFRLEdBQUc7R0FDekIsSUFBSSxtQkFBbUIsQ0FBQztHQUN4QixLQUFLLE1BQU0sT0FBTyxVQUFVO0lBQ3hCLElBQUksQ0FBQyxjQUFjLGdCQUFnQixLQUFLLENBQUMsMEJBQ3JDO0lBRUosTUFBTSxnQkFBZ0IsaUJBQWlCLE1BQU0sU0FBUyxJQUFJLENBQUMsWUFBWSxVQUFVLEdBQUcsVUFBVSxHQUFHO0lBQ2pHLElBQUksZUFBZTtLQUNmLG1CQUFtQjtNQUNmLEdBQUc7TUFDSCxHQUFHLGtCQUFrQixLQUFLLGNBQWMsT0FBTztLQUNuRDtLQUNBLGtCQUFrQixjQUFjLE9BQU87S0FDdkMsSUFBSSwwQkFDQSxNQUFNLFFBQVE7SUFFdEI7R0FDSjtHQUNBLElBQUksQ0FBQyxjQUFjLGdCQUFnQixHQUFHO0lBQ2xDLE1BQU0sUUFBUTtLQUNWLEtBQUs7S0FDTCxHQUFHO0lBQ1A7SUFDQSxJQUFJLENBQUMsMEJBQ0QsT0FBTztHQUVmO0VBQ0o7O0NBRUosa0JBQWtCLElBQUk7Q0FDdEIsT0FBTztBQUNYO0FBRUEsSUFBSSx5QkFBeUIsVUFBVyxNQUFNLFFBQVEsS0FBSyxJQUFJLFFBQVEsQ0FBQyxLQUFLO0FBRTdFLElBQUksWUFBWSxNQUFNLFVBQVUsQ0FDNUIsR0FBRyxNQUNILEdBQUcsc0JBQXNCLEtBQUssQ0FDbEM7QUFFQSxJQUFJLGtCQUFrQixVQUFVLE1BQU0sUUFBUSxLQUFLLElBQUksTUFBTSxVQUFVLEtBQUEsQ0FBUyxJQUFJLEtBQUE7QUFFcEYsU0FBUyxPQUFPLE1BQU0sT0FBTyxPQUFPO0NBQ2hDLE9BQU87RUFDSCxHQUFHLEtBQUssTUFBTSxHQUFHLEtBQUs7RUFDdEIsR0FBRyxzQkFBc0IsS0FBSztFQUM5QixHQUFHLEtBQUssTUFBTSxLQUFLO0NBQ3ZCO0FBQ0o7QUFFQSxJQUFJLGVBQWUsTUFBTSxNQUFNLE9BQU87Q0FDbEMsSUFBSSxDQUFDLE1BQU0sUUFBUSxJQUFJLEdBQ25CLE9BQU8sQ0FBQztDQUVaLElBQUksWUFBWSxLQUFLLEdBQUcsR0FDcEIsS0FBSyxNQUFNLEtBQUE7Q0FFZixLQUFLLE9BQU8sSUFBSSxHQUFHLEtBQUssT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUU7Q0FDMUMsT0FBTztBQUNYO0FBRUEsSUFBSSxhQUFhLE1BQU0sVUFBVSxDQUM3QixHQUFHLHNCQUFzQixLQUFLLEdBQzlCLEdBQUcsc0JBQXNCLElBQUksQ0FDakM7QUFFQSxJQUFJLFdBQVcsVUFBVSxNQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sT0FBTyxPQUFPLElBQUksQ0FBQztBQUV6RSxTQUFTLGdCQUFnQixNQUFNLFNBQVM7Q0FDcEMsSUFBSSxJQUFJO0NBQ1IsTUFBTSxPQUFPLENBQUMsR0FBRyxJQUFJO0NBQ3JCLEtBQUssTUFBTSxTQUFTLFNBQVM7RUFDekIsS0FBSyxPQUFPLFFBQVEsR0FBRyxDQUFDO0VBQ3hCO0NBQ0o7Q0FDQSxPQUFPLFFBQVEsSUFBSSxDQUFDLENBQUMsU0FBUyxPQUFPLENBQUM7QUFDMUM7QUFDQSxJQUFJLGlCQUFpQixNQUFNLFVBQVUsWUFBWSxLQUFLLElBQ2hELENBQUMsSUFDRCxnQkFBZ0IsTUFBTSxzQkFBc0IsS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLENBQUM7QUFFOUUsSUFBSSxlQUFlLE1BQU0sUUFBUSxXQUFXO0NBQ3hDLENBQUMsS0FBSyxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssU0FBUyxLQUFLLE9BQU87QUFDOUQ7QUFFQSxTQUFTLFFBQVEsUUFBUSxZQUFZO0NBQ2pDLE1BQU0sU0FBUyxXQUFXLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQztDQUN2QyxJQUFJLFFBQVE7Q0FDWixPQUFPLFFBQVEsUUFBUTtFQUNuQixJQUFJLGtCQUFrQixNQUFNLEdBQUc7R0FDM0IsU0FBUyxLQUFBO0dBQ1Q7RUFDSjtFQUNBLFNBQVMsT0FBTyxXQUFXO0VBQzNCO0NBQ0o7Q0FDQSxPQUFPO0FBQ1g7QUFDQSxTQUFTLGFBQWEsS0FBSztDQUN2QixLQUFLLE1BQU0sT0FBTyxLQUNkLElBQUksSUFBSSxlQUFlLEdBQUcsS0FBSyxDQUFDLFlBQVksSUFBSSxJQUFJLEdBQ2hELE9BQU87Q0FHZixPQUFPO0FBQ1g7QUFDQSxTQUFTLE1BQU0sUUFBUSxNQUFNO0NBQ3pCLElBQUksU0FBUyxJQUFJLEtBQUssT0FBTyxVQUFVLGVBQWUsS0FBSyxRQUFRLElBQUksR0FBRztFQUN0RSxPQUFPLE9BQU87RUFDZCxPQUFPO0NBQ1g7Q0FDQSxNQUFNLFFBQVEsTUFBTSxRQUFRLElBQUksSUFDMUIsT0FDQSxNQUFNLElBQUksSUFDTixDQUFDLElBQUksSUFDTCxhQUFhLElBQUk7Q0FDM0IsSUFBSSxNQUFNLE1BQU0sWUFBWSxtQkFBbUIsU0FBUyxPQUFPLE9BQU8sQ0FBQyxDQUFDLEdBQ3BFLE9BQU87Q0FFWCxNQUFNLGNBQWMsTUFBTSxXQUFXLElBQUksU0FBUyxRQUFRLFFBQVEsS0FBSztDQUN2RSxNQUFNLFFBQVEsTUFBTSxTQUFTO0NBQzdCLE1BQU0sTUFBTSxNQUFNO0NBQ2xCLElBQUksYUFDQSxPQUFPLFlBQVk7Q0FFdkIsSUFBSSxVQUFVLE1BQ1IsU0FBUyxXQUFXLEtBQUssY0FBYyxXQUFXLEtBQy9DLE1BQU0sUUFBUSxXQUFXLEtBQUssYUFBYSxXQUFXLElBQzNELE1BQU0sUUFBUSxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7Q0FFcEMsT0FBTztBQUNYO0FBRUEsSUFBSSxZQUFZLGFBQWEsT0FBTyxVQUFVO0NBQzFDLFlBQVksU0FBUztDQUNyQixPQUFPO0FBQ1g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdUNBLFNBQVMsY0FBYyxPQUFPO0NBQzFCLE1BQU0sY0FBYyxzQkFBc0I7Q0FDMUMsTUFBTSxFQUFFLFVBQVUsYUFBYSxNQUFNLFVBQVUsTUFBTSxVQUFVLGtCQUFrQixVQUFXO0NBQzVGLE1BQU0sQ0FBQyxRQUFRLGFBQUEsYUFBbUIsU0FBUyxRQUFRLGVBQWUsSUFBSSxDQUFDO0NBQ3ZFLE1BQU0sTUFBQSxhQUFZLE9BQU8sUUFBUSxlQUFlLElBQUksQ0FBQyxDQUFDLElBQUksVUFBVSxDQUFDO0NBQ3JFLE1BQU0sWUFBQSxhQUFrQixPQUFPLEtBQUs7Q0FDcEMsSUFBSSxDQUFDLFVBQ0QsUUFBUSxPQUFPLE1BQU0sSUFBSSxJQUFJO0NBRWpDLGFBQU0sY0FBYyxDQUFDLFlBQ2pCLFNBQ0EsT0FBTyxVQUFVLEtBQ2pCLFFBQVEsU0FBUyxNQUFNLEtBQUssR0FBRztFQUFDO0VBQVM7RUFBTSxPQUFPO0VBQVE7RUFBTztDQUFRLENBQUM7Q0FDbEYsZ0NBQWdDO0VBQzVCLElBQUksVUFDQTtFQUVKLE9BQU8sUUFBUSxVQUFVLE1BQU0sVUFBVSxFQUNyQyxPQUFPLEVBQUUsUUFBUSxNQUFNLHFCQUFzQjtHQUN6QyxJQUFJLG1CQUFtQixRQUFRLENBQUMsZ0JBQWdCO0lBQzVDLE1BQU0sY0FBYyxJQUFJLFFBQVEsSUFBSTtJQUNwQyxJQUFJLE1BQU0sUUFBUSxXQUFXLEdBQUc7S0FDNUIsVUFBVSxXQUFXO0tBQ3JCLElBQUksVUFBVSxZQUFZLElBQUksVUFBVTtJQUM1QyxPQUNLLElBQUksQ0FBQyxnQkFBZ0I7S0FDdEIsVUFBVSxDQUFDLENBQUM7S0FDWixJQUFJLFVBQVUsQ0FBQztJQUNuQjtHQUNKO0VBQ0osRUFDSixDQUFDLENBQUMsQ0FBQztDQUNQLEdBQUc7RUFBQztFQUFTO0VBQU07Q0FBUSxDQUFDO0NBQzVCLE1BQU0sZUFBQSxhQUFxQixhQUFhLDRCQUE0QjtFQUNoRSxVQUFVLFVBQVU7RUFDcEIsUUFBUSxlQUFlLE1BQU0sdUJBQXVCO0NBQ3hELEdBQUcsQ0FBQyxTQUFTLElBQUksQ0FBQztDQUNsQixNQUFNLFVBQVUsT0FBTyxZQUFZO0VBQy9CLElBQUksVUFDQTtFQUVKLE1BQU0sY0FBYyxzQkFBc0IsWUFBWSxLQUFLLENBQUM7RUFDNUQsTUFBTSwwQkFBMEIsU0FBUyxRQUFRLGVBQWUsSUFBSSxHQUFHLFdBQVc7RUFDbEYsUUFBUSxPQUFPLFFBQVEsa0JBQWtCLE1BQU0sd0JBQXdCLFNBQVMsR0FBRyxPQUFPO0VBQzFGLElBQUksVUFBVSxTQUFTLElBQUksU0FBUyxZQUFZLElBQUksVUFBVSxDQUFDO0VBQy9ELGFBQWEsdUJBQXVCO0VBQ3BDLFVBQVUsdUJBQXVCO0VBQ2pDLFFBQVEsZUFBZSxNQUFNLHlCQUF5QixVQUFVLEVBQzVELE1BQU0sZUFBZSxLQUFLLEVBQzlCLENBQUM7Q0FDTDtDQUNBLE1BQU0sV0FBVyxPQUFPLFlBQVk7RUFDaEMsSUFBSSxVQUNBO0VBRUosTUFBTSxlQUFlLHNCQUFzQixZQUFZLEtBQUssQ0FBQztFQUM3RCxNQUFNLDBCQUEwQixVQUFVLFFBQVEsZUFBZSxJQUFJLEdBQUcsWUFBWTtFQUNwRixRQUFRLE9BQU8sUUFBUSxrQkFBa0IsTUFBTSxHQUFHLE9BQU87RUFDekQsSUFBSSxVQUFVLFVBQVUsSUFBSSxTQUFTLGFBQWEsSUFBSSxVQUFVLENBQUM7RUFDakUsYUFBYSx1QkFBdUI7RUFDcEMsVUFBVSx1QkFBdUI7RUFDakMsUUFBUSxlQUFlLE1BQU0seUJBQXlCLFdBQVcsRUFDN0QsTUFBTSxlQUFlLEtBQUssRUFDOUIsQ0FBQztDQUNMO0NBQ0EsTUFBTSxVQUFVLFVBQVU7RUFDdEIsSUFBSSxVQUNBO0VBRUosTUFBTSwwQkFBMEIsY0FBYyxRQUFRLGVBQWUsSUFBSSxHQUFHLEtBQUs7RUFDakYsSUFBSSxVQUFVLGNBQWMsSUFBSSxTQUFTLEtBQUs7RUFDOUMsYUFBYSx1QkFBdUI7RUFDcEMsVUFBVSx1QkFBdUI7RUFDakMsQ0FBQyxNQUFNLFFBQVEsSUFBSSxRQUFRLFNBQVMsSUFBSSxDQUFDLEtBQ3JDLElBQUksUUFBUSxTQUFTLE1BQU0sS0FBQSxDQUFTO0VBQ3hDLFFBQVEsZUFBZSxNQUFNLHlCQUF5QixlQUFlLEVBQ2pFLE1BQU0sTUFDVixDQUFDO0NBQ0w7Q0FDQSxNQUFNLFlBQVksT0FBTyxPQUFPLFlBQVk7RUFDeEMsSUFBSSxVQUNBO0VBRUosTUFBTSxjQUFjLHNCQUFzQixZQUFZLEtBQUssQ0FBQztFQUM1RCxNQUFNLDBCQUEwQixPQUFPLFFBQVEsZUFBZSxJQUFJLEdBQUcsT0FBTyxXQUFXO0VBQ3ZGLFFBQVEsT0FBTyxRQUFRLGtCQUFrQixNQUFNLE9BQU8sT0FBTztFQUM3RCxJQUFJLFVBQVUsT0FBTyxJQUFJLFNBQVMsT0FBTyxZQUFZLElBQUksVUFBVSxDQUFDO0VBQ3BFLGFBQWEsdUJBQXVCO0VBQ3BDLFVBQVUsdUJBQXVCO0VBQ2pDLFFBQVEsZUFBZSxNQUFNLHlCQUF5QixRQUFRO0dBQzFELE1BQU07R0FDTixNQUFNLGVBQWUsS0FBSztFQUM5QixDQUFDO0NBQ0w7Q0FDQSxNQUFNLFFBQVEsUUFBUSxXQUFXO0VBQzdCLElBQUksVUFDQTtFQUVKLE1BQU0sMEJBQTBCLFFBQVEsZUFBZSxJQUFJO0VBQzNELFlBQVkseUJBQXlCLFFBQVEsTUFBTTtFQUNuRCxZQUFZLElBQUksU0FBUyxRQUFRLE1BQU07RUFDdkMsYUFBYSx1QkFBdUI7RUFDcEMsVUFBVSx1QkFBdUI7RUFDakMsUUFBUSxlQUFlLE1BQU0seUJBQXlCLGFBQWE7R0FDL0QsTUFBTTtHQUNOLE1BQU07RUFDVixHQUFHLEtBQUs7Q0FDWjtDQUNBLE1BQU0sUUFBUSxNQUFNLE9BQU87RUFDdkIsSUFBSSxVQUNBO0VBRUosTUFBTSwwQkFBMEIsUUFBUSxlQUFlLElBQUk7RUFDM0QsWUFBWSx5QkFBeUIsTUFBTSxFQUFFO0VBQzdDLFlBQVksSUFBSSxTQUFTLE1BQU0sRUFBRTtFQUNqQyxhQUFhLHVCQUF1QjtFQUNwQyxVQUFVLHVCQUF1QjtFQUNqQyxRQUFRLGVBQWUsTUFBTSx5QkFBeUIsYUFBYTtHQUMvRCxNQUFNO0dBQ04sTUFBTTtFQUNWLEdBQUcsS0FBSztDQUNaO0NBQ0EsTUFBTSxVQUFVLE9BQU8sVUFBVTtFQUM3QixJQUFJLFVBQ0E7RUFFSixNQUFNLGNBQWMsWUFBWSxLQUFLO0VBQ3JDLE1BQU0sMEJBQTBCLFNBQVMsUUFBUSxlQUFlLElBQUksR0FBRyxPQUFPLFdBQVc7RUFDekYsSUFBSSxVQUFVLENBQUMsR0FBRyx1QkFBdUIsQ0FBQyxDQUFDLEtBQUssTUFBTSxNQUFNLENBQUMsUUFBUSxNQUFNLFFBQVEsV0FBVyxJQUFJLElBQUksUUFBUSxFQUFFO0VBQ2hILGFBQWEsdUJBQXVCO0VBQ3BDLFVBQVUsQ0FBQyxHQUFHLHVCQUF1QixDQUFDO0VBQ3RDLFFBQVEsZUFBZSxNQUFNLHlCQUF5QixVQUFVO0dBQzVELE1BQU07R0FDTixNQUFNO0VBQ1YsR0FBRyxNQUFNLEtBQUs7Q0FDbEI7Q0FDQSxNQUFNLFdBQVcsVUFBVTtFQUN2QixJQUFJLFVBQ0E7RUFFSixNQUFNLDBCQUEwQixzQkFBc0IsWUFBWSxLQUFLLENBQUM7RUFDeEUsSUFBSSxVQUFVLHdCQUF3QixJQUFJLFVBQVU7RUFDcEQsYUFBYSxDQUFDLEdBQUcsdUJBQXVCLENBQUM7RUFDekMsVUFBVSxDQUFDLEdBQUcsdUJBQXVCLENBQUM7RUFDdEMsUUFBUSxlQUFlLE1BQU0sQ0FBQyxHQUFHLHVCQUF1QixJQUFJLFNBQVMsTUFBTSxDQUFDLEdBQUcsTUFBTSxLQUFLO0NBQzlGO0NBQ0EsYUFBTSxnQkFBZ0I7RUFDbEIsSUFBSSxVQUNBO0VBRUosUUFBUSxPQUFPLFNBQVM7RUFDeEIsVUFBVSxNQUFNLFFBQVEsTUFBTSxLQUMxQixRQUFRLFVBQVUsTUFBTSxLQUFLLEVBQ3pCLEdBQUcsUUFBUSxXQUNmLENBQUM7RUFDTCxNQUFNLGtCQUFrQixtQkFBbUIsUUFBUSxTQUFTLElBQUk7RUFDaEUsSUFBSSxVQUFVLFlBQ1QsQ0FBQyxnQkFBZ0IsY0FBYyxRQUFRLFdBQVcsZ0JBQ25ELENBQUMsbUJBQW1CLFFBQVEsU0FBUyxjQUFjLENBQUMsQ0FBQyxjQUNyRCxDQUFDLGdCQUFnQixVQUNqQixJQUFJLFFBQVEsU0FBUyxVQUNqQixRQUFRLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sV0FBVztHQUN4QyxJQUFJLElBQUk7R0FDUixRQUFRLG9CQUFvQixDQUFDLElBQUksQ0FBQztHQUNsQyxNQUFNLFFBQVEsSUFBSSxPQUFPLFFBQVEsSUFBSTtHQUNyQyxNQUFNLGdCQUFnQixJQUFJLFFBQVEsV0FBVyxRQUFRLElBQUk7R0FDekQsTUFBTSxvQkFBb0Isa0JBQWtCLGNBQWMsVUFBVSxLQUFLLGNBQWMsVUFBVSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHO0dBQ3JJLE1BQU0sdUJBQXVCLGtCQUN4QixjQUFjLGFBQWEsS0FBSyxjQUFjLFVBQVUsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRztHQUNqRyxJQUFJLGdCQUNHLENBQUMsU0FBUyxxQkFDUixVQUNJLHNCQUFzQixNQUFNLFFBQ3pCLHlCQUF5QixNQUFNLFdBQ3pDLFNBQVMsTUFBTSxNQUFNO0lBQ3ZCLElBQUksT0FDQSxTQUFTLEtBQUssS0FDVixDQUFDLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxPQUFPLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFDbkQsMEJBQTBCLFFBQVEsV0FBVyxRQUFRLEdBQUcsT0FBTyxNQUFNLEdBQUcsSUFBSSxJQUM1RSxJQUFJLFFBQVEsV0FBVyxRQUFRLE1BQU0sS0FBSztTQUdoRCxNQUFNLFFBQVEsV0FBVyxRQUFRLElBQUk7SUFFekMsUUFBUSxVQUFVLE1BQU0sS0FBSyxFQUN6QixRQUFRLFFBQVEsV0FBVyxPQUMvQixDQUFDO0dBQ0w7RUFDSixDQUFDO09BRUE7R0FDRCxNQUFNLFFBQVEsSUFBSSxRQUFRLFNBQVMsSUFBSTtHQUN2QyxJQUFJLFNBQ0EsTUFBTSxNQUNOLEVBQUUsbUJBQW1CLFFBQVEsU0FBUyxjQUFjLENBQUMsQ0FBQyxjQUNsRCxtQkFBbUIsUUFBUSxTQUFTLElBQUksQ0FBQyxDQUFDLGFBQzlDLGNBQWMsT0FBTyxRQUFRLE9BQU8sVUFBVSxRQUFRLGFBQWEsUUFBUSxTQUFTLGlCQUFpQixnQkFBZ0IsS0FBSyxRQUFRLFNBQVMsMkJBQTJCLElBQUksQ0FBQyxDQUFDLE1BQU0sVUFBVSxDQUFDLGNBQWMsS0FBSyxLQUM1TSxRQUFRLFVBQVUsTUFBTSxLQUFLLEVBQ3pCLFFBQVEsMEJBQTBCLFFBQVEsV0FBVyxRQUFRLE9BQU8sSUFBSSxFQUM1RSxDQUFDLENBQUM7RUFFZDtFQUtKLFVBQVUsV0FDTixRQUFRLFVBQVUsTUFBTSxLQUFLO0dBQ3pCO0dBQ0EsUUFBUSxZQUFZLFFBQVEsV0FBVztFQUMzQyxDQUFDO0VBQ0wsUUFBUSxPQUFPLFNBQ1gsc0JBQXNCLFFBQVEsVUFBVSxLQUFLLFFBQVE7R0FDakQsSUFBSSxRQUFRLE9BQU8sU0FDZixJQUFJLFdBQVcsUUFBUSxPQUFPLEtBQUssS0FDbkMsSUFBSSxPQUFPO0lBQ1gsSUFBSSxNQUFNO0lBQ1YsT0FBTztHQUNYO0VBRUosQ0FBQztFQUNMLFFBQVEsT0FBTyxRQUFRO0VBQ3ZCLFFBQVEsVUFBVTtFQUNsQixVQUFVLFVBQVU7Q0FDeEIsR0FBRztFQUFDO0VBQVE7RUFBTTtFQUFTO0NBQVEsQ0FBQztDQUNwQyxhQUFNLGdCQUFnQjtFQUNsQixJQUFJLENBQUMsVUFDRCxDQUFDLElBQUksUUFBUSxhQUFhLElBQUksS0FBSyxRQUFRLGVBQWUsSUFBSTtFQUVsRSxhQUFhO0dBQ1QsSUFBSSxVQUNBO0dBRUosTUFBTSw2QkFBNkIsRUFBRSxRQUFRLFNBQVMsb0JBQW9CO0dBQzFFLE1BQU0saUJBQWlCLE1BQU0sVUFBVTtJQUNuQyxNQUFNLFFBQVEsSUFBSSxRQUFRLFNBQVMsSUFBSTtJQUN2QyxJQUFJLFNBQVMsTUFBTSxJQUNmLE1BQU0sR0FBRyxRQUFRO0dBRXpCO0dBQ0EsSUFBSSxVQUFVLFdBQVcsNEJBQ3JCLFFBQVEsVUFBVSxNQUFNLEtBQUs7SUFDekI7SUFDQSxRQUFRLFlBQVksUUFBUSxXQUFXO0dBQzNDLENBQUM7R0FFTCw2QkFDTSxjQUFjLE1BQU0sS0FBSyxJQUN6QixRQUFRLFdBQVcsSUFBSTtFQUNqQztDQUNKLEdBQUc7RUFBQztFQUFNO0VBQVM7RUFBUztFQUFrQjtDQUFRLENBQUM7Q0FDdkQsT0FBTztFQUNILE1BQUEsYUFBWSxZQUFZLE1BQU07R0FBQztHQUFjO0dBQU07R0FBUztFQUFRLENBQUM7RUFDckUsTUFBQSxhQUFZLFlBQVksTUFBTTtHQUFDO0dBQWM7R0FBTTtHQUFTO0VBQVEsQ0FBQztFQUNyRSxTQUFBLGFBQWUsWUFBWSxTQUFTO0dBQ2hDO0dBQ0E7R0FDQTtHQUNBO0VBQ0osQ0FBQztFQUNELFFBQUEsYUFBYyxZQUFZLFFBQVE7R0FBQztHQUFjO0dBQU07R0FBUztFQUFRLENBQUM7RUFDekUsUUFBQSxhQUFjLFlBQVksUUFBUTtHQUFDO0dBQWM7R0FBTTtHQUFTO0VBQVEsQ0FBQztFQUN6RSxRQUFBLGFBQWMsWUFBWSxVQUFVO0dBQUM7R0FBYztHQUFNO0dBQVM7RUFBUSxDQUFDO0VBQzNFLFFBQUEsYUFBYyxZQUFZLFFBQVE7R0FBQztHQUFjO0dBQU07R0FBUztFQUFRLENBQUM7RUFDekUsU0FBQSxhQUFlLFlBQVksU0FBUztHQUNoQztHQUNBO0dBQ0E7R0FDQTtFQUNKLENBQUM7RUFDRCxRQUFBLGFBQWMsY0FBYyxPQUFPLEtBQUssT0FBTyxXQUFXO0dBQ3RELEdBQUc7R0FDSCxHQUFJLFVBQVUsUUFBUSxJQUFJLEVBQUUsU0FBUyxJQUFJLENBQUM7SUFDekMsVUFBVSxJQUFJLFFBQVEsVUFBVSxXQUFXO0VBQ2hELEVBQUUsR0FBRztHQUFDO0dBQVE7R0FBUztFQUFRLENBQUM7Q0FDcEM7QUFDSjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBa0NBLElBQU0sY0FBYyxVQUFVLE1BQU0sT0FBTyxjQUFjLEtBQUssQ0FBQztBQUUvRCxJQUFNLFdBQVcsUUFBUTtDQUNyQixNQUFNLFNBQVMsQ0FBQztDQUNoQixLQUFLLE1BQU0sT0FBTyxPQUFPLEtBQUssR0FBRyxHQUM3QixJQUFJLGFBQWEsSUFBSSxJQUFJLEtBQ3JCLElBQUksU0FBUyxRQUNiLENBQUMsYUFBYSxJQUFJLElBQUksR0FBRztFQUN6QixNQUFNLFNBQVMsUUFBUSxJQUFJLElBQUk7RUFDL0IsS0FBSyxNQUFNLGFBQWEsT0FBTyxLQUFLLE1BQU0sR0FDdEMsT0FBTyxHQUFHLElBQUksR0FBRyxlQUFlLE9BQU87Q0FFL0MsT0FFSSxPQUFPLE9BQU8sSUFBSTtDQUcxQixPQUFPO0FBQ1g7QUFFQSxJQUFNLGtCQUFBLGFBQXdCLGNBQWMsSUFBSTtBQUNoRCxnQkFBZ0IsY0FBYzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQStCOUIsSUFBTSx1QkFBQSxhQUE2QixXQUFXLGVBQWU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUErQjdELElBQU0sZ0JBQWdCLEVBQUUsVUFBVSxPQUFPLFdBQVcsZUFBZSxVQUFVLGFBQWEsVUFBVSxXQUFXLFNBQVMsV0FBVyxZQUFZLE9BQU8sb0JBQW9CLGNBQWMsWUFBWSxTQUFTLFVBQVUsVUFBVSxnQkFBaUI7Q0FDOU8sTUFBTSxnQkFBQSxhQUFzQixlQUFlO0VBQ3ZDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNKLElBQUk7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDSixDQUFDO0NBQ0QsT0FBQSxhQUFjLGNBQWMsZ0JBQWdCLFVBQVUsRUFBRSxPQUFPLGNBQWMsR0FBQSxhQUNuRSxjQUFjLHVCQUF1QixVQUFVLEVBQUUsT0FBTyxjQUFjLFFBQVEsR0FBRyxRQUFRLENBQUM7QUFDeEc7QUFFQSxJQUFNLGVBQWU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdUJyQixTQUFTLEtBQUssT0FBTztDQUNqQixNQUFNLFVBQVUsZUFBZTtDQUMvQixNQUFNLENBQUMsU0FBUyxjQUFBLGFBQW9CLFNBQVMsS0FBSztDQUNsRCxNQUFNLEVBQUUsVUFBVSxRQUFRLFNBQVMsVUFBVSxVQUFVLFFBQVEsU0FBUyxjQUFjLFNBQVMsU0FBUyxTQUFTLFFBQVEsV0FBVyxnQkFBZ0IsR0FBRyxTQUFTO0NBQ2hLLE1BQU0sU0FBQSxhQUFlLFlBQVksT0FBTyxVQUFVO0VBQzlDLElBQUksV0FBVztFQUNmLElBQUksT0FBTztFQUNYLE1BQU0sUUFBUSxhQUFhLE9BQU8sU0FBUztHQUN2QyxNQUFNLFdBQVcsSUFBSSxTQUFTO0dBQzlCLElBQUksZUFBZTtHQUNuQixJQUFJO0lBQ0EsZUFBZSxLQUFLLFVBQVUsSUFBSTtHQUN0QyxTQUNPLElBQUksQ0FBRTtHQUNiLE1BQU0sb0JBQW9CLFFBQVEsSUFBSTtHQUN0QyxLQUFLLE1BQU0sT0FBTyxtQkFDZCxTQUFTLE9BQU8sS0FBSyxrQkFBa0IsSUFBSTtHQUUvQyxJQUFJLFVBQ0EsTUFBTSxTQUFTO0lBQ1g7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNKLENBQUM7R0FFTCxJQUFJLFFBQ0EsSUFBSTtJQUNBLE1BQU0sZ0NBQWdDLENBQ2xDLFdBQVcsUUFBUSxpQkFDbkIsT0FDSixDQUFDLENBQUMsTUFBTSxVQUFVLFNBQVMsTUFBTSxTQUFTLE1BQU0sQ0FBQztJQUNqRCxNQUFNLFdBQVcsTUFBTSxNQUFNLE9BQU8sTUFBTSxHQUFHO0tBQ3pDO0tBQ0EsU0FBUztNQUNMLEdBQUc7TUFDSCxHQUFJLFdBQVcsWUFBWSx3QkFDckIsRUFBRSxnQkFBZ0IsUUFBUSxJQUMxQixDQUFDO0tBQ1g7S0FDQSxNQUFNLGdDQUFnQyxlQUFlO0lBQ3pELENBQUM7SUFDRCxJQUFJLGFBQ0MsaUJBQ0ssQ0FBQyxlQUFlLFNBQVMsTUFBTSxJQUMvQixTQUFTLFNBQVMsT0FBTyxTQUFTLFVBQVUsTUFBTTtLQUN4RCxXQUFXO0tBQ1gsV0FBVyxRQUFRLEVBQUUsU0FBUyxDQUFDO0tBQy9CLE9BQU8sT0FBTyxTQUFTLE1BQU07SUFDakMsT0FFSSxhQUFhLFVBQVUsRUFBRSxTQUFTLENBQUM7R0FFM0MsU0FDTyxPQUFPO0lBQ1YsV0FBVztJQUNYLFdBQVcsUUFBUSxFQUFFLE1BQU0sQ0FBQztHQUNoQztFQUVSLENBQUMsQ0FBQyxDQUFDLEtBQUs7RUFDUixJQUFJLFlBQVksU0FBUztHQUNyQixRQUFRLFVBQVUsTUFBTSxLQUFLLEVBQ3pCLG9CQUFvQixNQUN4QixDQUFDO0dBQ0QsUUFBUSxTQUFTLGVBQWUsRUFDNUIsS0FDSixDQUFDO0VBQ0w7Q0FDSixHQUFHO0VBQ0M7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0osQ0FBQztDQUNELGFBQU0sZ0JBQWdCO0VBQ2xCLFdBQVcsSUFBSTtDQUNuQixHQUFHLENBQUMsQ0FBQztDQUNMLE9BQU8sU0FBQSxhQUFnQixjQUFBLGFBQW9CLFVBQVUsTUFBTSxPQUFPLEVBQzlELE9BQ0osQ0FBQyxDQUFDLElBQUEsYUFBWSxjQUFjLFFBQVE7RUFBRSxZQUFZO0VBQWlCO0VBQWdCO0VBQWlCO0VBQVMsVUFBVTtFQUFRLEdBQUc7Q0FBSyxHQUFHLFFBQVE7QUFDdEo7QUFFQSxJQUFNLHNCQUFzQixFQUFFLFNBQVMsVUFBVSxPQUFPLE1BQU0sYUFBYyxPQUFPLGFBQWE7Q0FBRTtDQUFTO0NBQU07Q0FBVTtBQUFNLENBQUMsQ0FBQztBQUVuSSxJQUFJLHNCQUFzQjtDQUN0QixJQUFJLGFBQWEsQ0FBQztDQUNsQixNQUFNLFFBQVEsVUFBVTtFQUNwQixLQUFLLE1BQU0sWUFBWSxZQUNuQixTQUFTLFFBQVEsU0FBUyxLQUFLLEtBQUs7Q0FFNUM7Q0FDQSxNQUFNLGFBQWEsYUFBYTtFQUM1QixXQUFXLEtBQUssUUFBUTtFQUN4QixPQUFPLEVBQ0gsbUJBQW1CO0dBQ2YsYUFBYSxXQUFXLFFBQVEsTUFBTSxNQUFNLFFBQVE7RUFDeEQsRUFDSjtDQUNKO0NBQ0EsTUFBTSxvQkFBb0I7RUFDdEIsYUFBYSxDQUFDO0NBQ2xCO0NBQ0EsT0FBTztFQUNILElBQUksWUFBWTtHQUNaLE9BQU87RUFDWDtFQUNBO0VBQ0E7RUFDQTtDQUNKO0FBQ0o7QUFFQSxTQUFTLGtCQUFrQixhQUFhLFlBQVk7Q0FDaEQsTUFBTSxTQUFTLENBQUM7Q0FDaEIsS0FBSyxNQUFNLE9BQU8sYUFDZCxJQUFJLFlBQVksZUFBZSxHQUFHLEdBQUc7RUFDakMsTUFBTSxhQUFhLFlBQVk7RUFDL0IsTUFBTSxhQUFhLFdBQVc7RUFDOUIsSUFBSSxjQUFjLFNBQVMsVUFBVSxLQUFLLFlBQVk7R0FDbEQsTUFBTSxvQkFBb0Isa0JBQWtCLFlBQVksVUFBVTtHQUNsRSxJQUFJLFNBQVMsaUJBQWlCLEdBQzFCLE9BQU8sT0FBTztFQUV0QixPQUNLLElBQUksWUFBWSxNQUNqQixPQUFPLE9BQU87Q0FFdEI7Q0FFSixPQUFPO0FBQ1g7QUFFQSxJQUFJLG9CQUFvQixZQUFZLFFBQVEsU0FBUztBQUVyRCxJQUFJLHFCQUFxQixRQUFRLGFBQWEsR0FBRyxLQUFLLGdCQUFnQixHQUFHO0FBRXpFLElBQUksUUFBUSxRQUFRLGNBQWMsR0FBRyxLQUFLLElBQUk7QUFFOUMsSUFBSSxxQkFBcUIsU0FBUztDQUM5QixLQUFLLE1BQU0sT0FBTyxNQUNkLElBQUksV0FBVyxLQUFLLElBQUksR0FDcEIsT0FBTztDQUdmLE9BQU87QUFDWDtBQUVBLFNBQVMsY0FBYyxPQUFPO0NBQzFCLE9BQU8sTUFBTSxRQUFRLEtBQUssS0FBTSxTQUFTLEtBQUssS0FBSyxDQUFDLGtCQUFrQixLQUFLO0FBQy9FO0FBQ0EsU0FBUyxpQkFBaUIsVUFBVTtDQUNoQyxPQUFPLENBQUMsRUFBRSxZQUFZLFFBQVE7QUFDbEM7QUFDQSxTQUFTLHNCQUFzQixPQUFPO0NBQ2xDLE9BQU8sTUFBTSxRQUFRLEtBQUssSUFDcEIsQ0FBQyxNQUFNLE1BQU0sU0FBUyxDQUFDLFlBQVksSUFBSSxDQUFDLElBQ3hDLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDO0FBQzlCO0FBQ0EsU0FBUyxnQkFBZ0IsV0FBVyxLQUFLO0NBQ3JDLElBQUksTUFBTSxRQUFRLFNBQVMsR0FDdkIsVUFBVSxPQUFPLEtBQUE7TUFHakIsT0FBTyxVQUFVO0FBRXpCO0FBQ0EsU0FBUyxnQkFBZ0IsTUFBTSxTQUFTLENBQUMsR0FBRyxXQUFXO0NBQ25ELEtBQUssTUFBTSxPQUFPLE1BQU07RUFDcEIsTUFBTSxRQUFRLEtBQUs7RUFDbkIsTUFBTSxXQUFXLGFBQWEsVUFBVTtFQUN4QyxJQUFJLGNBQWMsS0FBSyxNQUNsQixDQUFDLE1BQU0sUUFBUSxLQUFLLEtBQUssQ0FBQyxpQkFBaUIsUUFBUSxJQUFJO0dBQ3hELE9BQU8sT0FBTyxNQUFNLFFBQVEsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDO0dBQzNDLGdCQUFnQixPQUFPLE9BQU8sTUFBTSxRQUFRO0dBQzVDLElBQUksc0JBQXNCLE9BQU8sSUFBSSxHQUNqQyxnQkFBZ0IsUUFBUSxHQUFHO0VBRW5DLE9BQ0ssSUFBSSxDQUFDLFlBQVksS0FBSyxHQUN2QixPQUFPLE9BQU87Q0FFdEI7Q0FDQSxPQUFPO0FBQ1g7QUFDQSxTQUFTLGVBQWUsTUFBTSxZQUFZLHVCQUF1QixXQUFXO0NBQ3hFLElBQUksQ0FBQyx1QkFDRCx3QkFBd0IsZ0JBQWdCLFlBQVksQ0FBQyxHQUFHLFNBQVM7Q0FFckUsS0FBSyxNQUFNLE9BQU8sTUFBTTtFQUNwQixNQUFNLFFBQVEsS0FBSztFQUNuQixNQUFNLFdBQVcsYUFBYSxVQUFVO0VBQ3hDLElBQUksY0FBYyxLQUFLLE1BQ2xCLENBQUMsTUFBTSxRQUFRLEtBQUssS0FBSyxDQUFDLGlCQUFpQixRQUFRLElBQUk7R0FDeEQsSUFBSSxZQUFZLFVBQVUsS0FBSyxZQUFZLHNCQUFzQixJQUFJLEdBQ2pFLHNCQUFzQixPQUFPLGdCQUFnQixPQUFPLE1BQU0sUUFBUSxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxRQUFRO1FBRzVGLGVBQWUsT0FBTyxrQkFBa0IsVUFBVSxJQUFJLENBQUMsSUFBSSxXQUFXLE1BQU0sc0JBQXNCLE1BQU0sUUFBUTtHQUVwSCxJQUFJLHNCQUFzQixzQkFBc0IsSUFBSSxHQUNoRCxnQkFBZ0IsdUJBQXVCLEdBQUc7RUFFbEQsT0FDSyxJQUFJLFVBQVUsT0FBTyxXQUFXLElBQUksR0FDckMsZ0JBQWdCLHVCQUF1QixHQUFHO09BRzFDLHNCQUFzQixPQUFPO0NBRXJDO0NBQ0EsT0FBTztBQUNYO0FBRUEsSUFBSSxtQkFBbUIsT0FBTyxFQUFFLGVBQWUsYUFBYSxpQkFBaUIsWUFBWSxLQUFLLElBQ3hGLFFBQ0EsZ0JBQ0ksVUFBVSxLQUNOLE1BQ0EsUUFDSSxDQUFDLFFBQ0QsUUFDUixlQUFlLFNBQVMsS0FBSyxJQUN6QixJQUFJLEtBQUssS0FBSyxJQUNkLGFBQ0ksV0FBVyxLQUFLLElBQ2hCO0FBRWxCLFNBQVMsY0FBYyxJQUFJO0NBQ3ZCLE1BQU0sTUFBTSxHQUFHO0NBQ2YsSUFBSSxZQUFZLEdBQUcsR0FDZixPQUFPLElBQUk7Q0FFZixJQUFJLGFBQWEsR0FBRyxHQUNoQixPQUFPLGNBQWMsR0FBRyxJQUFJLENBQUMsQ0FBQztDQUVsQyxJQUFJLGlCQUFpQixHQUFHLEdBQ3BCLE9BQU8sQ0FBQyxHQUFHLElBQUksZUFBZSxDQUFDLENBQUMsS0FBSyxFQUFFLFlBQVksS0FBSztDQUU1RCxJQUFJLGdCQUFnQixHQUFHLEdBQ25CLE9BQU8saUJBQWlCLEdBQUcsSUFBSSxDQUFDLENBQUM7Q0FFckMsT0FBTyxnQkFBZ0IsWUFBWSxJQUFJLEtBQUssSUFBSSxHQUFHLElBQUksUUFBUSxJQUFJLE9BQU8sRUFBRTtBQUNoRjtBQUVBLElBQUksc0JBQXNCLGFBQWEsU0FBUyxjQUFjLDhCQUE4QjtDQUN4RixNQUFNLFNBQVMsQ0FBQztDQUNoQixLQUFLLE1BQU0sUUFBUSxhQUFhO0VBQzVCLE1BQU0sUUFBUSxJQUFJLFNBQVMsSUFBSTtFQUMvQixTQUFTLElBQUksUUFBUSxNQUFNLE1BQU0sRUFBRTtDQUN2QztDQUNBLE9BQU87RUFDSDtFQUNBLE9BQU8sQ0FBQyxHQUFHLFdBQVc7RUFDdEI7RUFDQTtDQUNKO0FBQ0o7QUFFQSxJQUFJLGdCQUFnQixTQUFTLFlBQVksSUFBSSxJQUN2QyxPQUNBLFFBQVEsSUFBSSxJQUNSLEtBQUssU0FDTCxTQUFTLElBQUksSUFDVCxRQUFRLEtBQUssS0FBSyxJQUNkLEtBQUssTUFBTSxTQUNYLEtBQUssUUFDVDtBQUVkLElBQU0saUJBQWlCO0FBQ3ZCLElBQUksd0JBQXdCLG1CQUFtQjtDQUMzQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsZUFBZSxVQUNuQyxPQUFPO0NBQ1gsSUFBSSxXQUFXLGVBQWUsUUFBUSxHQUNsQyxPQUFPLGVBQWUsU0FBUyxZQUFZLFNBQVM7Q0FFeEQsSUFBSSxTQUFTLGVBQWUsUUFBUTtPQUMzQixNQUFNLE9BQU8sZUFBZSxVQUM3QixJQUFJLGVBQWUsU0FBUyxJQUFJLENBQUMsWUFDNUIsU0FBUyxnQkFDVixPQUFPO0NBQUE7Q0FJbkIsT0FBTztBQUNYO0FBRUEsSUFBSSxpQkFBaUIsWUFBWSxRQUFRLFVBQ3BDLFFBQVEsWUFDTCxRQUFRLE9BQ1IsUUFBUSxPQUNSLFFBQVEsYUFDUixRQUFRLGFBQ1IsUUFBUSxXQUNSLFFBQVE7QUFFaEIsU0FBUyxrQkFBa0IsUUFBUSxTQUFTLE1BQU07Q0FDOUMsTUFBTSxRQUFRLElBQUksUUFBUSxJQUFJO0NBQzlCLElBQUksU0FBUyxNQUFNLElBQUksR0FDbkIsT0FBTztFQUNIO0VBQ0E7Q0FDSjtDQUVKLE1BQU0sUUFBUSxLQUFLLE1BQU0sR0FBRztDQUM1QixPQUFPLE1BQU0sUUFBUTtFQUNqQixNQUFNLFlBQVksTUFBTSxLQUFLLEdBQUc7RUFDaEMsTUFBTSxRQUFRLElBQUksU0FBUyxTQUFTO0VBQ3BDLE1BQU0sYUFBYSxJQUFJLFFBQVEsU0FBUztFQUN4QyxJQUFJLFNBQVMsQ0FBQyxNQUFNLFFBQVEsS0FBSyxLQUFLLFNBQVMsV0FDM0MsT0FBTyxFQUFFLEtBQUs7RUFFbEIsSUFBSSxjQUFjLFdBQVcsTUFDekIsT0FBTztHQUNILE1BQU07R0FDTixPQUFPO0VBQ1g7RUFFSixJQUFJLGNBQWMsV0FBVyxRQUFRLFdBQVcsS0FBSyxNQUNqRCxPQUFPO0dBQ0gsTUFBTSxHQUFHLFVBQVU7R0FDbkIsT0FBTyxXQUFXO0VBQ3RCO0VBRUosTUFBTSxJQUFJO0NBQ2Q7Q0FDQSxPQUFPLEVBQ0gsS0FDSjtBQUNKO0FBRUEsSUFBSSx5QkFBeUIsZUFBZSxpQkFBaUIsaUJBQWlCLFdBQVc7Q0FDckYsZ0JBQWdCLGFBQWE7Q0FDN0IsTUFBTSxFQUFFLE1BQU0sR0FBRyxjQUFjO0NBQy9CLE1BQU0sT0FBTyxPQUFPLEtBQUssU0FBUztDQUNsQyxPQUFRLENBQUMsS0FBSyxVQUNULFVBQVUsS0FBSyxVQUFVLE9BQU8sS0FBSyxlQUFlLENBQUMsQ0FBQyxVQUN2RCxLQUFLLE1BQU0sUUFBUSxnQkFBZ0IsVUFDOUIsQ0FBQyxVQUFVLGdCQUFnQixJQUFJO0FBQzVDO0FBRUEsSUFBSSx5QkFBeUIsTUFBTSxZQUFZLFVBQVUsQ0FBQyxRQUN0RCxDQUFDLGNBQ0QsU0FBUyxjQUNULHNCQUFzQixJQUFJLENBQUMsQ0FBQyxNQUFNLGdCQUFnQixnQkFDN0MsUUFDSyxnQkFBZ0IsY0FBYyxZQUFZLFdBQVcsYUFBYSxHQUFHLElBQ3JFLFlBQVksV0FBVyxVQUFVLEtBQy9CLFdBQVcsV0FBVyxXQUFXLEVBQUU7QUFFbkQsSUFBSSxrQkFBa0IsYUFBYSxXQUFXLGFBQWEsZ0JBQWdCLFNBQVM7Q0FDaEYsSUFBSSxLQUFLLFNBQ0wsT0FBTztNQUVOLElBQUksQ0FBQyxlQUFlLEtBQUssV0FDMUIsT0FBTyxFQUFFLGFBQWE7TUFFckIsSUFBSSxjQUFjLGVBQWUsV0FBVyxLQUFLLFVBQ2xELE9BQU8sQ0FBQztNQUVQLElBQUksY0FBYyxlQUFlLGFBQWEsS0FBSyxZQUNwRCxPQUFPO0NBRVgsT0FBTztBQUNYO0FBRUEsSUFBSSxtQkFBbUIsS0FBSyxTQUFTLENBQUMsUUFBUSxJQUFJLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVLE1BQU0sS0FBSyxJQUFJO0FBRXZGLElBQU0saUJBQWlCO0NBQ25CLE1BQU0sZ0JBQWdCO0NBQ3RCLGdCQUFnQixnQkFBZ0I7Q0FDaEMsa0JBQWtCO0FBQ3RCO0FBQ0EsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxxQkFBcUI7Q0FDdkIsYUFBYTtDQUNiLFNBQVM7Q0FDVCxTQUFTO0NBQ1QsY0FBYztDQUNkLGFBQWE7Q0FDYixjQUFjO0NBQ2Qsb0JBQW9CO0NBQ3BCLFNBQVM7Q0FDVCxlQUFlLENBQUM7Q0FDaEIsYUFBYSxDQUFDO0NBQ2Qsa0JBQWtCLENBQUM7QUFDdkI7QUFDQSxTQUFTLGtCQUFrQixRQUFRLENBQUMsR0FBRztDQUNuQyxJQUFJLFdBQVc7RUFDWCxHQUFHO0VBQ0gsR0FBRztDQUNQO0NBQ0EsSUFBSSxhQUFhO0VBQ2IsR0FBRyxZQUFZLGtCQUFrQjtFQUNqQyxXQUFXLFdBQVcsU0FBUyxhQUFhO0VBQzVDLFFBQVEsU0FBUyxVQUFVLENBQUM7RUFDNUIsVUFBVSxTQUFTLFlBQVk7Q0FDbkM7Q0FDQSxJQUFJLFVBQVUsQ0FBQztDQUNmLElBQUksaUJBQWlCLFNBQVMsU0FBUyxhQUFhLEtBQUssU0FBUyxTQUFTLE1BQU0sSUFDM0UsWUFBWSxTQUFTLGlCQUFpQixTQUFTLE1BQU0sS0FBSyxDQUFDLElBQzNELENBQUM7Q0FDUCxJQUFJLGNBQWMsU0FBUyxtQkFDckIsQ0FBQyxJQUNELFlBQVksY0FBYztDQUNoQyxJQUFJLFNBQVM7RUFDVCxRQUFRO0VBQ1IsT0FBTztFQUNQLE9BQU87RUFDUCxhQUFhO0NBQ2pCO0NBQ0EsSUFBSSxTQUFTO0VBQ1QsdUJBQU8sSUFBSSxJQUFJO0VBQ2YsMEJBQVUsSUFBSSxJQUFJO0VBQ2xCLHlCQUFTLElBQUksSUFBSTtFQUNqQix1QkFBTyxJQUFJLElBQUk7RUFDZix1QkFBTyxJQUFJLElBQUk7RUFDZiw4QkFBYyxJQUFJLElBQUk7Q0FDMUI7Q0FDQSxNQUFNLHNCQUFzQixDQUFDO0NBQzdCLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLElBQUkseUJBQXlCO0NBQzdCLElBQUksOEJBQThCLG1CQUFtQixTQUFTLElBQUk7Q0FDbEUsSUFBSSw2QkFBNkIsbUJBQW1CLFNBQVMsY0FBYztDQUMzRSxNQUFNLHdCQUF3QjtFQUMxQixTQUFTO0VBQ1QsYUFBYTtFQUNiLGtCQUFrQjtFQUNsQixlQUFlO0VBQ2YsY0FBYztFQUNkLFNBQVM7RUFDVCxRQUFRO0NBQ1o7Q0FDQSxNQUFNLGtCQUFrQixFQUNwQixHQUFHLHNCQUNQO0NBQ0EsSUFBSSwyQkFBMkIsRUFDM0IsR0FBRyxnQkFDUDtDQUNBLE1BQU0sWUFBWTtFQUNkLE9BQU8sY0FBYztFQUNyQixPQUFPLGNBQWM7Q0FDekI7Q0FDQSxJQUFJLGtCQUFrQjtDQUN0QixNQUFNLG1DQUFtQyxTQUFTLGlCQUFpQixnQkFBZ0I7Q0FDbkYsTUFBTSxZQUFZLE1BQU0sY0FBYyxTQUFTO0VBQzNDLGFBQWEsT0FBTyxLQUFLO0VBQ3pCLE9BQU8sUUFBUSxXQUFXLFVBQVUsSUFBSTtDQUM1QztDQUNBLE1BQU0sWUFBWSxPQUFPLHNCQUFzQjtFQUMzQyxJQUFJLE9BQU8sYUFDUDtFQUVKLElBQUksQ0FBQyxTQUFTLGFBQ1QsZ0JBQWdCLFdBQ2IseUJBQXlCLFdBQ3pCLG9CQUFvQjtHQUN4QixNQUFNLFNBQVMsRUFBRTtHQUNqQixJQUFJO0dBQ0osSUFBSSxTQUFTLFVBQVU7SUFDbkIsVUFBVSxlQUFlLE1BQU0sV0FBVyxFQUFBLENBQUcsTUFBTTtJQUNuRCxXQUFXLG1CQUFtQixvQkFBb0I7R0FDdEQsT0FFSSxVQUFVLE1BQU0seUJBQXlCO0lBQ3JDLFFBQVE7SUFDUixnQkFBZ0I7SUFDaEIsV0FBVyxPQUFPO0dBQ3RCLENBQUM7R0FFTCxJQUFJLFdBQVcsbUJBQW1CLFlBQVksV0FBVyxTQUNyRCxVQUFVLE1BQU0sS0FBSyxFQUNqQixRQUNKLENBQUM7RUFFVDtDQUNKO0NBQ0EsTUFBTSx1QkFBdUIsT0FBTyxpQkFBaUI7RUFDakQsSUFBSSxDQUFDLFNBQVMsYUFDVCxnQkFBZ0IsZ0JBQ2IsZ0JBQWdCLG9CQUNoQix5QkFBeUIsZ0JBQ3pCLHlCQUF5QixtQkFBbUI7R0FDaEQsQ0FBQyxTQUFTLE1BQU0sS0FBSyxPQUFPLEtBQUssRUFBQSxDQUFHLFNBQVMsU0FBUztJQUNsRCxJQUFJLE1BQ0EsZUFDTSxJQUFJLFdBQVcsa0JBQWtCLE1BQU0sWUFBWSxJQUNuRCxNQUFNLFdBQVcsa0JBQWtCLElBQUk7R0FFckQsQ0FBQztHQUNELFVBQVUsTUFBTSxLQUFLO0lBQ2pCLGtCQUFrQixXQUFXO0lBQzdCLGNBQWMsQ0FBQyxjQUFjLFdBQVcsZ0JBQWdCO0dBQzVELENBQUM7RUFDTDtDQUNKO0NBQ0EsTUFBTSwyQkFBMkI7RUFDN0IsV0FBVyxjQUFjLGVBQWUsZ0JBQWdCLGFBQWEsS0FBQSxHQUFXLE9BQU87Q0FDM0Y7Q0FDQSxNQUFNLGtCQUFrQixNQUFNLFNBQVMsQ0FBQyxHQUFHLFFBQVEsTUFBTSxrQkFBa0IsTUFBTSw2QkFBNkIsU0FBUztFQUNuSCxJQUFJLFFBQVEsVUFBVSxDQUFDLFNBQVMsVUFBVTtHQUN0QyxPQUFPLFNBQVM7R0FDaEIsSUFBSSw4QkFBOEIsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJLENBQUMsR0FBRztJQUNqRSxNQUFNLGNBQWMsT0FBTyxJQUFJLFNBQVMsSUFBSSxHQUFHLEtBQUssTUFBTSxLQUFLLElBQUk7SUFDbkUsbUJBQW1CLElBQUksU0FBUyxNQUFNLFdBQVc7R0FDckQ7R0FDQSxJQUFJLDhCQUNBLE1BQU0sUUFBUSxJQUFJLFdBQVcsUUFBUSxJQUFJLENBQUMsR0FBRztJQUM3QyxNQUFNLFNBQVMsT0FBTyxJQUFJLFdBQVcsUUFBUSxJQUFJLEdBQUcsS0FBSyxNQUFNLEtBQUssSUFBSTtJQUN4RSxtQkFBbUIsSUFBSSxXQUFXLFFBQVEsTUFBTSxNQUFNO0lBQ3RELGdCQUFnQixXQUFXLFFBQVEsSUFBSTtHQUMzQztHQUNBLEtBQUssZ0JBQWdCLGlCQUNqQix5QkFBeUIsa0JBQ3pCLDhCQUNBLE1BQU0sUUFBUSxJQUFJLFdBQVcsZUFBZSxJQUFJLENBQUMsR0FBRztJQUNwRCxNQUFNLGdCQUFnQixPQUFPLElBQUksV0FBVyxlQUFlLElBQUksR0FBRyxLQUFLLE1BQU0sS0FBSyxJQUFJO0lBQ3RGLG1CQUFtQixJQUFJLFdBQVcsZUFBZSxNQUFNLGFBQWE7R0FDeEU7R0FDQSxJQUFJLGdCQUFnQixlQUFlLHlCQUF5QixhQUN4RCxtQkFBbUI7R0FFdkIsVUFBVSxNQUFNLEtBQUs7SUFDakI7SUFDQSxTQUFTLFVBQVUsTUFBTSxNQUFNO0lBQy9CLGFBQWEsV0FBVztJQUN4QixRQUFRLFdBQVc7SUFDbkIsU0FBUyxXQUFXO0dBQ3hCLENBQUM7RUFDTCxPQUVJLElBQUksYUFBYSxNQUFNLE1BQU07Q0FFckM7Q0FDQSxNQUFNLGdCQUFnQixNQUFNLFVBQVU7RUFDbEMsSUFBSSxXQUFXLFFBQVEsTUFBTSxLQUFLO0VBQ2xDLFdBQVcsU0FBUyxFQUFFLEdBQUcsV0FBVyxPQUFPO0VBQzNDLFVBQVUsTUFBTSxLQUFLLEVBQ2pCLFFBQVEsV0FBVyxPQUN2QixDQUFDO0NBQ0w7Q0FDQSxNQUFNLGNBQWMsV0FBVztFQUMzQixXQUFXLFNBQVM7RUFDcEIsVUFBVSxNQUFNLEtBQUs7R0FDakIsUUFBUSxXQUFXO0dBQ25CLFNBQVM7RUFDYixDQUFDO0NBQ0w7Q0FDQSxNQUFNLCtCQUErQixTQUFTO0VBQzFDLE1BQU0sV0FBVyxNQUFNLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxhQUFhLElBQUk7RUFDekQsSUFBSSxhQUFhO0VBQ2pCLElBQUksZ0JBQWdCO0VBQ3BCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFNBQVMsR0FBRyxLQUFLO0dBQzFDLE1BQU0sTUFBTSxTQUFTO0dBQ3JCLGFBQWEsa0JBQWtCLFVBQVUsSUFBSSxhQUFhLFdBQVc7R0FDckUsZ0JBQWdCLGtCQUFrQixhQUFhLElBQ3pDLGdCQUNBLGNBQWM7R0FDcEIsSUFBSSxlQUFlLFFBQVEsa0JBQWtCLE1BQ3pDLE9BQU87RUFFZjtFQUNBLE9BQU87Q0FDWDtDQUNBLE1BQU0sdUJBQXVCLE1BQU0sc0JBQXNCLE9BQU8sUUFBUTtFQUNwRSxNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7RUFDL0IsSUFBSSxPQUFPO0dBQ1AsSUFBSSw0QkFBNEIsSUFBSSxHQUNoQztHQUVKLE1BQU0sdUJBQXVCLFlBQVksSUFBSSxhQUFhLElBQUksQ0FBQztHQUMvRCxNQUFNLGVBQWUsSUFBSSxhQUFhLE1BQU0sWUFBWSxLQUFLLElBQUksSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLEtBQUs7R0FDbEcsWUFBWSxZQUFZLEtBQ25CLE9BQU8sSUFBSSxrQkFDWix1QkFDRSxJQUFJLGFBQWEsTUFBTSx1QkFBdUIsZUFBZSxjQUFjLE1BQU0sRUFBRSxDQUFDLElBQ3BGLGNBQWMsTUFBTSxZQUFZO0dBQ3RDLElBQUksT0FBTyxTQUFTLENBQUMsT0FBTyxRQUFRO0lBQ2hDLFVBQVU7SUFDVixJQUFJLHdCQUNBLFdBQVcsWUFDVixnQkFBZ0IsV0FBVyx5QkFBeUI7U0FFakQsQ0FEWSxVQUNMLEdBQUc7TUFDVixXQUFXLFVBQVU7TUFDckIsVUFBVSxNQUFNLEtBQUssRUFBRSxHQUFHLFdBQVcsQ0FBQztLQUMxQzs7SUFFSixJQUFJLE1BQU0sb0JBQ04sd0JBQ0EsQ0FBQyxZQUFZLElBQUksYUFBYSxJQUFJLENBQUMsS0FDbkMsVUFBVSxNQUFNLE1BQU0sR0FDdEIsT0FBTyxRQUFRO0dBRXZCO0VBQ0o7Q0FDSjtDQUNBLE1BQU0sdUJBQXVCLE1BQU0sWUFBWSxhQUFhLGFBQWEsaUJBQWlCO0VBQ3RGLElBQUksb0JBQW9CO0VBQ3hCLElBQUksa0JBQWtCO0VBQ3RCLE1BQU0sU0FBUyxFQUNYLEtBQ0o7RUFHQSxJQUFJLENBQUMsU0FBUyxZQUFZLGdCQUFnQixNQUFNO0dBQzVDLElBQUksQ0FBQyxlQUFlLGFBQWE7SUFDN0IsTUFBTSx5QkFBeUIsVUFBVSxJQUFJLGdCQUFnQixJQUFJLEdBQUcsVUFBVTtJQUM5RSxJQUFJLGdCQUFnQixXQUFXLHlCQUF5QixTQUFTO0tBQzdELGtCQUFrQixXQUFXO0tBQzdCLFdBQVcsVUFBVSxPQUFPLFVBQ3hCLENBQUMsMEJBQTBCLFVBQVU7S0FDekMsb0JBQW9CLG9CQUFvQixPQUFPO0lBQ25EO0lBQ0Esa0JBQWtCLENBQUMsQ0FBQyxJQUFJLFdBQVcsYUFBYSxJQUFJO0lBQ3BELElBQUksMkJBQTJCLFdBQVcsU0FDdEMsV0FBVyxjQUFjLGVBQWUsZ0JBQWdCLGFBQWEsS0FBQSxHQUFXLE9BQU87U0FHdkYseUJBQ00sTUFBTSxXQUFXLGFBQWEsSUFBSSxJQUNsQyxJQUFJLFdBQVcsYUFBYSxNQUFNLElBQUk7SUFFaEQsT0FBTyxjQUFjLFdBQVc7SUFDaEMsb0JBQ0ksc0JBQ00sZ0JBQWdCLGVBQ2QseUJBQXlCLGdCQUN6QixvQkFBb0IsQ0FBQztHQUNyQztHQUNBLElBQUksYUFBYTtJQUNiLE1BQU0seUJBQXlCLElBQUksV0FBVyxlQUFlLElBQUk7SUFDakUsSUFBSSxDQUFDLHdCQUF3QjtLQUN6QixJQUFJLFdBQVcsZUFBZSxNQUFNLFdBQVc7S0FDL0MsT0FBTyxnQkFBZ0IsV0FBVztLQUNsQyxvQkFDSSxzQkFDTSxnQkFBZ0IsaUJBQ2QseUJBQXlCLGtCQUN6QiwyQkFBMkI7SUFDM0M7R0FDSjtHQUNBLHFCQUFxQixnQkFBZ0IsVUFBVSxNQUFNLEtBQUssTUFBTTtFQUNwRTtFQUNBLE9BQU8sb0JBQW9CLFNBQVMsQ0FBQztDQUN6QztDQUNBLE1BQU0sdUJBQXVCLE1BQU0sU0FBUyxPQUFPLGVBQWU7RUFDOUQsTUFBTSxxQkFBcUIsSUFBSSxXQUFXLFFBQVEsSUFBSTtFQUN0RCxNQUFNLHFCQUFxQixnQkFBZ0IsV0FBVyx5QkFBeUIsWUFDM0UsVUFBVSxPQUFPLEtBQ2pCLFdBQVcsWUFBWTtFQUMzQixJQUFJLFNBQVMsY0FBYyxPQUFPO0dBQzlCLG9CQUFvQixRQUFRLFNBQVMsWUFBWSxhQUFhLE1BQU0sS0FBSyxDQUFDO0dBQzFFLG9CQUFvQixLQUFLLENBQUMsU0FBUyxVQUFVO0VBQ2pELE9BQ0s7R0FDRCxhQUFhLE9BQU8sS0FBSztHQUN6QixPQUFPLG9CQUFvQjtHQUMzQixRQUNNLElBQUksV0FBVyxRQUFRLE1BQU0sS0FBSyxJQUNsQyxNQUFNLFdBQVcsUUFBUSxJQUFJO0dBQ25DLFdBQVcsU0FBUyxFQUFFLEdBQUcsV0FBVyxPQUFPO0VBQy9DO0VBQ0EsS0FBSyxRQUFRLENBQUMsVUFBVSxvQkFBb0IsS0FBSyxJQUFJLHVCQUNqRCxDQUFDLGNBQWMsVUFBVSxLQUN6QixtQkFBbUI7R0FDbkIsTUFBTSxtQkFBbUI7SUFDckIsR0FBRztJQUNILEdBQUkscUJBQXFCLFVBQVUsT0FBTyxJQUFJLEVBQUUsUUFBUSxJQUFJLENBQUM7SUFDN0QsUUFBUSxXQUFXO0lBQ25CO0dBQ0o7R0FDQSxhQUFhO0lBQ1QsR0FBRztJQUNILEdBQUc7R0FDUDtHQUNBLFVBQVUsTUFBTSxLQUFLLGdCQUFnQjtFQUN6QztDQUNKO0NBQ0EsTUFBTSxhQUFhLE9BQU8sU0FBUztFQUMvQixvQkFBb0IsTUFBTSxJQUFJO0VBQzlCLE9BQU8sTUFBTSxTQUFTLFNBQVMsYUFBYSxTQUFTLFNBQVMsbUJBQW1CLFFBQVEsT0FBTyxPQUFPLFNBQVMsU0FBUyxjQUFjLFNBQVMseUJBQXlCLENBQUM7Q0FDOUs7Q0FDQSxNQUFNLDhCQUE4QixPQUFPLFVBQVU7RUFDakQsTUFBTSxFQUFFLFdBQVcsTUFBTSxXQUFXLEtBQUs7RUFDekMsb0JBQW9CLEtBQUs7RUFDekIsSUFBSSxPQUFPO0dBQ1AsS0FBSyxNQUFNLFFBQVEsT0FBTztJQUN0QixNQUFNLFFBQVEsSUFBSSxRQUFRLElBQUk7SUFDOUIsUUFDTSxPQUFPLE1BQU0sSUFBSSxJQUFJLEtBQ25CLFNBQVMsS0FBSyxLQUNkLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLE1BQU0sUUFBUSxDQUFDLE9BQU8sTUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDLElBQzFELDBCQUEwQixXQUFXLFFBQVEsR0FBRyxPQUFPLE1BQU0sR0FBRyxJQUFJLElBQ3BFLElBQUksV0FBVyxRQUFRLE1BQU0sS0FBSyxJQUN0QyxNQUFNLFdBQVcsUUFBUSxJQUFJO0dBQ3ZDO0dBQ0EsV0FBVyxTQUFTLEVBQUUsR0FBRyxXQUFXLE9BQU87RUFDL0MsT0FFSSxXQUFXLFNBQVM7RUFFeEIsT0FBTztDQUNYO0NBQ0EsTUFBTSxlQUFlLE9BQU8sRUFBRSxNQUFNLGdCQUFpQjtFQUNqRCxJQUFJLE1BQU0sVUFBVTtHQUNoQixNQUFNLFNBQVMsTUFBTSxNQUFNLFNBQVM7SUFDaEMsWUFBWTtJQUNaLFdBQVc7SUFDWDtJQUNBO0dBQ0osQ0FBQztHQUNELElBQUksU0FBUyxNQUFNLEdBQ2YsS0FBSyxNQUFNLE9BQU8sUUFBUTtJQUN0QixNQUFNLFFBQVEsT0FBTztJQUNyQixJQUFJLE9BQ0EsU0FBUyxHQUFHLGdCQUFnQixHQUFHLE9BQU87S0FDbEMsU0FBUyxTQUFTLE1BQU0sT0FBTyxJQUFJLE1BQU0sVUFBVTtLQUNuRCxNQUFNLE1BQU0sUUFBUSx1QkFBdUI7SUFDL0MsQ0FBQztHQUVUO1FBRUMsSUFBSSxTQUFTLE1BQU0sS0FBSyxDQUFDLFFBQzFCLFNBQVMsaUJBQWlCO0lBQ3RCLFNBQVMsVUFBVTtJQUNuQixNQUFNLHVCQUF1QjtHQUNqQyxDQUFDO1FBR0QsWUFBWSxlQUFlO0dBRS9CLE9BQU87RUFDWDtFQUNBLE9BQU87Q0FDWDtDQUNBLE1BQU0sMkJBQTJCLE9BQU8sRUFBRSxRQUFRLGdCQUFnQixNQUFNLFdBQVcsVUFBVTtFQUN6RixPQUFPO0VBQ1AsbUJBQW1CO0NBQ3ZCLFFBQVM7RUFDTCxJQUFJLE1BQU0sVUFBVTtHQUNoQixRQUFRLG9CQUFvQjtHQUs1QixJQUFJLENBQUMsTUFKZ0IsYUFBYTtJQUM5QjtJQUNBO0dBQ0osQ0FBQyxHQUNZO0lBQ1QsUUFBUSxRQUFRO0lBQ2hCLElBQUksZ0JBQ0EsT0FBTyxRQUFRO0dBRXZCO0VBQ0o7RUFDQSxLQUFLLE1BQU0sUUFBUSxRQUFRO0dBQ3ZCLE1BQU0sUUFBUSxPQUFPO0dBQ3JCLElBQUksT0FBTztJQUNQLE1BQU0sRUFBRSxJQUFJLEdBQUcsZUFBZTtJQUM5QixJQUFJLElBQUk7S0FDSixNQUFNLG1CQUFtQixPQUFPLE1BQU0sSUFBSSxHQUFHLElBQUk7S0FDakQsTUFBTSxvQkFBb0IsTUFBTSxNQUFNLHFCQUFxQixNQUFNLEVBQUU7S0FDbkUsTUFBTSwrQkFBK0IsZ0JBQWdCLG9CQUNqRCxnQkFBZ0IsZ0JBQ2hCLHlCQUF5QixvQkFDekIseUJBQXlCO0tBQzdCLElBQUkscUJBQXFCLDhCQUNyQixvQkFBb0IsQ0FBQyxHQUFHLElBQUksR0FBRyxJQUFJO0tBRXZDLE1BQU0sYUFBYSxNQUFNLGNBQWMsT0FBTyxPQUFPLFVBQVUsYUFBYSxrQ0FBa0MsU0FBUyw2QkFBNkIsQ0FBQyxnQkFBZ0IsZ0JBQWdCO0tBQ3JMLElBQUkscUJBQXFCLDhCQUNyQixvQkFBb0IsQ0FBQyxHQUFHLElBQUksQ0FBQztLQUVqQyxJQUFJLFdBQVcsR0FBRyxPQUFPO01BQ3JCLFFBQVEsUUFBUTtNQUNoQixJQUFJLGdCQUNBO0tBRVI7S0FDQSxDQUFDLG1CQUNJLElBQUksWUFBWSxHQUFHLElBQUksSUFDbEIsbUJBQ0ksMEJBQTBCLFdBQVcsUUFBUSxZQUFZLEdBQUcsSUFBSSxJQUNoRSxJQUFJLFdBQVcsUUFBUSxHQUFHLE1BQU0sV0FBVyxHQUFHLEtBQUssSUFDdkQsTUFBTSxXQUFXLFFBQVEsR0FBRyxJQUFJO0tBQzFDLElBQUksTUFBTSw2QkFBNkIsV0FBVyxHQUFHLE9BQ2pEO0lBRVI7SUFDQSxDQUFDLGNBQWMsVUFBVSxLQUNwQixNQUFNLHlCQUF5QjtLQUM1QjtLQUNBO0tBQ0EsUUFBUTtLQUNGO0tBQ047SUFDSixDQUFDO0dBQ1Q7RUFDSjtFQUNBLE9BQU8sUUFBUTtDQUNuQjtDQUNBLE1BQU0seUJBQXlCO0VBQzNCLEtBQUssTUFBTSxRQUFRLE9BQU8sU0FBUztHQUMvQixNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7R0FDL0IsVUFDSyxNQUFNLEdBQUcsT0FDSixNQUFNLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUN2QyxDQUFDLEtBQUssTUFBTSxHQUFHLEdBQUcsTUFDeEIsV0FBVyxJQUFJO0VBQ3ZCO0VBQ0EsT0FBTywwQkFBVSxJQUFJLElBQUk7Q0FDN0I7Q0FDQSxNQUFNLGFBQWEsTUFBTSxVQUFVLFFBQVEsUUFBUSxJQUFJLGFBQWEsTUFBTSxJQUFJLEdBQzFFLENBQUMsVUFBVSxPQUFPLFFBQVEsY0FBYyxnQkFBZ0IsY0FBYztDQUMxRSxNQUFNLGFBQWEsT0FBTyxjQUFjLGFBQWEsb0JBQW9CLE9BQU8sUUFBUSxFQUNwRixHQUFJLE9BQU8sUUFDTCxjQUNBLFlBQVksWUFBWSxJQUNwQixpQkFDQSxTQUFTLEtBQUssSUFDVixHQUFHLFFBQVEsYUFBYSxJQUN4QixhQUNsQixHQUFHLFVBQVUsWUFBWTtDQUN6QixNQUFNLGtCQUFrQixTQUFTLFFBQVEsSUFBSSxPQUFPLFFBQVEsY0FBYyxnQkFBZ0IsTUFBTSxTQUFTLG1CQUFtQixJQUFJLGdCQUFnQixNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0NBQy9KLE1BQU0saUJBQWlCLE1BQU0sT0FBTyxVQUFVLENBQUMsR0FBRyxZQUFZLE9BQU8sYUFBYSxVQUFVO0VBQ3hGLE1BQU0sUUFBUSxJQUFJLFNBQVMsSUFBSTtFQUMvQixJQUFJLGFBQWE7RUFDakIsSUFBSSxPQUFPO0dBQ1AsTUFBTSxpQkFBaUIsTUFBTTtHQUM3QixJQUFJLGdCQUFnQjtJQUNoQixDQUFDLGVBQWUsWUFDWixJQUFJLGFBQWEsTUFBTSxnQkFBZ0IsT0FBTyxjQUFjLENBQUM7SUFDakUsYUFDSSxjQUFjLGVBQWUsR0FBRyxLQUFLLGtCQUFrQixLQUFLLElBQ3RELEtBQ0E7SUFDVixJQUFJLGlCQUFpQixlQUFlLEdBQUcsR0FDbkMsQ0FBQyxHQUFHLGVBQWUsSUFBSSxPQUFPLENBQUMsQ0FBQyxTQUFTLGNBQWUsVUFBVSxXQUFXLFdBQVcsU0FBUyxVQUFVLEtBQUssQ0FBRTtTQUVqSCxJQUFJLGVBQWUsTUFDcEIsSUFBSSxnQkFBZ0IsZUFBZSxHQUFHLEdBQ2xDLGVBQWUsS0FBSyxTQUFTLGdCQUFnQjtLQUN6QyxJQUFJLENBQUMsWUFBWSxrQkFBa0IsQ0FBQyxZQUFZLFVBQzVDLElBQUksTUFBTSxRQUFRLFVBQVUsR0FDeEIsWUFBWSxVQUFVLENBQUMsQ0FBQyxXQUFXLE1BQU0sU0FBUyxTQUFTLFlBQVksS0FBSztVQUc1RSxZQUFZLFVBQ1IsZUFBZSxZQUFZLFNBQVMsQ0FBQyxDQUFDO0lBR3RELENBQUM7U0FHRCxlQUFlLEtBQUssU0FBUyxhQUFjLFNBQVMsVUFBVSxTQUFTLFVBQVUsVUFBVztTQUcvRixJQUFJLFlBQVksZUFBZSxHQUFHLEdBQ25DLGVBQWUsSUFBSSxRQUFRO1NBRTFCO0tBQ0QsZUFBZSxJQUFJLFFBQVE7S0FDM0IsSUFBSSxDQUFDLGVBQWUsSUFBSSxRQUFRLENBQUMsWUFDN0IsVUFBVSxNQUFNLEtBQUs7TUFDakI7TUFDQSxRQUFRLFlBQVksY0FBYyxZQUFZLFdBQVc7S0FDN0QsQ0FBQztJQUVUO0dBQ0o7RUFDSjtFQUNBLENBQUMsUUFBUSxlQUFlLFFBQVEsZ0JBQzVCLG9CQUFvQixNQUFNLFlBQVksUUFBUSxhQUFhLFFBQVEsYUFBYSxDQUFDLFVBQVU7RUFDL0YsUUFBUSxrQkFDSixRQUFRLE1BQU0sRUFDVixZQUFZLFFBQVEsV0FDeEIsQ0FBQztDQUNUO0NBQ0EsTUFBTSxrQkFBa0IsTUFBTSxPQUFPLFNBQVMsWUFBWSxPQUFPLGFBQWEsVUFBVTtFQUNwRixLQUFLLE1BQU0sWUFBWSxPQUFPO0dBQzFCLElBQUksQ0FBQyxNQUFNLGVBQWUsUUFBUSxHQUM5QjtHQUVKLE1BQU0sYUFBYSxNQUFNO0dBQ3pCLE1BQU0sWUFBWSxPQUFPLE1BQU07R0FDL0IsTUFBTSxRQUFRLElBQUksU0FBUyxTQUFTO0dBQ3BDLENBQUMsT0FBTyxNQUFNLElBQUksSUFBSSxLQUNsQixTQUFTLFVBQVUsS0FDbEIsU0FBUyxDQUFDLE1BQU0sT0FDakIsQ0FBQyxhQUFhLFVBQVUsSUFDdEIsZUFBZSxXQUFXLFlBQVksU0FBUyxXQUFXLFVBQVUsSUFDcEUsY0FBYyxXQUFXLFlBQVksU0FBUyxXQUFXLFVBQVU7RUFDN0U7Q0FDSjtDQUNBLE1BQU0sYUFBYSxNQUFNLE9BQU8sU0FBUyxXQUFXLGdCQUFnQixVQUFVO0VBQzFFLE1BQU0sUUFBUSxJQUFJLFNBQVMsSUFBSTtFQUMvQixNQUFNLGVBQWUsT0FBTyxNQUFNLElBQUksSUFBSTtFQUMxQyxNQUFNLGFBQWEsWUFBWSxRQUFRLFlBQVksS0FBSztFQUV4RCxNQUFNLG1CQUFtQixVQURILElBQUksYUFBYSxJQUNRLEdBQUcsVUFBVTtFQUM1RCxJQUFJLENBQUMsa0JBQ0QsSUFBSSxhQUFhLE1BQU0sVUFBVTtFQUVyQyxJQUFJLGNBQWM7R0FDZCxVQUFVLE1BQU0sS0FBSztJQUNqQjtJQUNBLFFBQVEsWUFBWSxjQUFjLFlBQVksV0FBVztHQUM3RCxDQUFDO0dBQ0QsS0FBSyxnQkFBZ0IsV0FDakIsZ0JBQWdCLGVBQ2hCLHlCQUF5QixXQUN6Qix5QkFBeUIsZ0JBQ3pCLFFBQVEsYUFBYTtJQUNyQixtQkFBbUI7SUFDbkIsSUFBSSxDQUFDLGVBQ0QsVUFBVSxNQUFNLEtBQUs7S0FDakI7S0FDQSxhQUFhLFdBQVc7S0FDeEIsU0FBUyxVQUFVLE1BQU0sVUFBVTtJQUN2QyxDQUFDO0dBRVQ7RUFDSixPQUNLO0dBQ0QsTUFBTSxVQUFXLE1BQU0sUUFBUSxVQUFVLEtBQUssQ0FBQyxXQUFXLFVBQ3RELGNBQWMsVUFBVTtHQUM1QixJQUFJLENBQUMsU0FBUyxNQUFNLE1BQU0sa0JBQWtCLFVBQVUsS0FBSyxTQUN2RCxjQUFjLE1BQU0sWUFBWSxTQUFTLFdBQVcsYUFBYTtRQUdqRSxlQUFlLE1BQU0sWUFBWSxTQUFTLFdBQVcsYUFBYTtFQUUxRTtFQUNBLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxlQUFlO0dBQ3JDLE1BQU0sVUFBVSxVQUFVLE1BQU0sTUFBTTtHQUN0QyxNQUFNLFNBQVMsWUFBWSxjQUFjLFlBQVksV0FBVztHQUNoRSxVQUFVLE1BQU0sS0FBSztJQUNqQixHQUFJLFdBQVc7SUFDZixNQUFNLE9BQU8sU0FBUyxVQUFVLE9BQU8sS0FBQTtJQUN2QztHQUNKLENBQUM7RUFDTDtDQUNKO0NBQ0EsTUFBTSxZQUFZLE1BQU0sT0FBTyxVQUFVLENBQUMsTUFBTSxVQUFVLE1BQU0sT0FBTyxTQUFTLEtBQUs7Q0FDckYsTUFBTSxhQUFhLFlBQVksVUFBVSxDQUFDLE1BQU07RUFDNUMsTUFBTSxvQkFBb0IsV0FBVyxVQUFVLElBQ3pDLFdBQVcsV0FBVyxJQUN0QjtFQUNOLElBQUksQ0FBQyxVQUFVLGFBQWEsaUJBQWlCLEdBQUc7R0FDNUMsY0FBYztJQUNWLEdBQUc7SUFDSCxHQUFHO0dBQ1A7R0FDQSxNQUFNLG1CQUFtQixRQUFRLGlCQUFpQjtHQUNsRCxLQUFLLE1BQU0sYUFBYSxPQUFPLE9BQzNCLElBQUksYUFBYSxrQkFDYixVQUFVLFdBQVcsaUJBQWlCLFlBQVksU0FBUyxNQUFNLElBQUk7R0FHN0UsVUFBVSxNQUFNLEtBQUs7SUFDakIsR0FBRztJQUNILE1BQU0sS0FBQTtJQUNOLE1BQU0sS0FBQTtJQUNOLEdBQUkseUJBQXlCLEVBQUUsUUFBUSxZQUFZLElBQUksQ0FBQztHQUM1RCxDQUFDO0dBQ0QsSUFBSSxRQUFRLGdCQUNSLFVBQVU7RUFFbEI7Q0FDSjtDQUNBLE1BQU0sV0FBVyxPQUFPLFVBQVU7RUFDOUIsT0FBTyxRQUFRO0VBQ2YsTUFBTSxTQUFTLE1BQU07RUFDckIsSUFBSSxPQUFPLE9BQU87RUFDbEIsSUFBSSxzQkFBc0I7RUFDMUIsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0VBQy9CLE1BQU0sOEJBQThCLGVBQWU7R0FDL0Msc0JBQ0ksT0FBTyxNQUFNLFVBQVUsS0FDbEIsYUFBYSxVQUFVLEtBQUssTUFBTSxXQUFXLFFBQVEsQ0FBQyxLQUN2RCxVQUFVLFlBQVksSUFBSSxhQUFhLE1BQU0sVUFBVSxDQUFDO0VBQ3BFO0VBQ0EsSUFBSSxPQUFPO0dBQ1AsSUFBSTtHQUNKLElBQUk7R0FDSixNQUFNLGFBQWEsT0FBTyxPQUNwQixjQUFjLE1BQU0sRUFBRSxJQUN0QixjQUFjLEtBQUs7R0FDekIsTUFBTSxjQUFjLE1BQU0sU0FBUyxPQUFPLFFBQVEsTUFBTSxTQUFTLE9BQU87R0FDeEUsTUFBTSx3QkFBd0IsQ0FBQyxjQUFjLE1BQU0sRUFBRSxLQUNqRCxDQUFDLE1BQU0sWUFDUCxDQUFDLFNBQVMsWUFDVixDQUFDLElBQUksV0FBVyxRQUFRLElBQUksS0FDNUIsQ0FBQyxNQUFNLEdBQUc7R0FDZCxNQUFNLHVCQUF1Qix5QkFDekIsZUFBZSxhQUFhLElBQUksV0FBVyxlQUFlLElBQUksR0FBRyxXQUFXLGFBQWEsNEJBQTRCLDJCQUEyQjtHQUNwSixNQUFNLFVBQVUsVUFBVSxNQUFNLFFBQVEsV0FBVztHQUNuRCxJQUFJLGFBQWEsTUFBTSxVQUFVO0dBQ2pDLElBQUk7UUFDSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLFVBQVU7S0FDN0IsTUFBTSxHQUFHLFVBQVUsTUFBTSxHQUFHLE9BQU8sS0FBSztLQUN4QyxNQUFNLG9CQUFvQixvQkFBb0I7S0FDOUMscUJBQXFCLGtCQUFrQixDQUFDO0lBQzVDO1VBRUMsSUFBSSxNQUFNLEdBQUcsVUFDZCxNQUFNLEdBQUcsU0FBUyxLQUFLO0dBRTNCLE1BQU0sYUFBYSxvQkFBb0IsTUFBTSxZQUFZLFdBQVc7R0FDcEUsTUFBTSxlQUFlLENBQUMsY0FBYyxVQUFVLEtBQUs7R0FDbkQsQ0FBQyxlQUNHLFVBQVUsTUFBTSxLQUFLO0lBQ2pCO0lBQ0EsTUFBTSxNQUFNO0lBQ1osR0FBSSx5QkFDRSxFQUFFLFFBQVEsWUFBWSxXQUFXLEVBQUUsSUFDbkMsQ0FBQztHQUNYLENBQUM7R0FDTCxJQUFJLHNCQUFzQjtJQUN0QixLQUFLLENBQUMseUJBQXlCLENBQUMsV0FBVyxhQUN0QyxnQkFBZ0IsV0FBVyx5QkFBeUI7U0FDakQsU0FBUyxTQUFTO1VBQ2QsYUFDQSxVQUFVO0tBQUEsT0FHYixJQUFJLENBQUMsYUFDTixVQUFVO0lBQUE7SUFHbEIsT0FBUSxnQkFDSixVQUFVLE1BQU0sS0FBSztLQUFFO0tBQU0sR0FBSSxVQUFVLENBQUMsSUFBSTtJQUFZLENBQUM7R0FDckU7R0FDQSxJQUFJLENBQUMsU0FBUyxZQUFZLE1BQU0sVUFDNUIsTUFBTSxhQUFhO0lBQ1Q7SUFDTixXQUFXLE1BQU07R0FDckIsQ0FBQztHQUVMLENBQUMsZUFBZSxXQUFXLFVBQVUsTUFBTSxLQUFLLEVBQUUsR0FBRyxXQUFXLENBQUM7R0FDakUsSUFBSSxTQUFTLFVBQVU7SUFDbkIsTUFBTSxFQUFFLFdBQVcsTUFBTSxXQUFXLENBQUMsSUFBSSxDQUFDO0lBQzFDLG9CQUFvQixDQUFDLElBQUksQ0FBQztJQUMxQiwyQkFBMkIsVUFBVTtJQUNyQyxJQUFJLENBQUMscUJBQXFCO0tBQ3RCLENBQUMsY0FBYyxVQUFVLEtBQUssVUFBVSxNQUFNLEtBQUssVUFBVTtLQUM3RDtJQUNKO0lBQ0EsTUFBTSw0QkFBNEIsa0JBQWtCLFdBQVcsUUFBUSxTQUFTLElBQUk7SUFDcEYsTUFBTSxvQkFBb0Isa0JBQWtCLFFBQVEsU0FBUywwQkFBMEIsUUFBUSxJQUFJO0lBQ25HLFFBQVEsa0JBQWtCO0lBQzFCLE9BQU8sa0JBQWtCO0lBQ3pCLFVBQVUsY0FBYyxNQUFNO0dBQ2xDLE9BQ0s7SUFDRCxvQkFBb0IsQ0FBQyxJQUFJLEdBQUcsSUFBSTtJQUNoQyxTQUFTLE1BQU0sY0FBYyxPQUFPLE9BQU8sVUFBVSxhQUFhLGtDQUFrQyxTQUFTLHlCQUF5QixFQUFBLENBQUc7SUFDekksb0JBQW9CLENBQUMsSUFBSSxDQUFDO0lBQzFCLDJCQUEyQixVQUFVO0lBQ3JDLElBQUk7U0FDSSxPQUNBLFVBQVU7VUFFVCxJQUFJLGdCQUFnQixXQUNyQix5QkFBeUIsU0FDekIsVUFBVSxNQUFNLHlCQUF5QjtNQUNyQyxRQUFRO01BQ1IsZ0JBQWdCO01BQ1Y7TUFDTixXQUFXLE1BQU07S0FDckIsQ0FBQztJQUFBO0dBR2I7R0FDQSxJQUFJLHFCQUFxQjtJQUNyQixNQUFNLEdBQUcsU0FDSixDQUFDLE1BQU0sUUFBUSxNQUFNLEdBQUcsSUFBSSxLQUFLLE1BQU0sR0FBRyxLQUFLLFNBQVMsTUFDekQsUUFBUSxNQUFNLEdBQUcsSUFBSTtJQUN6QixvQkFBb0IsTUFBTSxTQUFTLE9BQU8sVUFBVTtHQUN4RDtFQUNKO0NBQ0o7Q0FDQSxNQUFNLGVBQWUsS0FBSyxRQUFRO0VBQzlCLElBQUksSUFBSSxXQUFXLFFBQVEsR0FBRyxLQUFLLElBQUksT0FBTztHQUMxQyxJQUFJLE1BQU07R0FDVixPQUFPO0VBQ1g7Q0FFSjtDQUNBLE1BQU0sVUFBVSxPQUFPLE1BQU0sVUFBVSxDQUFDLE1BQU07RUFDMUMsSUFBSTtFQUNKLElBQUk7RUFDSixNQUFNLGFBQWEsc0JBQXNCLElBQUk7RUFDN0MsSUFBSSxTQUFTLFVBQVU7R0FDbkIsTUFBTSxTQUFTLE1BQU0sNEJBQTRCLFlBQVksSUFBSSxJQUFJLE9BQU8sVUFBVTtHQUN0RixVQUFVLGNBQWMsTUFBTTtHQUM5QixtQkFBbUIsT0FDYixDQUFDLFdBQVcsTUFBTSxTQUFTLElBQUksUUFBUSxJQUFJLENBQUMsSUFDNUM7RUFDVixPQUNLLElBQUksTUFBTTtHQUNYLG9CQUFvQixNQUFNLFFBQVEsSUFBSSxXQUFXLElBQUksT0FBTyxjQUFjO0lBQ3RFLE1BQU0sUUFBUSxJQUFJLFNBQVMsU0FBUztJQUNwQyxPQUFPLE1BQU0seUJBQXlCO0tBQ2xDLFFBQVEsU0FBUyxNQUFNLEtBQUssR0FBRyxZQUFZLE1BQU0sSUFBSTtLQUNyRCxXQUFXLE9BQU87SUFDdEIsQ0FBQztHQUNMLENBQUMsQ0FBQyxFQUFBLENBQUcsTUFBTSxPQUFPO0dBQ2xCLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQyxXQUFXLFlBQVksVUFBVTtFQUM3RCxPQUVJLG1CQUFtQixVQUFVLE1BQU0seUJBQXlCO0dBQ3hELFFBQVE7R0FDUjtHQUNBLFdBQVcsT0FBTztFQUN0QixDQUFDO0VBRUwsSUFBSSxRQUFRLGNBQWMsU0FBUyxjQUFjLFNBQVMsSUFBSSxHQUFHO0dBQzdELE1BQU0sUUFBUSxJQUFJLFdBQVcsUUFBUSxJQUFJO0dBQ3pDLElBQUksT0FBTztJQUNQLE1BQU0sV0FBVyxRQUFRLElBQUk7SUFDN0Isb0JBQW9CLFFBQVEsU0FBUyxZQUFZLGFBQWEsTUFBTSxLQUFLLENBQUM7SUFDMUUsb0JBQW9CLEtBQUssQ0FBQyxTQUFTLFVBQVU7R0FDakQsT0FDSztJQUNELGFBQWEsT0FBTyxLQUFLO0lBQ3pCLE9BQU8sb0JBQW9CO0dBQy9CO0VBQ0o7RUFDQSxVQUFVLE1BQU0sS0FBSztHQUNqQixHQUFJLENBQUMsU0FBUyxJQUFJLE1BQ1osZ0JBQWdCLFdBQVcseUJBQXlCLFlBQ2xELFlBQVksV0FBVyxVQUN6QixDQUFDLElBQ0QsRUFBRSxLQUFLO0dBQ2IsR0FBSSxTQUFTLFlBQVksQ0FBQyxPQUFPLEVBQUUsUUFBUSxJQUFJLENBQUM7R0FDaEQsUUFBUSxXQUFXO0VBQ3ZCLENBQUM7RUFDRCxRQUFRLGVBQ0osQ0FBQyxvQkFDRCxzQkFBc0IsU0FBUyxhQUFhLE9BQU8sYUFBYSxPQUFPLEtBQUs7RUFDaEYsT0FBTztDQUNYO0NBQ0EsTUFBTSxhQUFhLFlBQVksV0FBVztFQUN0QyxJQUFJLFNBQVMsRUFDVCxHQUFJLE9BQU8sUUFBUSxjQUFjLGVBQ3JDO0VBQ0EsSUFBSSxRQUNBLFNBQVMsa0JBQWtCLE9BQU8sY0FBYyxXQUFXLGNBQWMsV0FBVyxlQUFlLE1BQU07RUFFN0csT0FBTyxZQUFZLFVBQVUsSUFDdkIsU0FDQSxTQUFTLFVBQVUsSUFDZixJQUFJLFFBQVEsVUFBVSxJQUN0QixXQUFXLEtBQUssU0FBUyxJQUFJLFFBQVEsSUFBSSxDQUFDO0NBQ3hEO0NBQ0EsTUFBTSxpQkFBaUIsTUFBTSxlQUFlO0VBQ3hDLFNBQVMsQ0FBQyxDQUFDLEtBQUssYUFBYSxXQUFBLENBQVksUUFBUSxJQUFJO0VBQ3JELFNBQVMsQ0FBQyxDQUFDLEtBQUssYUFBYSxXQUFBLENBQVksYUFBYSxJQUFJO0VBQzFELE9BQU8sS0FBSyxhQUFhLFdBQUEsQ0FBWSxRQUFRLElBQUk7RUFDakQsY0FBYyxDQUFDLENBQUMsSUFBSSxXQUFXLGtCQUFrQixJQUFJO0VBQ3JELFdBQVcsQ0FBQyxDQUFDLEtBQUssYUFBYSxXQUFBLENBQVksZUFBZSxJQUFJO0NBQ2xFO0NBQ0EsTUFBTSxlQUFlLFNBQVM7RUFDMUIsTUFBTSxRQUFRLE9BQU8sc0JBQXNCLElBQUksSUFBSSxLQUFBO0VBQ25ELFVBQVUsUUFBUSxVQUFVLEtBQUssS0FBYSxNQUFNLFNBQVMsY0FBYyxNQUFNLFdBQVcsUUFBUSxTQUFTLENBQUM7RUFDOUcsSUFBSSxPQUNBLE1BQU0sU0FBUyxjQUFjO0dBQ3pCLFVBQVUsTUFBTSxLQUFLO0lBQ2pCLE1BQU07SUFDTixRQUFRLFdBQVc7R0FDdkIsQ0FBQztFQUNMLENBQUM7T0FHRCxVQUFVLE1BQU0sS0FBSyxFQUNqQixRQUFRLENBQUMsRUFDYixDQUFDO0NBRVQ7Q0FDQSxNQUFNLFlBQVksTUFBTSxPQUFPLFlBQVk7RUFDdkMsTUFBTSxPQUFPLElBQUksU0FBUyxNQUFNLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUEsQ0FBRztFQUV0RCxNQUFNLEVBQUUsS0FBSyxZQUFZLFNBQVMsTUFBTSxHQUFHLG9CQUR0QixJQUFJLFdBQVcsUUFBUSxJQUFJLEtBQUssQ0FBQztFQUV0RCxJQUFJLFdBQVcsUUFBUSxNQUFNO0dBQ3pCLEdBQUc7R0FDSCxHQUFHO0dBQ0g7RUFDSixDQUFDO0VBQ0QsVUFBVSxNQUFNLEtBQUs7R0FDakI7R0FDQSxRQUFRLFdBQVc7R0FDbkIsU0FBUztFQUNiLENBQUM7RUFDRCxXQUFXLFFBQVEsZUFBZSxPQUFPLElBQUksU0FBUyxJQUFJLE1BQU07Q0FDcEU7Q0FDQSxNQUFNLFNBQVMsTUFBTSxpQkFBaUI7RUFDbEMsSUFBSSxXQUFXLElBQUksR0FBRztHQUNsQjtHQUNBLE1BQU0sRUFBRSxnQkFBZ0IsVUFBVSxNQUFNLFVBQVUsRUFDOUMsT0FBTyxZQUFZLFlBQVksV0FDM0IsS0FBSyxRQUFRLFVBQVUsVUFBVSxLQUFBLEdBQVcsWUFBWSxHQUFHLE9BQU8sRUFDMUUsQ0FBQztHQUNELElBQUksU0FBUztHQUNiLE9BQU8sRUFDSCxtQkFBbUI7SUFDZixJQUFJLFFBQ0E7SUFFSixTQUFTO0lBQ1Q7SUFDQSxZQUFZO0dBQ2hCLEVBQ0o7RUFDSjtFQUNBLE9BQU8sVUFBVSxNQUFNLGNBQWMsSUFBSTtDQUM3QztDQUNBLE1BQU0sY0FBYyxVQUFVO0VBQzFCLElBQUk7RUFDSixNQUFNLGNBQWMsQ0FBQyxHQUFHLEtBQUssTUFBTSxlQUFlLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUc7RUFDdEYsSUFBSSxhQUNBO0VBRUosTUFBTSxFQUFFLGdCQUFnQixVQUFVLE1BQU0sVUFBVSxFQUM5QyxPQUFPLGNBQWM7R0FDakIsSUFBSSxzQkFBc0IsTUFBTSxNQUFNLFVBQVUsTUFBTSxNQUFNLEtBQUssS0FDN0Qsc0JBQXNCLFdBQVcsTUFBTSxhQUFhLGlCQUFpQixlQUFlLE1BQU0sWUFBWSxHQUFHO0lBQ3pHLE1BQU0sV0FBVyxFQUFFLEdBQUcsWUFBWTtJQUNsQyxNQUFNLFNBQVM7S0FDWCxRQUFRO0tBQ1IsR0FBRztLQUNILEdBQUc7S0FDSCxlQUFlO0lBQ25CLENBQUM7R0FDTDtFQUNKLEVBQ0osQ0FBQztFQUNELElBQUksQ0FBQyxhQUNELE9BQU87RUFFWCxJQUFJLFNBQVM7RUFDYixhQUFhO0dBQ1QsSUFBSSxRQUNBO0dBRUosU0FBUztHQUNUO0dBQ0EsWUFBWTtFQUNoQjtDQUNKO0NBQ0EsTUFBTSxhQUFhLFVBQVU7RUFDekIsT0FBTyxRQUFRO0VBQ2YsMkJBQTJCO0dBQ3ZCLEdBQUc7R0FDSCxHQUFHLE1BQU07RUFDYjtFQUNBLE9BQU8sV0FBVztHQUNkLEdBQUc7R0FDSCxXQUFXO0lBQ1AsR0FBRztJQUNILEdBQUcsTUFBTTtHQUNiO0VBQ0osQ0FBQztDQUNMO0NBQ0EsTUFBTSxjQUFjLE1BQU0sVUFBVSxDQUFDLE1BQU07RUFDdkMsS0FBSyxNQUFNLGFBQWEsT0FBTyxzQkFBc0IsSUFBSSxJQUFJLE9BQU8sT0FBTztHQUN2RSxPQUFPLE1BQU0sT0FBTyxTQUFTO0dBQzdCLE9BQU8sTUFBTSxPQUFPLFNBQVM7R0FDN0IsSUFBSSxDQUFDLFFBQVEsV0FBVztJQUNwQixNQUFNLFNBQVMsU0FBUztJQUN4QixNQUFNLGFBQWEsU0FBUztHQUNoQztHQUNBLENBQUMsUUFBUSxhQUFhLE1BQU0sV0FBVyxRQUFRLFNBQVM7R0FDeEQsQ0FBQyxRQUFRLGFBQWEsTUFBTSxXQUFXLGFBQWEsU0FBUztHQUM3RCxDQUFDLFFBQVEsZUFBZSxNQUFNLFdBQVcsZUFBZSxTQUFTO0dBQ2pFLENBQUMsUUFBUSxvQkFDTCxNQUFNLFdBQVcsa0JBQWtCLFNBQVM7R0FDaEQsQ0FBQyxTQUFTLG9CQUNOLENBQUMsUUFBUSxvQkFDVCxNQUFNLGdCQUFnQixTQUFTO0VBQ3ZDO0VBQ0EsVUFBVSxNQUFNLEtBQUssRUFDakIsUUFBUSxZQUFZLFdBQVcsRUFDbkMsQ0FBQztFQUNELFVBQVUsTUFBTSxLQUFLO0dBQ2pCLEdBQUc7R0FDSCxHQUFJLENBQUMsUUFBUSxZQUFZLENBQUMsSUFBSSxFQUFFLFNBQVMsVUFBVSxFQUFFO0VBQ3pELENBQUM7RUFDRCxDQUFDLFFBQVEsZUFBZSxVQUFVO0NBQ3RDO0NBQ0EsTUFBTSxxQkFBcUIsRUFBRSxVQUFVLFdBQVk7RUFDL0MsSUFBSyxVQUFVLFFBQVEsS0FBSyxPQUFPLFNBQy9CLENBQUMsQ0FBQyxZQUNGLE9BQU8sU0FBUyxJQUFJLElBQUksR0FBRztHQUczQixNQUFNLHVCQUZjLE9BQU8sU0FBUyxJQUFJLElBRUQsTUFBTSxDQUR6QixDQUFDO0dBRXJCLFdBQVcsT0FBTyxTQUFTLElBQUksSUFBSSxJQUFJLE9BQU8sU0FBUyxPQUFPLElBQUk7R0FDbEUsd0JBQXdCLE9BQU8sU0FBUyxDQUFDLE9BQU8sVUFBVSxVQUFVO0VBQ3hFO0NBQ0o7Q0FDQSxNQUFNLFlBQVksTUFBTSxVQUFVLENBQUMsTUFBTTtFQUNyQyxJQUFJLFFBQVEsSUFBSSxTQUFTLElBQUk7RUFDN0IsTUFBTSxvQkFBb0IsVUFBVSxRQUFRLFFBQVEsS0FBSyxVQUFVLFNBQVMsUUFBUTtFQUNwRixNQUFNLDBCQUEwQixDQUFDLE9BQU8sYUFBYSxJQUFJLElBQUksS0FBSyxTQUFTLE1BQU0sTUFBTSxDQUFDLE1BQU0sR0FBRztFQUNqRyxJQUFJLFNBQVMsTUFBTTtHQUNmLEdBQUksU0FBUyxDQUFDO0dBQ2QsSUFBSTtJQUNBLEdBQUksU0FBUyxNQUFNLEtBQUssTUFBTSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRTtJQUNuRDtJQUNBLE9BQU87SUFDUCxHQUFHO0dBQ1A7RUFDSixDQUFDO0VBQ0QsT0FBTyxNQUFNLElBQUksSUFBSTtFQUNyQixJQUFJLFNBQVMsQ0FBQyx5QkFDVixrQkFBa0I7R0FDZCxVQUFVLFVBQVUsUUFBUSxRQUFRLElBQzlCLFFBQVEsV0FDUixTQUFTO0dBQ2Y7RUFDSixDQUFDO09BR0Qsb0JBQW9CLE1BQU0sTUFBTSxRQUFRLEtBQUs7RUFFakQsT0FBTztHQUNILEdBQUksb0JBQ0UsRUFBRSxVQUFVLFFBQVEsWUFBWSxTQUFTLFNBQVMsSUFDbEQsQ0FBQztHQUNQLEdBQUksU0FBUyxjQUNQO0lBQ0UsVUFBVSxDQUFDLENBQUMsUUFBUTtJQUNwQixLQUFLLGFBQWEsUUFBUSxHQUFHO0lBQzdCLEtBQUssYUFBYSxRQUFRLEdBQUc7SUFDN0IsV0FBVyxhQUFhLFFBQVEsU0FBUztJQUN6QyxXQUFXLGFBQWEsUUFBUSxTQUFTO0lBQ3pDLFNBQVMsYUFBYSxRQUFRLE9BQU87R0FDekMsSUFDRSxDQUFDO0dBQ1A7R0FDQTtHQUNBLFFBQVE7R0FDUixNQUFNLFFBQVE7SUFDVixJQUFJLEtBQUs7S0FDTCxPQUFPLGFBQWEsSUFBSSxJQUFJO0tBQzVCLFNBQVMsTUFBTSxPQUFPO0tBQ3RCLE9BQU8sYUFBYSxPQUFPLElBQUk7S0FDL0IsUUFBUSxJQUFJLFNBQVMsSUFBSTtLQUN6QixNQUFNLFdBQVcsWUFBWSxJQUFJLEtBQUssSUFDaEMsSUFBSSxtQkFDQSxJQUFJLGlCQUFpQix1QkFBdUIsQ0FBQyxDQUFDLE1BQU0sTUFDcEQsTUFDSjtLQUNOLE1BQU0sa0JBQWtCLGtCQUFrQixRQUFRO0tBQ2xELE1BQU0sT0FBTyxNQUFNLEdBQUcsUUFBUSxDQUFDO0tBQy9CLElBQUksa0JBQ0UsS0FBSyxNQUFNLFdBQVcsV0FBVyxRQUFRLElBQ3pDLGFBQWEsTUFBTSxHQUFHLEtBQ3hCO0tBRUosSUFBSSxTQUFTLE1BQU0sRUFDZixJQUFJO01BQ0EsR0FBRyxNQUFNO01BQ1QsR0FBSSxrQkFDRTtPQUNFLE1BQU07UUFDRixHQUFHLEtBQUssT0FBTyxJQUFJO1FBQ25CO1FBQ0EsR0FBSSxNQUFNLFFBQVEsSUFBSSxnQkFBZ0IsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO09BQzNEO09BQ0EsS0FBSztRQUFFLE1BQU0sU0FBUztRQUFNO09BQUs7TUFDckMsSUFDRSxFQUFFLEtBQUssU0FBUztLQUMxQixFQUNKLENBQUM7S0FDRCxvQkFBb0IsTUFBTSxPQUFPLEtBQUEsR0FBVyxRQUFRO0lBQ3hELE9BQ0s7S0FDRCxRQUFRLElBQUksU0FBUyxNQUFNLENBQUMsQ0FBQztLQUM3QixJQUFJLE1BQU0sSUFDTixNQUFNLEdBQUcsUUFBUTtLQUVyQixDQUFDLFNBQVMsb0JBQW9CLFFBQVEscUJBQ2xDLEVBQUUsbUJBQW1CLE9BQU8sT0FBTyxJQUFJLEtBQUssT0FBTyxXQUNuRCxPQUFPLFFBQVEsSUFBSSxJQUFJO0lBQy9CO0dBQ0o7RUFDSjtDQUNKO0NBQ0EsTUFBTSxvQkFBb0IsU0FBUyxvQkFDL0IsQ0FBQyxTQUFTLDZCQUNWLHNCQUFzQixTQUFTLGFBQWEsT0FBTyxLQUFLO0NBQzVELE1BQU0sZ0JBQWdCLGFBQWE7RUFDL0IsSUFBSSxVQUFVLFFBQVEsR0FBRztHQUNyQixVQUFVLE1BQU0sS0FBSyxFQUFFLFNBQVMsQ0FBQztHQUNqQyxzQkFBc0IsVUFBVSxLQUFLLFNBQVM7SUFDMUMsTUFBTSxlQUFlLElBQUksU0FBUyxJQUFJO0lBQ3RDLElBQUksY0FBYztLQUNkLElBQUksV0FBVyxhQUFhLEdBQUcsWUFBWTtLQUMzQyxJQUFJLE1BQU0sUUFBUSxhQUFhLEdBQUcsSUFBSSxHQUNsQyxhQUFhLEdBQUcsS0FBSyxTQUFTLGFBQWE7TUFDdkMsU0FBUyxXQUFXLGFBQWEsR0FBRyxZQUFZO0tBQ3BELENBQUM7SUFFVDtHQUNKLEdBQUcsR0FBRyxLQUFLO0VBQ2Y7Q0FDSjtDQUNBLE1BQU0sZ0JBQWdCLFNBQVMsY0FBYyxPQUFPLE1BQU07RUFDdEQsSUFBSSxlQUFlLEtBQUE7RUFDbkIsSUFBSSxHQUFHO0dBQ0gsRUFBRSxrQkFBa0IsRUFBRSxlQUFlO0dBQ3JDLEVBQUUsV0FDRSxFQUFFLFFBQVE7RUFDbEI7RUFDQSxJQUFJLGNBQWMsWUFBWSxXQUFXO0VBQ3pDLFVBQVUsTUFBTSxLQUFLLEVBQ2pCLGNBQWMsS0FDbEIsQ0FBQztFQUNELElBQUksU0FBUyxVQUFVO0dBQ25CLE1BQU0sRUFBRSxRQUFRLFdBQVcsTUFBTSxXQUFXO0dBQzVDLG9CQUFvQjtHQUNwQixXQUFXLFNBQVM7R0FDcEIsY0FBYyxZQUFZLE1BQU07RUFDcEMsT0FFSSxNQUFNLHlCQUF5QjtHQUMzQixRQUFRO0dBQ1IsV0FBVyxPQUFPO0VBQ3RCLENBQUM7RUFFTCxJQUFJLE9BQU8sU0FBUyxNQUNoQixLQUFLLE1BQU0sUUFBUSxPQUFPLFVBQ3RCLE1BQU0sYUFBYSxJQUFJO0VBRy9CLE1BQU0sV0FBVyxRQUFRLGVBQWU7RUFDeEMsSUFBSSxjQUFjLFdBQVcsTUFBTSxHQUFHO0dBQ2xDLFVBQVUsTUFBTSxLQUFLLEVBQ2pCLFFBQVEsQ0FBQyxFQUNiLENBQUM7R0FDRCxJQUFJO0lBQ0EsTUFBTSxRQUFRLGFBQWEsQ0FBQztHQUNoQyxTQUNPLE9BQU87SUFDVixlQUFlO0dBQ25CO0VBQ0osT0FDSztHQUNELElBQUksV0FDQSxNQUFNLFVBQVUsRUFBRSxHQUFHLFdBQVcsT0FBTyxHQUFHLENBQUM7R0FFL0MsWUFBWTtHQUNaLFdBQVcsV0FBVztFQUMxQjtFQUNBLFVBQVUsTUFBTSxLQUFLO0dBQ2pCLGFBQWE7R0FDYixjQUFjO0dBQ2Qsb0JBQW9CLGNBQWMsV0FBVyxNQUFNLEtBQUssQ0FBQztHQUN6RCxhQUFhLFdBQVcsY0FBYztHQUN0QyxRQUFRLFdBQVc7RUFDdkIsQ0FBQztFQUNELElBQUksY0FDQSxNQUFNO0NBRWQ7Q0FDQSxNQUFNLGNBQWMsTUFBTSxVQUFVLENBQUMsTUFBTTtFQUN2QyxJQUFJLElBQUksU0FBUyxJQUFJLEdBQUc7R0FDcEIsSUFBSSxZQUFZLFFBQVEsWUFBWSxHQUNoQyxTQUFTLE1BQU0sWUFBWSxJQUFJLGdCQUFnQixJQUFJLENBQUMsQ0FBQztRQUVwRDtJQUNELFNBQVMsTUFBTSxRQUFRLFlBQVk7SUFDbkMsSUFBSSxnQkFBZ0IsTUFBTSxZQUFZLFFBQVEsWUFBWSxDQUFDO0dBQy9EO0dBQ0EsSUFBSSxDQUFDLFFBQVEsYUFDVCxNQUFNLFdBQVcsZUFBZSxJQUFJO0dBRXhDLElBQUksQ0FBQyxRQUFRLFdBQVc7SUFDcEIsTUFBTSxXQUFXLGFBQWEsSUFBSTtJQUNsQyxXQUFXLFVBQVUsUUFBUSxlQUN2QixVQUFVLE1BQU0sWUFBWSxJQUFJLGdCQUFnQixJQUFJLENBQUMsQ0FBQyxJQUN0RCxVQUFVO0dBQ3BCO0dBQ0EsSUFBSSxDQUFDLFFBQVEsV0FBVztJQUNwQixNQUFNLFdBQVcsUUFBUSxJQUFJO0lBQzdCLGdCQUFnQixXQUFXLFVBQVU7R0FDekM7R0FDQSxVQUFVLE1BQU0sS0FBSyxFQUFFLEdBQUcsV0FBVyxDQUFDO0VBQzFDO0NBQ0o7Q0FDQSxNQUFNLFVBQVUsWUFBWSxtQkFBbUIsQ0FBQyxNQUFNO0VBQ2xELE1BQU0sZ0JBQWdCLGFBQWEsWUFBWSxVQUFVLElBQUk7RUFDN0QsTUFBTSxxQkFBcUIsWUFBWSxhQUFhO0VBQ3BELE1BQU0scUJBQXFCLGNBQWMsVUFBVTtFQUNuRCxNQUFNLFNBQVM7RUFDZixNQUFNLFlBQVk7RUFDbEIsSUFBSSxDQUFDLGlCQUFpQixtQkFDbEIsaUJBQWlCO0VBRXJCLElBQUksQ0FBQyxpQkFBaUIsWUFBWTtHQUM5QixJQUFJLGlCQUFpQixpQkFBaUI7SUFDbEMsTUFBTSxnQ0FBZ0IsSUFBSSxJQUFJLENBQzFCLEdBQUcsT0FBTyxPQUNWLEdBQUcsT0FBTyxLQUFLLGVBQWUsZ0JBQWdCLGFBQWEsS0FBQSxHQUFXLFNBQVMsQ0FBQyxDQUNwRixDQUFDO0lBQ0QsS0FBSyxNQUFNLGFBQWEsTUFBTSxLQUFLLGFBQWEsR0FBRztLQUMvQyxNQUFNLFVBQVUsSUFBSSxXQUFXLGFBQWEsU0FBUztLQUNyRCxNQUFNLGdCQUFnQixJQUFJLGFBQWEsU0FBUztLQUNoRCxNQUFNLFdBQVcsSUFBSSxRQUFRLFNBQVM7S0FDdEMsSUFBSSxXQUFXLENBQUMsWUFBWSxhQUFhLEdBQ3JDLElBQUksUUFBUSxXQUFXLGFBQWE7VUFFbkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLFFBQVEsR0FDdEMsU0FBUyxXQUFXLFFBQVE7SUFFcEM7R0FDSixPQUNLO0lBQ0QsSUFBSSxTQUFTLFlBQVksVUFBVSxHQUMvQixLQUFLLE1BQU0sUUFBUSxPQUFPLE9BQU87S0FDN0IsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0tBQy9CLElBQUksU0FBUyxNQUFNLElBQUk7TUFDbkIsTUFBTSxpQkFBaUIsTUFBTSxRQUFRLE1BQU0sR0FBRyxJQUFJLElBQzVDLE1BQU0sR0FBRyxLQUFLLEtBQ2QsTUFBTSxHQUFHO01BQ2YsSUFBSSxjQUFjLGNBQWMsR0FBRztPQUMvQixNQUFNLE9BQU8sZUFBZSxRQUFRLE1BQU07T0FDMUMsSUFBSSxNQUFNO1FBQ04sS0FBSyxNQUFNO1FBQ1g7T0FDSjtNQUNKO0tBQ0o7SUFDSjtJQUVKLElBQUksaUJBQWlCLGVBQ2pCLEtBQUssTUFBTSxhQUFhLE9BQU8sT0FDM0IsU0FBUyxXQUFXLElBQUksUUFBUSxTQUFTLENBQUM7U0FJOUMsVUFBVSxDQUFDO0dBRW5CO0dBQ0EsSUFBSSxTQUFTLGtCQUFrQjtJQUMzQixjQUFjLGlCQUFpQixvQkFDekIsWUFBWSxjQUFjLElBQzFCLENBQUM7SUFDUCxJQUFJLGlCQUFpQixlQUNqQixLQUFLLE1BQU0sYUFBYSxPQUFPLE9BQzNCLElBQUksYUFBYSxXQUFXLElBQUksUUFBUSxTQUFTLENBQUM7R0FHOUQsT0FFSSxjQUFjLFlBQVksTUFBTTtHQUVwQyxVQUFVLE1BQU0sS0FBSyxFQUNqQixRQUFRLEVBQUUsR0FBRyxPQUFPLEVBQ3hCLENBQUM7R0FDRCxVQUFVLE1BQU0sS0FBSztJQUNqQixNQUFNLEtBQUE7SUFDTixNQUFNLEtBQUE7SUFDTixRQUFRLEVBQUUsR0FBRyxPQUFPO0dBQ3hCLENBQUM7RUFDTDtFQUNBLFNBQVM7R0FDTCxPQUFPLGlCQUFpQixrQkFBa0IsT0FBTyx3QkFBUSxJQUFJLElBQUk7R0FDakUseUJBQVMsSUFBSSxJQUFJO0dBQ2pCLHVCQUFPLElBQUksSUFBSTtHQUNmLDhCQUFjLElBQUksSUFBSTtHQUN0QiwwQkFBVSxJQUFJLElBQUk7R0FDbEIsdUJBQU8sSUFBSSxJQUFJO0dBQ2YsVUFBVTtHQUNWLE9BQU87RUFDWDtFQUNBLE9BQU8sUUFDSCxDQUFDLGdCQUFnQixXQUNiLENBQUMsQ0FBQyxpQkFBaUIsZUFDbkIsQ0FBQyxDQUFDLGlCQUFpQixtQkFDbEIsQ0FBQyxTQUFTLG9CQUFvQixDQUFDLGNBQWMsTUFBTTtFQUM1RCxPQUFPLFFBQVEsQ0FBQyxDQUFDLFNBQVM7RUFDMUIsT0FBTyxjQUFjLENBQUMsQ0FBQyxpQkFBaUI7RUFDeEMsT0FBTyxTQUFTO0VBQ2hCLElBQUksQ0FBQyxpQkFBaUIsWUFDbEIsV0FBVyxTQUFTLENBQUM7RUFFekIsVUFBVSxNQUFNLEtBQUs7R0FDakIsYUFBYSxpQkFBaUIsa0JBQ3hCLFdBQVcsY0FDWDtHQUNOLFNBQVMscUJBQ0gsUUFDQSxpQkFBaUIsWUFDYixXQUFXLFVBQ1gsaUJBQWlCLGFBQ2IsVUFBVSxJQUNWLENBQUMsRUFBRSxpQkFBaUIscUJBQ2xCLENBQUMsVUFBVSxZQUFZLGNBQWM7R0FDckQsYUFBYSxpQkFBaUIsa0JBQ3hCLFdBQVcsY0FDWDtHQUNOLGFBQWEscUJBQ1AsQ0FBQyxJQUNELGlCQUFpQixrQkFDYixpQkFBaUIscUJBQXFCLGNBQ2xDLGVBQWUsZ0JBQWdCLGFBQWEsS0FBQSxHQUFXLFNBQVMsSUFDaEUsV0FBVyxjQUNmLGlCQUFpQixxQkFBcUIsYUFDbEMsZUFBZSxnQkFBZ0IsWUFBWSxLQUFBLEdBQVcsU0FBUyxJQUMvRCxpQkFBaUIsWUFDYixXQUFXLGNBQ1gsQ0FBQztHQUNuQixlQUFlLGlCQUFpQixjQUMxQixXQUFXLGdCQUNYLENBQUM7R0FDUCxRQUFRLGlCQUFpQixhQUFhLFdBQVcsU0FBUyxDQUFDO0dBQzNELG9CQUFvQixpQkFBaUIseUJBQy9CLFdBQVcscUJBQ1g7R0FDTixjQUFjO0dBQ2QsZUFBZTtFQUNuQixDQUFDO0NBQ0w7Q0FDQSxNQUFNLFNBQVMsWUFBWSxxQkFBcUIsT0FBTyxXQUFXLFVBQVUsSUFDdEUsV0FBVyxXQUFXLElBQ3RCLFlBQVk7RUFBRSxHQUFHLFNBQVM7RUFBYyxHQUFHO0NBQWlCLENBQUM7Q0FDbkUsTUFBTSxZQUFZLE1BQU0sVUFBVSxDQUFDLE1BQU07RUFDckMsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJO0VBQy9CLE1BQU0saUJBQWlCLFNBQVMsTUFBTTtFQUN0QyxJQUFJLGdCQUFnQjtHQUNoQixNQUFNLFdBQVcsZUFBZSxPQUMxQixlQUFlLEtBQUssS0FDcEIsZUFBZTtHQUNyQixJQUFJLFNBQVMsT0FDVCxpQkFBaUI7SUFDYixTQUFTLE1BQU07SUFDZixRQUFRLGdCQUNKLFdBQVcsU0FBUyxNQUFNLEtBQzFCLFNBQVMsT0FBTztHQUN4QixDQUFDO0VBRVQ7Q0FDSjtDQUNBLE1BQU0saUJBQWlCLHFCQUFxQjtFQU14QyxNQUFNLEVBQUUsTUFBTSxNQUFNLFFBQVEsR0FBRyxjQUFjO0VBQzdDLGFBQWE7R0FDVCxHQUFHO0dBQ0gsR0FBRztFQUNQO0NBQ0o7Q0FDQSxNQUFNLDRCQUE0QixXQUFXLFNBQVMsYUFBYSxLQUMvRCxTQUFTLGNBQWMsQ0FBQyxDQUFDLE1BQU0sV0FBVztFQUN0QyxNQUFNLFFBQVEsU0FBUyxZQUFZO0VBQ25DLFVBQVUsTUFBTSxLQUFLLEVBQ2pCLFdBQVcsTUFDZixDQUFDO0NBQ0wsQ0FBQztDQUNMLE1BQU0sc0JBQXNCLFFBQVEsVUFBVSxDQUFDLE1BQU07RUFDakQsaUJBQWlCLFlBQVksTUFBTTtFQUNuQyxJQUFJLENBQUMsUUFBUSxXQUFXO0dBQ3BCLE1BQU0saUJBQWlCLGVBQWUsZ0JBQWdCLGFBQWEsS0FBQSxHQUFXLE9BQU87R0FDckYsV0FBVyxjQUFjO0dBQ3pCLFdBQVcsVUFBVSxDQUFDLGNBQWMsY0FBYztFQUN0RDtFQUNBLElBQUksQ0FBQyxRQUFRLGFBQ1QsVUFBVTtFQUVkLFVBQVUsTUFBTSxLQUFLO0dBQ2pCLEdBQUc7R0FDSCxlQUFlO0VBQ25CLENBQUM7Q0FDTDtDQUNBLE1BQU0sVUFBVTtFQUNaLFNBQVM7R0FDTDtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBLElBQUksVUFBVTtJQUNWLE9BQU87R0FDWDtHQUNBLElBQUksY0FBYztJQUNkLE9BQU87R0FDWDtHQUNBLElBQUksU0FBUztJQUNULE9BQU87R0FDWDtHQUNBLElBQUksT0FBTyxPQUFPO0lBQ2QsU0FBUztHQUNiO0dBQ0EsSUFBSSxpQkFBaUI7SUFDakIsT0FBTztHQUNYO0dBQ0EsSUFBSSxTQUFTO0lBQ1QsT0FBTztHQUNYO0dBQ0EsSUFBSSxPQUFPLE9BQU87SUFDZCxTQUFTO0dBQ2I7R0FDQSxJQUFJLGFBQWE7SUFDYixPQUFPO0dBQ1g7R0FDQSxJQUFJLFdBQVc7SUFDWCxPQUFPO0dBQ1g7R0FDQSxJQUFJLFNBQVMsT0FBTztJQUNoQixXQUFXO0tBQ1AsR0FBRztLQUNILEdBQUc7SUFDUDtJQUNBLDhCQUE4QixtQkFBbUIsU0FBUyxJQUFJO0lBQzlELDZCQUE2QixtQkFBbUIsU0FBUyxjQUFjO0dBQzNFO0VBQ0o7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNKO0NBQ0EsT0FBTztFQUNILEdBQUc7RUFDSCxhQUFhO0NBQ2pCO0FBQ0o7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQStCQSxTQUFTLFFBQVEsUUFBUSxDQUFDLEdBQUc7Q0FDekIsTUFBTSxlQUFBLGFBQXFCLE9BQU8sS0FBQSxDQUFTO0NBQzNDLE1BQU0sVUFBQSxhQUFnQixPQUFPLEtBQUEsQ0FBUztDQUN0QyxNQUFNLG1CQUFBLGFBQXlCLE9BQU8sTUFBTSxXQUFXO0NBQ3ZELE1BQU0sQ0FBQyxXQUFXLG1CQUFBLGFBQXlCLGdCQUFnQjtFQUN2RCxHQUFHLFlBQVksa0JBQWtCO0VBQ2pDLFdBQVcsV0FBVyxNQUFNLGFBQWE7RUFDekMsUUFBUSxNQUFNLFVBQVUsQ0FBQztFQUN6QixVQUFVLE1BQU0sWUFBWTtFQUM1QixlQUFlLFdBQVcsTUFBTSxhQUFhLElBQ3ZDLEtBQUEsSUFDQSxNQUFNO0NBQ2hCLEVBQUU7Q0FDRixJQUFJLENBQUMsYUFBYSxXQUNiLE1BQU0sZUFBZSxpQkFBaUIsWUFBWSxNQUFNLGFBQWM7RUFDdkUsaUJBQWlCLFVBQVUsTUFBTTtFQUNqQyxJQUFJLE1BQU0sYUFBYTtHQUNuQixhQUFhLFVBQVU7SUFDbkIsR0FBRyxNQUFNO0lBQ1Q7R0FDSjtHQUNBLElBQUksTUFBTSxpQkFBaUIsQ0FBQyxXQUFXLE1BQU0sYUFBYSxHQUN0RCxNQUFNLFlBQVksTUFBTSxNQUFNLGVBQWUsTUFBTSxZQUFZO0VBRXZFLE9BQ0s7R0FDRCxNQUFNLEVBQUUsYUFBYSxHQUFHLFNBQVMsa0JBQWtCLEtBQUs7R0FDeEQsYUFBYSxVQUFVO0lBQ25CLEdBQUc7SUFDSDtHQUNKO0VBQ0o7Q0FDSjtDQUNBLE1BQU0sVUFBVSxhQUFhLFFBQVE7Q0FDckMsUUFBUSxXQUFXO0NBQ25CLGdDQUFnQztFQUM1QixNQUFNLE1BQU0sUUFBUSxXQUFXO0dBQzNCLFdBQVcsUUFBUTtHQUNuQixnQkFBZ0IsZ0JBQWdCO0lBQzVCLEdBQUcsUUFBUTtJQUNYLGVBQWUsUUFBUTtHQUMzQixDQUFDO0dBQ0QsY0FBYztFQUNsQixDQUFDO0VBQ0QsaUJBQWlCLFVBQVU7R0FDdkIsR0FBRztHQUNILFNBQVM7RUFDYixFQUFFO0VBQ0YsUUFBUSxXQUFXLFVBQVU7RUFDN0IsT0FBTztDQUNYLEdBQUcsQ0FBQyxPQUFPLENBQUM7Q0FDWixhQUFNLGdCQUFnQixRQUFRLGFBQWEsTUFBTSxRQUFRLEdBQUcsQ0FBQyxTQUFTLE1BQU0sUUFBUSxDQUFDO0NBQ3JGLGFBQU0sZ0JBQWdCO0VBQ2xCLElBQUksTUFBTSxNQUNOLFFBQVEsU0FBUyxPQUFPLE1BQU07RUFFbEMsSUFBSSxNQUFNLGdCQUNOLFFBQVEsU0FBUyxpQkFBaUIsTUFBTTtDQUVoRCxHQUFHO0VBQUM7RUFBUyxNQUFNO0VBQU0sTUFBTTtDQUFjLENBQUM7Q0FDOUMsYUFBTSxnQkFBZ0I7RUFDbEIsSUFBSSxNQUFNLFFBQVE7R0FDZCxRQUFRLFdBQVcsTUFBTSxNQUFNO0dBQy9CLFFBQVEsWUFBWTtFQUN4QjtDQUNKLEdBQUcsQ0FBQyxTQUFTLE1BQU0sTUFBTSxDQUFDO0NBQzFCLGFBQU0sZ0JBQWdCO0VBQ2xCLE1BQU0sb0JBQ0YsUUFBUSxVQUFVLE1BQU0sS0FBSyxFQUN6QixRQUFRLFFBQVEsVUFBVSxFQUM5QixDQUFDO0NBQ1QsR0FBRyxDQUFDLFNBQVMsTUFBTSxnQkFBZ0IsQ0FBQztDQUNwQyxhQUFNLGdCQUFnQjtFQUNsQixJQUFJLFFBQVEsZ0JBQWdCLFNBQVM7R0FDakMsTUFBTSxVQUFVLFFBQVEsVUFBVTtHQUNsQyxJQUFJLFlBQVksVUFBVSxTQUN0QixRQUFRLFVBQVUsTUFBTSxLQUFLLEVBQ3pCLFFBQ0osQ0FBQztFQUVUO0NBQ0osR0FBRyxDQUFDLFNBQVMsVUFBVSxPQUFPLENBQUM7Q0FDL0IsYUFBTSxnQkFBZ0I7RUFDbEIsSUFBSTtFQUNKLElBQUksTUFBTSxVQUFVLENBQUMsVUFBVSxNQUFNLFFBQVEsUUFBUSxPQUFPLEdBQUc7R0FDM0QsUUFBUSxPQUFPLE1BQU0sUUFBUTtJQUN6QixlQUFlO0lBQ2YsR0FBRyxRQUFRLFNBQVM7R0FDeEIsQ0FBQztHQUNELElBQUksR0FBRyxLQUFLLFFBQVEsU0FBUyxrQkFBa0IsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxjQUMvRSxRQUFRLFVBQVU7R0FFdEIsUUFBUSxVQUFVLE1BQU07R0FDeEIsaUJBQWlCLFdBQVcsRUFBRSxHQUFHLE1BQU0sRUFBRTtFQUM3QyxPQUVJLFFBQVEsb0JBQW9CO0NBRXBDLEdBQUcsQ0FBQyxTQUFTLE1BQU0sTUFBTSxDQUFDO0NBQzFCLGFBQU0sZ0JBQWdCO0VBQ2xCLElBQUksQ0FBQyxRQUFRLE9BQU8sT0FBTztHQUN2QixRQUFRLFVBQVU7R0FDbEIsUUFBUSxPQUFPLFFBQVE7RUFDM0I7RUFDQSxJQUFJLFFBQVEsT0FBTyxPQUFPO0dBQ3RCLFFBQVEsT0FBTyxRQUFRO0dBQ3ZCLFFBQVEsVUFBVSxNQUFNLEtBQUssRUFBRSxHQUFHLFFBQVEsV0FBVyxDQUFDO0VBQzFEO0VBQ0EsUUFBUSxpQkFBaUI7Q0FDN0IsQ0FBQztDQUNELGFBQWEsUUFBUSxZQUFBLGFBQWtCLGNBQWMsa0JBQWtCLFdBQVcsT0FBTyxHQUFHLENBQUMsU0FBUyxTQUFTLENBQUM7Q0FDaEgsT0FBTyxhQUFhO0FBQ3hCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUE0QkEsSUFBTSxTQUFTLFVBQVUsTUFBTSxPQUFPLFNBQVM7Q0FBRSxNQUFNLE1BQU07Q0FBTyxHQUFHO0FBQU0sQ0FBQyxDQUFDIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==