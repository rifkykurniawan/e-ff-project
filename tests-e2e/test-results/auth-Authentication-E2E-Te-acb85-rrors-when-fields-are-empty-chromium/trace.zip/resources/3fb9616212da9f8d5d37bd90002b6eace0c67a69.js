import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const _jsxDEV = __vite__cjsImport16_react_jsxDevRuntime["jsxDEV"];import { BrowserRouter as Router, Routes, Route } from "/node_modules/.vite/deps/react-router-dom.js?v=63710477";
import { QueryClient, QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=909c015f";
import { AuthProvider } from "/src/components/AuthContext.tsx";
import { ThemeProvider } from "/src/components/ThemeContext.tsx";
import { ProtectedRoute } from "/src/components/ProtectedRoute.tsx";
import { MainLayout } from "/src/layouts/MainLayout.tsx";
import { LoginPage } from "/src/pages/LoginPage.tsx";
import { SignupPage } from "/src/pages/SignupPage.tsx";
import { DashboardPage } from "/src/pages/DashboardPage.tsx";
import { AccountsPage } from "/src/pages/AccountsPage.tsx";
import { CategoriesPage } from "/src/pages/CategoriesPage.tsx";
import { TransactionsPage } from "/src/pages/TransactionsPage.tsx";
import { BudgetsPage } from "/src/pages/BudgetsPage.tsx";
import { SavingGoalsPage } from "/src/pages/SavingGoalsPage.tsx";
import { ReportsPage } from "/src/pages/ReportsPage.tsx";
import "/src/App.css";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/App.tsx";
import __vite__cjsImport16_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
const queryClient = new QueryClient();
function App() {
	return /* @__PURE__ */ _jsxDEV(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ _jsxDEV(ThemeProvider, { children: /* @__PURE__ */ _jsxDEV(AuthProvider, { children: /* @__PURE__ */ _jsxDEV(Router, { children: /* @__PURE__ */ _jsxDEV(Routes, { children: [
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/login",
				element: /* @__PURE__ */ _jsxDEV(LoginPage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 27,
					columnNumber: 45
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				path: "/signup",
				element: /* @__PURE__ */ _jsxDEV(SignupPage, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 46
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 15
			}, this),
			/* @__PURE__ */ _jsxDEV(Route, {
				element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 31
				}, this),
				children: /* @__PURE__ */ _jsxDEV(Route, {
					element: /* @__PURE__ */ _jsxDEV(MainLayout, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 33
					}, this),
					children: [
						/* @__PURE__ */ _jsxDEV(Route, {
							path: "/",
							element: /* @__PURE__ */ _jsxDEV(DashboardPage, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 31,
								columnNumber: 44
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 31,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV(Route, {
							path: "/accounts",
							element: /* @__PURE__ */ _jsxDEV(AccountsPage, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 32,
								columnNumber: 52
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV(Route, {
							path: "/categories",
							element: /* @__PURE__ */ _jsxDEV(CategoriesPage, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 33,
								columnNumber: 54
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 33,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV(Route, {
							path: "/transactions",
							element: /* @__PURE__ */ _jsxDEV(TransactionsPage, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 34,
								columnNumber: 56
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 34,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV(Route, {
							path: "/budgets",
							element: /* @__PURE__ */ _jsxDEV(BudgetsPage, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 35,
								columnNumber: 51
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV(Route, {
							path: "/saving-goals",
							element: /* @__PURE__ */ _jsxDEV(SavingGoalsPage, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 36,
								columnNumber: 56
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 36,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV(Route, {
							path: "/reports",
							element: /* @__PURE__ */ _jsxDEV(ReportsPage, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 37,
								columnNumber: 51
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 37,
							columnNumber: 19
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 17
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 15
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 13
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 11
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 9
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 5
	}, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUIsUUFBUSxRQUFRLGFBQWE7QUFDdkQsU0FBUyxhQUFhLDJCQUEyQjtBQUNqRCxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLHFCQUFxQjtBQUM5QixTQUFTLHNCQUFzQjtBQUMvQixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLGlCQUFpQjtBQUMxQixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLHFCQUFxQjtBQUM5QixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLHNCQUFzQjtBQUMvQixTQUFTLHdCQUF3QjtBQUNqQyxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLG1CQUFtQjtBQUM1QixPQUFPOzs7QUFFUCxNQUFNLGNBQWMsSUFBSSxZQUFZO0FBRXBDLFNBQVMsTUFBTTtDQUNiLE9BQ0Usd0JBQUMscUJBQUQ7RUFBcUIsUUFBUTtZQUMzQix3QkFBQyxlQUFELFlBQ0Usd0JBQUMsY0FBRCxZQUNFLHdCQUFDLFFBQUQsWUFDRSx3QkFBQyxRQUFEO0dBQ0Usd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBUyxTQUFTLHdCQUFDLFdBQUQsQ0FBWTs7Ozs7R0FBSTs7Ozs7R0FDOUMsd0JBQUMsT0FBRDtJQUFPLE1BQUs7SUFBVSxTQUFTLHdCQUFDLFlBQUQsQ0FBYTs7Ozs7R0FBSTs7Ozs7R0FDaEQsd0JBQUMsT0FBRDtJQUFPLFNBQVMsd0JBQUMsZ0JBQUQsQ0FBaUI7Ozs7O2NBQy9CLHdCQUFDLE9BQUQ7S0FBTyxTQUFTLHdCQUFDLFlBQUQsQ0FBYTs7Ozs7ZUFBN0I7TUFDRSx3QkFBQyxPQUFEO09BQU8sTUFBSztPQUFJLFNBQVMsd0JBQUMsZUFBRCxDQUFnQjs7Ozs7TUFBSTs7Ozs7TUFDN0Msd0JBQUMsT0FBRDtPQUFPLE1BQUs7T0FBWSxTQUFTLHdCQUFDLGNBQUQsQ0FBZTs7Ozs7TUFBSTs7Ozs7TUFDcEQsd0JBQUMsT0FBRDtPQUFPLE1BQUs7T0FBYyxTQUFTLHdCQUFDLGdCQUFELENBQWlCOzs7OztNQUFJOzs7OztNQUN4RCx3QkFBQyxPQUFEO09BQU8sTUFBSztPQUFnQixTQUFTLHdCQUFDLGtCQUFELENBQW1COzs7OztNQUFJOzs7OztNQUM1RCx3QkFBQyxPQUFEO09BQU8sTUFBSztPQUFXLFNBQVMsd0JBQUMsYUFBRCxDQUFjOzs7OztNQUFJOzs7OztNQUNsRCx3QkFBQyxPQUFEO09BQU8sTUFBSztPQUFnQixTQUFTLHdCQUFDLGlCQUFELENBQWtCOzs7OztNQUFJOzs7OztNQUMzRCx3QkFBQyxPQUFEO09BQU8sTUFBSztPQUFXLFNBQVMsd0JBQUMsYUFBRCxDQUFjOzs7OztNQUFJOzs7OztLQUM3Qzs7Ozs7O0dBQ0Y7Ozs7O0VBQ0Q7Ozs7V0FDRjs7OztXQUNJOzs7O1dBQ0Q7Ozs7O0NBQ0k7Ozs7O0FBRXpCOztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCcm93c2VyUm91dGVyIGFzIFJvdXRlciwgUm91dGVzLCBSb3V0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyBRdWVyeUNsaWVudCwgUXVlcnlDbGllbnRQcm92aWRlciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcbmltcG9ydCB7IEF1dGhQcm92aWRlciB9IGZyb20gXCIuL2NvbXBvbmVudHMvQXV0aENvbnRleHRcIjtcbmltcG9ydCB7IFRoZW1lUHJvdmlkZXIgfSBmcm9tIFwiLi9jb21wb25lbnRzL1RoZW1lQ29udGV4dFwiO1xuaW1wb3J0IHsgUHJvdGVjdGVkUm91dGUgfSBmcm9tIFwiLi9jb21wb25lbnRzL1Byb3RlY3RlZFJvdXRlXCI7XG5pbXBvcnQgeyBNYWluTGF5b3V0IH0gZnJvbSBcIi4vbGF5b3V0cy9NYWluTGF5b3V0XCI7XG5pbXBvcnQgeyBMb2dpblBhZ2UgfSBmcm9tIFwiLi9wYWdlcy9Mb2dpblBhZ2VcIjtcbmltcG9ydCB7IFNpZ251cFBhZ2UgfSBmcm9tIFwiLi9wYWdlcy9TaWdudXBQYWdlXCI7XG5pbXBvcnQgeyBEYXNoYm9hcmRQYWdlIH0gZnJvbSBcIi4vcGFnZXMvRGFzaGJvYXJkUGFnZVwiO1xuaW1wb3J0IHsgQWNjb3VudHNQYWdlIH0gZnJvbSBcIi4vcGFnZXMvQWNjb3VudHNQYWdlXCI7XG5pbXBvcnQgeyBDYXRlZ29yaWVzUGFnZSB9IGZyb20gXCIuL3BhZ2VzL0NhdGVnb3JpZXNQYWdlXCI7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnNQYWdlIH0gZnJvbSBcIi4vcGFnZXMvVHJhbnNhY3Rpb25zUGFnZVwiO1xuaW1wb3J0IHsgQnVkZ2V0c1BhZ2UgfSBmcm9tIFwiLi9wYWdlcy9CdWRnZXRzUGFnZVwiO1xuaW1wb3J0IHsgU2F2aW5nR29hbHNQYWdlIH0gZnJvbSBcIi4vcGFnZXMvU2F2aW5nR29hbHNQYWdlXCI7XG5pbXBvcnQgeyBSZXBvcnRzUGFnZSB9IGZyb20gXCIuL3BhZ2VzL1JlcG9ydHNQYWdlXCI7XG5pbXBvcnQgXCIuL0FwcC5jc3NcIjtcblxuY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKTtcblxuZnVuY3Rpb24gQXBwKCkge1xuICByZXR1cm4gKFxuICAgIDxRdWVyeUNsaWVudFByb3ZpZGVyIGNsaWVudD17cXVlcnlDbGllbnR9PlxuICAgICAgPFRoZW1lUHJvdmlkZXI+XG4gICAgICAgIDxBdXRoUHJvdmlkZXI+XG4gICAgICAgICAgPFJvdXRlcj5cbiAgICAgICAgICAgIDxSb3V0ZXM+XG4gICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2xvZ2luXCIgZWxlbWVudD17PExvZ2luUGFnZSAvPn0gLz5cbiAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvc2lnbnVwXCIgZWxlbWVudD17PFNpZ251cFBhZ2UgLz59IC8+XG4gICAgICAgICAgICAgIDxSb3V0ZSBlbGVtZW50PXs8UHJvdGVjdGVkUm91dGUgLz59PlxuICAgICAgICAgICAgICAgIDxSb3V0ZSBlbGVtZW50PXs8TWFpbkxheW91dCAvPn0+XG4gICAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9cIiBlbGVtZW50PXs8RGFzaGJvYXJkUGFnZSAvPn0gLz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2FjY291bnRzXCIgZWxlbWVudD17PEFjY291bnRzUGFnZSAvPn0gLz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2NhdGVnb3JpZXNcIiBlbGVtZW50PXs8Q2F0ZWdvcmllc1BhZ2UgLz59IC8+XG4gICAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi90cmFuc2FjdGlvbnNcIiBlbGVtZW50PXs8VHJhbnNhY3Rpb25zUGFnZSAvPn0gLz5cbiAgICAgICAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2J1ZGdldHNcIiBlbGVtZW50PXs8QnVkZ2V0c1BhZ2UgLz59IC8+XG4gICAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9zYXZpbmctZ29hbHNcIiBlbGVtZW50PXs8U2F2aW5nR29hbHNQYWdlIC8+fSAvPlxuICAgICAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvcmVwb3J0c1wiIGVsZW1lbnQ9ezxSZXBvcnRzUGFnZSAvPn0gLz5cbiAgICAgICAgICAgICAgICA8L1JvdXRlPlxuICAgICAgICAgICAgICA8L1JvdXRlPlxuICAgICAgICAgICAgPC9Sb3V0ZXM+XG4gICAgICAgICAgPC9Sb3V0ZXI+XG4gICAgICAgIDwvQXV0aFByb3ZpZGVyPlxuICAgICAgPC9UaGVtZVByb3ZpZGVyPlxuICAgIDwvUXVlcnlDbGllbnRQcm92aWRlcj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwO1xuIl19