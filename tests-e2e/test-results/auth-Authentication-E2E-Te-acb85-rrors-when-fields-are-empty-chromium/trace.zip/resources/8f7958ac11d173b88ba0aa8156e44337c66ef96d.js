import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SignupPage.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=513be775";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=0a9b0578";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=9dd4f110";
import * as z from "/node_modules/.vite/deps/zod.js?v=9219c26e";
import { useAuth } from "/src/hooks/useAuth.ts";
import { useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=63710477";
import { Wallet, Sun, Moon, ArrowRight, Sparkles, CheckCircle2 } from "/node_modules/.vite/deps/lucide-react.js?v=7df35618";
import { useTheme } from "/src/components/ThemeContext.tsx";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/SignupPage.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
var _s = $RefreshSig$();
const signupSchema = z.object({
	firstName: z.string().min(2, "First name must be at least 2 characters"),
	lastName: z.string().min(1, "Last name must be at least 1 character"),
	email: z.string().email("Please enter a valid email address"),
	password: z.string().min(8, "Password must be at least 8 characters"),
	confirmPassword: z.string().min(8, "Password must be at least 8 characters")
}).refine((data) => data.password === data.confirmPassword, {
	message: "Passwords do not match",
	path: ["confirmPassword"]
});
export const SignupPage = () => {
	_s();
	const { signUp } = useAuth();
	const { theme, toggleTheme } = useTheme();
	const navigate = useNavigate();
	const [errorMsg, setErrorMsg] = useState(null);
	const [successMsg, setSuccessMsg] = useState(null);
	const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({ resolver: zodResolver(signupSchema) });
	const onSubmit = async (data) => {
		setErrorMsg(null);
		setSuccessMsg(null);
		try {
			await signUp({
				email: data.email,
				password: data.password,
				first_name: data.firstName,
				last_name: data.lastName
			});
			setSuccessMsg("Account created successfully! Pending administrator approval. Redirecting to sign in...");
			setTimeout(() => {
				navigate("/login");
			}, 3e3);
		} catch (err) {
			setErrorMsg(err.response?.data?.message || err.message || "Failed to create account");
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "relative min-h-screen bg-[#f4f9f6] dark:bg-[#05160E] text-zinc-800 dark:text-zinc-100 flex flex-col transition-colors duration-300 selection:bg-[#3cd395] selection:text-black",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "fixed inset-0 bg-[url('/imageBackground.svg')] bg-contain bg-no-repeat bg-center opacity-25 dark:opacity-15 pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("header", {
				className: "w-full max-w-7xl mx-auto px-6 py-5 flex items-center justify-between border-b border-[#cce8db]/60 dark:border-[#123022]/40",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex h-9 w-9 items-center justify-center rounded-lg bg-[#3cd395]/10 text-[#3cd395]",
						children: /* @__PURE__ */ _jsxDEV(Wallet, { className: "h-5 w-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "font-bold text-lg tracking-tight text-[#0a271c] dark:text-white",
						children: "E-Finance"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-4",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: toggleTheme,
						"data-testid": "theme-toggle-button",
						className: "flex items-center gap-1.5 bg-[#e6f4ed] hover:bg-[#d2ebd9] dark:bg-[#0e271c] dark:hover:bg-[#153828] border border-[#cce8db] dark:border-[#1a4230] hover:border-[#b4e0c4] dark:hover:border-[#22573f] rounded-full px-3 py-1 text-xs font-semibold text-[#0a271c] dark:text-zinc-300 hover:text-[#061c13] dark:hover:text-white transition-all cursor-pointer",
						title: "Toggle Theme",
						children: [theme === "dark" ? /* @__PURE__ */ _jsxDEV(Sun, { className: "h-3.5 w-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 33
						}, this) : /* @__PURE__ */ _jsxDEV(Moon, { className: "h-3.5 w-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 67
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: theme === "dark" ? "Light" : "Dark" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 67,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 max-w-7xl w-full mx-auto px-6 py-12 md:py-20 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-7 space-y-8",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "inline-flex items-center gap-3",
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-bold uppercase tracking-widest text-[#248d61] dark:text-[#3cd395]",
								children: "E-FINANCE APP"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 94,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-4xl sm:text-5xl lg:text-6xl font-medium text-[#0a271c] dark:text-white leading-[1.15] tracking-tight",
							children: [
								"Take Control of Your Wealth, ",
								/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 98,
									columnNumber: 42
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[#248d61] dark:text-[#3cd395]",
									children: "Secure and Private."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 99,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap items-center gap-4 pt-2",
							children: /* @__PURE__ */ _jsxDEV(Link, {
								to: "/login",
								className: "flex items-center gap-2 bg-[#3cd395] hover:bg-[#4be4a4] text-black font-semibold px-5 py-2.5 rounded-full transition-all hover:translate-x-0.5",
								children: ["Sign In to Your Account ", /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "h-4 w-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 107,
									columnNumber: 39
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 103,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4 pt-8 border-t border-[#cce8db]/60 dark:border-[#123022]/40 max-w-lg",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-start gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "h-5 w-5 text-[#248d61] dark:text-[#3cd395] shrink-0 mt-0.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 114,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-semibold text-[#0a271c] dark:text-white text-sm",
									children: "Row Level Security"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 116,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-zinc-500 dark:text-zinc-400",
									children: "Database security policies enforced by Supabase."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 117,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-start gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "h-5 w-5 text-[#248d61] dark:text-[#3cd395] shrink-0 mt-0.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 121,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-semibold text-[#0a271c] dark:text-white text-sm",
									children: "Instant Insights"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 123,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-zinc-500 dark:text-zinc-400",
									children: "Analyze your net worth and track habits in real time."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 124,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 122,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-5 flex justify-center lg:justify-end",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "w-full max-w-md rounded-2xl border border-[#cce8db] dark:border-[#1a4230] bg-white/80 dark:bg-[#0a1e15]/60 backdrop-blur-md p-8 shadow-2xl relative overflow-hidden",
						children: [/* @__PURE__ */ _jsxDEV("div", { className: "absolute -top-10 -right-10 w-32 h-32 bg-[#3cd395]/10 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "relative z-10",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mb-6",
									children: [/* @__PURE__ */ _jsxDEV("h2", {
										className: "text-2xl font-bold text-[#0a271c] dark:text-white tracking-tight",
										children: "Create Account"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 138,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm text-zinc-500 dark:text-zinc-400 mt-1",
										children: "Register to start managing your finances"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 139,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 137,
									columnNumber: 15
								}, this),
								errorMsg && /* @__PURE__ */ _jsxDEV("div", {
									className: "rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-650 dark:text-red-400 mb-4 animate-pulse",
									children: errorMsg
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 143,
									columnNumber: 17
								}, this),
								successMsg && /* @__PURE__ */ _jsxDEV("div", {
									className: "rounded-lg border border-[#3cd395]/30 bg-[#3cd395]/10 p-3 text-sm text-[#248d61] dark:text-[#3cd395] mb-4",
									children: successMsg
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("form", {
									className: "space-y-4",
									onSubmit: handleSubmit(onSubmit),
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "grid grid-cols-2 gap-4",
											children: [/* @__PURE__ */ _jsxDEV("div", { children: [
												/* @__PURE__ */ _jsxDEV("label", {
													htmlFor: "firstName",
													className: "block text-xs font-semibold uppercase tracking-wider text-zinc-550 dark:text-zinc-400 mb-1",
													children: "First Name"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 157,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ _jsxDEV("input", {
													id: "firstName",
													type: "text",
													...register("firstName"),
													"data-testid": "signup-first-name-input",
													className: `block w-full rounded-lg border bg-white dark:bg-[#05160E]/80 border-[#cce8db] dark:border-[#1a4230] px-3 py-2 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 dark:placeholder-zinc-500 focus:border-[#248d61] dark:focus:border-[#3cd395] focus:outline-none focus:ring-1 focus:ring-[#3cd395]/40 transition-all ${errors.firstName ? "border-red-500" : ""}`,
													placeholder: "John"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 160,
													columnNumber: 21
												}, this),
												errors.firstName && /* @__PURE__ */ _jsxDEV("p", {
													className: "mt-1 text-xs text-red-500 dark:text-red-400",
													children: errors.firstName.message
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 171,
													columnNumber: 23
												}, this)
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 156,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
												/* @__PURE__ */ _jsxDEV("label", {
													htmlFor: "lastName",
													className: "block text-xs font-semibold uppercase tracking-wider text-zinc-550 dark:text-zinc-400 mb-1",
													children: "Last Name"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 176,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ _jsxDEV("input", {
													id: "lastName",
													type: "text",
													...register("lastName"),
													"data-testid": "signup-last-name-input",
													className: `block w-full rounded-lg border bg-white dark:bg-[#05160E]/80 border-[#cce8db] dark:border-[#1a4230] px-3 py-2 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 dark:placeholder-zinc-500 focus:border-[#248d61] dark:focus:border-[#3cd395] focus:outline-none focus:ring-1 focus:ring-[#3cd395]/40 transition-all ${errors.lastName ? "border-red-500" : ""}`,
													placeholder: "Doe"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 179,
													columnNumber: 21
												}, this),
												errors.lastName && /* @__PURE__ */ _jsxDEV("p", {
													className: "mt-1 text-xs text-red-500 dark:text-red-400",
													children: errors.lastName.message
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 190,
													columnNumber: 23
												}, this)
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 175,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 155,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("label", {
												htmlFor: "email",
												className: "block text-xs font-semibold uppercase tracking-wider text-zinc-550 dark:text-zinc-400 mb-1",
												children: "Email Address"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 196,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												id: "email",
												type: "email",
												autoComplete: "email",
												...register("email"),
												"data-testid": "signup-email-input",
												className: `block w-full rounded-lg border bg-white dark:bg-[#05160E]/80 border-[#cce8db] dark:border-[#1a4230] px-3 py-2.5 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 dark:placeholder-zinc-500 focus:border-[#248d61] dark:focus:border-[#3cd395] focus:outline-none focus:ring-1 focus:ring-[#3cd395]/40 transition-all ${errors.email ? "border-red-500" : ""}`,
												placeholder: "example@mail.com"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 199,
												columnNumber: 19
											}, this),
											errors.email && /* @__PURE__ */ _jsxDEV("p", {
												className: "mt-1 text-xs text-red-500 dark:text-red-400",
												children: errors.email.message
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 211,
												columnNumber: 21
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 195,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("label", {
												htmlFor: "password",
												className: "block text-xs font-semibold uppercase tracking-wider text-zinc-550 dark:text-zinc-400 mb-1",
												children: "Password"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 216,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												id: "password",
												type: "password",
												autoComplete: "new-password",
												...register("password"),
												"data-testid": "signup-password-input",
												className: `block w-full rounded-lg border bg-white dark:bg-[#05160E]/80 border-[#cce8db] dark:border-[#1a4230] px-3 py-2.5 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 dark:placeholder-zinc-500 focus:border-[#248d61] dark:focus:border-[#3cd395] focus:outline-none focus:ring-1 focus:ring-[#3cd395]/40 transition-all ${errors.password ? "border-red-500" : ""}`,
												placeholder: "••••••••"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 219,
												columnNumber: 19
											}, this),
											errors.password && /* @__PURE__ */ _jsxDEV("p", {
												className: "mt-1 text-xs text-red-500 dark:text-red-400",
												children: errors.password.message
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 231,
												columnNumber: 21
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 215,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("label", {
												htmlFor: "confirmPassword",
												className: "block text-xs font-semibold uppercase tracking-wider text-zinc-550 dark:text-zinc-400 mb-1",
												children: "Confirm Password"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 236,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												id: "confirmPassword",
												type: "password",
												autoComplete: "new-password",
												...register("confirmPassword"),
												"data-testid": "signup-confirm-password-input",
												className: `block w-full rounded-lg border bg-white dark:bg-[#05160E]/80 border-[#cce8db] dark:border-[#1a4230] px-3 py-2.5 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 dark:placeholder-zinc-500 focus:border-[#248d61] dark:focus:border-[#3cd395] focus:outline-none focus:ring-1 focus:ring-[#3cd395]/40 transition-all ${errors.confirmPassword ? "border-red-500" : ""}`,
												placeholder: "••••••••"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 239,
												columnNumber: 19
											}, this),
											errors.confirmPassword && /* @__PURE__ */ _jsxDEV("p", {
												className: "mt-1 text-xs text-red-500 dark:text-red-400",
												children: errors.confirmPassword.message
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 251,
												columnNumber: 21
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 235,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "pt-2",
											children: /* @__PURE__ */ _jsxDEV("button", {
												type: "submit",
												disabled: isSubmitting,
												"data-testid": "signup-submit-button",
												className: "flex w-full justify-center items-center gap-2 rounded-lg bg-[#3cd395] hover:bg-[#4be4a4] px-4 py-2.5 text-sm font-semibold text-black transition-colors focus:outline-none focus:ring-2 focus:ring-[#3cd395] focus:ring-offset-2 focus:ring-offset-[#0a1e15] disabled:opacity-50 cursor-pointer",
												children: isSubmitting ? /* @__PURE__ */ _jsxDEV("div", { className: "h-5 w-5 animate-spin rounded-full border-2 border-black border-t-transparent" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 263,
													columnNumber: 23
												}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", { children: "Sign Up" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 266,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "h-4 w-4" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 267,
													columnNumber: 25
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 265,
													columnNumber: 23
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 256,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 255,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-center text-xs text-zinc-500 dark:text-zinc-450 mt-6 pt-4 border-t border-[#cce8db]/60 dark:border-[#123022]/40",
											children: [
												"Already have an account?",
												" ",
												/* @__PURE__ */ _jsxDEV(Link, {
													to: "/login",
													className: "font-semibold text-[#248d61] dark:text-[#3cd395] hover:text-[#2fae7a] dark:hover:text-[#4be4a4] transition-colors",
													children: "Sign In"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 275,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 273,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 154,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 132,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 131,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 90,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "w-full max-w-7xl mx-auto px-6 py-8 mt-auto flex flex-col sm:flex-row items-center justify-between text-xs text-zinc-500 border-t border-[#cce8db]/40 dark:border-[#123022]/20",
				children: [/* @__PURE__ */ _jsxDEV("p", { children: [
					"© ",
					new Date().getFullYear(),
					" E-Finance by rkDEV. All rights reserved."
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 287,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 sm:mt-0 flex items-center gap-1.5",
					children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "h-3.5 w-3.5 text-[#248d61] dark:text-[#3cd395]" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 289,
						columnNumber: 11
					}, this), " Built for user privacy."]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 288,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 286,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 60,
		columnNumber: 5
	}, this);
};
_s(SignupPage, "Jrjoe2MPuxaDCaOYEf9UANKY3OI=", false, function() {
	return [
		useAuth,
		useTheme,
		useNavigate,
		useForm
	];
});
_c = SignupPage;
var _c;
$RefreshReg$(_c, "SignupPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/SignupPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/SignupPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/SignupPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/SignupPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGVBQWU7QUFDeEIsU0FBUyxtQkFBbUI7QUFDNUIsWUFBWSxPQUFPO0FBQ25CLFNBQVMsZUFBZTtBQUN4QixTQUFTLGFBQWEsWUFBWTtBQUNsQyxTQUFTLFFBQVEsS0FBSyxNQUFNLFlBQVksVUFBVSxvQkFBb0I7QUFDdEUsU0FBUyxnQkFBZ0I7Ozs7QUFFekIsTUFBTSxlQUFlLEVBQUUsT0FBTztDQUM1QixXQUFXLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxHQUFHLDBDQUEwQztDQUN2RSxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxHQUFHLHdDQUF3QztDQUNwRSxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUMsTUFBTSxvQ0FBb0M7Q0FDNUQsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksR0FBRyx3Q0FBd0M7Q0FDcEUsaUJBQWlCLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxHQUFHLHdDQUF3QztBQUM3RSxDQUFDLENBQUMsQ0FBQyxRQUFRLFNBQVMsS0FBSyxhQUFhLEtBQUssaUJBQWlCO0NBQzFELFNBQVM7Q0FDVCxNQUFNLENBQUMsaUJBQWlCO0FBQzFCLENBQUM7QUFJRCxPQUFPLE1BQU0sbUJBQTZCOztDQUN4QyxNQUFNLEVBQUUsV0FBVyxRQUFRO0NBQzNCLE1BQU0sRUFBRSxPQUFPLGdCQUFnQixTQUFTO0NBQ3hDLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBd0IsSUFBSTtDQUM1RCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBd0IsSUFBSTtDQUVoRSxNQUFNLEVBQ0osVUFDQSxjQUNBLFdBQVcsRUFBRSxRQUFRLG1CQUNuQixRQUFzQixFQUN4QixVQUFVLFlBQVksWUFBWSxFQUNwQyxDQUFDO0NBRUQsTUFBTSxXQUFXLE9BQU8sU0FBdUI7RUFDN0MsWUFBWSxJQUFJO0VBQ2hCLGNBQWMsSUFBSTtFQUNsQixJQUFJO0dBQ0YsTUFBTSxPQUFPO0lBQ1gsT0FBTyxLQUFLO0lBQ1osVUFBVSxLQUFLO0lBQ2YsWUFBWSxLQUFLO0lBQ2pCLFdBQVcsS0FBSztHQUNsQixDQUFDO0dBQ0QsY0FBYyx5RkFBeUY7R0FDdkcsaUJBQWlCO0lBQ2YsU0FBUyxRQUFRO0dBQ25CLEdBQUcsR0FBSTtFQUNULFNBQVMsS0FBVTtHQUNqQixZQUNFLElBQUksVUFBVSxNQUFNLFdBQVcsSUFBSSxXQUFXLDBCQUNoRDtFQUNGO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFELEVBQ0UsV0FBVSxrSUFDWDs7Ozs7R0FHRCx3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztLQUMxQjs7OztlQUNMLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFrRTtLQUFlOzs7O2FBQzlGOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBRWIsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxlQUFZO01BQ1osV0FBVTtNQUNWLE9BQU07Z0JBSlIsQ0FNRyxVQUFVLFNBQVMsd0JBQUMsS0FBRCxFQUFLLFdBQVUsY0FBZTs7OztpQkFBSSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O2dCQUNyRix3QkFBQyxRQUFELFlBQU8sVUFBVSxTQUFTLFVBQVUsT0FBYTs7OztjQUMzQzs7Ozs7O0lBQ0w7Ozs7WUFDQzs7Ozs7O0dBR1Isd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaEIsQ0FFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWlGO09BQW1COzs7OztNQUNqSDs7Ozs7TUFFTCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUEwSDtRQUMzRix3QkFBQyxNQUFELENBQUs7Ozs7O1FBQ2xDLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFxQztRQUF5Qjs7Ozs7T0FDNUU7Ozs7OztNQUVKLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLE1BQUQ7UUFDRSxJQUFHO1FBQ0gsV0FBVTtrQkFGWixDQUdDLDRCQUN5Qix3QkFBQyxZQUFELEVBQVksV0FBVSxVQUFXOzs7O2dCQUNyRDs7Ozs7O01BQ0g7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLDZEQUE4RDs7OztrQkFDdEYsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF1RDtRQUFzQjs7OztrQkFDM0Ysd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQTJDO1FBQW1EOzs7O2dCQUN4Rzs7OztnQkFDRjs7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSw2REFBOEQ7Ozs7a0JBQ3RGLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBdUQ7UUFBb0I7Ozs7a0JBQ3pGLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUEyQztRQUF3RDs7OztnQkFDN0c7Ozs7Z0JBQ0Y7Ozs7O2VBQ0Y7Ozs7OztLQUNGOzs7OztjQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FFRSx3QkFBQyxPQUFELEVBQUssV0FBVSxpR0FBc0c7Ozs7Z0JBRXJILHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBbUU7U0FBa0I7Ozs7bUJBQ25HLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFnRDtTQUEyQzs7OztpQkFDckc7Ozs7OztRQUVKLFlBQ0Msd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1o7UUFDRTs7Ozs7UUFHTixjQUNDLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaO1FBQ0U7Ozs7O1FBR1Asd0JBQUMsUUFBRDtTQUFNLFdBQVU7U0FBWSxVQUFVLGFBQWEsUUFBUTttQkFBM0Q7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQ7WUFDRSx3QkFBQyxTQUFEO2FBQU8sU0FBUTthQUFZLFdBQVU7dUJBQTZGO1lBRTNIOzs7OztZQUNQLHdCQUFDLFNBQUQ7YUFDRSxJQUFHO2FBQ0gsTUFBSzthQUNMLEdBQUksU0FBUyxXQUFXO2FBQ3hCLGVBQVk7YUFDWixXQUFXLGdVQUNULE9BQU8sWUFBWSxtQkFBbUI7YUFFeEMsYUFBWTtZQUNiOzs7OztZQUNBLE9BQU8sYUFDTix3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBK0MsT0FBTyxVQUFVO1lBQVc7Ozs7O1dBRXZGOzs7O3FCQUVMLHdCQUFDLE9BQUQ7WUFDRSx3QkFBQyxTQUFEO2FBQU8sU0FBUTthQUFXLFdBQVU7dUJBQTZGO1lBRTFIOzs7OztZQUNQLHdCQUFDLFNBQUQ7YUFDRSxJQUFHO2FBQ0gsTUFBSzthQUNMLEdBQUksU0FBUyxVQUFVO2FBQ3ZCLGVBQVk7YUFDWixXQUFXLGdVQUNULE9BQU8sV0FBVyxtQkFBbUI7YUFFdkMsYUFBWTtZQUNiOzs7OztZQUNBLE9BQU8sWUFDTix3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBK0MsT0FBTyxTQUFTO1lBQVc7Ozs7O1dBRXRGOzs7O21CQUNGOzs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQ0Usd0JBQUMsU0FBRDtZQUFPLFNBQVE7WUFBUSxXQUFVO3NCQUE2RjtXQUV2SDs7Ozs7V0FDUCx3QkFBQyxTQUFEO1lBQ0UsSUFBRztZQUNILE1BQUs7WUFDTCxjQUFhO1lBQ2IsR0FBSSxTQUFTLE9BQU87WUFDcEIsZUFBWTtZQUNaLFdBQVcsa1VBQ1QsT0FBTyxRQUFRLG1CQUFtQjtZQUVwQyxhQUFZO1dBQ2I7Ozs7O1dBQ0EsT0FBTyxTQUNOLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUErQyxPQUFPLE1BQU07V0FBVzs7Ozs7VUFFbkY7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUNFLHdCQUFDLFNBQUQ7WUFBTyxTQUFRO1lBQVcsV0FBVTtzQkFBNkY7V0FFMUg7Ozs7O1dBQ1Asd0JBQUMsU0FBRDtZQUNFLElBQUc7WUFDSCxNQUFLO1lBQ0wsY0FBYTtZQUNiLEdBQUksU0FBUyxVQUFVO1lBQ3ZCLGVBQVk7WUFDWixXQUFXLGtVQUNULE9BQU8sV0FBVyxtQkFBbUI7WUFFdkMsYUFBWTtXQUNiOzs7OztXQUNBLE9BQU8sWUFDTix3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBK0MsT0FBTyxTQUFTO1dBQVc7Ozs7O1VBRXRGOzs7OztVQUVMLHdCQUFDLE9BQUQ7V0FDRSx3QkFBQyxTQUFEO1lBQU8sU0FBUTtZQUFrQixXQUFVO3NCQUE2RjtXQUVqSTs7Ozs7V0FDUCx3QkFBQyxTQUFEO1lBQ0UsSUFBRztZQUNILE1BQUs7WUFDTCxjQUFhO1lBQ2IsR0FBSSxTQUFTLGlCQUFpQjtZQUM5QixlQUFZO1lBQ1osV0FBVyxrVUFDVCxPQUFPLGtCQUFrQixtQkFBbUI7WUFFOUMsYUFBWTtXQUNiOzs7OztXQUNBLE9BQU8sbUJBQ04sd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQStDLE9BQU8sZ0JBQWdCO1dBQVc7Ozs7O1VBRTdGOzs7OztVQUVMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNiLHdCQUFDLFVBQUQ7WUFDRSxNQUFLO1lBQ0wsVUFBVTtZQUNWLGVBQVk7WUFDWixXQUFVO3NCQUVULGVBQ0Msd0JBQUMsT0FBRCxFQUFLLFdBQVUsK0VBQW9GOzs7O3VCQUVuRyxnREFDRSx3QkFBQyxRQUFELFlBQU0sVUFBYTs7OztzQkFDbkIsd0JBQUMsWUFBRCxFQUFZLFdBQVUsVUFBVzs7OztvQkFDakM7Ozs7O1dBRUU7Ozs7O1VBQ0w7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFBc0k7WUFDM0c7WUFDekIsd0JBQUMsTUFBRDthQUFNLElBQUc7YUFBUyxXQUFVO3VCQUFvSDtZQUUxSTs7Ozs7V0FDSDs7Ozs7O1NBQ0Q7Ozs7OztPQUNIOzs7OztjQUNGOzs7Ozs7SUFDRjs7OztZQUNEOzs7Ozs7R0FHTix3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQixDQUNFLHdCQUFDLEtBQUQ7S0FBRztLQUFRLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtLQUFFO0lBQTRDOzs7O2NBQ2hGLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWIsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxpREFBa0Q7Ozs7ZUFBQywwQkFDdEU7Ozs7O1lBQ0c7Ozs7OztFQUNMOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTaWdudXBQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZUZvcm0gfSBmcm9tIFwicmVhY3QtaG9vay1mb3JtXCI7XG5pbXBvcnQgeyB6b2RSZXNvbHZlciB9IGZyb20gXCJAaG9va2Zvcm0vcmVzb2x2ZXJzL3pvZFwiO1xuaW1wb3J0ICogYXMgeiBmcm9tIFwiem9kXCI7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uL2hvb2tzL3VzZUF1dGhcIjtcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IFdhbGxldCwgU3VuLCBNb29uLCBBcnJvd1JpZ2h0LCBTcGFya2xlcywgQ2hlY2tDaXJjbGUyIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9UaGVtZUNvbnRleHRcIjtcblxuY29uc3Qgc2lnbnVwU2NoZW1hID0gei5vYmplY3Qoe1xuICBmaXJzdE5hbWU6IHouc3RyaW5nKCkubWluKDIsIFwiRmlyc3QgbmFtZSBtdXN0IGJlIGF0IGxlYXN0IDIgY2hhcmFjdGVyc1wiKSxcbiAgbGFzdE5hbWU6IHouc3RyaW5nKCkubWluKDEsIFwiTGFzdCBuYW1lIG11c3QgYmUgYXQgbGVhc3QgMSBjaGFyYWN0ZXJcIiksXG4gIGVtYWlsOiB6LnN0cmluZygpLmVtYWlsKFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgZW1haWwgYWRkcmVzc1wiKSxcbiAgcGFzc3dvcmQ6IHouc3RyaW5nKCkubWluKDgsIFwiUGFzc3dvcmQgbXVzdCBiZSBhdCBsZWFzdCA4IGNoYXJhY3RlcnNcIiksXG4gIGNvbmZpcm1QYXNzd29yZDogei5zdHJpbmcoKS5taW4oOCwgXCJQYXNzd29yZCBtdXN0IGJlIGF0IGxlYXN0IDggY2hhcmFjdGVyc1wiKSxcbn0pLnJlZmluZSgoZGF0YSkgPT4gZGF0YS5wYXNzd29yZCA9PT0gZGF0YS5jb25maXJtUGFzc3dvcmQsIHtcbiAgbWVzc2FnZTogXCJQYXNzd29yZHMgZG8gbm90IG1hdGNoXCIsXG4gIHBhdGg6IFtcImNvbmZpcm1QYXNzd29yZFwiXSxcbn0pO1xuXG50eXBlIFNpZ251cEZpZWxkcyA9IHouaW5mZXI8dHlwZW9mIHNpZ251cFNjaGVtYT47XG5cbmV4cG9ydCBjb25zdCBTaWdudXBQYWdlOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgeyBzaWduVXAgfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgeyB0aGVtZSwgdG9nZ2xlVGhlbWUgfSA9IHVzZVRoZW1lKCk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgW2Vycm9yTXNnLCBzZXRFcnJvck1zZ10gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3N1Y2Nlc3NNc2csIHNldFN1Y2Nlc3NNc2ddID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3Qge1xuICAgIHJlZ2lzdGVyLFxuICAgIGhhbmRsZVN1Ym1pdCxcbiAgICBmb3JtU3RhdGU6IHsgZXJyb3JzLCBpc1N1Ym1pdHRpbmcgfSxcbiAgfSA9IHVzZUZvcm08U2lnbnVwRmllbGRzPih7XG4gICAgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKHNpZ251cFNjaGVtYSksXG4gIH0pO1xuXG4gIGNvbnN0IG9uU3VibWl0ID0gYXN5bmMgKGRhdGE6IFNpZ251cEZpZWxkcykgPT4ge1xuICAgIHNldEVycm9yTXNnKG51bGwpO1xuICAgIHNldFN1Y2Nlc3NNc2cobnVsbCk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHNpZ25VcCh7XG4gICAgICAgIGVtYWlsOiBkYXRhLmVtYWlsLFxuICAgICAgICBwYXNzd29yZDogZGF0YS5wYXNzd29yZCxcbiAgICAgICAgZmlyc3RfbmFtZTogZGF0YS5maXJzdE5hbWUsXG4gICAgICAgIGxhc3RfbmFtZTogZGF0YS5sYXN0TmFtZSxcbiAgICAgIH0pO1xuICAgICAgc2V0U3VjY2Vzc01zZyhcIkFjY291bnQgY3JlYXRlZCBzdWNjZXNzZnVsbHkhIFBlbmRpbmcgYWRtaW5pc3RyYXRvciBhcHByb3ZhbC4gUmVkaXJlY3RpbmcgdG8gc2lnbiBpbi4uLlwiKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBuYXZpZ2F0ZShcIi9sb2dpblwiKTtcbiAgICAgIH0sIDMwMDApO1xuICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICBzZXRFcnJvck1zZyhcbiAgICAgICAgZXJyLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IGVyci5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIGNyZWF0ZSBhY2NvdW50XCJcbiAgICAgICk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtaW4taC1zY3JlZW4gYmctWyNmNGY5ZjZdIGRhcms6YmctWyMwNTE2MEVdIHRleHQtemluYy04MDAgZGFyazp0ZXh0LXppbmMtMTAwIGZsZXggZmxleC1jb2wgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwIHNlbGVjdGlvbjpiZy1bIzNjZDM5NV0gc2VsZWN0aW9uOnRleHQtYmxhY2tcIj5cbiAgICAgIHsvKiBCYWNrZ3JvdW5kIEltYWdlIHdpdGggVHJhbnNwYXJlbmN5ICovfVxuICAgICAgPGRpdiBcbiAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1bdXJsKCcvaW1hZ2VCYWNrZ3JvdW5kLnN2ZycpXSBiZy1jb250YWluIGJnLW5vLXJlcGVhdCBiZy1jZW50ZXIgb3BhY2l0eS0yNSBkYXJrOm9wYWNpdHktMTUgcG9pbnRlci1ldmVudHMtbm9uZVwiXG4gICAgICAvPlxuXG4gICAgICB7LyogSGVhZGVyIE5hdmlnYXRpb24gKi99XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy03eGwgbXgtYXV0byBweC02IHB5LTUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1bI2NjZThkYl0vNjAgZGFyazpib3JkZXItWyMxMjMwMjJdLzQwXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC05IHctOSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBiZy1bIzNjZDM5NV0vMTAgdGV4dC1bIzNjZDM5NV1cIj5cbiAgICAgICAgICAgIDxXYWxsZXQgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtbGcgdHJhY2tpbmctdGlnaHQgdGV4dC1bIzBhMjcxY10gZGFyazp0ZXh0LXdoaXRlXCI+RS1GaW5hbmNlPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgey8qIFRoZW1lL0RhcmsgU3dpdGNoZXIgQ2Fwc3VsZSAqL31cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVUaGVtZX1cbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwidGhlbWUtdG9nZ2xlLWJ1dHRvblwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLVsjZTZmNGVkXSBob3ZlcjpiZy1bI2QyZWJkOV0gZGFyazpiZy1bIzBlMjcxY10gZGFyazpob3ZlcjpiZy1bIzE1MzgyOF0gYm9yZGVyIGJvcmRlci1bI2NjZThkYl0gZGFyazpib3JkZXItWyMxYTQyMzBdIGhvdmVyOmJvcmRlci1bI2I0ZTBjNF0gZGFyazpob3Zlcjpib3JkZXItWyMyMjU3M2ZdIHJvdW5kZWQtZnVsbCBweC0zIHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtWyMwYTI3MWNdIGRhcms6dGV4dC16aW5jLTMwMCBob3Zlcjp0ZXh0LVsjMDYxYzEzXSBkYXJrOmhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgdGl0bGU9XCJUb2dnbGUgVGhlbWVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHt0aGVtZSA9PT0gXCJkYXJrXCIgPyA8U3VuIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz4gOiA8TW9vbiBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+fVxuICAgICAgICAgICAgPHNwYW4+e3RoZW1lID09PSBcImRhcmtcIiA/IFwiTGlnaHRcIiA6IFwiRGFya1wifTwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAgey8qIE1haW4gQ29udGVudCBBcmVhICovfVxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIG1heC13LTd4bCB3LWZ1bGwgbXgtYXV0byBweC02IHB5LTEyIG1kOnB5LTIwIGdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTEyIGdhcC0xMiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgey8qIExlZnQgQ29sdW1uOiBIZXJvIFRleHQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNyBzcGFjZS15LThcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LVsjMjQ4ZDYxXSBkYXJrOnRleHQtWyMzY2QzOTVdXCI+RS1GSU5BTkNFIEFQUDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBzbTp0ZXh0LTV4bCBsZzp0ZXh0LTZ4bCBmb250LW1lZGl1bSB0ZXh0LVsjMGEyNzFjXSBkYXJrOnRleHQtd2hpdGUgbGVhZGluZy1bMS4xNV0gdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgIFRha2UgQ29udHJvbCBvZiBZb3VyIFdlYWx0aCwgPGJyIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsjMjQ4ZDYxXSBkYXJrOnRleHQtWyMzY2QzOTVdXCI+U2VjdXJlIGFuZCBQcml2YXRlLjwvc3Bhbj5cbiAgICAgICAgICA8L2gxPlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTQgcHQtMlwiPlxuICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgdG89XCIvbG9naW5cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1bIzNjZDM5NV0gaG92ZXI6YmctWyM0YmU0YTRdIHRleHQtYmxhY2sgZm9udC1zZW1pYm9sZCBweC01IHB5LTIuNSByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1hbGwgaG92ZXI6dHJhbnNsYXRlLXgtMC41XCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgU2lnbiBJbiB0byBZb3VyIEFjY291bnQgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogVmFsdWUgUHJvcHMgR3JpZCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTQgcHQtOCBib3JkZXItdCBib3JkZXItWyNjY2U4ZGJdLzYwIGRhcms6Ym9yZGVyLVsjMTIzMDIyXS80MCBtYXgtdy1sZ1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJoLTUgdy01IHRleHQtWyMyNDhkNjFdIGRhcms6dGV4dC1bIzNjZDM5NV0gc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LVsjMGEyNzFjXSBkYXJrOnRleHQtd2hpdGUgdGV4dC1zbVwiPlJvdyBMZXZlbCBTZWN1cml0eTwvaDQ+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMFwiPkRhdGFiYXNlIHNlY3VyaXR5IHBvbGljaWVzIGVuZm9yY2VkIGJ5IFN1cGFiYXNlLjwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LVsjMjQ4ZDYxXSBkYXJrOnRleHQtWyMzY2QzOTVdIHNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1bIzBhMjcxY10gZGFyazp0ZXh0LXdoaXRlIHRleHQtc21cIj5JbnN0YW50IEluc2lnaHRzPC9oND5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtemluYy01MDAgZGFyazp0ZXh0LXppbmMtNDAwXCI+QW5hbHl6ZSB5b3VyIG5ldCB3b3J0aCBhbmQgdHJhY2sgaGFiaXRzIGluIHJlYWwgdGltZS48L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBSaWdodCBDb2x1bW46IEdsYXNzbW9ycGhpYyBTaWdudXAgQ2FyZCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi01IGZsZXgganVzdGlmeS1jZW50ZXIgbGc6anVzdGlmeS1lbmRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1tZCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLVsjY2NlOGRiXSBkYXJrOmJvcmRlci1bIzFhNDIzMF0gYmctd2hpdGUvODAgZGFyazpiZy1bIzBhMWUxNV0vNjAgYmFja2Ryb3AtYmx1ci1tZCBwLTggc2hhZG93LTJ4bCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgIHsvKiBCYWNrZ3JvdW5kIGFtYmllbnQgZ2xvdyBpbnNpZGUgY2FyZCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC0xMCAtcmlnaHQtMTAgdy0zMiBoLTMyIGJnLVsjM2NkMzk1XS8xMCByb3VuZGVkLWZ1bGwgYmx1ci0zeGwgcG9pbnRlci1ldmVudHMtbm9uZVwiPjwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LVsjMGEyNzFjXSBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj5DcmVhdGUgQWNjb3VudDwvaDI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMCBtdC0xXCI+UmVnaXN0ZXIgdG8gc3RhcnQgbWFuYWdpbmcgeW91ciBmaW5hbmNlczwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAge2Vycm9yTXNnICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1yZWQtNTAwLzMwIGJnLXJlZC01MDAvMTAgcC0zIHRleHQtc20gdGV4dC1yZWQtNjUwIGRhcms6dGV4dC1yZWQtNDAwIG1iLTQgYW5pbWF0ZS1wdWxzZVwiPlxuICAgICAgICAgICAgICAgICAge2Vycm9yTXNnfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHtzdWNjZXNzTXNnICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1bIzNjZDM5NV0vMzAgYmctWyMzY2QzOTVdLzEwIHAtMyB0ZXh0LXNtIHRleHQtWyMyNDhkNjFdIGRhcms6dGV4dC1bIzNjZDM5NV0gbWItNFwiPlxuICAgICAgICAgICAgICAgICAge3N1Y2Nlc3NNc2d9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS00XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChvblN1Ym1pdCl9PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJmaXJzdE5hbWVcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtemluYy01NTAgZGFyazp0ZXh0LXppbmMtNDAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICBGaXJzdCBOYW1lXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZmlyc3ROYW1lXCJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiZmlyc3ROYW1lXCIpfVxuICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwic2lnbnVwLWZpcnN0LW5hbWUtaW5wdXRcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJsb2NrIHctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBiZy13aGl0ZSBkYXJrOmJnLVsjMDUxNjBFXS84MCBib3JkZXItWyNjY2U4ZGJdIGRhcms6Ym9yZGVyLVsjMWE0MjMwXSBweC0zIHB5LTIgdGV4dC1zbSB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci16aW5jLTQwMCBkYXJrOnBsYWNlaG9sZGVyLXppbmMtNTAwIGZvY3VzOmJvcmRlci1bIzI0OGQ2MV0gZGFyazpmb2N1czpib3JkZXItWyMzY2QzOTVdIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1bIzNjZDM5NV0vNDAgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9ycy5maXJzdE5hbWUgPyBcImJvcmRlci1yZWQtNTAwXCIgOiBcIlwiXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJKb2huXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5maXJzdE5hbWUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDAgZGFyazp0ZXh0LXJlZC00MDBcIj57ZXJyb3JzLmZpcnN0TmFtZS5tZXNzYWdlfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImxhc3ROYW1lXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXppbmMtNTUwIGRhcms6dGV4dC16aW5jLTQwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgTGFzdCBOYW1lXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwibGFzdE5hbWVcIlxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJsYXN0TmFtZVwiKX1cbiAgICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cInNpZ251cC1sYXN0LW5hbWUtaW5wdXRcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJsb2NrIHctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBiZy13aGl0ZSBkYXJrOmJnLVsjMDUxNjBFXS84MCBib3JkZXItWyNjY2U4ZGJdIGRhcms6Ym9yZGVyLVsjMWE0MjMwXSBweC0zIHB5LTIgdGV4dC1zbSB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci16aW5jLTQwMCBkYXJrOnBsYWNlaG9sZGVyLXppbmMtNTAwIGZvY3VzOmJvcmRlci1bIzI0OGQ2MV0gZGFyazpmb2N1czpib3JkZXItWyMzY2QzOTVdIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1bIzNjZDM5NV0vNDAgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9ycy5sYXN0TmFtZSA/IFwiYm9yZGVyLXJlZC01MDBcIiA6IFwiXCJcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRvZVwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubGFzdE5hbWUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDAgZGFyazp0ZXh0LXJlZC00MDBcIj57ZXJyb3JzLmxhc3ROYW1lLm1lc3NhZ2V9PC9wPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJlbWFpbFwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC16aW5jLTU1MCBkYXJrOnRleHQtemluYy00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICBFbWFpbCBBZGRyZXNzXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImVtYWlsXCIpfVxuICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cInNpZ251cC1lbWFpbC1pbnB1dFwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJsb2NrIHctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBiZy13aGl0ZSBkYXJrOmJnLVsjMDUxNjBFXS84MCBib3JkZXItWyNjY2U4ZGJdIGRhcms6Ym9yZGVyLVsjMWE0MjMwXSBweC0zIHB5LTIuNSB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXppbmMtNDAwIGRhcms6cGxhY2Vob2xkZXItemluYy01MDAgZm9jdXM6Ym9yZGVyLVsjMjQ4ZDYxXSBkYXJrOmZvY3VzOmJvcmRlci1bIzNjZDM5NV0gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLVsjM2NkMzk1XS80MCB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICAgIGVycm9ycy5lbWFpbCA/IFwiYm9yZGVyLXJlZC01MDBcIiA6IFwiXCJcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZXhhbXBsZUBtYWlsLmNvbVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbWFpbCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDAgZGFyazp0ZXh0LXJlZC00MDBcIj57ZXJyb3JzLmVtYWlsLm1lc3NhZ2V9PC9wPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBhc3N3b3JkXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXppbmMtNTUwIGRhcms6dGV4dC16aW5jLTQwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIFBhc3N3b3JkXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIGlkPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJuZXctcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJwYXNzd29yZFwiKX1cbiAgICAgICAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJzaWdudXAtcGFzc3dvcmQtaW5wdXRcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BibG9jayB3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYmctd2hpdGUgZGFyazpiZy1bIzA1MTYwRV0vODAgYm9yZGVyLVsjY2NlOGRiXSBkYXJrOmJvcmRlci1bIzFhNDIzMF0gcHgtMyBweS0yLjUgdGV4dC1zbSB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci16aW5jLTQwMCBkYXJrOnBsYWNlaG9sZGVyLXppbmMtNTAwIGZvY3VzOmJvcmRlci1bIzI0OGQ2MV0gZGFyazpmb2N1czpib3JkZXItWyMzY2QzOTVdIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1bIzNjZDM5NV0vNDAgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICBlcnJvcnMucGFzc3dvcmQgPyBcImJvcmRlci1yZWQtNTAwXCIgOiBcIlwiXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuKAouKAouKAouKAouKAouKAouKAouKAolwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDAgZGFyazp0ZXh0LXJlZC00MDBcIj57ZXJyb3JzLnBhc3N3b3JkLm1lc3NhZ2V9PC9wPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImNvbmZpcm1QYXNzd29yZFwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC16aW5jLTU1MCBkYXJrOnRleHQtemluYy00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICBDb25maXJtIFBhc3N3b3JkXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIGlkPVwiY29uZmlybVBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwibmV3LXBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiY29uZmlybVBhc3N3b3JkXCIpfVxuICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cInNpZ251cC1jb25maXJtLXBhc3N3b3JkLWlucHV0XCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmxvY2sgdy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJnLXdoaXRlIGRhcms6YmctWyMwNTE2MEVdLzgwIGJvcmRlci1bI2NjZThkYl0gZGFyazpib3JkZXItWyMxYTQyMzBdIHB4LTMgcHktMi41IHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgcGxhY2Vob2xkZXItemluYy00MDAgZGFyazpwbGFjZWhvbGRlci16aW5jLTUwMCBmb2N1czpib3JkZXItWyMyNDhkNjFdIGRhcms6Zm9jdXM6Ym9yZGVyLVsjM2NkMzk1XSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctWyMzY2QzOTVdLzQwIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgZXJyb3JzLmNvbmZpcm1QYXNzd29yZCA/IFwiYm9yZGVyLXJlZC01MDBcIiA6IFwiXCJcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCiXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvbmZpcm1QYXNzd29yZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDAgZGFyazp0ZXh0LXJlZC00MDBcIj57ZXJyb3JzLmNvbmZpcm1QYXNzd29yZC5tZXNzYWdlfTwvcD5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTJcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XG4gICAgICAgICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwic2lnbnVwLXN1Ym1pdC1idXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHctZnVsbCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC1sZyBiZy1bIzNjZDM5NV0gaG92ZXI6YmctWyM0YmU0YTRdIHB4LTQgcHktMi41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIHRyYW5zaXRpb24tY29sb3JzIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzNjZDM5NV0gZm9jdXM6cmluZy1vZmZzZXQtMiBmb2N1czpyaW5nLW9mZnNldC1bIzBhMWUxNV0gZGlzYWJsZWQ6b3BhY2l0eS01MCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtpc1N1Ym1pdHRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTUgdy01IGFuaW1hdGUtc3BpbiByb3VuZGVkLWZ1bGwgYm9yZGVyLTIgYm9yZGVyLWJsYWNrIGJvcmRlci10LXRyYW5zcGFyZW50XCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlNpZ24gVXA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LXhzIHRleHQtemluYy01MDAgZGFyazp0ZXh0LXppbmMtNDUwIG10LTYgcHQtNCBib3JkZXItdCBib3JkZXItWyNjY2U4ZGJdLzYwIGRhcms6Ym9yZGVyLVsjMTIzMDIyXS80MFwiPlxuICAgICAgICAgICAgICAgICAgQWxyZWFkeSBoYXZlIGFuIGFjY291bnQ/e1wiIFwifVxuICAgICAgICAgICAgICAgICAgPExpbmsgdG89XCIvbG9naW5cIiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtWyMyNDhkNjFdIGRhcms6dGV4dC1bIzNjZDM5NV0gaG92ZXI6dGV4dC1bIzJmYWU3YV0gZGFyazpob3Zlcjp0ZXh0LVsjNGJlNGE0XSB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICBTaWduIEluXG4gICAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvbWFpbj5cblxuICAgICAgey8qIEZvb3RlciAqL31cbiAgICAgIDxmb290ZXIgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LTd4bCBteC1hdXRvIHB4LTYgcHktOCBtdC1hdXRvIGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtemluYy01MDAgYm9yZGVyLXQgYm9yZGVyLVsjY2NlOGRiXS80MCBkYXJrOmJvcmRlci1bIzEyMzAyMl0vMjBcIj5cbiAgICAgICAgPHA+JmNvcHk7IHtuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCl9IEUtRmluYW5jZSBieSBya0RFVi4gQWxsIHJpZ2h0cyByZXNlcnZlZC48L3A+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgc206bXQtMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cImgtMy41IHctMy41IHRleHQtWyMyNDhkNjFdIGRhcms6dGV4dC1bIzNjZDM5NV1cIiAvPiBCdWlsdCBmb3IgdXNlciBwcml2YWN5LlxuICAgICAgICA8L3A+XG4gICAgICA8L2Zvb3Rlcj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=