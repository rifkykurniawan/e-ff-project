import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SavingGoalsPage.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport12_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=513be775";
import { Plus, Edit2, Trash2, Calendar, Target, Award, PiggyBank } from "/node_modules/.vite/deps/lucide-react.js?v=7df35618";
import { useSavingGoals } from "/src/hooks/useSavingGoals.ts";
import { Modal } from "/src/components/Modal.tsx";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=0a9b0578";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=9dd4f110";
import { savingGoalSchema } from "/src/types/savingGoals.ts";
import { useAccounts } from "/src/hooks/useAccounts.ts";
import { useCategories } from "/src/hooks/useCategories.ts";
import { useTransactions } from "/src/hooks/useTransactions.ts";
import { z } from "/node_modules/.vite/deps/zod.js?v=9219c26e";
import { useOutletContext } from "/node_modules/.vite/deps/react-router-dom.js?v=63710477";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/SavingGoalsPage.tsx";
import __vite__cjsImport12_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
var _s = $RefreshSig$();
const addSavingsSchema = z.object({
	amount: z.coerce.number().positive("Amount must be greater than 0"),
	source_account_id: z.string().uuid("Please select a valid source account"),
	category_id: z.string().uuid("Please select a valid category").optional().nullable(),
	date: z.string().min(1, "Date is required")
});
export function SavingGoalsPage() {
	_s();
	const [isModalOpen, setIsModalOpen] = useState(false);
	const [editingGoal, setEditingGoal] = useState(null);
	const [addingSavingsGoal, setAddingSavingsGoal] = useState(null);
	const { showBalances } = useOutletContext();
	const formatAmount = (val) => {
		return showBalances ? `Rp ${val.toLocaleString()}` : "Rp ••••••";
	};
	const { savingGoals, isLoading, createSavingGoal, updateSavingGoal, deleteSavingGoal } = useSavingGoals();
	const { accounts } = useAccounts();
	const { categories } = useCategories();
	const { createTransaction, isCreating: isLoggingTransaction } = useTransactions();
	// Local copies of addingSavingsGoal fields to avoid TS null narrowing issues in JSX
	const addingGoalName = addingSavingsGoal?.name || "";
	const addingGoalTarget = addingSavingsGoal?.target_amount ?? 0;
	const addingGoalCurrent = addingSavingsGoal?.current_amount ?? 0;
	// Form for Set/Edit Goal
	const { register, handleSubmit, formState: { errors }, reset, watch } = useForm({
		resolver: zodResolver(savingGoalSchema),
		defaultValues: {
			name: "",
			target_amount: 0,
			current_amount: 0,
			target_date: "",
			notes: "",
			account_id: ""
		}
	});
	const watchedAccountId = watch("account_id");
	// Form for Add Savings Modal
	const { register: registerSavings, handleSubmit: handleSubmitSavings, formState: { errors: savingsErrors }, reset: resetSavings } = useForm({
		resolver: zodResolver(addSavingsSchema),
		defaultValues: {
			amount: undefined,
			source_account_id: "",
			category_id: "",
			date: new Date().toISOString().split("T")[0]
		}
	});
	const handleOpenAddModal = () => {
		setEditingGoal(null);
		reset({
			name: "",
			target_amount: 0,
			current_amount: 0,
			target_date: "",
			notes: "",
			account_id: ""
		});
		setIsModalOpen(true);
	};
	const handleOpenEditModal = (goal) => {
		setEditingGoal(goal);
		reset({
			name: goal.name,
			target_amount: goal.target_amount,
			current_amount: goal.current_amount,
			target_date: goal.target_date || "",
			notes: goal.notes || "",
			account_id: goal.account_id || ""
		});
		setIsModalOpen(true);
	};
	const handleCloseModal = () => {
		setIsModalOpen(false);
		setEditingGoal(null);
	};
	const handleOpenAddSavings = (goal) => {
		setAddingSavingsGoal(goal);
		const matchedCategory = categories.find((c) => c.type === "Expense" && (c.name.toLowerCase().includes("saving") || c.name.toLowerCase().includes("tabungan")));
		resetSavings({
			amount: undefined,
			source_account_id: "",
			category_id: matchedCategory?.id || categories.find((c) => c.type === "Expense")?.id || "",
			date: new Date().toISOString().split("T")[0]
		});
	};
	const handleCloseSavingsModal = () => {
		setAddingSavingsGoal(null);
		resetSavings();
	};
	const onSavingsFormSubmit = async (data) => {
		if (!addingSavingsGoal) return;
		const potentialNewAmount = Number(addingSavingsGoal.current_amount) + Number(data.amount);
		if (potentialNewAmount > Number(addingSavingsGoal.target_amount)) {
			alert("Added amount exceeds target goal limit.");
			return;
		}
		try {
			if (addingSavingsGoal.account_id) {
				// If the saving goal has its own account, log a Transfer from source to the saving goal's account
				await createTransaction({
					description: `Savings: ${addingSavingsGoal.name}`,
					amount: data.amount,
					type: "Transfer",
					date: data.date,
					source_account_id: data.source_account_id,
					destination_account_id: addingSavingsGoal.account_id,
					notes: `Savings contribution to goal "${addingSavingsGoal.name}"`
				});
			} else {
				// Fallback: update saving goal directly and log as Expense
				await updateSavingGoal({
					id: addingSavingsGoal.id,
					input: { current_amount: potentialNewAmount }
				});
				await createTransaction({
					description: `Savings: ${addingSavingsGoal.name}`,
					amount: data.amount,
					type: "Expense",
					date: data.date,
					source_account_id: data.source_account_id,
					category_id: data.category_id || undefined,
					notes: `Savings contribution to goal "${addingSavingsGoal.name}"`
				});
			}
			handleCloseSavingsModal();
		} catch (err) {
			console.error(err);
			alert(err.message || "Failed to add savings.");
		}
	};
	const handleDelete = async (id) => {
		if (confirm("Are you sure you want to delete this saving goal?")) {
			try {
				await deleteSavingGoal(id);
			} catch (err) {
				console.error(err);
				alert(err.message || "Failed to delete saving goal.");
			}
		}
	};
	const onFormSubmit = async (data) => {
		try {
			if (editingGoal) {
				await updateSavingGoal({
					id: editingGoal.id,
					input: data
				});
			} else {
				await createSavingGoal(data);
			}
			handleCloseModal();
		} catch (err) {
			console.error(err);
			alert(err.message || "Failed to save saving goal.");
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-2xl font-bold text-zinc-900 dark:text-white tracking-tight flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV(Target, { className: "h-6 w-6 text-emerald-500" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 212,
					columnNumber: 13
				}, this), "Saving Goals"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 211,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-zinc-500 dark:text-zinc-400 mt-1",
				children: "Set, track, and manage your family's savings targets."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 215,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 210,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				onClick: handleOpenAddModal,
				"data-testid": "add-goal-button",
				className: "flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-lg text-sm font-medium transition-colors shadow-sm",
				children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "h-4 w-4" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 222,
					columnNumber: 11
				}, this), "Add Goal"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 217,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 209,
			columnNumber: 7
		}, this),
		isLoading ? /* @__PURE__ */ _jsxDEV("div", {
			className: "flex h-64 items-center justify-center text-zinc-500",
			children: "Loading saving goals..."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 229,
			columnNumber: 9
		}, this) : savingGoals.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 p-12 text-center",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-zinc-100 dark:bg-zinc-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4",
					children: /* @__PURE__ */ _jsxDEV(Award, { className: "h-8 w-8 text-zinc-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 233,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 232,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-lg font-semibold text-zinc-900 dark:text-white mb-2",
					children: "No Saving Goals Found"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 235,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-zinc-500 dark:text-zinc-400 mb-6 max-w-sm mx-auto",
					children: "You don't have any savings targets configured. Let's create your first goal!"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 236,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: handleOpenAddModal,
					className: "inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors",
					children: "Create Your First Goal"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 239,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 231,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
			children: savingGoals.map((goal) => {
				const progress = goal.target_amount > 0 ? goal.current_amount / goal.target_amount * 100 : 0;
				const isCompleted = progress >= 100;
				return /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 p-6 flex flex-col justify-between shadow-sm relative overflow-hidden group",
					children: [
						isCompleted && /* @__PURE__ */ _jsxDEV("div", {
							className: "absolute top-0 right-0 bg-emerald-500 text-white text-xs px-3 py-1 font-semibold rounded-bl-lg uppercase tracking-wider",
							children: "Completed"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 259,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between items-start mb-2 pr-12",
								children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-lg font-bold text-zinc-900 dark:text-white line-clamp-1",
									children: goal.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 267,
									columnNumber: 23
								}, this), goal.accounts && /* @__PURE__ */ _jsxDEV("span", {
									className: "inline-block mt-1 text-xs font-medium text-emerald-600 dark:text-emerald-450 bg-emerald-500/10 px-2 py-0.5 rounded",
									children: ["Account: ", goal.accounts.name]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 269,
									columnNumber: 25
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 266,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 265,
								columnNumber: 19
							}, this),
							goal.target_date && /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1 text-xs text-zinc-400 dark:text-zinc-500 mb-4",
								children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "h-3.5 w-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 278,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Target: ", new Date(goal.target_date).toLocaleDateString(undefined, {
									month: "short",
									day: "numeric",
									year: "numeric"
								})] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 279,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 277,
								columnNumber: 21
							}, this),
							goal.notes && /* @__PURE__ */ _jsxDEV("p", {
								className: "text-sm text-zinc-500 dark:text-zinc-400 line-clamp-2 mb-5 h-10",
								children: goal.notes
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 284,
								columnNumber: 21
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 264,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2 mb-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between items-end text-xs font-semibold",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-zinc-500 dark:text-zinc-400",
									children: [
										formatAmount(goal.current_amount),
										" / ",
										formatAmount(goal.target_amount)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 292,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-emerald-600 dark:text-emerald-400 font-bold",
									children: [progress.toFixed(0), "%"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 295,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 291,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "w-full bg-zinc-100 dark:bg-zinc-800 h-2.5 rounded-full overflow-hidden",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: `h-full rounded-full transition-all duration-300 ${isCompleted ? "bg-emerald-500" : "bg-emerald-500"}`,
									style: { width: `${Math.min(progress, 100)}%` }
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 298,
									columnNumber: 23
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 297,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 290,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-end items-center gap-2 pt-2 border-t border-zinc-100 dark:border-zinc-800/80",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleOpenAddSavings(goal),
									disabled: isCompleted,
									"data-testid": "add-savings-button",
									className: "flex-1 mr-2 flex items-center justify-center gap-1.5 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-500/10 dark:hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all disabled:opacity-50 disabled:pointer-events-none cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV(PiggyBank, { className: "h-3.5 w-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 315,
										columnNumber: 23
									}, this), "Add Savings"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 309,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleOpenEditModal(goal),
									"data-testid": "edit-goal-button",
									className: "p-2 text-zinc-400 hover:text-zinc-600 dark:hover:text-white hover:bg-zinc-100 dark:hover:bg-zinc-850 rounded-lg transition-all cursor-pointer",
									title: "Edit Goal",
									children: /* @__PURE__ */ _jsxDEV(Edit2, { className: "h-4 w-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 324,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 318,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleDelete(goal.id),
									"data-testid": "delete-goal-button",
									className: "p-2 text-zinc-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 rounded-lg transition-all cursor-pointer",
									title: "Delete Goal",
									children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "h-4 w-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 332,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 326,
									columnNumber: 21
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 308,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 288,
							columnNumber: 17
						}, this)
					]
				}, goal.id, true, {
					fileName: _jsxFileName,
					lineNumber: 253,
					columnNumber: 15
				}, this);
			})
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 247,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(Modal, {
			isOpen: isModalOpen,
			onClose: handleCloseModal,
			title: editingGoal ? "Edit Saving Goal" : "Create Saving Goal",
			children: /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit(onFormSubmit),
				className: "space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
							children: "Goal Name"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 351,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							...register("name"),
							placeholder: "e.g., Vacation fund, Downpayment",
							className: `w-full rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.name ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 354,
							columnNumber: 13
						}, this),
						errors.name?.message && /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-1 text-xs text-red-500",
							children: errors.name?.message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 362,
							columnNumber: 38
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 350,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
							children: "Associated Account (e.g. BCA, BRI, Seabank)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 367,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "relative",
							children: [/* @__PURE__ */ _jsxDEV("select", {
								...register("account_id"),
								className: `w-full appearance-none rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 pr-10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.account_id ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`,
								children: [/* @__PURE__ */ _jsxDEV("option", {
									value: "",
									children: "No account (manual balance tracking)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 377,
									columnNumber: 17
								}, this), accounts.map((acc) => /* @__PURE__ */ _jsxDEV("option", {
									value: acc.id,
									children: [
										acc.name,
										" (",
										acc.type,
										") - Rp ",
										acc.balance.toLocaleString()
									]
								}, acc.id, true, {
									fileName: _jsxFileName,
									lineNumber: 379,
									columnNumber: 19
								}, this))]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 371,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-zinc-500",
								children: /* @__PURE__ */ _jsxDEV("svg", {
									className: "h-4 w-4",
									fill: "none",
									stroke: "currentColor",
									viewBox: "0 0 24 24",
									xmlns: "http://www.w3.org/2000/svg",
									children: /* @__PURE__ */ _jsxDEV("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										strokeWidth: "2",
										d: "M19 9l-7 7-7-7"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 386,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 385,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 384,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 370,
							columnNumber: 13
						}, this),
						errors.account_id?.message && /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-1 text-xs text-red-500",
							children: errors.account_id?.message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 390,
							columnNumber: 44
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 366,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
								children: "Target Amount (Rp)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 396,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "number",
								...register("target_amount"),
								placeholder: "0",
								className: `w-full rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.target_amount ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 399,
								columnNumber: 15
							}, this),
							errors.target_amount?.message && /* @__PURE__ */ _jsxDEV("p", {
								className: "mt-1 text-xs text-red-500",
								children: errors.target_amount?.message
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 407,
								columnNumber: 49
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 395,
							columnNumber: 13
						}, this), !watchedAccountId && /* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
								children: "Current Amount (Rp)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 413,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "number",
								...register("current_amount"),
								placeholder: "0",
								className: `w-full rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.current_amount ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 416,
								columnNumber: 17
							}, this),
							errors.current_amount?.message && /* @__PURE__ */ _jsxDEV("p", {
								className: "mt-1 text-xs text-red-500",
								children: errors.current_amount?.message
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 424,
								columnNumber: 52
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 412,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 393,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
							children: "Target Date (Optional)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 431,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("input", {
							type: "date",
							...register("target_date"),
							className: `w-full rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.target_date ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 434,
							columnNumber: 13
						}, this),
						errors.target_date?.message && /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-1 text-xs text-red-500",
							children: errors.target_date?.message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 441,
							columnNumber: 45
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 430,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
						children: "Notes (Optional)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 446,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("textarea", {
						...register("notes"),
						placeholder: "Provide context or details about this saving goal...",
						rows: 3,
						className: "w-full rounded-lg border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 px-3 py-2 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 449,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 445,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "pt-4 flex justify-end",
						children: /* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							className: "w-full sm:w-auto rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 transition-colors",
							children: editingGoal ? "Save Goal" : "Create Goal"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 459,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 458,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 348,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 343,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Modal, {
			isOpen: addingSavingsGoal !== null,
			onClose: handleCloseSavingsModal,
			title: addingSavingsGoal ? `Add Savings to ${addingGoalName}` : "Add Savings",
			children: /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmitSavings(onSavingsFormSubmit),
				className: "space-y-4",
				children: [
					addingSavingsGoal && /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-zinc-50 dark:bg-zinc-950 p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 text-xs text-zinc-505 dark:text-zinc-500 space-y-1",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Target Amount:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 480,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "font-semibold text-zinc-800 dark:text-zinc-200",
									children: formatAmount(addingGoalTarget)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 481,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 479,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Current Amount:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 484,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "font-semibold text-zinc-800 dark:text-zinc-200",
									children: formatAmount(addingGoalCurrent)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 485,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 483,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between border-t border-zinc-200 dark:border-zinc-800 pt-1.5 mt-1 text-emerald-600 dark:text-emerald-400 font-medium",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Remaining to Save:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 488,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: formatAmount(addingGoalTarget - addingGoalCurrent) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 489,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 487,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 478,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
							children: "Amount to Add (Rp)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 496,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("input", {
							type: "number",
							...registerSavings("amount"),
							placeholder: "e.g., 500000",
							className: `w-full rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${savingsErrors.amount ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 499,
							columnNumber: 13
						}, this),
						savingsErrors.amount?.message && /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-1 text-xs text-red-500",
							children: savingsErrors.amount?.message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 507,
							columnNumber: 47
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 495,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
							children: "Source Account (to Deduct From)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 512,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "relative",
							children: [/* @__PURE__ */ _jsxDEV("select", {
								...registerSavings("source_account_id"),
								className: `w-full appearance-none rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 pr-10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${savingsErrors.source_account_id ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`,
								children: [/* @__PURE__ */ _jsxDEV("option", {
									value: "",
									children: "Select source account..."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 522,
									columnNumber: 17
								}, this), accounts.map((acc) => /* @__PURE__ */ _jsxDEV("option", {
									value: acc.id,
									children: [
										acc.name,
										" (Rp ",
										acc.balance.toLocaleString(),
										")"
									]
								}, acc.id, true, {
									fileName: _jsxFileName,
									lineNumber: 524,
									columnNumber: 19
								}, this))]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 516,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-zinc-500",
								children: /* @__PURE__ */ _jsxDEV("svg", {
									className: "h-4 w-4",
									fill: "none",
									stroke: "currentColor",
									viewBox: "0 0 24 24",
									xmlns: "http://www.w3.org/2000/svg",
									children: /* @__PURE__ */ _jsxDEV("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										strokeWidth: "2",
										d: "M19 9l-7 7-7-7"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 531,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 530,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 529,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 515,
							columnNumber: 13
						}, this),
						savingsErrors.source_account_id?.message && /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-1 text-xs text-red-500",
							children: savingsErrors.source_account_id?.message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 535,
							columnNumber: 59
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 511,
						columnNumber: 11
					}, this),
					!addingSavingsGoal?.account_id && /* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
							children: "Expense Category"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 541,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "relative",
							children: [/* @__PURE__ */ _jsxDEV("select", {
								...registerSavings("category_id"),
								className: `w-full appearance-none rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 pr-10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${savingsErrors.category_id ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`,
								children: [/* @__PURE__ */ _jsxDEV("option", {
									value: "",
									children: "Select category..."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 551,
									columnNumber: 19
								}, this), categories.filter((c) => c.type === "Expense").map((cat) => /* @__PURE__ */ _jsxDEV("option", {
									value: cat.id,
									children: cat.name
								}, cat.id, false, {
									fileName: _jsxFileName,
									lineNumber: 553,
									columnNumber: 21
								}, this))]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 545,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-zinc-500",
								children: /* @__PURE__ */ _jsxDEV("svg", {
									className: "h-4 w-4",
									fill: "none",
									stroke: "currentColor",
									viewBox: "0 0 24 24",
									xmlns: "http://www.w3.org/2000/svg",
									children: /* @__PURE__ */ _jsxDEV("path", {
										strokeLinecap: "round",
										strokeLinejoin: "round",
										strokeWidth: "2",
										d: "M19 9l-7 7-7-7"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 560,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 559,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 558,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 544,
							columnNumber: 15
						}, this),
						savingsErrors.category_id?.message && /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-1 text-xs text-red-500",
							children: savingsErrors.category_id?.message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 564,
							columnNumber: 55
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 540,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
							children: "Date"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 570,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("input", {
							type: "date",
							...registerSavings("date"),
							className: `w-full rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${savingsErrors.date ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 573,
							columnNumber: 13
						}, this),
						savingsErrors.date?.message && /* @__PURE__ */ _jsxDEV("p", {
							className: "mt-1 text-xs text-red-500",
							children: savingsErrors.date?.message
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 580,
							columnNumber: 46
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 569,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "pt-4 flex justify-end",
						children: /* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: isLoggingTransaction,
							className: "w-full sm:w-auto rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 disabled:opacity-50 transition-colors cursor-pointer",
							children: isLoggingTransaction ? "Adding Savings..." : "Confirm & Add"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 585,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 584,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 475,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 470,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 207,
		columnNumber: 5
	}, this);
}
_s(SavingGoalsPage, "mIwK8FTwadsrsCZwx7aEhDGhLPY=", false, function() {
	return [
		useOutletContext,
		useSavingGoals,
		useAccounts,
		useCategories,
		useTransactions,
		useForm,
		useForm
	];
});
_c = SavingGoalsPage;
var _c;
$RefreshReg$(_c, "SavingGoalsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/SavingGoalsPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/SavingGoalsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/SavingGoalsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/SavingGoalsPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLE9BQU8sUUFBUSxVQUFVLFFBQVEsT0FBTyxpQkFBaUI7QUFDeEUsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsZUFBZTtBQUN4QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLHdCQUErRDtBQUN4RSxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLHFCQUFxQjtBQUM5QixTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLFNBQVM7QUFDbEIsU0FBUyx3QkFBd0I7Ozs7QUFFakMsTUFBTSxtQkFBbUIsRUFBRSxPQUFPO0NBQ2hDLFFBQVEsRUFBRSxPQUFPLE9BQU8sQ0FBQyxDQUFDLFNBQVMsK0JBQStCO0NBQ2xFLG1CQUFtQixFQUFFLE9BQU8sQ0FBQyxDQUFDLEtBQUssc0NBQXNDO0NBQ3pFLGFBQWEsRUFBRSxPQUFPLENBQUMsQ0FBQyxLQUFLLGdDQUFnQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUztDQUNuRixNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxHQUFHLGtCQUFrQjtBQUM1QyxDQUFDO0FBR0QsT0FBTyxTQUFTLGtCQUFrQjs7Q0FDaEMsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsS0FBSztDQUNwRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBNEIsSUFBSTtDQUN0RSxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUE0QixJQUFJO0NBQ2xGLE1BQU0sRUFBRSxpQkFBaUIsaUJBQTRDO0NBRXJFLE1BQU0sZ0JBQWdCLFFBQWdCO0VBQ3BDLE9BQU8sZUFBZSxNQUFNLElBQUksZUFBZSxNQUFNO0NBQ3ZEO0NBRUEsTUFBTSxFQUFFLGFBQWEsV0FBVyxrQkFBa0Isa0JBQWtCLHFCQUFxQixlQUFlO0NBQ3hHLE1BQU0sRUFBRSxhQUFhLFlBQVk7Q0FDakMsTUFBTSxFQUFFLGVBQWUsY0FBYztDQUNyQyxNQUFNLEVBQUUsbUJBQW1CLFlBQVkseUJBQXlCLGdCQUFnQjs7Q0FHaEYsTUFBTSxpQkFBaUIsbUJBQW1CLFFBQVE7Q0FDbEQsTUFBTSxtQkFBbUIsbUJBQW1CLGlCQUFpQjtDQUM3RCxNQUFNLG9CQUFvQixtQkFBbUIsa0JBQWtCOztDQUcvRCxNQUFNLEVBQ0osVUFDQSxjQUNBLFdBQVcsRUFBRSxVQUNiLE9BQ0EsVUFDRSxRQUF5QjtFQUMzQixVQUFVLFlBQVksZ0JBQWdCO0VBQ3RDLGVBQWU7R0FDYixNQUFNO0dBQ04sZUFBZTtHQUNmLGdCQUFnQjtHQUNoQixhQUFhO0dBQ2IsT0FBTztHQUNQLFlBQVk7RUFDZDtDQUNGLENBQUM7Q0FFRCxNQUFNLG1CQUFtQixNQUFNLFlBQVk7O0NBRzNDLE1BQU0sRUFDSixVQUFVLGlCQUNWLGNBQWMscUJBQ2QsV0FBVyxFQUFFLFFBQVEsaUJBQ3JCLE9BQU8saUJBQ0wsUUFBeUI7RUFDM0IsVUFBVSxZQUFZLGdCQUFnQjtFQUN0QyxlQUFlO0dBQ2IsUUFBUTtHQUNSLG1CQUFtQjtHQUNuQixhQUFhO0dBQ2IsTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7RUFDNUM7Q0FDRixDQUFDO0NBRUQsTUFBTSwyQkFBMkI7RUFDL0IsZUFBZSxJQUFJO0VBQ25CLE1BQU07R0FDSixNQUFNO0dBQ04sZUFBZTtHQUNmLGdCQUFnQjtHQUNoQixhQUFhO0dBQ2IsT0FBTztHQUNQLFlBQVk7RUFDZCxDQUFDO0VBQ0QsZUFBZSxJQUFJO0NBQ3JCO0NBRUEsTUFBTSx1QkFBdUIsU0FBcUI7RUFDaEQsZUFBZSxJQUFJO0VBQ25CLE1BQU07R0FDSixNQUFNLEtBQUs7R0FDWCxlQUFlLEtBQUs7R0FDcEIsZ0JBQWdCLEtBQUs7R0FDckIsYUFBYSxLQUFLLGVBQWU7R0FDakMsT0FBTyxLQUFLLFNBQVM7R0FDckIsWUFBWSxLQUFLLGNBQWM7RUFDakMsQ0FBQztFQUNELGVBQWUsSUFBSTtDQUNyQjtDQUVBLE1BQU0seUJBQXlCO0VBQzdCLGVBQWUsS0FBSztFQUNwQixlQUFlLElBQUk7Q0FDckI7Q0FFQSxNQUFNLHdCQUF3QixTQUFxQjtFQUNqRCxxQkFBcUIsSUFBSTtFQUN6QixNQUFNLGtCQUFrQixXQUFXLE1BQ2hDLE1BQU0sRUFBRSxTQUFTLGNBQ2pCLEVBQUUsS0FBSyxZQUFZLENBQUMsQ0FBQyxTQUFTLFFBQVEsS0FBSyxFQUFFLEtBQUssWUFBWSxDQUFDLENBQUMsU0FBUyxVQUFVLEVBQ3RGO0VBQ0EsYUFBYTtHQUNYLFFBQVE7R0FDUixtQkFBbUI7R0FDbkIsYUFBYSxpQkFBaUIsTUFBTSxXQUFXLE1BQUssTUFBSyxFQUFFLFNBQVMsU0FBUyxDQUFDLEVBQUUsTUFBTTtHQUN0RixNQUFNLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztFQUM1QyxDQUFDO0NBQ0g7Q0FFQSxNQUFNLGdDQUFnQztFQUNwQyxxQkFBcUIsSUFBSTtFQUN6QixhQUFhO0NBQ2Y7Q0FFQSxNQUFNLHNCQUFzQixPQUFPLFNBQTBCO0VBQzNELElBQUksQ0FBQyxtQkFBbUI7RUFFeEIsTUFBTSxxQkFBcUIsT0FBTyxrQkFBa0IsY0FBYyxJQUFJLE9BQU8sS0FBSyxNQUFNO0VBQ3hGLElBQUkscUJBQXFCLE9BQU8sa0JBQWtCLGFBQWEsR0FBRztHQUNoRSxNQUFNLHlDQUF5QztHQUMvQztFQUNGO0VBRUEsSUFBSTtHQUNGLElBQUksa0JBQWtCLFlBQVk7O0lBRWhDLE1BQU0sa0JBQWtCO0tBQ3RCLGFBQWEsWUFBWSxrQkFBa0I7S0FDM0MsUUFBUSxLQUFLO0tBQ2IsTUFBTTtLQUNOLE1BQU0sS0FBSztLQUNYLG1CQUFtQixLQUFLO0tBQ3hCLHdCQUF3QixrQkFBa0I7S0FDMUMsT0FBTyxpQ0FBaUMsa0JBQWtCLEtBQUs7SUFDakUsQ0FBQztHQUNILE9BQU87O0lBRUwsTUFBTSxpQkFBaUI7S0FDckIsSUFBSSxrQkFBa0I7S0FDdEIsT0FBTyxFQUNMLGdCQUFnQixtQkFDbEI7SUFDRixDQUFDO0lBRUQsTUFBTSxrQkFBa0I7S0FDdEIsYUFBYSxZQUFZLGtCQUFrQjtLQUMzQyxRQUFRLEtBQUs7S0FDYixNQUFNO0tBQ04sTUFBTSxLQUFLO0tBQ1gsbUJBQW1CLEtBQUs7S0FDeEIsYUFBYSxLQUFLLGVBQWU7S0FDakMsT0FBTyxpQ0FBaUMsa0JBQWtCLEtBQUs7SUFDakUsQ0FBQztHQUNIO0dBRUEsd0JBQXdCO0VBQzFCLFNBQVMsS0FBVTtHQUNqQixRQUFRLE1BQU0sR0FBRztHQUNqQixNQUFNLElBQUksV0FBVyx3QkFBd0I7RUFDL0M7Q0FDRjtDQUVBLE1BQU0sZUFBZSxPQUFPLE9BQWU7RUFDekMsSUFBSSxRQUFRLG1EQUFtRCxHQUFHO0dBQ2hFLElBQUk7SUFDRixNQUFNLGlCQUFpQixFQUFFO0dBQzNCLFNBQVMsS0FBVTtJQUNqQixRQUFRLE1BQU0sR0FBRztJQUNqQixNQUFNLElBQUksV0FBVywrQkFBK0I7R0FDdEQ7RUFDRjtDQUNGO0NBRUEsTUFBTSxlQUFlLE9BQU8sU0FBMEI7RUFDcEQsSUFBSTtHQUNGLElBQUksYUFBYTtJQUNmLE1BQU0saUJBQWlCO0tBQ3JCLElBQUksWUFBWTtLQUNoQixPQUFPO0lBQ1QsQ0FBQztHQUNILE9BQU87SUFDTCxNQUFNLGlCQUFpQixJQUFJO0dBQzdCO0dBQ0EsaUJBQWlCO0VBQ25CLFNBQVMsS0FBVTtHQUNqQixRQUFRLE1BQU0sR0FBRztHQUNqQixNQUFNLElBQUksV0FBVyw2QkFBNkI7RUFDcEQ7Q0FDRjtDQUdBLE9BQ0Usd0JBQUMsT0FBRDtFQUVFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBZCxDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDJCQUE0Qjs7OztjQUFDLGNBRTdDOzs7OzthQUNKLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQXdDO0dBQXdEOzs7O1dBQzFHOzs7O2FBQ0wsd0JBQUMsVUFBRDtJQUNFLFNBQVM7SUFDVCxlQUFZO0lBQ1osV0FBVTtjQUhaLENBS0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7OztjQUFDLFVBRXRCOzs7OztXQUNMOzs7Ozs7RUFHSixZQUNDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQXNEO0VBQTRCOzs7O2FBQy9GLFlBQVksV0FBVyxJQUN6Qix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxPQUFELEVBQU8sV0FBVSx3QkFBeUI7Ozs7O0lBQ3ZDOzs7OztJQUNMLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQTJEO0lBQXlCOzs7OztJQUNsRyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUF5RDtJQUVuRTs7Ozs7SUFDSCx3QkFBQyxVQUFEO0tBQ0UsU0FBUztLQUNULFdBQVU7ZUFDWDtJQUVPOzs7OztHQUNMOzs7OzthQUVMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1osWUFBWSxLQUFLLFNBQVM7SUFDekIsTUFBTSxXQUFXLEtBQUssZ0JBQWdCLElBQUssS0FBSyxpQkFBaUIsS0FBSyxnQkFBaUIsTUFBTTtJQUM3RixNQUFNLGNBQWMsWUFBWTtJQUVoQyxPQUNFLHdCQUFDLE9BQUQ7S0FFRSxXQUFVO2VBRlo7TUFLRyxlQUNDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUEwSDtNQUVwSTs7Ozs7TUFHUCx3QkFBQyxPQUFEO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFnRSxLQUFLO1FBQVM7Ozs7a0JBQzNGLEtBQUssWUFDSix3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FBcUksYUFDekgsS0FBSyxTQUFTLElBQ3BCOzs7OztnQkFFTDs7Ozs7T0FDRjs7Ozs7T0FFSixLQUFLLGVBQ0osd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O2tCQUNuQyx3QkFBQyxRQUFELGFBQU0sWUFBUyxJQUFJLEtBQUssS0FBSyxXQUFXLENBQUMsQ0FBQyxtQkFBbUIsV0FBVztTQUFFLE9BQU87U0FBUyxLQUFLO1NBQVcsTUFBTTtRQUFVLENBQUMsQ0FBUTs7OztnQkFDaEk7Ozs7OztPQUdOLEtBQUssU0FDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBbUUsS0FBSztPQUFTOzs7OztNQUU3Rjs7Ozs7TUFFTCx3QkFBQyxPQUFELGFBRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQjtVQUNHLGFBQWEsS0FBSyxjQUFjO1VBQUU7VUFBSSxhQUFhLEtBQUssYUFBYTtTQUNsRTs7Ozs7a0JBQ04sd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQW9FLFNBQVMsUUFBUSxDQUFDLEdBQUUsR0FBTzs7Ozs7Z0JBQzVGOzs7OztpQkFDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxPQUFEO1NBQ0UsV0FBVyxtREFDVCxjQUFjLG1CQUFtQjtTQUVuQyxPQUFPLEVBQUUsT0FBTyxHQUFHLEtBQUssSUFBSSxVQUFVLEdBQUcsRUFBRSxHQUFHO1FBQy9DOzs7OztPQUNFOzs7O2VBQ0Y7Ozs7O2dCQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsVUFBRDtTQUNFLGVBQWUscUJBQXFCLElBQUk7U0FDeEMsVUFBVTtTQUNWLGVBQVk7U0FDWixXQUFVO21CQUpaLENBTUUsd0JBQUMsV0FBRCxFQUFXLFdBQVUsY0FBZTs7OzttQkFBQyxhQUUvQjs7Ozs7O1FBQ1Isd0JBQUMsVUFBRDtTQUNFLGVBQWUsb0JBQW9CLElBQUk7U0FDdkMsZUFBWTtTQUNaLFdBQVU7U0FDVixPQUFNO21CQUVOLHdCQUFDLE9BQUQsRUFBTyxXQUFVLFVBQVc7Ozs7O1FBQ3RCOzs7OztRQUNSLHdCQUFDLFVBQUQ7U0FDRSxlQUFlLGFBQWEsS0FBSyxFQUFFO1NBQ25DLGVBQVk7U0FDWixXQUFVO1NBQ1YsT0FBTTttQkFFTix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztRQUN2Qjs7Ozs7T0FDTDs7Ozs7Y0FDRjs7Ozs7S0FDRjtPQWxGRSxLQUFLOzs7O1dBa0ZQO0dBRVQsQ0FBQztFQUNFOzs7OztFQUlQLHdCQUFDLE9BQUQ7R0FDRSxRQUFRO0dBQ1IsU0FBUztHQUNULE9BQU8sY0FBYyxxQkFBcUI7YUFFMUMsd0JBQUMsUUFBRDtJQUFNLFVBQVUsYUFBYSxZQUFZO0lBQUcsV0FBVTtjQUF0RDtLQUVFLHdCQUFDLE9BQUQ7TUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBa0U7TUFFNUU7Ozs7O01BQ1Asd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTCxHQUFJLFNBQVMsTUFBTTtPQUNuQixhQUFZO09BQ1osV0FBVyxnS0FDVCxPQUFPLE9BQU8sd0NBQXdDO01BRXpEOzs7OztNQUNBLE9BQU8sTUFBTSxXQUFXLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUE2QixPQUFPLE1BQU07TUFBVzs7Ozs7S0FDeEY7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFrRTtNQUU1RTs7Ozs7TUFDUCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQ7UUFDRSxHQUFJLFNBQVMsWUFBWTtRQUN6QixXQUFXLHNMQUNULE9BQU8sYUFBYSx3Q0FBd0M7a0JBSGhFLENBTUUsd0JBQUMsVUFBRDtTQUFRLE9BQU07bUJBQUc7UUFBNEM7Ozs7a0JBQzVELFNBQVMsS0FBSyxRQUNiLHdCQUFDLFVBQUQ7U0FBcUIsT0FBTyxJQUFJO21CQUFoQztVQUNHLElBQUk7VUFBSztVQUFHLElBQUk7VUFBSztVQUFRLElBQUksUUFBUSxlQUFlO1NBQ25EO1dBRkssSUFBSTs7OztlQUVULENBQ1QsQ0FDSzs7Ozs7aUJBQ1Isd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsT0FBRDtTQUFLLFdBQVU7U0FBVSxNQUFLO1NBQU8sUUFBTztTQUFlLFNBQVE7U0FBWSxPQUFNO21CQUNuRix3QkFBQyxRQUFEO1VBQU0sZUFBYztVQUFRLGdCQUFlO1VBQVEsYUFBWTtVQUFJLEdBQUU7U0FBdUI7Ozs7O1FBQ3pGOzs7OztPQUNGOzs7O2VBQ0Y7Ozs7OztNQUNKLE9BQU8sWUFBWSxXQUFXLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUE2QixPQUFPLFlBQVk7TUFBVzs7Ozs7S0FDcEc7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FFRSx3QkFBQyxPQUFEO09BQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWtFO09BRTVFOzs7OztPQUNQLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsR0FBSSxTQUFTLGVBQWU7UUFDNUIsYUFBWTtRQUNaLFdBQVcsZ0tBQ1QsT0FBTyxnQkFBZ0Isd0NBQXdDO09BRWxFOzs7OztPQUNBLE9BQU8sZUFBZSxXQUFXLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUE2QixPQUFPLGVBQWU7T0FBVzs7Ozs7TUFDMUc7Ozs7Z0JBR0osQ0FBQyxvQkFDQSx3QkFBQyxPQUFEO09BQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWtFO09BRTVFOzs7OztPQUNQLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsR0FBSSxTQUFTLGdCQUFnQjtRQUM3QixhQUFZO1FBQ1osV0FBVyxnS0FDVCxPQUFPLGlCQUFpQix3Q0FBd0M7T0FFbkU7Ozs7O09BQ0EsT0FBTyxnQkFBZ0IsV0FBVyx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBNkIsT0FBTyxnQkFBZ0I7T0FBVzs7Ozs7TUFDNUc7Ozs7Y0FFSjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFrRTtNQUU1RTs7Ozs7TUFDUCx3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMLEdBQUksU0FBUyxhQUFhO09BQzFCLFdBQVcsZ0tBQ1QsT0FBTyxjQUFjLHdDQUF3QztNQUVoRTs7Ozs7TUFDQSxPQUFPLGFBQWEsV0FBVyx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBNkIsT0FBTyxhQUFhO01BQVc7Ozs7O0tBQ3RHOzs7OztLQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBa0U7S0FFNUU7Ozs7ZUFDUCx3QkFBQyxZQUFEO01BQ0UsR0FBSSxTQUFTLE9BQU87TUFDcEIsYUFBWTtNQUNaLE1BQU07TUFDTixXQUFVO0tBQ1g7Ozs7YUFDRTs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLFdBQVU7aUJBRVQsY0FBYyxjQUFjO01BQ3ZCOzs7OztLQUNMOzs7OztJQUNEOzs7Ozs7RUFDRDs7Ozs7RUFHUCx3QkFBQyxPQUFEO0dBQ0UsUUFBUSxzQkFBc0I7R0FDOUIsU0FBUztHQUNULE9BQU8sb0JBQW9CLGtCQUFrQixtQkFBbUI7YUFFaEUsd0JBQUMsUUFBRDtJQUFNLFVBQVUsb0JBQW9CLG1CQUFtQjtJQUFHLFdBQVU7Y0FBcEU7S0FFRyxxQkFDQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLGlCQUFvQjs7OztrQkFDMUIsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWtELGFBQWEsZ0JBQWdCO1FBQVE7Ozs7Z0JBQ3BHOzs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxrQkFBcUI7Ozs7a0JBQzNCLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFrRCxhQUFhLGlCQUFpQjtRQUFROzs7O2dCQUNyRzs7Ozs7O09BQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0scUJBQXdCOzs7O2tCQUM5Qix3QkFBQyxRQUFELFlBQU8sYUFBYSxtQkFBbUIsaUJBQWlCLEVBQVE7Ozs7Z0JBQzdEOzs7Ozs7TUFDRjs7Ozs7O0tBSVAsd0JBQUMsT0FBRDtNQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFrRTtNQUU1RTs7Ozs7TUFDUCx3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMLEdBQUksZ0JBQWdCLFFBQVE7T0FDNUIsYUFBWTtPQUNaLFdBQVcsZ0tBQ1QsY0FBYyxTQUFTLHdDQUF3QztNQUVsRTs7Ozs7TUFDQSxjQUFjLFFBQVEsV0FBVyx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBNkIsY0FBYyxRQUFRO01BQVc7Ozs7O0tBQzFHOzs7OztLQUdMLHdCQUFDLE9BQUQ7TUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBa0U7TUFFNUU7Ozs7O01BQ1Asd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQ0UsR0FBSSxnQkFBZ0IsbUJBQW1CO1FBQ3ZDLFdBQVcsc0xBQ1QsY0FBYyxvQkFBb0Isd0NBQXdDO2tCQUg5RSxDQU1FLHdCQUFDLFVBQUQ7U0FBUSxPQUFNO21CQUFHO1FBQWdDOzs7O2tCQUNoRCxTQUFTLEtBQUssUUFDYix3QkFBQyxVQUFEO1NBQXFCLE9BQU8sSUFBSTttQkFBaEM7VUFDRyxJQUFJO1VBQUs7VUFBTSxJQUFJLFFBQVEsZUFBZTtVQUFFO1NBQ3ZDO1dBRkssSUFBSTs7OztlQUVULENBQ1QsQ0FDSzs7Ozs7aUJBQ1Isd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsT0FBRDtTQUFLLFdBQVU7U0FBVSxNQUFLO1NBQU8sUUFBTztTQUFlLFNBQVE7U0FBWSxPQUFNO21CQUNuRix3QkFBQyxRQUFEO1VBQU0sZUFBYztVQUFRLGdCQUFlO1VBQVEsYUFBWTtVQUFJLEdBQUU7U0FBdUI7Ozs7O1FBQ3pGOzs7OztPQUNGOzs7O2VBQ0Y7Ozs7OztNQUNILGNBQWMsbUJBQW1CLFdBQVcsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTZCLGNBQWMsbUJBQW1CO01BQVc7Ozs7O0tBQ2pJOzs7OztLQUdKLENBQUMsbUJBQW1CLGNBQ25CLHdCQUFDLE9BQUQ7TUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBa0U7TUFFNUU7Ozs7O01BQ1Asd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQ0UsR0FBSSxnQkFBZ0IsYUFBYTtRQUNqQyxXQUFXLHNMQUNULGNBQWMsY0FBYyx3Q0FBd0M7a0JBSHhFLENBTUUsd0JBQUMsVUFBRDtTQUFRLE9BQU07bUJBQUc7UUFBMEI7Ozs7a0JBQzFDLFdBQVcsUUFBTyxNQUFLLEVBQUUsU0FBUyxTQUFTLENBQUMsQ0FBQyxLQUFLLFFBQ2pELHdCQUFDLFVBQUQ7U0FBcUIsT0FBTyxJQUFJO21CQUM3QixJQUFJO1FBQ0MsR0FGSyxJQUFJOzs7O2VBRVQsQ0FDVCxDQUNLOzs7OztpQkFDUix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxPQUFEO1NBQUssV0FBVTtTQUFVLE1BQUs7U0FBTyxRQUFPO1NBQWUsU0FBUTtTQUFZLE9BQU07bUJBQ25GLHdCQUFDLFFBQUQ7VUFBTSxlQUFjO1VBQVEsZ0JBQWU7VUFBUSxhQUFZO1VBQUksR0FBRTtTQUF1Qjs7Ozs7UUFDekY7Ozs7O09BQ0Y7Ozs7ZUFDRjs7Ozs7O01BQ0gsY0FBYyxhQUFhLFdBQVcsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTZCLGNBQWMsYUFBYTtNQUFXOzs7OztLQUNySDs7Ozs7S0FJUCx3QkFBQyxPQUFEO01BQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWtFO01BRTVFOzs7OztNQUNQLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsR0FBSSxnQkFBZ0IsTUFBTTtPQUMxQixXQUFXLGdLQUNULGNBQWMsT0FBTyx3Q0FBd0M7TUFFaEU7Ozs7O01BQ0MsY0FBYyxNQUFNLFdBQVcsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTZCLGNBQWMsTUFBTTtNQUFXOzs7OztLQUN2Rzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLFVBQVU7T0FDVixXQUFVO2lCQUVULHVCQUF1QixzQkFBc0I7TUFDeEM7Ozs7O0tBQ0w7Ozs7O0lBQ0Q7Ozs7OztFQUNEOzs7OztDQUNKOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNhdmluZ0dvYWxzUGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IFBsdXMsIEVkaXQyLCBUcmFzaDIsIENhbGVuZGFyLCBUYXJnZXQsIEF3YXJkLCBQaWdneUJhbmsgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyB1c2VTYXZpbmdHb2FscyB9IGZyb20gXCIuLi9ob29rcy91c2VTYXZpbmdHb2Fsc1wiO1xuaW1wb3J0IHsgTW9kYWwgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9Nb2RhbFwiO1xuaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gXCJyZWFjdC1ob29rLWZvcm1cIjtcbmltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSBcIkBob29rZm9ybS9yZXNvbHZlcnMvem9kXCI7XG5pbXBvcnQgeyBzYXZpbmdHb2FsU2NoZW1hLCB0eXBlIFNhdmluZ0dvYWxJbnB1dCwgdHlwZSBTYXZpbmdHb2FsIH0gZnJvbSBcIi4uL3R5cGVzL3NhdmluZ0dvYWxzXCI7XG5pbXBvcnQgeyB1c2VBY2NvdW50cyB9IGZyb20gXCIuLi9ob29rcy91c2VBY2NvdW50c1wiO1xuaW1wb3J0IHsgdXNlQ2F0ZWdvcmllcyB9IGZyb20gXCIuLi9ob29rcy91c2VDYXRlZ29yaWVzXCI7XG5pbXBvcnQgeyB1c2VUcmFuc2FjdGlvbnMgfSBmcm9tIFwiLi4vaG9va3MvdXNlVHJhbnNhY3Rpb25zXCI7XG5pbXBvcnQgeyB6IH0gZnJvbSBcInpvZFwiO1xuaW1wb3J0IHsgdXNlT3V0bGV0Q29udGV4dCB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5cbmNvbnN0IGFkZFNhdmluZ3NTY2hlbWEgPSB6Lm9iamVjdCh7XG4gIGFtb3VudDogei5jb2VyY2UubnVtYmVyKCkucG9zaXRpdmUoXCJBbW91bnQgbXVzdCBiZSBncmVhdGVyIHRoYW4gMFwiKSxcbiAgc291cmNlX2FjY291bnRfaWQ6IHouc3RyaW5nKCkudXVpZChcIlBsZWFzZSBzZWxlY3QgYSB2YWxpZCBzb3VyY2UgYWNjb3VudFwiKSxcbiAgY2F0ZWdvcnlfaWQ6IHouc3RyaW5nKCkudXVpZChcIlBsZWFzZSBzZWxlY3QgYSB2YWxpZCBjYXRlZ29yeVwiKS5vcHRpb25hbCgpLm51bGxhYmxlKCksXG4gIGRhdGU6IHouc3RyaW5nKCkubWluKDEsIFwiRGF0ZSBpcyByZXF1aXJlZFwiKSxcbn0pO1xudHlwZSBBZGRTYXZpbmdzSW5wdXQgPSB6LmluZmVyPHR5cGVvZiBhZGRTYXZpbmdzU2NoZW1hPjtcblxuZXhwb3J0IGZ1bmN0aW9uIFNhdmluZ0dvYWxzUGFnZSgpIHtcbiAgY29uc3QgW2lzTW9kYWxPcGVuLCBzZXRJc01vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlZGl0aW5nR29hbCwgc2V0RWRpdGluZ0dvYWxdID0gdXNlU3RhdGU8U2F2aW5nR29hbCB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbYWRkaW5nU2F2aW5nc0dvYWwsIHNldEFkZGluZ1NhdmluZ3NHb2FsXSA9IHVzZVN0YXRlPFNhdmluZ0dvYWwgfCBudWxsPihudWxsKTtcbiAgY29uc3QgeyBzaG93QmFsYW5jZXMgfSA9IHVzZU91dGxldENvbnRleHQ8eyBzaG93QmFsYW5jZXM6IGJvb2xlYW4gfT4oKTtcblxuICBjb25zdCBmb3JtYXRBbW91bnQgPSAodmFsOiBudW1iZXIpID0+IHtcbiAgICByZXR1cm4gc2hvd0JhbGFuY2VzID8gYFJwICR7dmFsLnRvTG9jYWxlU3RyaW5nKCl9YCA6IFwiUnAg4oCi4oCi4oCi4oCi4oCi4oCiXCI7XG4gIH07XG5cbiAgY29uc3QgeyBzYXZpbmdHb2FscywgaXNMb2FkaW5nLCBjcmVhdGVTYXZpbmdHb2FsLCB1cGRhdGVTYXZpbmdHb2FsLCBkZWxldGVTYXZpbmdHb2FsIH0gPSB1c2VTYXZpbmdHb2FscygpO1xuICBjb25zdCB7IGFjY291bnRzIH0gPSB1c2VBY2NvdW50cygpO1xuICBjb25zdCB7IGNhdGVnb3JpZXMgfSA9IHVzZUNhdGVnb3JpZXMoKTtcbiAgY29uc3QgeyBjcmVhdGVUcmFuc2FjdGlvbiwgaXNDcmVhdGluZzogaXNMb2dnaW5nVHJhbnNhY3Rpb24gfSA9IHVzZVRyYW5zYWN0aW9ucygpO1xuXG4gIC8vIExvY2FsIGNvcGllcyBvZiBhZGRpbmdTYXZpbmdzR29hbCBmaWVsZHMgdG8gYXZvaWQgVFMgbnVsbCBuYXJyb3dpbmcgaXNzdWVzIGluIEpTWFxuICBjb25zdCBhZGRpbmdHb2FsTmFtZSA9IGFkZGluZ1NhdmluZ3NHb2FsPy5uYW1lIHx8IFwiXCI7XG4gIGNvbnN0IGFkZGluZ0dvYWxUYXJnZXQgPSBhZGRpbmdTYXZpbmdzR29hbD8udGFyZ2V0X2Ftb3VudCA/PyAwO1xuICBjb25zdCBhZGRpbmdHb2FsQ3VycmVudCA9IGFkZGluZ1NhdmluZ3NHb2FsPy5jdXJyZW50X2Ftb3VudCA/PyAwO1xuXG4gIC8vIEZvcm0gZm9yIFNldC9FZGl0IEdvYWxcbiAgY29uc3Qge1xuICAgIHJlZ2lzdGVyLFxuICAgIGhhbmRsZVN1Ym1pdCxcbiAgICBmb3JtU3RhdGU6IHsgZXJyb3JzIH0sXG4gICAgcmVzZXQsXG4gICAgd2F0Y2hcbiAgfSA9IHVzZUZvcm08U2F2aW5nR29hbElucHV0Pih7XG4gICAgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKHNhdmluZ0dvYWxTY2hlbWEpIGFzIGFueSxcbiAgICBkZWZhdWx0VmFsdWVzOiB7XG4gICAgICBuYW1lOiBcIlwiLFxuICAgICAgdGFyZ2V0X2Ftb3VudDogMCxcbiAgICAgIGN1cnJlbnRfYW1vdW50OiAwLFxuICAgICAgdGFyZ2V0X2RhdGU6IFwiXCIsXG4gICAgICBub3RlczogXCJcIixcbiAgICAgIGFjY291bnRfaWQ6IFwiXCIsXG4gICAgfVxuICB9KTtcblxuICBjb25zdCB3YXRjaGVkQWNjb3VudElkID0gd2F0Y2goXCJhY2NvdW50X2lkXCIpO1xuXG4gIC8vIEZvcm0gZm9yIEFkZCBTYXZpbmdzIE1vZGFsXG4gIGNvbnN0IHtcbiAgICByZWdpc3RlcjogcmVnaXN0ZXJTYXZpbmdzLFxuICAgIGhhbmRsZVN1Ym1pdDogaGFuZGxlU3VibWl0U2F2aW5ncyxcbiAgICBmb3JtU3RhdGU6IHsgZXJyb3JzOiBzYXZpbmdzRXJyb3JzIH0sXG4gICAgcmVzZXQ6IHJlc2V0U2F2aW5ncyxcbiAgfSA9IHVzZUZvcm08QWRkU2F2aW5nc0lucHV0Pih7XG4gICAgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKGFkZFNhdmluZ3NTY2hlbWEpIGFzIGFueSxcbiAgICBkZWZhdWx0VmFsdWVzOiB7XG4gICAgICBhbW91bnQ6IHVuZGVmaW5lZCBhcyBhbnksXG4gICAgICBzb3VyY2VfYWNjb3VudF9pZDogXCJcIixcbiAgICAgIGNhdGVnb3J5X2lkOiBcIlwiLFxuICAgICAgZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXVxuICAgIH1cbiAgfSk7XG5cbiAgY29uc3QgaGFuZGxlT3BlbkFkZE1vZGFsID0gKCkgPT4ge1xuICAgIHNldEVkaXRpbmdHb2FsKG51bGwpO1xuICAgIHJlc2V0KHtcbiAgICAgIG5hbWU6IFwiXCIsXG4gICAgICB0YXJnZXRfYW1vdW50OiAwLFxuICAgICAgY3VycmVudF9hbW91bnQ6IDAsXG4gICAgICB0YXJnZXRfZGF0ZTogXCJcIixcbiAgICAgIG5vdGVzOiBcIlwiLFxuICAgICAgYWNjb3VudF9pZDogXCJcIixcbiAgICB9KTtcbiAgICBzZXRJc01vZGFsT3Blbih0cnVlKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVPcGVuRWRpdE1vZGFsID0gKGdvYWw6IFNhdmluZ0dvYWwpID0+IHtcbiAgICBzZXRFZGl0aW5nR29hbChnb2FsKTtcbiAgICByZXNldCh7XG4gICAgICBuYW1lOiBnb2FsLm5hbWUsXG4gICAgICB0YXJnZXRfYW1vdW50OiBnb2FsLnRhcmdldF9hbW91bnQsXG4gICAgICBjdXJyZW50X2Ftb3VudDogZ29hbC5jdXJyZW50X2Ftb3VudCxcbiAgICAgIHRhcmdldF9kYXRlOiBnb2FsLnRhcmdldF9kYXRlIHx8IFwiXCIsXG4gICAgICBub3RlczogZ29hbC5ub3RlcyB8fCBcIlwiLFxuICAgICAgYWNjb3VudF9pZDogZ29hbC5hY2NvdW50X2lkIHx8IFwiXCIsXG4gICAgfSk7XG4gICAgc2V0SXNNb2RhbE9wZW4odHJ1ZSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ2xvc2VNb2RhbCA9ICgpID0+IHtcbiAgICBzZXRJc01vZGFsT3BlbihmYWxzZSk7XG4gICAgc2V0RWRpdGluZ0dvYWwobnVsbCk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlT3BlbkFkZFNhdmluZ3MgPSAoZ29hbDogU2F2aW5nR29hbCkgPT4ge1xuICAgIHNldEFkZGluZ1NhdmluZ3NHb2FsKGdvYWwpO1xuICAgIGNvbnN0IG1hdGNoZWRDYXRlZ29yeSA9IGNhdGVnb3JpZXMuZmluZChcbiAgICAgIChjKSA9PiBjLnR5cGUgPT09IFwiRXhwZW5zZVwiICYmIFxuICAgICAgKGMubmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKFwic2F2aW5nXCIpIHx8IGMubmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKFwidGFidW5nYW5cIikpXG4gICAgKTtcbiAgICByZXNldFNhdmluZ3Moe1xuICAgICAgYW1vdW50OiB1bmRlZmluZWQgYXMgYW55LFxuICAgICAgc291cmNlX2FjY291bnRfaWQ6IFwiXCIsXG4gICAgICBjYXRlZ29yeV9pZDogbWF0Y2hlZENhdGVnb3J5Py5pZCB8fCBjYXRlZ29yaWVzLmZpbmQoYyA9PiBjLnR5cGUgPT09IFwiRXhwZW5zZVwiKT8uaWQgfHwgXCJcIixcbiAgICAgIGRhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF1cbiAgICB9KTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVDbG9zZVNhdmluZ3NNb2RhbCA9ICgpID0+IHtcbiAgICBzZXRBZGRpbmdTYXZpbmdzR29hbChudWxsKTtcbiAgICByZXNldFNhdmluZ3MoKTtcbiAgfTtcblxuICBjb25zdCBvblNhdmluZ3NGb3JtU3VibWl0ID0gYXN5bmMgKGRhdGE6IEFkZFNhdmluZ3NJbnB1dCkgPT4ge1xuICAgIGlmICghYWRkaW5nU2F2aW5nc0dvYWwpIHJldHVybjtcbiAgICBcbiAgICBjb25zdCBwb3RlbnRpYWxOZXdBbW91bnQgPSBOdW1iZXIoYWRkaW5nU2F2aW5nc0dvYWwuY3VycmVudF9hbW91bnQpICsgTnVtYmVyKGRhdGEuYW1vdW50KTtcbiAgICBpZiAocG90ZW50aWFsTmV3QW1vdW50ID4gTnVtYmVyKGFkZGluZ1NhdmluZ3NHb2FsLnRhcmdldF9hbW91bnQpKSB7XG4gICAgICBhbGVydChcIkFkZGVkIGFtb3VudCBleGNlZWRzIHRhcmdldCBnb2FsIGxpbWl0LlwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgaWYgKGFkZGluZ1NhdmluZ3NHb2FsLmFjY291bnRfaWQpIHtcbiAgICAgICAgLy8gSWYgdGhlIHNhdmluZyBnb2FsIGhhcyBpdHMgb3duIGFjY291bnQsIGxvZyBhIFRyYW5zZmVyIGZyb20gc291cmNlIHRvIHRoZSBzYXZpbmcgZ29hbCdzIGFjY291bnRcbiAgICAgICAgYXdhaXQgY3JlYXRlVHJhbnNhY3Rpb24oe1xuICAgICAgICAgIGRlc2NyaXB0aW9uOiBgU2F2aW5nczogJHthZGRpbmdTYXZpbmdzR29hbC5uYW1lfWAsXG4gICAgICAgICAgYW1vdW50OiBkYXRhLmFtb3VudCxcbiAgICAgICAgICB0eXBlOiBcIlRyYW5zZmVyXCIsXG4gICAgICAgICAgZGF0ZTogZGF0YS5kYXRlLFxuICAgICAgICAgIHNvdXJjZV9hY2NvdW50X2lkOiBkYXRhLnNvdXJjZV9hY2NvdW50X2lkLFxuICAgICAgICAgIGRlc3RpbmF0aW9uX2FjY291bnRfaWQ6IGFkZGluZ1NhdmluZ3NHb2FsLmFjY291bnRfaWQsXG4gICAgICAgICAgbm90ZXM6IGBTYXZpbmdzIGNvbnRyaWJ1dGlvbiB0byBnb2FsIFwiJHthZGRpbmdTYXZpbmdzR29hbC5uYW1lfVwiYFxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEZhbGxiYWNrOiB1cGRhdGUgc2F2aW5nIGdvYWwgZGlyZWN0bHkgYW5kIGxvZyBhcyBFeHBlbnNlXG4gICAgICAgIGF3YWl0IHVwZGF0ZVNhdmluZ0dvYWwoe1xuICAgICAgICAgIGlkOiBhZGRpbmdTYXZpbmdzR29hbC5pZCxcbiAgICAgICAgICBpbnB1dDoge1xuICAgICAgICAgICAgY3VycmVudF9hbW91bnQ6IHBvdGVudGlhbE5ld0Ftb3VudFxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG5cbiAgICAgICAgYXdhaXQgY3JlYXRlVHJhbnNhY3Rpb24oe1xuICAgICAgICAgIGRlc2NyaXB0aW9uOiBgU2F2aW5nczogJHthZGRpbmdTYXZpbmdzR29hbC5uYW1lfWAsXG4gICAgICAgICAgYW1vdW50OiBkYXRhLmFtb3VudCxcbiAgICAgICAgICB0eXBlOiBcIkV4cGVuc2VcIixcbiAgICAgICAgICBkYXRlOiBkYXRhLmRhdGUsXG4gICAgICAgICAgc291cmNlX2FjY291bnRfaWQ6IGRhdGEuc291cmNlX2FjY291bnRfaWQsXG4gICAgICAgICAgY2F0ZWdvcnlfaWQ6IGRhdGEuY2F0ZWdvcnlfaWQgfHwgdW5kZWZpbmVkLFxuICAgICAgICAgIG5vdGVzOiBgU2F2aW5ncyBjb250cmlidXRpb24gdG8gZ29hbCBcIiR7YWRkaW5nU2F2aW5nc0dvYWwubmFtZX1cImBcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIGhhbmRsZUNsb3NlU2F2aW5nc01vZGFsKCk7XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgICAgIGFsZXJ0KGVyci5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIGFkZCBzYXZpbmdzLlwiKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKGlkOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoY29uZmlybShcIkFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGUgdGhpcyBzYXZpbmcgZ29hbD9cIikpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IGRlbGV0ZVNhdmluZ0dvYWwoaWQpO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xuICAgICAgICBhbGVydChlcnIubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBkZWxldGUgc2F2aW5nIGdvYWwuXCIpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICBjb25zdCBvbkZvcm1TdWJtaXQgPSBhc3luYyAoZGF0YTogU2F2aW5nR29hbElucHV0KSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGlmIChlZGl0aW5nR29hbCkge1xuICAgICAgICBhd2FpdCB1cGRhdGVTYXZpbmdHb2FsKHtcbiAgICAgICAgICBpZDogZWRpdGluZ0dvYWwuaWQsXG4gICAgICAgICAgaW5wdXQ6IGRhdGFcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhd2FpdCBjcmVhdGVTYXZpbmdHb2FsKGRhdGEpO1xuICAgICAgfVxuICAgICAgaGFuZGxlQ2xvc2VNb2RhbCgpO1xuICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgICBhbGVydChlcnIubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBzYXZlIHNhdmluZyBnb2FsLlwiKTtcbiAgICB9XG4gIH07XG5cblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICB7LyogSGVhZGVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBzbTppdGVtcy1jZW50ZXIgbWItOCBnYXAtNFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxUYXJnZXQgY2xhc3NOYW1lPVwiaC02IHctNiB0ZXh0LWVtZXJhbGQtNTAwXCIgLz5cbiAgICAgICAgICAgIFNhdmluZyBHb2Fsc1xuICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00MDAgbXQtMVwiPlNldCwgdHJhY2ssIGFuZCBtYW5hZ2UgeW91ciBmYW1pbHkncyBzYXZpbmdzIHRhcmdldHMuPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZU9wZW5BZGRNb2RhbH1cbiAgICAgICAgICBkYXRhLXRlc3RpZD1cImFkZC1nb2FsLWJ1dHRvblwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC03MDAgdGV4dC13aGl0ZSBweC00IHB5LTIuNSByb3VuZGVkLWxnIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgc2hhZG93LXNtXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgIEFkZCBHb2FsXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBNYWluIGNvbnRlbnQgZ3JpZCAqL31cbiAgICAgIHtpc0xvYWRpbmcgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTY0IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXppbmMtNTAwXCI+TG9hZGluZyBzYXZpbmcgZ29hbHMuLi48L2Rpdj5cbiAgICAgICkgOiBzYXZpbmdHb2Fscy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwIHAtMTIgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXppbmMtMTAwIGRhcms6YmctemluYy04MDAgdy0xNiBoLTE2IHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIG1iLTRcIj5cbiAgICAgICAgICAgIDxBd2FyZCBjbGFzc05hbWU9XCJoLTggdy04IHRleHQtemluYy00MDBcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgbWItMlwiPk5vIFNhdmluZyBHb2FscyBGb3VuZDwvaDM+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00MDAgbWItNiBtYXgtdy1zbSBteC1hdXRvXCI+XG4gICAgICAgICAgICBZb3UgZG9uJ3QgaGF2ZSBhbnkgc2F2aW5ncyB0YXJnZXRzIGNvbmZpZ3VyZWQuIExldCdzIGNyZWF0ZSB5b3VyIGZpcnN0IGdvYWwhXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZU9wZW5BZGRNb2RhbH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTcwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLWxnIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIENyZWF0ZSBZb3VyIEZpcnN0IEdvYWxcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cbiAgICAgICAgICB7c2F2aW5nR29hbHMubWFwKChnb2FsKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBwcm9ncmVzcyA9IGdvYWwudGFyZ2V0X2Ftb3VudCA+IDAgPyAoZ29hbC5jdXJyZW50X2Ftb3VudCAvIGdvYWwudGFyZ2V0X2Ftb3VudCkgKiAxMDAgOiAwO1xuICAgICAgICAgICAgY29uc3QgaXNDb21wbGV0ZWQgPSBwcm9ncmVzcyA+PSAxMDA7XG5cbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAga2V5PXtnb2FsLmlkfSBcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAgcC02IGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIHNoYWRvdy1zbSByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gZ3JvdXBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgey8qIENvbXBsZXRpb24gQmFkZ2UgT3ZlcmxheSAqL31cbiAgICAgICAgICAgICAgICB7aXNDb21wbGV0ZWQgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCByaWdodC0wIGJnLWVtZXJhbGQtNTAwIHRleHQtd2hpdGUgdGV4dC14cyBweC0zIHB5LTEgZm9udC1zZW1pYm9sZCByb3VuZGVkLWJsLWxnIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICAgICAgICBDb21wbGV0ZWRcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBtYi0yIHByLTEyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIGxpbmUtY2xhbXAtMVwiPntnb2FsLm5hbWV9PC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICB7Z29hbC5hY2NvdW50cyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtYmxvY2sgbXQtMSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDUwIGJnLWVtZXJhbGQtNTAwLzEwIHB4LTIgcHktMC41IHJvdW5kZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgQWNjb3VudDoge2dvYWwuYWNjb3VudHMubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7Z29hbC50YXJnZXRfZGF0ZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC14cyB0ZXh0LXppbmMtNDAwIGRhcms6dGV4dC16aW5jLTUwMCBtYi00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5UYXJnZXQ6IHtuZXcgRGF0ZShnb2FsLnRhcmdldF9kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcodW5kZWZpbmVkLCB7IG1vbnRoOiBcInNob3J0XCIsIGRheTogXCJudW1lcmljXCIsIHllYXI6IFwibnVtZXJpY1wiIH0pfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICB7Z29hbC5ub3RlcyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00MDAgbGluZS1jbGFtcC0yIG1iLTUgaC0xMFwiPntnb2FsLm5vdGVzfTwvcD5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgey8qIFByb2dyZXNzIEluZm8gKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiBtYi00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtZW5kIHRleHQteHMgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtemluYy01MDAgZGFyazp0ZXh0LXppbmMtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0QW1vdW50KGdvYWwuY3VycmVudF9hbW91bnQpfSAvIHtmb3JtYXRBbW91bnQoZ29hbC50YXJnZXRfYW1vdW50KX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1ib2xkXCI+e3Byb2dyZXNzLnRvRml4ZWQoMCl9JTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXppbmMtMTAwIGRhcms6YmctemluYy04MDAgaC0yLjUgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BoLWZ1bGwgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICBpc0NvbXBsZXRlZCA/IFwiYmctZW1lcmFsZC01MDBcIiA6IFwiYmctZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7TWF0aC5taW4ocHJvZ3Jlc3MsIDEwMCl9JWAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7LyogQWN0aW9ucyBmb290ZXIgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgaXRlbXMtY2VudGVyIGdhcC0yIHB0LTIgYm9yZGVyLXQgYm9yZGVyLXppbmMtMTAwIGRhcms6Ym9yZGVyLXppbmMtODAwLzgwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVPcGVuQWRkU2F2aW5ncyhnb2FsKX1cbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNDb21wbGV0ZWR9XG4gICAgICAgICAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJhZGQtc2F2aW5ncy1idXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBtci0yIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgYmctZW1lcmFsZC01MCBob3ZlcjpiZy1lbWVyYWxkLTEwMCBkYXJrOmJnLWVtZXJhbGQtNTAwLzEwIGRhcms6aG92ZXI6YmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTcwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgcHgtMyBweS0xLjUgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpwb2ludGVyLWV2ZW50cy1ub25lIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxQaWdneUJhbmsgY2xhc3NOYW1lPVwiaC0zLjUgdy0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIEFkZCBTYXZpbmdzXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlT3BlbkVkaXRNb2RhbChnb2FsKX1cbiAgICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cImVkaXQtZ29hbC1idXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXppbmMtNDAwIGhvdmVyOnRleHQtemluYy02MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLXppbmMtMTAwIGRhcms6aG92ZXI6YmctemluYy04NTAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJFZGl0IEdvYWxcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPEVkaXQyIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZShnb2FsLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cImRlbGV0ZS1nb2FsLWJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHRleHQtemluYy00MDAgaG92ZXI6dGV4dC1yZWQtNTAwIGhvdmVyOmJnLXJlZC01MCBkYXJrOmhvdmVyOmJnLXJlZC01MDAvMTAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGUgR29hbFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIEFkZCAvIEVkaXQgR29hbCBNb2RhbCAqL31cbiAgICAgIDxNb2RhbFxuICAgICAgICBpc09wZW49e2lzTW9kYWxPcGVufVxuICAgICAgICBvbkNsb3NlPXtoYW5kbGVDbG9zZU1vZGFsfVxuICAgICAgICB0aXRsZT17ZWRpdGluZ0dvYWwgPyBcIkVkaXQgU2F2aW5nIEdvYWxcIiA6IFwiQ3JlYXRlIFNhdmluZyBHb2FsXCJ9XG4gICAgICA+XG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXQob25Gb3JtU3VibWl0KX0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgey8qIEdvYWwgTmFtZSAqL31cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC16aW5jLTcwMCBkYXJrOnRleHQtemluYy0zMDAgbWItMVwiPlxuICAgICAgICAgICAgICBHb2FsIE5hbWVcbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJuYW1lXCIpfVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4sIFZhY2F0aW9uIGZ1bmQsIERvd25wYXltZW50XCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJnLXdoaXRlIGRhcms6YmctemluYy05MDAgcHgtMyBweS0yIHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwICR7XG4gICAgICAgICAgICAgICAgZXJyb3JzLm5hbWUgPyBcImJvcmRlci1yZWQtNTAwIGZvY3VzOmJvcmRlci1yZWQtNTAwXCIgOiBcImJvcmRlci16aW5jLTMwMCBkYXJrOmJvcmRlci16aW5jLTcwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICB7ZXJyb3JzLm5hbWU/Lm1lc3NhZ2UgJiYgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTUwMFwiPntlcnJvcnMubmFtZT8ubWVzc2FnZX08L3A+fVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEFzc29jaWF0ZWQgQWNjb3VudCAqL31cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC16aW5jLTcwMCBkYXJrOnRleHQtemluYy0zMDAgbWItMVwiPlxuICAgICAgICAgICAgICBBc3NvY2lhdGVkIEFjY291bnQgKGUuZy4gQkNBLCBCUkksIFNlYWJhbmspXG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiYWNjb3VudF9pZFwiKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgYXBwZWFyYW5jZS1ub25lIHJvdW5kZWQtbGcgYm9yZGVyIGJnLXdoaXRlIGRhcms6YmctemluYy05MDAgcHgtMyBweS0yIHByLTEwIHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwICR7XG4gICAgICAgICAgICAgICAgICBlcnJvcnMuYWNjb3VudF9pZCA/IFwiYm9yZGVyLXJlZC01MDAgZm9jdXM6Ym9yZGVyLXJlZC01MDBcIiA6IFwiYm9yZGVyLXppbmMtMzAwIGRhcms6Ym9yZGVyLXppbmMtNzAwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+Tm8gYWNjb3VudCAobWFudWFsIGJhbGFuY2UgdHJhY2tpbmcpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAge2FjY291bnRzLm1hcCgoYWNjKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17YWNjLmlkfSB2YWx1ZT17YWNjLmlkfT5cbiAgICAgICAgICAgICAgICAgICAge2FjYy5uYW1lfSAoe2FjYy50eXBlfSkgLSBScCB7YWNjLmJhbGFuY2UudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIGluc2V0LXktMCByaWdodC0wIGZsZXggaXRlbXMtY2VudGVyIHB4LTMgdGV4dC16aW5jLTUwMFwiPlxuICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwiaC00IHctNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cbiAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTE5IDlsLTcgNy03LTdcIj48L3BhdGg+XG4gICAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7ZXJyb3JzLmFjY291bnRfaWQ/Lm1lc3NhZ2UgJiYgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTUwMFwiPntlcnJvcnMuYWNjb3VudF9pZD8ubWVzc2FnZX08L3A+fVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAgICB7LyogVGFyZ2V0IEFtb3VudCAqL31cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtemluYy03MDAgZGFyazp0ZXh0LXppbmMtMzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICBUYXJnZXQgQW1vdW50IChScClcbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwidGFyZ2V0X2Ftb3VudFwiKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHB4LTMgcHktMiB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCAke1xuICAgICAgICAgICAgICAgICAgZXJyb3JzLnRhcmdldF9hbW91bnQgPyBcImJvcmRlci1yZWQtNTAwIGZvY3VzOmJvcmRlci1yZWQtNTAwXCIgOiBcImJvcmRlci16aW5jLTMwMCBkYXJrOmJvcmRlci16aW5jLTcwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICB7ZXJyb3JzLnRhcmdldF9hbW91bnQ/Lm1lc3NhZ2UgJiYgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTUwMFwiPntlcnJvcnMudGFyZ2V0X2Ftb3VudD8ubWVzc2FnZX08L3A+fVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBDdXJyZW50IEFtb3VudCAqL31cbiAgICAgICAgICAgIHshd2F0Y2hlZEFjY291bnRJZCAmJiAoXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC16aW5jLTcwMCBkYXJrOnRleHQtemluYy0zMDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgQ3VycmVudCBBbW91bnQgKFJwKVxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImN1cnJlbnRfYW1vdW50XCIpfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHB4LTMgcHktMiB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCAke1xuICAgICAgICAgICAgICAgICAgICBlcnJvcnMuY3VycmVudF9hbW91bnQgPyBcImJvcmRlci1yZWQtNTAwIGZvY3VzOmJvcmRlci1yZWQtNTAwXCIgOiBcImJvcmRlci16aW5jLTMwMCBkYXJrOmJvcmRlci16aW5jLTcwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmN1cnJlbnRfYW1vdW50Py5tZXNzYWdlICYmIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDBcIj57ZXJyb3JzLmN1cnJlbnRfYW1vdW50Py5tZXNzYWdlfTwvcD59XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBUYXJnZXQgRGF0ZSAqL31cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC16aW5jLTcwMCBkYXJrOnRleHQtemluYy0zMDAgbWItMVwiPlxuICAgICAgICAgICAgICBUYXJnZXQgRGF0ZSAoT3B0aW9uYWwpXG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwidGFyZ2V0X2RhdGVcIil9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHB4LTMgcHktMiB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCAke1xuICAgICAgICAgICAgICAgIGVycm9ycy50YXJnZXRfZGF0ZSA/IFwiYm9yZGVyLXJlZC01MDAgZm9jdXM6Ym9yZGVyLXJlZC01MDBcIiA6IFwiYm9yZGVyLXppbmMtMzAwIGRhcms6Ym9yZGVyLXppbmMtNzAwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIHtlcnJvcnMudGFyZ2V0X2RhdGU/Lm1lc3NhZ2UgJiYgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTUwMFwiPntlcnJvcnMudGFyZ2V0X2RhdGU/Lm1lc3NhZ2V9PC9wPn1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBOb3RlcyAqL31cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC16aW5jLTcwMCBkYXJrOnRleHQtemluYy0zMDAgbWItMVwiPlxuICAgICAgICAgICAgICBOb3RlcyAoT3B0aW9uYWwpXG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcIm5vdGVzXCIpfVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlByb3ZpZGUgY29udGV4dCBvciBkZXRhaWxzIGFib3V0IHRoaXMgc2F2aW5nIGdvYWwuLi5cIlxuICAgICAgICAgICAgICByb3dzPXszfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXppbmMtMzAwIGRhcms6Ym9yZGVyLXppbmMtNzAwIGJnLXdoaXRlIGRhcms6YmctemluYy05MDAgcHgtMyBweS0yIHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgcGxhY2Vob2xkZXItemluYy00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFN1Ym1pdCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHNtOnctYXV0byByb3VuZGVkLWxnIGJnLWVtZXJhbGQtNjAwIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgaG92ZXI6YmctZW1lcmFsZC03MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwIGZvY3VzOnJpbmctb2Zmc2V0LTIgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7ZWRpdGluZ0dvYWwgPyBcIlNhdmUgR29hbFwiIDogXCJDcmVhdGUgR29hbFwifVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgIDwvTW9kYWw+XG5cbiAgICAgIHsvKiBBZGQgU2F2aW5ncyBNb2RhbCAqL31cbiAgICAgIDxNb2RhbFxuICAgICAgICBpc09wZW49e2FkZGluZ1NhdmluZ3NHb2FsICE9PSBudWxsfVxuICAgICAgICBvbkNsb3NlPXtoYW5kbGVDbG9zZVNhdmluZ3NNb2RhbH1cbiAgICAgICAgdGl0bGU9e2FkZGluZ1NhdmluZ3NHb2FsID8gYEFkZCBTYXZpbmdzIHRvICR7YWRkaW5nR29hbE5hbWV9YCA6IFwiQWRkIFNhdmluZ3NcIn1cbiAgICAgID5cbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdFNhdmluZ3Mob25TYXZpbmdzRm9ybVN1Ym1pdCl9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgIHsvKiBUYXJnZXQgSW5mbyAqL31cbiAgICAgICAgICB7YWRkaW5nU2F2aW5nc0dvYWwgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy16aW5jLTUwIGRhcms6YmctemluYy05NTAgcC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMCB0ZXh0LXhzIHRleHQtemluYy01MDUgZGFyazp0ZXh0LXppbmMtNTAwIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+VGFyZ2V0IEFtb3VudDo8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXppbmMtODAwIGRhcms6dGV4dC16aW5jLTIwMFwiPntmb3JtYXRBbW91bnQoYWRkaW5nR29hbFRhcmdldCl9PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPkN1cnJlbnQgQW1vdW50Ojwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtemluYy04MDAgZGFyazp0ZXh0LXppbmMtMjAwXCI+e2Zvcm1hdEFtb3VudChhZGRpbmdHb2FsQ3VycmVudCl9PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBib3JkZXItdCBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAgcHQtMS41IG10LTEgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj5SZW1haW5pbmcgdG8gU2F2ZTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4+e2Zvcm1hdEFtb3VudChhZGRpbmdHb2FsVGFyZ2V0IC0gYWRkaW5nR29hbEN1cnJlbnQpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIEFtb3VudCB0byBTYXZlICovfVxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXppbmMtNzAwIGRhcms6dGV4dC16aW5jLTMwMCBtYi0xXCI+XG4gICAgICAgICAgICAgIEFtb3VudCB0byBBZGQgKFJwKVxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyU2F2aW5ncyhcImFtb3VudFwiKX1cbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuLCA1MDAwMDBcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCBweC0zIHB5LTIgdGV4dC1zbSB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAvMjAgJHtcbiAgICAgICAgICAgICAgICBzYXZpbmdzRXJyb3JzLmFtb3VudCA/IFwiYm9yZGVyLXJlZC01MDAgZm9jdXM6Ym9yZGVyLXJlZC01MDBcIiA6IFwiYm9yZGVyLXppbmMtMzAwIGRhcms6Ym9yZGVyLXppbmMtNzAwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIHtzYXZpbmdzRXJyb3JzLmFtb3VudD8ubWVzc2FnZSAmJiA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1yZWQtNTAwXCI+e3NhdmluZ3NFcnJvcnMuYW1vdW50Py5tZXNzYWdlfTwvcD59XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogU291cmNlIEFjY291bnQgKi99XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtemluYy03MDAgZGFyazp0ZXh0LXppbmMtMzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgU291cmNlIEFjY291bnQgKHRvIERlZHVjdCBGcm9tKVxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlclNhdmluZ3MoXCJzb3VyY2VfYWNjb3VudF9pZFwiKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgYXBwZWFyYW5jZS1ub25lIHJvdW5kZWQtbGcgYm9yZGVyIGJnLXdoaXRlIGRhcms6YmctemluYy05MDAgcHgtMyBweS0yIHByLTEwIHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwICR7XG4gICAgICAgICAgICAgICAgICBzYXZpbmdzRXJyb3JzLnNvdXJjZV9hY2NvdW50X2lkID8gXCJib3JkZXItcmVkLTUwMCBmb2N1czpib3JkZXItcmVkLTUwMFwiIDogXCJib3JkZXItemluYy0zMDAgZGFyazpib3JkZXItemluYy03MDAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwXCJcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3Qgc291cmNlIGFjY291bnQuLi48L29wdGlvbj5cbiAgICAgICAgICAgICAgICB7YWNjb3VudHMubWFwKChhY2MpID0+IChcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXthY2MuaWR9IHZhbHVlPXthY2MuaWR9PlxuICAgICAgICAgICAgICAgICAgICB7YWNjLm5hbWV9IChScCB7YWNjLmJhbGFuY2UudG9Mb2NhbGVTdHJpbmcoKX0pXG4gICAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSBpbnNldC15LTAgcmlnaHQtMCBmbGV4IGl0ZW1zLWNlbnRlciBweC0zIHRleHQtemluYy01MDBcIj5cbiAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cImgtNCB3LTRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XG4gICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xOSA5bC03IDctNy03XCI+PC9wYXRoPlxuICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgIHtzYXZpbmdzRXJyb3JzLnNvdXJjZV9hY2NvdW50X2lkPy5tZXNzYWdlICYmIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDBcIj57c2F2aW5nc0Vycm9ycy5zb3VyY2VfYWNjb3VudF9pZD8ubWVzc2FnZX08L3A+fVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEV4cGVuc2UgQ2F0ZWdvcnkgKE9ubHkgZm9yIG1hbnVhbCBzYXZpbmdzIHdpdGhvdXQgYXNzb2NpYXRlZCBhY2NvdW50KSAqL31cbiAgICAgICAgICB7IWFkZGluZ1NhdmluZ3NHb2FsPy5hY2NvdW50X2lkICYmIChcbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtemluYy03MDAgZGFyazp0ZXh0LXppbmMtMzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICBFeHBlbnNlIENhdGVnb3J5XG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXJTYXZpbmdzKFwiY2F0ZWdvcnlfaWRcIil9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgYXBwZWFyYW5jZS1ub25lIHJvdW5kZWQtbGcgYm9yZGVyIGJnLXdoaXRlIGRhcms6YmctemluYy05MDAgcHgtMyBweS0yIHByLTEwIHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwICR7XG4gICAgICAgICAgICAgICAgICAgIHNhdmluZ3NFcnJvcnMuY2F0ZWdvcnlfaWQgPyBcImJvcmRlci1yZWQtNTAwIGZvY3VzOmJvcmRlci1yZWQtNTAwXCIgOiBcImJvcmRlci16aW5jLTMwMCBkYXJrOmJvcmRlci16aW5jLTcwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBjYXRlZ29yeS4uLjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAge2NhdGVnb3JpZXMuZmlsdGVyKGMgPT4gYy50eXBlID09PSBcIkV4cGVuc2VcIikubWFwKChjYXQpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2NhdC5pZH0gdmFsdWU9e2NhdC5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAge2NhdC5uYW1lfVxuICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSBpbnNldC15LTAgcmlnaHQtMCBmbGV4IGl0ZW1zLWNlbnRlciBweC0zIHRleHQtemluYy01MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwiaC00IHctNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cbiAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTkgOWwtNyA3LTctN1wiPjwvcGF0aD5cbiAgICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgIHtzYXZpbmdzRXJyb3JzLmNhdGVnb3J5X2lkPy5tZXNzYWdlICYmIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDBcIj57c2F2aW5nc0Vycm9ycy5jYXRlZ29yeV9pZD8ubWVzc2FnZX08L3A+fVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBEYXRlICovfVxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXppbmMtNzAwIGRhcms6dGV4dC16aW5jLTMwMCBtYi0xXCI+XG4gICAgICAgICAgICAgIERhdGVcbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICB7Li4ucmVnaXN0ZXJTYXZpbmdzKFwiZGF0ZVwiKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJnLXdoaXRlIGRhcms6YmctemluYy05MDAgcHgtMyBweS0yIHRleHQtc20gdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwLzIwICR7XG4gICAgICAgICAgICAgICAgc2F2aW5nc0Vycm9ycy5kYXRlID8gXCJib3JkZXItcmVkLTUwMCBmb2N1czpib3JkZXItcmVkLTUwMFwiIDogXCJib3JkZXItemluYy0zMDAgZGFyazpib3JkZXItemluYy03MDAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwXCJcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgIHtzYXZpbmdzRXJyb3JzLmRhdGU/Lm1lc3NhZ2UgJiYgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTUwMFwiPntzYXZpbmdzRXJyb3JzLmRhdGU/Lm1lc3NhZ2V9PC9wPn1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBTdWJtaXQgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGZsZXgganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvZ2dpbmdUcmFuc2FjdGlvbn1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHNtOnctYXV0byByb3VuZGVkLWxnIGJnLWVtZXJhbGQtNjAwIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgaG92ZXI6YmctZW1lcmFsZC03MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwIGZvY3VzOnJpbmctb2Zmc2V0LTIgZGlzYWJsZWQ6b3BhY2l0eS01MCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtpc0xvZ2dpbmdUcmFuc2FjdGlvbiA/IFwiQWRkaW5nIFNhdmluZ3MuLi5cIiA6IFwiQ29uZmlybSAmIEFkZFwifVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgIDwvTW9kYWw+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXX0=