import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AuthContext.tsx");const React = __vite__cjsImport0_react; const createContext = __vite__cjsImport0_react["createContext"]; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=513be775";
import { useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=909c015f";
import { authService } from "/src/services/authService.ts";
import { supabase } from "/src/services/supabaseClient.ts";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/components/AuthContext.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
export const AuthContext = createContext(undefined);
_c = AuthContext;
export const AuthProvider = ({ children }) => {
	_s();
	const [user, setUser] = useState(null);
	const queryClient = useQueryClient();
	const [loading, setLoading] = useState(true);
	// Initialize and listen for Supabase auth state changes
	useEffect(() => {
		const initializeAuth = async () => {
			try {
				const response = await authService.getMe();
				if (response.success && response.data) {
					setUser(response.data);
				} else {
					setUser(null);
				}
			} catch (error) {
				console.error("Session restoration failed:", error);
				setUser(null);
			} finally {
				setLoading(false);
			}
		};
		initializeAuth();
		// Listen for dynamic auth state changes
		const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
			if (session && session.user) {
				const { data: profile } = await supabase.from("users").select("first_name, last_name, is_verified").eq("id", session.user.id).single();
				if (!profile || !profile.is_verified) {
					await supabase.auth.signOut();
					setUser(null);
				} else {
					setUser({
						id: session.user.id,
						email: session.user.email || "",
						first_name: profile.first_name,
						last_name: profile.last_name,
						email_confirmed: !!session.user.email_confirmed_at,
						is_verified: profile.is_verified
					});
				}
			} else {
				setUser(null);
			}
			setLoading(false);
		});
		return () => {
			subscription.unsubscribe();
		};
	}, []);
	// Auto logout after 4 hours of inactivity
	useEffect(() => {
		if (!user) return;
		let lastActivity = Date.now();
		const fourHours = 4 * 60 * 60 * 1e3;
		const resetTimer = () => {
			lastActivity = Date.now();
		};
		const events = [
			"mousedown",
			"keydown",
			"scroll",
			"touchstart",
			"click"
		];
		events.forEach((event) => {
			window.addEventListener(event, resetTimer);
		});
		const interval = setInterval(() => {
			const timeSinceLastActivity = Date.now() - lastActivity;
			if (timeSinceLastActivity >= fourHours) {
				console.log("Auto-logging out due to 4 hours of inactivity.");
				logout();
			}
		}, 15e3);
		return () => {
			events.forEach((event) => {
				window.removeEventListener(event, resetTimer);
			});
			clearInterval(interval);
		};
	}, [user]);
	const login = async (credentials) => {
		setLoading(true);
		try {
			const response = await authService.login(credentials);
			if (response.success && response.data) {
				queryClient.clear();
				setUser(response.data.user);
			} else {
				throw new Error(response.message || "Login failed");
			}
		} catch (error) {
			setUser(null);
			throw error;
		} finally {
			setLoading(false);
		}
	};
	const signUp = async (credentials) => {
		setLoading(true);
		try {
			const response = await authService.signUp(credentials);
			if (response.success && response.data) {
				queryClient.clear();
				setUser(response.data);
			} else {
				throw new Error(response.message || "Sign up failed");
			}
		} catch (error) {
			setUser(null);
			throw error;
		} finally {
			setLoading(false);
		}
	};
	const logout = async () => {
		setLoading(true);
		try {
			await authService.logout();
			queryClient.clear();
			setUser(null);
		} catch (error) {
			console.error("Logout failed:", error);
		} finally {
			setLoading(false);
		}
	};
	const value = {
		user,
		isAuthenticated: !!user,
		loading,
		login,
		signUp,
		logout
	};
	return /* @__PURE__ */ _jsxDEV(AuthContext.Provider, {
		value,
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 169,
		columnNumber: 10
	}, this);
};
_s(AuthProvider, "mOLUmMhAU+0Xj+QrPRxLht63cS8=", false, function() {
	return [useQueryClient];
});
_c2 = AuthProvider;
export const useAuth = () => {
	_s2();
	const context = React.useContext(AuthContext);
	if (context === undefined) {
		throw new Error("useAuth must be used within an AuthProvider");
	}
	return context;
};
_s2(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c, _c2;
$RefreshReg$(_c, "AuthContext");
$RefreshReg$(_c2, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AuthContext.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/components/AuthContext.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/components/AuthContext.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/components/AuthContext.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGVBQWUsVUFBVSxpQkFBaUM7QUFDMUUsU0FBUyxzQkFBc0I7QUFFL0IsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxnQkFBZ0I7Ozs7QUFXekIsT0FBTyxNQUFNLGNBQWMsY0FBMkMsU0FBUzs7QUFFL0UsT0FBTyxNQUFNLGdCQUFtRCxFQUFFLGVBQWU7O0NBQy9FLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBOEIsSUFBSTtDQUMxRCxNQUFNLGNBQWMsZUFBZTtDQUVuQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQWtCLElBQUk7O0NBR3BELGdCQUFnQjtFQUNkLE1BQU0saUJBQWlCLFlBQVk7R0FDakMsSUFBSTtJQUNGLE1BQU0sV0FBVyxNQUFNLFlBQVksTUFBTTtJQUN6QyxJQUFJLFNBQVMsV0FBVyxTQUFTLE1BQU07S0FDckMsUUFBUSxTQUFTLElBQUk7SUFDdkIsT0FBTztLQUNMLFFBQVEsSUFBSTtJQUNkO0dBQ0YsU0FBUyxPQUFPO0lBQ2QsUUFBUSxNQUFNLCtCQUErQixLQUFLO0lBQ2xELFFBQVEsSUFBSTtHQUNkLFVBQVU7SUFDUixXQUFXLEtBQUs7R0FDbEI7RUFDRjtFQUVBLGVBQWU7O0VBR2YsTUFBTSxFQUFFLE1BQU0sRUFBRSxtQkFBbUIsU0FBUyxLQUFLLGtCQUMvQyxPQUFPLFFBQVEsWUFBWTtHQUN6QixJQUFJLFdBQVcsUUFBUSxNQUFNO0lBQzFCLE1BQU0sRUFBRSxNQUFNLFlBQVksTUFBTSxTQUM5QixLQUFLLE9BQU8sQ0FBQyxDQUNiLE9BQU8sb0NBQW9DLENBQUMsQ0FDNUMsR0FBRyxNQUFNLFFBQVEsS0FBSyxFQUFFLENBQUMsQ0FDekIsT0FBTztJQUVWLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxhQUFhO0tBQ3BDLE1BQU0sU0FBUyxLQUFLLFFBQVE7S0FDNUIsUUFBUSxJQUFJO0lBQ2QsT0FBTztLQUNMLFFBQVE7TUFDTixJQUFJLFFBQVEsS0FBSztNQUNqQixPQUFPLFFBQVEsS0FBSyxTQUFTO01BQzdCLFlBQVksUUFBUTtNQUNwQixXQUFXLFFBQVE7TUFDbkIsaUJBQWlCLENBQUMsQ0FBQyxRQUFRLEtBQUs7TUFDaEMsYUFBYSxRQUFRO0tBQ3ZCLENBQUM7SUFDSDtHQUNGLE9BQU87SUFDTCxRQUFRLElBQUk7R0FDZDtHQUNBLFdBQVcsS0FBSztFQUNsQixDQUNGO0VBRUEsYUFBYTtHQUNYLGFBQWEsWUFBWTtFQUMzQjtDQUNGLEdBQUcsQ0FBQyxDQUFDOztDQUdMLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxNQUFNO0VBRVgsSUFBSSxlQUFlLEtBQUssSUFBSTtFQUM1QixNQUFNLFlBQVksSUFBSSxLQUFLLEtBQUs7RUFFaEMsTUFBTSxtQkFBbUI7R0FDdkIsZUFBZSxLQUFLLElBQUk7RUFDMUI7RUFFQSxNQUFNLFNBQVM7R0FBQztHQUFhO0dBQVc7R0FBVTtHQUFjO0VBQU87RUFDdkUsT0FBTyxTQUFTLFVBQVU7R0FDeEIsT0FBTyxpQkFBaUIsT0FBTyxVQUFVO0VBQzNDLENBQUM7RUFFRCxNQUFNLFdBQVcsa0JBQWtCO0dBQ2pDLE1BQU0sd0JBQXdCLEtBQUssSUFBSSxJQUFJO0dBQzNDLElBQUkseUJBQXlCLFdBQVc7SUFDdEMsUUFBUSxJQUFJLGdEQUFnRDtJQUM1RCxPQUFPO0dBQ1Q7RUFDRixHQUFHLElBQUs7RUFFUixhQUFhO0dBQ1gsT0FBTyxTQUFTLFVBQVU7SUFDeEIsT0FBTyxvQkFBb0IsT0FBTyxVQUFVO0dBQzlDLENBQUM7R0FDRCxjQUFjLFFBQVE7RUFDeEI7Q0FDRixHQUFHLENBQUMsSUFBSSxDQUFDO0NBRVQsTUFBTSxRQUFRLE9BQU8sZ0JBQWtDO0VBQ3JELFdBQVcsSUFBSTtFQUNmLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxZQUFZLE1BQU0sV0FBVztHQUNwRCxJQUFJLFNBQVMsV0FBVyxTQUFTLE1BQU07SUFDckMsWUFBWSxNQUFNO0lBQ2xCLFFBQVEsU0FBUyxLQUFLLElBQUk7R0FDNUIsT0FBTztJQUNMLE1BQU0sSUFBSSxNQUFNLFNBQVMsV0FBVyxjQUFjO0dBQ3BEO0VBQ0YsU0FBUyxPQUFPO0dBQ2QsUUFBUSxJQUFJO0dBQ1osTUFBTTtFQUNSLFVBQVU7R0FDUixXQUFXLEtBQUs7RUFDbEI7Q0FDRjtDQUVBLE1BQU0sU0FBUyxPQUFPLGdCQUFtQztFQUN2RCxXQUFXLElBQUk7RUFDZixJQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sWUFBWSxPQUFPLFdBQVc7R0FDckQsSUFBSSxTQUFTLFdBQVcsU0FBUyxNQUFNO0lBQ3JDLFlBQVksTUFBTTtJQUNsQixRQUFRLFNBQVMsSUFBSTtHQUN2QixPQUFPO0lBQ0wsTUFBTSxJQUFJLE1BQU0sU0FBUyxXQUFXLGdCQUFnQjtHQUN0RDtFQUNGLFNBQVMsT0FBTztHQUNkLFFBQVEsSUFBSTtHQUNaLE1BQU07RUFDUixVQUFVO0dBQ1IsV0FBVyxLQUFLO0VBQ2xCO0NBQ0Y7Q0FFQSxNQUFNLFNBQVMsWUFBWTtFQUN6QixXQUFXLElBQUk7RUFDZixJQUFJO0dBQ0YsTUFBTSxZQUFZLE9BQU87R0FDekIsWUFBWSxNQUFNO0dBQ2xCLFFBQVEsSUFBSTtFQUNkLFNBQVMsT0FBTztHQUNkLFFBQVEsTUFBTSxrQkFBa0IsS0FBSztFQUN2QyxVQUFVO0dBQ1IsV0FBVyxLQUFLO0VBQ2xCO0NBQ0Y7Q0FFQSxNQUFNLFFBQXlCO0VBQzdCO0VBQ0EsaUJBQWlCLENBQUMsQ0FBQztFQUNuQjtFQUNBO0VBQ0E7RUFDQTtDQUNGO0NBRUEsT0FBTyx3QkFBQyxZQUFZLFVBQWI7RUFBNkI7RUFBUTtDQUErQjs7Ozs7QUFDN0U7Ozs7O0FBRUEsT0FBTyxNQUFNLGdCQUFnQjs7Q0FDM0IsTUFBTSxVQUFVLE1BQU0sV0FBVyxXQUFXO0NBQzVDLElBQUksWUFBWSxXQUFXO0VBQ3pCLE1BQU0sSUFBSSxNQUFNLDZDQUE2QztDQUMvRDtDQUNBLE9BQU87QUFDVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBdXRoQ29udGV4dC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IGNyZWF0ZUNvbnRleHQsIHVzZVN0YXRlLCB1c2VFZmZlY3QsIHR5cGUgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VRdWVyeUNsaWVudCB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3QtcXVlcnlcIjtcbmltcG9ydCB0eXBlIHsgVXNlclJlc3BvbnNlLCBMb2dpbkNyZWRlbnRpYWxzLCBTaWduVXBDcmVkZW50aWFscyB9IGZyb20gXCIuLi90eXBlcy9hdXRoXCI7XG5pbXBvcnQgeyBhdXRoU2VydmljZSB9IGZyb20gXCIuLi9zZXJ2aWNlcy9hdXRoU2VydmljZVwiO1xuaW1wb3J0IHsgc3VwYWJhc2UgfSBmcm9tIFwiLi4vc2VydmljZXMvc3VwYWJhc2VDbGllbnRcIjtcblxuaW50ZXJmYWNlIEF1dGhDb250ZXh0VHlwZSB7XG4gIHVzZXI6IFVzZXJSZXNwb25zZSB8IG51bGw7XG4gIGlzQXV0aGVudGljYXRlZDogYm9vbGVhbjtcbiAgbG9hZGluZzogYm9vbGVhbjtcbiAgbG9naW46IChjcmVkZW50aWFsczogTG9naW5DcmVkZW50aWFscykgPT4gUHJvbWlzZTx2b2lkPjtcbiAgc2lnblVwOiAoY3JlZGVudGlhbHM6IFNpZ25VcENyZWRlbnRpYWxzKSA9PiBQcm9taXNlPHZvaWQ+O1xuICBsb2dvdXQ6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBBdXRoQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQ8QXV0aENvbnRleHRUeXBlIHwgdW5kZWZpbmVkPih1bmRlZmluZWQpO1xuXG5leHBvcnQgY29uc3QgQXV0aFByb3ZpZGVyOiBSZWFjdC5GQzx7IGNoaWxkcmVuOiBSZWFjdE5vZGUgfT4gPSAoeyBjaGlsZHJlbiB9KSA9PiB7XG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlPFVzZXJSZXNwb25zZSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCk7XG5cbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGU8Ym9vbGVhbj4odHJ1ZSk7XG5cbiAgLy8gSW5pdGlhbGl6ZSBhbmQgbGlzdGVuIGZvciBTdXBhYmFzZSBhdXRoIHN0YXRlIGNoYW5nZXNcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBpbml0aWFsaXplQXV0aCA9IGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXV0aFNlcnZpY2UuZ2V0TWUoKTtcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN1Y2Nlc3MgJiYgcmVzcG9uc2UuZGF0YSkge1xuICAgICAgICAgIHNldFVzZXIocmVzcG9uc2UuZGF0YSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc2V0VXNlcihudWxsKTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIlNlc3Npb24gcmVzdG9yYXRpb24gZmFpbGVkOlwiLCBlcnJvcik7XG4gICAgICAgIHNldFVzZXIobnVsbCk7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgaW5pdGlhbGl6ZUF1dGgoKTtcblxuICAgIC8vIExpc3RlbiBmb3IgZHluYW1pYyBhdXRoIHN0YXRlIGNoYW5nZXNcbiAgICBjb25zdCB7IGRhdGE6IHsgc3Vic2NyaXB0aW9uIH0gfSA9IHN1cGFiYXNlLmF1dGgub25BdXRoU3RhdGVDaGFuZ2UoXG4gICAgICBhc3luYyAoX2V2ZW50LCBzZXNzaW9uKSA9PiB7XG4gICAgICAgIGlmIChzZXNzaW9uICYmIHNlc3Npb24udXNlcikge1xuICAgICAgICAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgICAuZnJvbShcInVzZXJzXCIpXG4gICAgICAgICAgICAuc2VsZWN0KFwiZmlyc3RfbmFtZSwgbGFzdF9uYW1lLCBpc192ZXJpZmllZFwiKVxuICAgICAgICAgICAgLmVxKFwiaWRcIiwgc2Vzc2lvbi51c2VyLmlkKVxuICAgICAgICAgICAgLnNpbmdsZSgpO1xuIFxuICAgICAgICAgIGlmICghcHJvZmlsZSB8fCAhcHJvZmlsZS5pc192ZXJpZmllZCkge1xuICAgICAgICAgICAgYXdhaXQgc3VwYWJhc2UuYXV0aC5zaWduT3V0KCk7XG4gICAgICAgICAgICBzZXRVc2VyKG51bGwpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzZXRVc2VyKHtcbiAgICAgICAgICAgICAgaWQ6IHNlc3Npb24udXNlci5pZCxcbiAgICAgICAgICAgICAgZW1haWw6IHNlc3Npb24udXNlci5lbWFpbCB8fCBcIlwiLFxuICAgICAgICAgICAgICBmaXJzdF9uYW1lOiBwcm9maWxlLmZpcnN0X25hbWUsXG4gICAgICAgICAgICAgIGxhc3RfbmFtZTogcHJvZmlsZS5sYXN0X25hbWUsXG4gICAgICAgICAgICAgIGVtYWlsX2NvbmZpcm1lZDogISFzZXNzaW9uLnVzZXIuZW1haWxfY29uZmlybWVkX2F0LFxuICAgICAgICAgICAgICBpc192ZXJpZmllZDogcHJvZmlsZS5pc192ZXJpZmllZCxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzZXRVc2VyKG51bGwpO1xuICAgICAgICB9XG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgfVxuICAgICk7XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIC8vIEF1dG8gbG9nb3V0IGFmdGVyIDQgaG91cnMgb2YgaW5hY3Rpdml0eVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghdXNlcikgcmV0dXJuO1xuXG4gICAgbGV0IGxhc3RBY3Rpdml0eSA9IERhdGUubm93KCk7XG4gICAgY29uc3QgZm91ckhvdXJzID0gNCAqIDYwICogNjAgKiAxMDAwO1xuXG4gICAgY29uc3QgcmVzZXRUaW1lciA9ICgpID0+IHtcbiAgICAgIGxhc3RBY3Rpdml0eSA9IERhdGUubm93KCk7XG4gICAgfTtcblxuICAgIGNvbnN0IGV2ZW50cyA9IFtcIm1vdXNlZG93blwiLCBcImtleWRvd25cIiwgXCJzY3JvbGxcIiwgXCJ0b3VjaHN0YXJ0XCIsIFwiY2xpY2tcIl07XG4gICAgZXZlbnRzLmZvckVhY2goKGV2ZW50KSA9PiB7XG4gICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihldmVudCwgcmVzZXRUaW1lcik7XG4gICAgfSk7XG5cbiAgICBjb25zdCBpbnRlcnZhbCA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgIGNvbnN0IHRpbWVTaW5jZUxhc3RBY3Rpdml0eSA9IERhdGUubm93KCkgLSBsYXN0QWN0aXZpdHk7XG4gICAgICBpZiAodGltZVNpbmNlTGFzdEFjdGl2aXR5ID49IGZvdXJIb3Vycykge1xuICAgICAgICBjb25zb2xlLmxvZyhcIkF1dG8tbG9nZ2luZyBvdXQgZHVlIHRvIDQgaG91cnMgb2YgaW5hY3Rpdml0eS5cIik7XG4gICAgICAgIGxvZ291dCgpO1xuICAgICAgfVxuICAgIH0sIDE1MDAwKTsgLy8gQ2hlY2sgZXZlcnkgMTUgc2Vjb25kc1xuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGV2ZW50cy5mb3JFYWNoKChldmVudCkgPT4ge1xuICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihldmVudCwgcmVzZXRUaW1lcik7XG4gICAgICB9KTtcbiAgICAgIGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWwpO1xuICAgIH07XG4gIH0sIFt1c2VyXSk7XG5cbiAgY29uc3QgbG9naW4gPSBhc3luYyAoY3JlZGVudGlhbHM6IExvZ2luQ3JlZGVudGlhbHMpID0+IHtcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGF1dGhTZXJ2aWNlLmxvZ2luKGNyZWRlbnRpYWxzKTtcbiAgICAgIGlmIChyZXNwb25zZS5zdWNjZXNzICYmIHJlc3BvbnNlLmRhdGEpIHtcbiAgICAgICAgcXVlcnlDbGllbnQuY2xlYXIoKTtcbiAgICAgICAgc2V0VXNlcihyZXNwb25zZS5kYXRhLnVzZXIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKHJlc3BvbnNlLm1lc3NhZ2UgfHwgXCJMb2dpbiBmYWlsZWRcIik7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHNldFVzZXIobnVsbCk7XG4gICAgICB0aHJvdyBlcnJvcjtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IHNpZ25VcCA9IGFzeW5jIChjcmVkZW50aWFsczogU2lnblVwQ3JlZGVudGlhbHMpID0+IHtcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGF1dGhTZXJ2aWNlLnNpZ25VcChjcmVkZW50aWFscyk7XG4gICAgICBpZiAocmVzcG9uc2Uuc3VjY2VzcyAmJiByZXNwb25zZS5kYXRhKSB7XG4gICAgICAgIHF1ZXJ5Q2xpZW50LmNsZWFyKCk7XG4gICAgICAgIHNldFVzZXIocmVzcG9uc2UuZGF0YSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IocmVzcG9uc2UubWVzc2FnZSB8fCBcIlNpZ24gdXAgZmFpbGVkXCIpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBzZXRVc2VyKG51bGwpO1xuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBsb2dvdXQgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYXV0aFNlcnZpY2UubG9nb3V0KCk7XG4gICAgICBxdWVyeUNsaWVudC5jbGVhcigpO1xuICAgICAgc2V0VXNlcihudWxsKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkxvZ291dCBmYWlsZWQ6XCIsIGVycm9yKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IHZhbHVlOiBBdXRoQ29udGV4dFR5cGUgPSB7XG4gICAgdXNlcixcbiAgICBpc0F1dGhlbnRpY2F0ZWQ6ICEhdXNlcixcbiAgICBsb2FkaW5nLFxuICAgIGxvZ2luLFxuICAgIHNpZ25VcCxcbiAgICBsb2dvdXQsXG4gIH07XG5cbiAgcmV0dXJuIDxBdXRoQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17dmFsdWV9PntjaGlsZHJlbn08L0F1dGhDb250ZXh0LlByb3ZpZGVyPjtcbn07XG5cbmV4cG9ydCBjb25zdCB1c2VBdXRoID0gKCkgPT4ge1xuICBjb25zdCBjb250ZXh0ID0gUmVhY3QudXNlQ29udGV4dChBdXRoQ29udGV4dCk7XG4gIGlmIChjb250ZXh0ID09PSB1bmRlZmluZWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJ1c2VBdXRoIG11c3QgYmUgdXNlZCB3aXRoaW4gYW4gQXV0aFByb3ZpZGVyXCIpO1xuICB9XG4gIHJldHVybiBjb250ZXh0O1xufTtcbiJdfQ==