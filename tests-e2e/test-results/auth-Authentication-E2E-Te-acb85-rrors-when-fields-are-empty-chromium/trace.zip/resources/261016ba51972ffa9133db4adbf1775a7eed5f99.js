import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/accounts/AccountForm.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=0a9b0578";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=9dd4f110";
import { accountSchema, accountTypes } from "/src/types/accounts.ts";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/features/accounts/AccountForm.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
var _s = $RefreshSig$();
export function AccountForm({ initialData, onSubmit, isSubmitting }) {
	_s();
	const { register, handleSubmit, formState: { errors } } = useForm({
		resolver: zodResolver(accountSchema),
		defaultValues: initialData ? {
			name: initialData.name,
			type: initialData.type,
			balance: initialData.balance
		} : {
			name: "",
			type: "Bank",
			balance: 0
		}
	});
	return /* @__PURE__ */ _jsxDEV("form", {
		onSubmit: handleSubmit(onSubmit),
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("label", {
					className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
					children: "Account Name"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					type: "text",
					...register("name"),
					"data-testid": "account-name-input",
					placeholder: "e.g., Dad's Wallet",
					className: `w-full rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.name ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 9
				}, this),
				errors.name && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-xs text-red-500",
					children: errors.name.message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 25
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("label", {
					className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
					children: "Account Type"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "relative",
					children: [/* @__PURE__ */ _jsxDEV("select", {
						...register("type"),
						"data-testid": "account-type-select",
						className: `w-full appearance-none rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 pr-10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.type ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`,
						children: accountTypes.map((type) => /* @__PURE__ */ _jsxDEV("option", {
							value: type,
							children: type
						}, type, false, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-zinc-500",
						children: /* @__PURE__ */ _jsxDEV("svg", {
							className: "h-4 w-4",
							fill: "none",
							stroke: "currentColor",
							viewBox: "0 0 24 24",
							xmlns: "http://www.w3.org/2000/svg",
							children: /* @__PURE__ */ _jsxDEV("path", {
								strokeLinecap: "round",
								strokeLinejoin: "round",
								strokeWidth: "2",
								d: "M19 9l-7 7-7-7"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 51,
					columnNumber: 9
				}, this),
				errors.type && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-xs text-red-500",
					children: errors.type.message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 25
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("label", {
					className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
					children: "Starting Balance"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "relative",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "absolute inset-y-0 left-0 flex items-center pl-3 text-zinc-500 sm:text-sm",
						children: "Rp"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "number",
						...register("balance"),
						"data-testid": "account-balance-input",
						placeholder: "0",
						className: `w-full rounded-lg border bg-white dark:bg-zinc-900 pl-9 pr-3 py-2 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.balance ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 9
				}, this),
				errors.balance && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-xs text-red-500",
					children: errors.balance.message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 28
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "pt-4 flex justify-end",
				children: /* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: isSubmitting,
					"data-testid": "account-submit-button",
					className: "rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 disabled:opacity-50 transition-colors",
					children: isSubmitting ? "Saving..." : "Save Account"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 94,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 93,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 5
	}, this);
}
_s(AccountForm, "HLC1IFclXfL/K+q6lxeDS/Po7Wk=", false, function() {
	return [useForm];
});
_c = AccountForm;
var _c;
$RefreshReg$(_c, "AccountForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/accounts/AccountForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/features/accounts/AccountForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/features/accounts/AccountForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/features/accounts/AccountForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsZUFBZSxvQkFBcUQ7Ozs7QUFRN0UsT0FBTyxTQUFTLFlBQVksRUFBRSxhQUFhLFVBQVUsZ0JBQWtDOztDQUNyRixNQUFNLEVBQ0osVUFDQSxjQUNBLFdBQVcsRUFBRSxhQUNYLFFBQVE7RUFDVixVQUFVLFlBQVksYUFBYTtFQUNuQyxlQUFlLGNBQWM7R0FDM0IsTUFBTSxZQUFZO0dBQ2xCLE1BQU0sWUFBWTtHQUNsQixTQUFTLFlBQVk7RUFDdkIsSUFBSTtHQUNGLE1BQU07R0FDTixNQUFNO0dBQ04sU0FBUztFQUNYO0NBQ0YsQ0FBQztDQUVELE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFVBQVUsYUFBYSxRQUFlO0VBQUcsV0FBVTtZQUF6RDtHQUNFLHdCQUFDLE9BQUQ7SUFDRSx3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUFrRTtJQUU1RTs7Ozs7SUFDUCx3QkFBQyxTQUFEO0tBQ0UsTUFBSztLQUNMLEdBQUksU0FBUyxNQUFNO0tBQ25CLGVBQVk7S0FDWixhQUFZO0tBQ1osV0FBVyxxTEFDVCxPQUFPLE9BQU8sd0NBQXdDO0lBRXpEOzs7OztJQUNBLE9BQU8sUUFBUSx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUE2QixPQUFPLEtBQUs7SUFBVzs7Ozs7R0FDOUU7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUNFLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWtFO0lBRTVFOzs7OztJQUNQLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFEO01BQ0UsR0FBSSxTQUFTLE1BQU07TUFDbkIsZUFBWTtNQUNaLFdBQVcsc0xBQ1QsT0FBTyxPQUFPLHdDQUF3QztnQkFHdkQsYUFBYSxLQUFJLFNBQ2hCLHdCQUFDLFVBQUQ7T0FBbUIsT0FBTztpQkFBTztNQUFhLEdBQWpDOzs7O2FBQWlDLENBQy9DO0tBQ0s7Ozs7ZUFDUix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxPQUFEO09BQUssV0FBVTtPQUFVLE1BQUs7T0FBTyxRQUFPO09BQWUsU0FBUTtPQUFZLE9BQU07aUJBQ25GLHdCQUFDLFFBQUQ7UUFBTSxlQUFjO1FBQVEsZ0JBQWU7UUFBUSxhQUFZO1FBQUksR0FBRTtPQUF1Qjs7Ozs7TUFDekY7Ozs7O0tBQ0Y7Ozs7YUFDRjs7Ozs7O0lBQ0osT0FBTyxRQUFRLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQTZCLE9BQU8sS0FBSztJQUFXOzs7OztHQUM5RTs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQ0Usd0JBQUMsU0FBRDtLQUFPLFdBQVU7ZUFBa0U7SUFFNUU7Ozs7O0lBQ1Asd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUE0RTtLQUV0Rjs7OztlQUNOLHdCQUFDLFNBQUQ7TUFDRSxNQUFLO01BQ0wsR0FBSSxTQUFTLFNBQVM7TUFDdEIsZUFBWTtNQUNaLGFBQVk7TUFDWixXQUFXLDBMQUNULE9BQU8sVUFBVSx3Q0FBd0M7S0FFNUQ7Ozs7YUFDRTs7Ozs7O0lBQ0osT0FBTyxXQUFXLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQTZCLE9BQU8sUUFBUTtJQUFXOzs7OztHQUNwRjs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsVUFBVTtLQUNWLGVBQVk7S0FDWixXQUFVO2VBRVQsZUFBZSxjQUFjO0lBQ3hCOzs7OztHQUNMOzs7OztFQUNEOzs7Ozs7QUFFViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBY2NvdW50Rm9ybS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gXCJyZWFjdC1ob29rLWZvcm1cIjtcbmltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSBcIkBob29rZm9ybS9yZXNvbHZlcnMvem9kXCI7XG5pbXBvcnQgeyBhY2NvdW50U2NoZW1hLCBhY2NvdW50VHlwZXMsIHR5cGUgQWNjb3VudElucHV0LCB0eXBlIEFjY291bnQgfSBmcm9tIFwiLi4vLi4vdHlwZXMvYWNjb3VudHNcIjtcblxuaW50ZXJmYWNlIEFjY291bnRGb3JtUHJvcHMge1xuICBpbml0aWFsRGF0YT86IEFjY291bnQ7XG4gIG9uU3VibWl0OiAoZGF0YTogQWNjb3VudElucHV0KSA9PiBQcm9taXNlPHZvaWQ+O1xuICBpc1N1Ym1pdHRpbmc/OiBib29sZWFuO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQWNjb3VudEZvcm0oeyBpbml0aWFsRGF0YSwgb25TdWJtaXQsIGlzU3VibWl0dGluZyB9OiBBY2NvdW50Rm9ybVByb3BzKSB7XG4gIGNvbnN0IHtcbiAgICByZWdpc3RlcixcbiAgICBoYW5kbGVTdWJtaXQsXG4gICAgZm9ybVN0YXRlOiB7IGVycm9ycyB9LFxuICB9ID0gdXNlRm9ybSh7XG4gICAgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKGFjY291bnRTY2hlbWEpLFxuICAgIGRlZmF1bHRWYWx1ZXM6IGluaXRpYWxEYXRhID8ge1xuICAgICAgbmFtZTogaW5pdGlhbERhdGEubmFtZSxcbiAgICAgIHR5cGU6IGluaXRpYWxEYXRhLnR5cGUsXG4gICAgICBiYWxhbmNlOiBpbml0aWFsRGF0YS5iYWxhbmNlLFxuICAgIH0gOiB7XG4gICAgICBuYW1lOiBcIlwiLFxuICAgICAgdHlwZTogXCJCYW5rXCIsXG4gICAgICBiYWxhbmNlOiAwLFxuICAgIH0sXG4gIH0pO1xuXG4gIHJldHVybiAoXG4gICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChvblN1Ym1pdCBhcyBhbnkpfSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtemluYy03MDAgZGFyazp0ZXh0LXppbmMtMzAwIG1iLTFcIj5cbiAgICAgICAgICBBY2NvdW50IE5hbWVcbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgIHsuLi5yZWdpc3RlcihcIm5hbWVcIil9XG4gICAgICAgICAgZGF0YS10ZXN0aWQ9XCJhY2NvdW50LW5hbWUtaW5wdXRcIlxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiwgRGFkJ3MgV2FsbGV0XCJcbiAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCBweC0zIHB5LTIgdGV4dC1zbSB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci16aW5jLTQwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAvMjAgJHtcbiAgICAgICAgICAgIGVycm9ycy5uYW1lID8gXCJib3JkZXItcmVkLTUwMCBmb2N1czpib3JkZXItcmVkLTUwMFwiIDogXCJib3JkZXItemluYy0zMDAgZGFyazpib3JkZXItemluYy03MDAgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwXCJcbiAgICAgICAgICB9YH1cbiAgICAgICAgLz5cbiAgICAgICAge2Vycm9ycy5uYW1lICYmIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDBcIj57ZXJyb3JzLm5hbWUubWVzc2FnZX08L3A+fVxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtemluYy03MDAgZGFyazp0ZXh0LXppbmMtMzAwIG1iLTFcIj5cbiAgICAgICAgICBBY2NvdW50IFR5cGVcbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcInR5cGVcIil9XG4gICAgICAgICAgICBkYXRhLXRlc3RpZD1cImFjY291bnQtdHlwZS1zZWxlY3RcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIGFwcGVhcmFuY2Utbm9uZSByb3VuZGVkLWxnIGJvcmRlciBiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHB4LTMgcHktMiBwci0xMCB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCAke1xuICAgICAgICAgICAgICBlcnJvcnMudHlwZSA/IFwiYm9yZGVyLXJlZC01MDAgZm9jdXM6Ym9yZGVyLXJlZC01MDBcIiA6IFwiYm9yZGVyLXppbmMtMzAwIGRhcms6Ym9yZGVyLXppbmMtNzAwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7YWNjb3VudFR5cGVzLm1hcCh0eXBlID0+IChcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3R5cGV9IHZhbHVlPXt0eXBlfT57dHlwZX08L29wdGlvbj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSBpbnNldC15LTAgcmlnaHQtMCBmbGV4IGl0ZW1zLWNlbnRlciBweC0zIHRleHQtemluYy01MDBcIj5cbiAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwiaC00IHctNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIj5cbiAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTkgOWwtNyA3LTctN1wiPjwvcGF0aD5cbiAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge2Vycm9ycy50eXBlICYmIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDBcIj57ZXJyb3JzLnR5cGUubWVzc2FnZX08L3A+fVxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtemluYy03MDAgZGFyazp0ZXh0LXppbmMtMzAwIG1iLTFcIj5cbiAgICAgICAgICBTdGFydGluZyBCYWxhbmNlXG4gICAgICAgIDwvbGFiZWw+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgbGVmdC0wIGZsZXggaXRlbXMtY2VudGVyIHBsLTMgdGV4dC16aW5jLTUwMCBzbTp0ZXh0LXNtXCI+XG4gICAgICAgICAgICBScFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwiYmFsYW5jZVwiKX1cbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwiYWNjb3VudC1iYWxhbmNlLWlucHV0XCJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMFwiXG4gICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCBwbC05IHByLTMgcHktMiB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXppbmMtNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCAke1xuICAgICAgICAgICAgICBlcnJvcnMuYmFsYW5jZSA/IFwiYm9yZGVyLXJlZC01MDAgZm9jdXM6Ym9yZGVyLXJlZC01MDBcIiA6IFwiYm9yZGVyLXppbmMtMzAwIGRhcms6Ym9yZGVyLXppbmMtNzAwIGZvY3VzOmJvcmRlci1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAge2Vycm9ycy5iYWxhbmNlICYmIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDBcIj57ZXJyb3JzLmJhbGFuY2UubWVzc2FnZX08L3A+fVxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBmbGV4IGp1c3RpZnktZW5kXCI+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxuICAgICAgICAgIGRhdGEtdGVzdGlkPVwiYWNjb3VudC1zdWJtaXQtYnV0dG9uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJnLWVtZXJhbGQtNjAwIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgaG92ZXI6YmctZW1lcmFsZC03MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwIGZvY3VzOnJpbmctb2Zmc2V0LTIgZGlzYWJsZWQ6b3BhY2l0eS01MCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgID5cbiAgICAgICAgICB7aXNTdWJtaXR0aW5nID8gXCJTYXZpbmcuLi5cIiA6IFwiU2F2ZSBBY2NvdW50XCJ9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9mb3JtPlxuICApO1xufVxuIl19