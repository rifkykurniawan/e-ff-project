import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LoginPage.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=513be775";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=0a9b0578";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=9dd4f110";
import * as z from "/node_modules/.vite/deps/zod.js?v=9219c26e";
import { useAuth } from "/src/hooks/useAuth.ts";
import { useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=63710477";
import { Wallet, Sun, Moon, ArrowRight, Sparkles, CheckCircle2 } from "/node_modules/.vite/deps/lucide-react.js?v=7df35618";
import { useTheme } from "/src/components/ThemeContext.tsx";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/LoginPage.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
var _s = $RefreshSig$();
const loginSchema = z.object({
	email: z.string().email("Please enter a valid email address"),
	password: z.string().min(8, "Password must be at least 8 characters")
});
export const LoginPage = () => {
	_s();
	const { login } = useAuth();
	const { theme, toggleTheme } = useTheme();
	const navigate = useNavigate();
	const [errorMsg, setErrorMsg] = useState(null);
	const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({ resolver: zodResolver(loginSchema) });
	const onSubmit = async (data) => {
		setErrorMsg(null);
		try {
			await login(data);
			navigate("/");
		} catch (err) {
			setErrorMsg(err.response?.data?.message || err.message || "Invalid email or password");
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "relative min-h-screen bg-[#f4f9f6] dark:bg-[#05160E] text-zinc-800 dark:text-zinc-100 flex flex-col transition-colors duration-300 selection:bg-[#3cd395] selection:text-black",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "fixed inset-0 bg-[url('/imageBackground.svg')] bg-contain bg-no-repeat bg-center opacity-25 dark:opacity-15 pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("header", {
				className: "w-full max-w-7xl mx-auto px-6 py-5 flex items-center justify-between border-b border-[#cce8db]/60 dark:border-[#123022]/40",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex h-9 w-9 items-center justify-center rounded-lg bg-[#3cd395]/10 text-[#3cd395]",
						children: /* @__PURE__ */ _jsxDEV(Wallet, { className: "h-5 w-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 54,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "font-bold text-lg tracking-tight text-[#0a271c] dark:text-white",
						children: "E-Finance"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 56,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-4",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: toggleTheme,
						"data-testid": "theme-toggle-button",
						className: "flex items-center gap-1.5 bg-[#e6f4ed] hover:bg-[#d2ebd9] dark:bg-[#0e271c] dark:hover:bg-[#153828] border border-[#cce8db] dark:border-[#1a4230] hover:border-[#b4e0c4] dark:hover:border-[#22573f] rounded-full px-3 py-1 text-xs font-semibold text-[#0a271c] dark:text-zinc-300 hover:text-[#061c13] dark:hover:text-white transition-all cursor-pointer",
						title: "Toggle Theme",
						children: [theme === "dark" ? /* @__PURE__ */ _jsxDEV(Sun, { className: "h-3.5 w-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 33
						}, this) : /* @__PURE__ */ _jsxDEV(Moon, { className: "h-3.5 w-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 67
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: theme === "dark" ? "Light" : "Dark" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 max-w-7xl w-full mx-auto px-6 py-12 md:py-20 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-7 space-y-8",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "inline-flex items-center gap-3",
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-bold uppercase tracking-widest text-[#248d61] dark:text-[#3cd395]",
								children: "E-FINANCE APP"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-4xl sm:text-5xl lg:text-6xl font-medium text-[#0a271c] dark:text-white leading-[1.15] tracking-tight",
							children: [
								"Master Your Money, ",
								/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 82,
									columnNumber: 32
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[#248d61] dark:text-[#3cd395]",
									children: "Not Your Financial Stress."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 83,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4 pt-8 border-t border-[#cce8db]/60 dark:border-[#123022]/40 max-w-lg",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-start gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "h-5 w-5 text-[#248d61] dark:text-[#3cd395] shrink-0 mt-0.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 89,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-semibold text-[#0a271c] dark:text-white text-sm",
									children: "100% Private"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 91,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-zinc-500 dark:text-zinc-400",
									children: "Relax! Your data never leaves your instance."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 92,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 90,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 88,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-start gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "h-5 w-5 text-[#248d61] dark:text-[#3cd395] shrink-0 mt-0.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 96,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-semibold text-[#0a271c] dark:text-white text-sm",
									children: "Smart Budgets"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 98,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-zinc-500 dark:text-zinc-400",
									children: "Track and manage your spending habits effortlessly."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 99,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 97,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-5 flex justify-center lg:justify-end",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "w-full max-w-md rounded-2xl border border-[#cce8db] dark:border-[#1a4230] bg-white/80 dark:bg-[#0a1e15]/60 backdrop-blur-md p-8 shadow-2xl relative overflow-hidden",
						children: [/* @__PURE__ */ _jsxDEV("div", { className: "absolute -top-10 -right-10 w-32 h-32 bg-[#3cd395]/10 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "relative z-10",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mb-6",
									children: [/* @__PURE__ */ _jsxDEV("h2", {
										className: "text-2xl font-bold text-[#0a271c] dark:text-white tracking-tight",
										children: "Welcome Back"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 113,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm text-zinc-500 dark:text-zinc-400 mt-1",
										children: "Sign in to manage your finances"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 114,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 112,
									columnNumber: 15
								}, this),
								errorMsg && /* @__PURE__ */ _jsxDEV("div", {
									className: "rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-650 dark:text-red-400 mb-6 animate-pulse",
									children: errorMsg
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 118,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("form", {
									className: "space-y-5",
									onSubmit: handleSubmit(onSubmit),
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("label", {
												htmlFor: "email",
												className: "block text-xs font-semibold uppercase tracking-wider text-zinc-550 dark:text-zinc-400 mb-1.5",
												children: "Email Address"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 125,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												id: "email",
												type: "email",
												autoComplete: "email",
												...register("email"),
												"data-testid": "login-email-input",
												className: `block w-full rounded-lg border bg-white dark:bg-[#05160E]/80 border-[#cce8db] dark:border-[#1a4230] px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 dark:placeholder-zinc-500 focus:border-[#248d61] dark:focus:border-[#3cd395] focus:outline-none focus:ring-1 focus:ring-[#3cd395]/40 transition-all ${errors.email ? "border-red-500" : ""}`,
												placeholder: "example@mail.com"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 128,
												columnNumber: 19
											}, this),
											errors.email && /* @__PURE__ */ _jsxDEV("p", {
												className: "mt-1 text-xs text-red-500 dark:text-red-400",
												children: errors.email.message
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 140,
												columnNumber: 21
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 124,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between items-center mb-1.5",
												children: /* @__PURE__ */ _jsxDEV("label", {
													htmlFor: "password",
													className: "block text-xs font-semibold uppercase tracking-wider text-zinc-550 dark:text-zinc-400",
													children: "Password"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 146,
													columnNumber: 21
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 145,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												id: "password",
												type: "password",
												autoComplete: "current-password",
												...register("password"),
												"data-testid": "login-password-input",
												className: `block w-full rounded-lg border bg-white dark:bg-[#05160E]/80 border-[#cce8db] dark:border-[#1a4230] px-3.5 py-2.5 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 dark:placeholder-zinc-500 focus:border-[#248d61] dark:focus:border-[#3cd395] focus:outline-none focus:ring-1 focus:ring-[#3cd395]/40 transition-all ${errors.password ? "border-red-500" : ""}`,
												placeholder: "••••••••"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 150,
												columnNumber: 19
											}, this),
											errors.password && /* @__PURE__ */ _jsxDEV("p", {
												className: "mt-1 text-xs text-red-500 dark:text-red-400",
												children: errors.password.message
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 162,
												columnNumber: 21
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 144,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "pt-2",
											children: /* @__PURE__ */ _jsxDEV("button", {
												type: "submit",
												disabled: isSubmitting,
												"data-testid": "login-submit-button",
												className: "flex w-full justify-center items-center gap-2 rounded-lg bg-[#3cd395] hover:bg-[#4be4a4] px-4 py-2.5 text-sm font-semibold text-black transition-colors focus:outline-none focus:ring-2 focus:ring-[#3cd395] focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-[#0a1e15] disabled:opacity-50 cursor-pointer",
												children: isSubmitting ? /* @__PURE__ */ _jsxDEV("div", { className: "h-5 w-5 animate-spin rounded-full border-2 border-black border-t-transparent" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 174,
													columnNumber: 23
												}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", { children: "Sign In" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 177,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "h-4 w-4" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 178,
													columnNumber: 25
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 176,
													columnNumber: 23
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 167,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 166,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-center text-xs text-zinc-500 dark:text-zinc-450 mt-6 pt-4 border-t border-[#cce8db]/60 dark:border-[#123022]/40",
											children: [
												"Don't have an account?",
												" ",
												/* @__PURE__ */ _jsxDEV(Link, {
													to: "/signup",
													className: "font-semibold text-[#248d61] dark:text-[#3cd395] hover:text-[#2fae7a] dark:hover:text-[#4be4a4] transition-colors",
													children: "Sign Up"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 186,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 184,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 123,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 106,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "w-full max-w-7xl mx-auto px-6 py-8 mt-auto flex flex-col sm:flex-row items-center justify-between text-xs text-zinc-500 border-t border-[#cce8db]/40 dark:border-[#123022]/20",
				children: [/* @__PURE__ */ _jsxDEV("p", { children: [
					"© ",
					new Date().getFullYear(),
					" E-Finance by rkDEV. All rights reserved."
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 198,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-2 sm:mt-0 flex items-center gap-1.5",
					children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "h-3.5 w-3.5 text-[#248d61] dark:text-[#3cd395]" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 200,
						columnNumber: 11
					}, this), " Built for user privacy."]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 199,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 197,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 44,
		columnNumber: 5
	}, this);
};
_s(LoginPage, "tE+QLg31ZvT0scRTYMZf3CK2abs=", false, function() {
	return [
		useAuth,
		useTheme,
		useNavigate,
		useForm
	];
});
_c = LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/LoginPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/LoginPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/LoginPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/LoginPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGVBQWU7QUFDeEIsU0FBUyxtQkFBbUI7QUFDNUIsWUFBWSxPQUFPO0FBQ25CLFNBQVMsZUFBZTtBQUN4QixTQUFTLGFBQWEsWUFBWTtBQUNsQyxTQUFTLFFBQVEsS0FBSyxNQUFNLFlBQVksVUFBVSxvQkFBb0I7QUFDdEUsU0FBUyxnQkFBZ0I7Ozs7QUFFekIsTUFBTSxjQUFjLEVBQUUsT0FBTztDQUMzQixPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUMsTUFBTSxvQ0FBb0M7Q0FDNUQsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDLElBQUksR0FBRyx3Q0FBd0M7QUFDdEUsQ0FBQztBQUlELE9BQU8sTUFBTSxrQkFBNEI7O0NBQ3ZDLE1BQU0sRUFBRSxVQUFVLFFBQVE7Q0FDMUIsTUFBTSxFQUFFLE9BQU8sZ0JBQWdCLFNBQVM7Q0FDeEMsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUF3QixJQUFJO0NBRTVELE1BQU0sRUFDSixVQUNBLGNBQ0EsV0FBVyxFQUFFLFFBQVEsbUJBQ25CLFFBQXFCLEVBQ3ZCLFVBQVUsWUFBWSxXQUFXLEVBQ25DLENBQUM7Q0FFRCxNQUFNLFdBQVcsT0FBTyxTQUFzQjtFQUM1QyxZQUFZLElBQUk7RUFDaEIsSUFBSTtHQUNGLE1BQU0sTUFBTSxJQUFJO0dBQ2hCLFNBQVMsR0FBRztFQUNkLFNBQVMsS0FBVTtHQUNqQixZQUNFLElBQUksVUFBVSxNQUFNLFdBQVcsSUFBSSxXQUFXLDJCQUNoRDtFQUNGO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFELEVBQ0UsV0FBVSxrSUFDWDs7Ozs7R0FHRCx3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztLQUMxQjs7OztlQUNMLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFrRTtLQUFlOzs7O2FBQzlGOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBRWIsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxlQUFZO01BQ1osV0FBVTtNQUNWLE9BQU07Z0JBSlIsQ0FNRyxVQUFVLFNBQVMsd0JBQUMsS0FBRCxFQUFLLFdBQVUsY0FBZTs7OztpQkFBSSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O2dCQUNyRix3QkFBQyxRQUFELFlBQU8sVUFBVSxTQUFTLFVBQVUsT0FBYTs7OztjQUMzQzs7Ozs7O0lBQ0w7Ozs7WUFDQzs7Ozs7O0dBR1Isd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaEIsQ0FFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWlGO09BQW1COzs7OztNQUNqSDs7Ozs7TUFFTCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUEwSDtRQUNyRyx3QkFBQyxNQUFELENBQUs7Ozs7O1FBQ3hCLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFxQztRQUFnQzs7Ozs7T0FDbkY7Ozs7OztNQUdKLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSw2REFBOEQ7Ozs7a0JBQ3RGLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBdUQ7UUFBZ0I7Ozs7a0JBQ3JGLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUEyQztRQUErQzs7OztnQkFDcEc7Ozs7Z0JBQ0Y7Ozs7O2lCQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsY0FBRCxFQUFjLFdBQVUsNkRBQThEOzs7O2tCQUN0Rix3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXVEO1FBQWlCOzs7O2tCQUN0Rix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBMkM7UUFBc0Q7Ozs7Z0JBQzNHOzs7O2dCQUNGOzs7OztlQUNGOzs7Ozs7S0FDRjs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBRUUsd0JBQUMsT0FBRCxFQUFLLFdBQVUsaUdBQXNHOzs7O2dCQUVySCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQW1FO1NBQWdCOzs7O21CQUNqRyx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBZ0Q7U0FBa0M7Ozs7aUJBQzVGOzs7Ozs7UUFFSixZQUNDLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaO1FBQ0U7Ozs7O1FBR1Asd0JBQUMsUUFBRDtTQUFNLFdBQVU7U0FBWSxVQUFVLGFBQWEsUUFBUTttQkFBM0Q7VUFDRSx3QkFBQyxPQUFEO1dBQ0Usd0JBQUMsU0FBRDtZQUFPLFNBQVE7WUFBUSxXQUFVO3NCQUErRjtXQUV6SDs7Ozs7V0FDUCx3QkFBQyxTQUFEO1lBQ0UsSUFBRztZQUNILE1BQUs7WUFDTCxjQUFhO1lBQ2IsR0FBSSxTQUFTLE9BQU87WUFDcEIsZUFBWTtZQUNaLFdBQVcsb1VBQ1QsT0FBTyxRQUFRLG1CQUFtQjtZQUVwQyxhQUFZO1dBQ2I7Ozs7O1dBQ0EsT0FBTyxTQUNOLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUErQyxPQUFPLE1BQU07V0FBVzs7Ozs7VUFFbkY7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNiLHdCQUFDLFNBQUQ7YUFBTyxTQUFRO2FBQVcsV0FBVTt1QkFBd0Y7WUFFckg7Ozs7O1dBQ0o7Ozs7O1dBQ0wsd0JBQUMsU0FBRDtZQUNFLElBQUc7WUFDSCxNQUFLO1lBQ0wsY0FBYTtZQUNiLEdBQUksU0FBUyxVQUFVO1lBQ3ZCLGVBQVk7WUFDWixXQUFXLG9VQUNULE9BQU8sV0FBVyxtQkFBbUI7WUFFdkMsYUFBWTtXQUNiOzs7OztXQUNBLE9BQU8sWUFDTix3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBK0MsT0FBTyxTQUFTO1dBQVc7Ozs7O1VBRXRGOzs7OztVQUVMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNiLHdCQUFDLFVBQUQ7WUFDRSxNQUFLO1lBQ0wsVUFBVTtZQUNWLGVBQVk7WUFDWixXQUFVO3NCQUVULGVBQ0Msd0JBQUMsT0FBRCxFQUFLLFdBQVUsK0VBQW9GOzs7O3VCQUVuRyxnREFDRSx3QkFBQyxRQUFELFlBQU0sVUFBYTs7OztzQkFDbkIsd0JBQUMsWUFBRCxFQUFZLFdBQVUsVUFBVzs7OztvQkFDakM7Ozs7O1dBRUU7Ozs7O1VBQ0w7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFBc0k7WUFDN0c7WUFDdkIsd0JBQUMsTUFBRDthQUFNLElBQUc7YUFBVSxXQUFVO3VCQUFvSDtZQUUzSTs7Ozs7V0FDSDs7Ozs7O1NBQ0Q7Ozs7OztPQUNIOzs7OztjQUNGOzs7Ozs7SUFDRjs7OztZQUNEOzs7Ozs7R0FHTix3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQixDQUNFLHdCQUFDLEtBQUQ7S0FBRztLQUFRLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtLQUFFO0lBQTRDOzs7O2NBQ2hGLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWIsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxpREFBa0Q7Ozs7ZUFBQywwQkFDdEU7Ozs7O1lBQ0c7Ozs7OztFQUNMOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJMb2dpblBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gXCJyZWFjdC1ob29rLWZvcm1cIjtcbmltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSBcIkBob29rZm9ybS9yZXNvbHZlcnMvem9kXCI7XG5pbXBvcnQgKiBhcyB6IGZyb20gXCJ6b2RcIjtcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vaG9va3MvdXNlQXV0aFwiO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUsIExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuaW1wb3J0IHsgV2FsbGV0LCBTdW4sIE1vb24sIEFycm93UmlnaHQsIFNwYXJrbGVzLCBDaGVja0NpcmNsZTIgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gXCIuLi9jb21wb25lbnRzL1RoZW1lQ29udGV4dFwiO1xuXG5jb25zdCBsb2dpblNjaGVtYSA9IHoub2JqZWN0KHtcbiAgZW1haWw6IHouc3RyaW5nKCkuZW1haWwoXCJQbGVhc2UgZW50ZXIgYSB2YWxpZCBlbWFpbCBhZGRyZXNzXCIpLFxuICBwYXNzd29yZDogei5zdHJpbmcoKS5taW4oOCwgXCJQYXNzd29yZCBtdXN0IGJlIGF0IGxlYXN0IDggY2hhcmFjdGVyc1wiKSxcbn0pO1xuXG50eXBlIExvZ2luRmllbGRzID0gei5pbmZlcjx0eXBlb2YgbG9naW5TY2hlbWE+O1xuXG5leHBvcnQgY29uc3QgTG9naW5QYWdlOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgeyBsb2dpbiB9ID0gdXNlQXV0aCgpO1xuICBjb25zdCB7IHRoZW1lLCB0b2dnbGVUaGVtZSB9ID0gdXNlVGhlbWUoKTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuICBjb25zdCBbZXJyb3JNc2csIHNldEVycm9yTXNnXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IHtcbiAgICByZWdpc3RlcixcbiAgICBoYW5kbGVTdWJtaXQsXG4gICAgZm9ybVN0YXRlOiB7IGVycm9ycywgaXNTdWJtaXR0aW5nIH0sXG4gIH0gPSB1c2VGb3JtPExvZ2luRmllbGRzPih7XG4gICAgcmVzb2x2ZXI6IHpvZFJlc29sdmVyKGxvZ2luU2NoZW1hKSxcbiAgfSk7XG5cbiAgY29uc3Qgb25TdWJtaXQgPSBhc3luYyAoZGF0YTogTG9naW5GaWVsZHMpID0+IHtcbiAgICBzZXRFcnJvck1zZyhudWxsKTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgbG9naW4oZGF0YSk7XG4gICAgICBuYXZpZ2F0ZShcIi9cIik7XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIHNldEVycm9yTXNnKFxuICAgICAgICBlcnIucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgZXJyLm1lc3NhZ2UgfHwgXCJJbnZhbGlkIGVtYWlsIG9yIHBhc3N3b3JkXCJcbiAgICAgICk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtaW4taC1zY3JlZW4gYmctWyNmNGY5ZjZdIGRhcms6YmctWyMwNTE2MEVdIHRleHQtemluYy04MDAgZGFyazp0ZXh0LXppbmMtMTAwIGZsZXggZmxleC1jb2wgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwIHNlbGVjdGlvbjpiZy1bIzNjZDM5NV0gc2VsZWN0aW9uOnRleHQtYmxhY2tcIj5cbiAgICAgIHsvKiBCYWNrZ3JvdW5kIEltYWdlIHdpdGggVHJhbnNwYXJlbmN5ICovfVxuICAgICAgPGRpdiBcbiAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1bdXJsKCcvaW1hZ2VCYWNrZ3JvdW5kLnN2ZycpXSBiZy1jb250YWluIGJnLW5vLXJlcGVhdCBiZy1jZW50ZXIgb3BhY2l0eS0yNSBkYXJrOm9wYWNpdHktMTUgcG9pbnRlci1ldmVudHMtbm9uZVwiXG4gICAgICAvPlxuXG4gICAgICB7LyogSGVhZGVyIE5hdmlnYXRpb24gKi99XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy03eGwgbXgtYXV0byBweC02IHB5LTUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1bI2NjZThkYl0vNjAgZGFyazpib3JkZXItWyMxMjMwMjJdLzQwXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC05IHctOSBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1sZyBiZy1bIzNjZDM5NV0vMTAgdGV4dC1bIzNjZDM5NV1cIj5cbiAgICAgICAgICAgIDxXYWxsZXQgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtbGcgdHJhY2tpbmctdGlnaHQgdGV4dC1bIzBhMjcxY10gZGFyazp0ZXh0LXdoaXRlXCI+RS1GaW5hbmNlPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgey8qIFRoZW1lL0RhcmsgU3dpdGNoZXIgQ2Fwc3VsZSAqL31cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVUaGVtZX1cbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwidGhlbWUtdG9nZ2xlLWJ1dHRvblwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLVsjZTZmNGVkXSBob3ZlcjpiZy1bI2QyZWJkOV0gZGFyazpiZy1bIzBlMjcxY10gZGFyazpob3ZlcjpiZy1bIzE1MzgyOF0gYm9yZGVyIGJvcmRlci1bI2NjZThkYl0gZGFyazpib3JkZXItWyMxYTQyMzBdIGhvdmVyOmJvcmRlci1bI2I0ZTBjNF0gZGFyazpob3Zlcjpib3JkZXItWyMyMjU3M2ZdIHJvdW5kZWQtZnVsbCBweC0zIHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtWyMwYTI3MWNdIGRhcms6dGV4dC16aW5jLTMwMCBob3Zlcjp0ZXh0LVsjMDYxYzEzXSBkYXJrOmhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgdGl0bGU9XCJUb2dnbGUgVGhlbWVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHt0aGVtZSA9PT0gXCJkYXJrXCIgPyA8U3VuIGNsYXNzTmFtZT1cImgtMy41IHctMy41XCIgLz4gOiA8TW9vbiBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNVwiIC8+fVxuICAgICAgICAgICAgPHNwYW4+e3RoZW1lID09PSBcImRhcmtcIiA/IFwiTGlnaHRcIiA6IFwiRGFya1wifTwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAgey8qIE1haW4gQ29udGVudCBBcmVhICovfVxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIG1heC13LTd4bCB3LWZ1bGwgbXgtYXV0byBweC02IHB5LTEyIG1kOnB5LTIwIGdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTEyIGdhcC0xMiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgey8qIExlZnQgQ29sdW1uOiBIZXJvIFRleHQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNyBzcGFjZS15LThcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LVsjMjQ4ZDYxXSBkYXJrOnRleHQtWyMzY2QzOTVdXCI+RS1GSU5BTkNFIEFQUDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBzbTp0ZXh0LTV4bCBsZzp0ZXh0LTZ4bCBmb250LW1lZGl1bSB0ZXh0LVsjMGEyNzFjXSBkYXJrOnRleHQtd2hpdGUgbGVhZGluZy1bMS4xNV0gdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgIE1hc3RlciBZb3VyIE1vbmV5LCA8YnIgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWyMyNDhkNjFdIGRhcms6dGV4dC1bIzNjZDM5NV1cIj5Ob3QgWW91ciBGaW5hbmNpYWwgU3RyZXNzLjwvc3Bhbj5cbiAgICAgICAgICA8L2gxPlxuXG4gICAgICAgICAgey8qIFZhbHVlIFByb3BzIEdyaWQgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC00IHB0LTggYm9yZGVyLXQgYm9yZGVyLVsjY2NlOGRiXS82MCBkYXJrOmJvcmRlci1bIzEyMzAyMl0vNDAgbWF4LXctbGdcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LVsjMjQ4ZDYxXSBkYXJrOnRleHQtWyMzY2QzOTVdIHNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1bIzBhMjcxY10gZGFyazp0ZXh0LXdoaXRlIHRleHQtc21cIj4xMDAlIFByaXZhdGU8L2g0PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00MDBcIj5SZWxheCEgWW91ciBkYXRhIG5ldmVyIGxlYXZlcyB5b3VyIGluc3RhbmNlLjwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LVsjMjQ4ZDYxXSBkYXJrOnRleHQtWyMzY2QzOTVdIHNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1bIzBhMjcxY10gZGFyazp0ZXh0LXdoaXRlIHRleHQtc21cIj5TbWFydCBCdWRnZXRzPC9oND5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtemluYy01MDAgZGFyazp0ZXh0LXppbmMtNDAwXCI+VHJhY2sgYW5kIG1hbmFnZSB5b3VyIHNwZW5kaW5nIGhhYml0cyBlZmZvcnRsZXNzbHkuPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogUmlnaHQgQ29sdW1uOiBHbGFzc21vcnBoaWMgTG9naW4gQ2FyZCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi01IGZsZXgganVzdGlmeS1jZW50ZXIgbGc6anVzdGlmeS1lbmRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1tZCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLVsjY2NlOGRiXSBkYXJrOmJvcmRlci1bIzFhNDIzMF0gYmctd2hpdGUvODAgZGFyazpiZy1bIzBhMWUxNV0vNjAgYmFja2Ryb3AtYmx1ci1tZCBwLTggc2hhZG93LTJ4bCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgIHsvKiBCYWNrZ3JvdW5kIGFtYmllbnQgZ2xvdyBpbnNpZGUgY2FyZCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC0xMCAtcmlnaHQtMTAgdy0zMiBoLTMyIGJnLVsjM2NkMzk1XS8xMCByb3VuZGVkLWZ1bGwgYmx1ci0zeGwgcG9pbnRlci1ldmVudHMtbm9uZVwiPjwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LVsjMGEyNzFjXSBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj5XZWxjb21lIEJhY2s8L2gyPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00MDAgbXQtMVwiPlNpZ24gaW4gdG8gbWFuYWdlIHlvdXIgZmluYW5jZXM8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHtlcnJvck1zZyAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItcmVkLTUwMC8zMCBiZy1yZWQtNTAwLzEwIHAtMyB0ZXh0LXNtIHRleHQtcmVkLTY1MCBkYXJrOnRleHQtcmVkLTQwMCBtYi02IGFuaW1hdGUtcHVsc2VcIj5cbiAgICAgICAgICAgICAgICAgIHtlcnJvck1zZ31cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTVcIiBvblN1Ym1pdD17aGFuZGxlU3VibWl0KG9uU3VibWl0KX0+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZW1haWxcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtemluYy01NTAgZGFyazp0ZXh0LXppbmMtNDAwIG1iLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICBFbWFpbCBBZGRyZXNzXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImVtYWlsXCIpfVxuICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cImxvZ2luLWVtYWlsLWlucHV0XCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmxvY2sgdy1mdWxsIHJvdW5kZWQtbGcgYm9yZGVyIGJnLXdoaXRlIGRhcms6YmctWyMwNTE2MEVdLzgwIGJvcmRlci1bI2NjZThkYl0gZGFyazpib3JkZXItWyMxYTQyMzBdIHB4LTMuNSBweS0yLjUgdGV4dC1zbSB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZSBwbGFjZWhvbGRlci16aW5jLTQwMCBkYXJrOnBsYWNlaG9sZGVyLXppbmMtNTAwIGZvY3VzOmJvcmRlci1bIzI0OGQ2MV0gZGFyazpmb2N1czpib3JkZXItWyMzY2QzOTVdIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTEgZm9jdXM6cmluZy1bIzNjZDM5NV0vNDAgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICBlcnJvcnMuZW1haWwgPyBcImJvcmRlci1yZWQtNTAwXCIgOiBcIlwiXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImV4YW1wbGVAbWFpbC5jb21cIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW1haWwgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1yZWQtNTAwIGRhcms6dGV4dC1yZWQtNDAwXCI+e2Vycm9ycy5lbWFpbC5tZXNzYWdlfTwvcD5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicGFzc3dvcmRcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtemluYy01NTAgZGFyazp0ZXh0LXppbmMtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgUGFzc3dvcmRcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIGlkPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJjdXJyZW50LXBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICAgICAgey4uLnJlZ2lzdGVyKFwicGFzc3dvcmRcIil9XG4gICAgICAgICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwibG9naW4tcGFzc3dvcmQtaW5wdXRcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BibG9jayB3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYmctd2hpdGUgZGFyazpiZy1bIzA1MTYwRV0vODAgYm9yZGVyLVsjY2NlOGRiXSBkYXJrOmJvcmRlci1bIzFhNDIzMF0gcHgtMy41IHB5LTIuNSB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXppbmMtNDAwIGRhcms6cGxhY2Vob2xkZXItemluYy01MDAgZm9jdXM6Ym9yZGVyLVsjMjQ4ZDYxXSBkYXJrOmZvY3VzOmJvcmRlci1bIzNjZDM5NV0gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLVsjM2NkMzk1XS80MCB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICAgIGVycm9ycy5wYXNzd29yZCA/IFwiYm9yZGVyLXJlZC01MDBcIiA6IFwiXCJcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCiXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBhc3N3b3JkICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTUwMCBkYXJrOnRleHQtcmVkLTQwMFwiPntlcnJvcnMucGFzc3dvcmQubWVzc2FnZX08L3A+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yXCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxuICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cImxvZ2luLXN1Ym1pdC1idXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHctZnVsbCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgZ2FwLTIgcm91bmRlZC1sZyBiZy1bIzNjZDM5NV0gaG92ZXI6YmctWyM0YmU0YTRdIHB4LTQgcHktMi41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWJsYWNrIHRyYW5zaXRpb24tY29sb3JzIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzNjZDM5NV0gZm9jdXM6cmluZy1vZmZzZXQtMiBmb2N1czpyaW5nLW9mZnNldC13aGl0ZSBkYXJrOmZvY3VzOnJpbmctb2Zmc2V0LVsjMGExZTE1XSBkaXNhYmxlZDpvcGFjaXR5LTUwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2lzU3VibWl0dGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtNSB3LTUgYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBib3JkZXItMiBib3JkZXItYmxhY2sgYm9yZGVyLXQtdHJhbnNwYXJlbnRcIj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2lnbiBJbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQteHMgdGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00NTAgbXQtNiBwdC00IGJvcmRlci10IGJvcmRlci1bI2NjZThkYl0vNjAgZGFyazpib3JkZXItWyMxMjMwMjJdLzQwXCI+XG4gICAgICAgICAgICAgICAgICBEb24ndCBoYXZlIGFuIGFjY291bnQ/e1wiIFwifVxuICAgICAgICAgICAgICAgICAgPExpbmsgdG89XCIvc2lnbnVwXCIgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LVsjMjQ4ZDYxXSBkYXJrOnRleHQtWyMzY2QzOTVdIGhvdmVyOnRleHQtWyMyZmFlN2FdIGRhcms6aG92ZXI6dGV4dC1bIzRiZTRhNF0gdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAgU2lnbiBVcFxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L21haW4+XG5cbiAgICAgIHsvKiBGb290ZXIgKi99XG4gICAgICA8Zm9vdGVyIGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy03eGwgbXgtYXV0byBweC02IHB5LTggbXQtYXV0byBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyB0ZXh0LXppbmMtNTAwIGJvcmRlci10IGJvcmRlci1bI2NjZThkYl0vNDAgZGFyazpib3JkZXItWyMxMjMwMjJdLzIwXCI+XG4gICAgICAgIDxwPiZjb3B5OyB7bmV3IERhdGUoKS5nZXRGdWxsWWVhcigpfSBFLUZpbmFuY2UgYnkgcmtERVYuIEFsbCByaWdodHMgcmVzZXJ2ZWQuPC9wPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHNtOm10LTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJoLTMuNSB3LTMuNSB0ZXh0LVsjMjQ4ZDYxXSBkYXJrOnRleHQtWyMzY2QzOTVdXCIgLz4gQnVpbHQgZm9yIHVzZXIgcHJpdmFjeS5cbiAgICAgICAgPC9wPlxuICAgICAgPC9mb290ZXI+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19