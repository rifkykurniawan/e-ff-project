import { supabase } from "/src/services/supabaseClient.ts";
export const authService = {
	signUp: async (credentials) => {
		try {
			const { data, error } = await supabase.auth.signUp({
				email: credentials.email,
				password: credentials.password,
				options: { data: {
					first_name: credentials.first_name,
					last_name: credentials.last_name
				} }
			});
			if (error) {
				const message = error.message === "Signups not allowed for this instance" ? "Signups are currently not available. Please contact the administrator to create your account." : error.message;
				return {
					success: false,
					message,
					data: null,
					errors: { message: [message] }
				};
			}
			if (!data.user) {
				return {
					success: false,
					message: "Failed to create user account.",
					data: null
				};
			}
			// Automatically sign out because signup creates a session, but they need admin approval first
			await supabase.auth.signOut();
			return {
				success: true,
				message: "Registration successful. Your account is pending administrator approval.",
				data: {
					id: data.user.id,
					email: data.user.email || "",
					first_name: credentials.first_name,
					last_name: credentials.last_name,
					email_confirmed: !!data.user.email_confirmed_at,
					is_verified: false
				}
			};
		} catch (err) {
			return {
				success: false,
				message: err.message || "An unexpected error occurred",
				data: null
			};
		}
	},
	login: async (credentials) => {
		try {
			const { data, error } = await supabase.auth.signInWithPassword({
				email: credentials.email,
				password: credentials.password
			});
			if (error) {
				return {
					success: false,
					message: error.message,
					data: null,
					errors: { message: [error.message] }
				};
			}
			if (!data.user || !data.session) {
				return {
					success: false,
					message: "Failed to establish a session.",
					data: null
				};
			}
			const { data: profile } = await supabase.from("users").select("first_name, last_name, is_verified").eq("id", data.user.id).single();
			if (!profile || !profile.is_verified) {
				await supabase.auth.signOut();
				return {
					success: false,
					message: "Your account is pending administrator approval.",
					data: null,
					errors: { message: ["Your account is pending administrator approval."] }
				};
			}
			return {
				success: true,
				message: "Login successful",
				data: {
					access_token: data.session.access_token,
					token_type: "bearer",
					user: {
						id: data.user.id,
						email: data.user.email || "",
						first_name: profile.first_name,
						last_name: profile.last_name,
						email_confirmed: !!data.user.email_confirmed_at,
						is_verified: profile.is_verified
					}
				}
			};
		} catch (err) {
			return {
				success: false,
				message: err.message || "An unexpected error occurred",
				data: null
			};
		}
	},
	getMe: async () => {
		try {
			const { data, error } = await supabase.auth.getSession();
			if (error) {
				return {
					success: false,
					message: error.message,
					data: null
				};
			}
			if (!data.session || !data.session.user) {
				return {
					success: false,
					message: "No active session found.",
					data: null
				};
			}
			const user = data.session.user;
			const { data: profile } = await supabase.from("users").select("first_name, last_name, is_verified").eq("id", user.id).single();
			if (!profile || !profile.is_verified) {
				await supabase.auth.signOut();
				return {
					success: false,
					message: "Your account is pending administrator approval.",
					data: null
				};
			}
			return {
				success: true,
				message: "Session retrieved successfully",
				data: {
					id: user.id,
					email: user.email || "",
					first_name: profile.first_name,
					last_name: profile.last_name,
					email_confirmed: !!user.email_confirmed_at,
					is_verified: profile.is_verified
				}
			};
		} catch (err) {
			return {
				success: false,
				message: err.message || "An unexpected error occurred",
				data: null
			};
		}
	},
	logout: async () => {
		await supabase.auth.signOut();
	}
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFHekIsT0FBTyxNQUFNLGNBQWM7Q0FDekIsUUFBUSxPQUFPLGdCQUE0RTtFQUN6RixJQUFJO0dBQ0YsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLFNBQVMsS0FBSyxPQUFPO0lBQ2pELE9BQU8sWUFBWTtJQUNuQixVQUFVLFlBQVk7SUFDdEIsU0FBUyxFQUNQLE1BQU07S0FDSixZQUFZLFlBQVk7S0FDeEIsV0FBVyxZQUFZO0lBQ3pCLEVBQ0Y7R0FDRixDQUFDO0dBRUQsSUFBSSxPQUFPO0lBQ1QsTUFBTSxVQUFVLE1BQU0sWUFBWSwwQ0FDOUIsa0dBQ0EsTUFBTTtJQUNWLE9BQU87S0FDTCxTQUFTO0tBQ1Q7S0FDQSxNQUFNO0tBQ04sUUFBUSxFQUFFLFNBQVMsQ0FBQyxPQUFPLEVBQUU7SUFDL0I7R0FDRjtHQUVBLElBQUksQ0FBQyxLQUFLLE1BQU07SUFDZCxPQUFPO0tBQ0wsU0FBUztLQUNULFNBQVM7S0FDVCxNQUFNO0lBQ1I7R0FDRjs7R0FHQSxNQUFNLFNBQVMsS0FBSyxRQUFRO0dBRTVCLE9BQU87SUFDTCxTQUFTO0lBQ1QsU0FBUztJQUNULE1BQU07S0FDSixJQUFJLEtBQUssS0FBSztLQUNkLE9BQU8sS0FBSyxLQUFLLFNBQVM7S0FDMUIsWUFBWSxZQUFZO0tBQ3hCLFdBQVcsWUFBWTtLQUN2QixpQkFBaUIsQ0FBQyxDQUFDLEtBQUssS0FBSztLQUM3QixhQUFhO0lBQ2Y7R0FDRjtFQUNGLFNBQVMsS0FBVTtHQUNqQixPQUFPO0lBQ0wsU0FBUztJQUNULFNBQVMsSUFBSSxXQUFXO0lBQ3hCLE1BQU07R0FDUjtFQUNGO0NBQ0Y7Q0FFQSxPQUFPLE9BQU8sZ0JBQTRFO0VBQ3hGLElBQUk7R0FDRixNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLLG1CQUFtQjtJQUM3RCxPQUFPLFlBQVk7SUFDbkIsVUFBVSxZQUFZO0dBQ3hCLENBQUM7R0FFRCxJQUFJLE9BQU87SUFDVCxPQUFPO0tBQ0wsU0FBUztLQUNULFNBQVMsTUFBTTtLQUNmLE1BQU07S0FDTixRQUFRLEVBQUUsU0FBUyxDQUFDLE1BQU0sT0FBTyxFQUFFO0lBQ3JDO0dBQ0Y7R0FFQSxJQUFJLENBQUMsS0FBSyxRQUFRLENBQUMsS0FBSyxTQUFTO0lBQy9CLE9BQU87S0FDTCxTQUFTO0tBQ1QsU0FBUztLQUNULE1BQU07SUFDUjtHQUNGO0dBRUEsTUFBTSxFQUFFLE1BQU0sWUFBWSxNQUFNLFNBQzdCLEtBQUssT0FBTyxDQUFDLENBQ2IsT0FBTyxvQ0FBb0MsQ0FBQyxDQUM1QyxHQUFHLE1BQU0sS0FBSyxLQUFLLEVBQUUsQ0FBQyxDQUN0QixPQUFPO0dBRVYsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLGFBQWE7SUFDcEMsTUFBTSxTQUFTLEtBQUssUUFBUTtJQUM1QixPQUFPO0tBQ0wsU0FBUztLQUNULFNBQVM7S0FDVCxNQUFNO0tBQ04sUUFBUSxFQUFFLFNBQVMsQ0FBQyxpREFBaUQsRUFBRTtJQUN6RTtHQUNGO0dBRUEsT0FBTztJQUNMLFNBQVM7SUFDVCxTQUFTO0lBQ1QsTUFBTTtLQUNKLGNBQWMsS0FBSyxRQUFRO0tBQzNCLFlBQVk7S0FDWixNQUFNO01BQ0osSUFBSSxLQUFLLEtBQUs7TUFDZCxPQUFPLEtBQUssS0FBSyxTQUFTO01BQzFCLFlBQVksUUFBUTtNQUNwQixXQUFXLFFBQVE7TUFDbkIsaUJBQWlCLENBQUMsQ0FBQyxLQUFLLEtBQUs7TUFDN0IsYUFBYSxRQUFRO0tBQ3ZCO0lBQ0Y7R0FDRjtFQUNGLFNBQVMsS0FBVTtHQUNqQixPQUFPO0lBQ0wsU0FBUztJQUNULFNBQVMsSUFBSSxXQUFXO0lBQ3hCLE1BQU07R0FDUjtFQUNGO0NBQ0Y7Q0FFQSxPQUFPLFlBQXFEO0VBQzFELElBQUk7R0FDRixNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLLFdBQVc7R0FDdkQsSUFBSSxPQUFPO0lBQ1QsT0FBTztLQUNMLFNBQVM7S0FDVCxTQUFTLE1BQU07S0FDZixNQUFNO0lBQ1I7R0FDRjtHQUVBLElBQUksQ0FBQyxLQUFLLFdBQVcsQ0FBQyxLQUFLLFFBQVEsTUFBTTtJQUN2QyxPQUFPO0tBQ0wsU0FBUztLQUNULFNBQVM7S0FDVCxNQUFNO0lBQ1I7R0FDRjtHQUVBLE1BQU0sT0FBTyxLQUFLLFFBQVE7R0FFMUIsTUFBTSxFQUFFLE1BQU0sWUFBWSxNQUFNLFNBQzdCLEtBQUssT0FBTyxDQUFDLENBQ2IsT0FBTyxvQ0FBb0MsQ0FBQyxDQUM1QyxHQUFHLE1BQU0sS0FBSyxFQUFFLENBQUMsQ0FDakIsT0FBTztHQUVWLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxhQUFhO0lBQ3BDLE1BQU0sU0FBUyxLQUFLLFFBQVE7SUFDNUIsT0FBTztLQUNMLFNBQVM7S0FDVCxTQUFTO0tBQ1QsTUFBTTtJQUNSO0dBQ0Y7R0FFQSxPQUFPO0lBQ0wsU0FBUztJQUNULFNBQVM7SUFDVCxNQUFNO0tBQ0osSUFBSSxLQUFLO0tBQ1QsT0FBTyxLQUFLLFNBQVM7S0FDckIsWUFBWSxRQUFRO0tBQ3BCLFdBQVcsUUFBUTtLQUNuQixpQkFBaUIsQ0FBQyxDQUFDLEtBQUs7S0FDeEIsYUFBYSxRQUFRO0lBQ3ZCO0dBQ0Y7RUFDRixTQUFTLEtBQVU7R0FDakIsT0FBTztJQUNMLFNBQVM7SUFDVCxTQUFTLElBQUksV0FBVztJQUN4QixNQUFNO0dBQ1I7RUFDRjtDQUNGO0NBRUEsUUFBUSxZQUEyQjtFQUNqQyxNQUFNLFNBQVMsS0FBSyxRQUFRO0NBQzlCO0FBQ0YiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiYXV0aFNlcnZpY2UudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc3VwYWJhc2UgfSBmcm9tIFwiLi9zdXBhYmFzZUNsaWVudFwiO1xuaW1wb3J0IHR5cGUgeyBMb2dpbkNyZWRlbnRpYWxzLCBTaWduVXBDcmVkZW50aWFscywgVG9rZW5SZXNwb25zZSwgVXNlclJlc3BvbnNlLCBFbnZlbG9wZVJlc3BvbnNlIH0gZnJvbSBcIi4uL3R5cGVzL2F1dGhcIjtcblxuZXhwb3J0IGNvbnN0IGF1dGhTZXJ2aWNlID0ge1xuICBzaWduVXA6IGFzeW5jIChjcmVkZW50aWFsczogU2lnblVwQ3JlZGVudGlhbHMpOiBQcm9taXNlPEVudmVsb3BlUmVzcG9uc2U8VXNlclJlc3BvbnNlPj4gPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25VcCh7XG4gICAgICAgIGVtYWlsOiBjcmVkZW50aWFscy5lbWFpbCxcbiAgICAgICAgcGFzc3dvcmQ6IGNyZWRlbnRpYWxzLnBhc3N3b3JkLFxuICAgICAgICBvcHRpb25zOiB7XG4gICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgZmlyc3RfbmFtZTogY3JlZGVudGlhbHMuZmlyc3RfbmFtZSxcbiAgICAgICAgICAgIGxhc3RfbmFtZTogY3JlZGVudGlhbHMubGFzdF9uYW1lLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9KTtcblxuICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvci5tZXNzYWdlID09PSBcIlNpZ251cHMgbm90IGFsbG93ZWQgZm9yIHRoaXMgaW5zdGFuY2VcIlxuICAgICAgICAgID8gXCJTaWdudXBzIGFyZSBjdXJyZW50bHkgbm90IGF2YWlsYWJsZS4gUGxlYXNlIGNvbnRhY3QgdGhlIGFkbWluaXN0cmF0b3IgdG8gY3JlYXRlIHlvdXIgYWNjb3VudC5cIlxuICAgICAgICAgIDogZXJyb3IubWVzc2FnZTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgICBtZXNzYWdlLFxuICAgICAgICAgIGRhdGE6IG51bGwgYXMgYW55LFxuICAgICAgICAgIGVycm9yczogeyBtZXNzYWdlOiBbbWVzc2FnZV0gfSxcbiAgICAgICAgfTtcbiAgICAgIH1cblxuICAgICAgaWYgKCFkYXRhLnVzZXIpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBjcmVhdGUgdXNlciBhY2NvdW50LlwiLFxuICAgICAgICAgIGRhdGE6IG51bGwgYXMgYW55LFxuICAgICAgICB9O1xuICAgICAgfVxuXG4gICAgICAvLyBBdXRvbWF0aWNhbGx5IHNpZ24gb3V0IGJlY2F1c2Ugc2lnbnVwIGNyZWF0ZXMgYSBzZXNzaW9uLCBidXQgdGhleSBuZWVkIGFkbWluIGFwcHJvdmFsIGZpcnN0XG4gICAgICBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25PdXQoKTtcblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgbWVzc2FnZTogXCJSZWdpc3RyYXRpb24gc3VjY2Vzc2Z1bC4gWW91ciBhY2NvdW50IGlzIHBlbmRpbmcgYWRtaW5pc3RyYXRvciBhcHByb3ZhbC5cIixcbiAgICAgICAgZGF0YToge1xuICAgICAgICAgIGlkOiBkYXRhLnVzZXIuaWQsXG4gICAgICAgICAgZW1haWw6IGRhdGEudXNlci5lbWFpbCB8fCBcIlwiLFxuICAgICAgICAgIGZpcnN0X25hbWU6IGNyZWRlbnRpYWxzLmZpcnN0X25hbWUsXG4gICAgICAgICAgbGFzdF9uYW1lOiBjcmVkZW50aWFscy5sYXN0X25hbWUsXG4gICAgICAgICAgZW1haWxfY29uZmlybWVkOiAhIWRhdGEudXNlci5lbWFpbF9jb25maXJtZWRfYXQsXG4gICAgICAgICAgaXNfdmVyaWZpZWQ6IGZhbHNlLFxuICAgICAgICB9LFxuICAgICAgfTtcbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgIG1lc3NhZ2U6IGVyci5tZXNzYWdlIHx8IFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZFwiLFxuICAgICAgICBkYXRhOiBudWxsIGFzIGFueSxcbiAgICAgIH07XG4gICAgfVxuICB9LFxuXG4gIGxvZ2luOiBhc3luYyAoY3JlZGVudGlhbHM6IExvZ2luQ3JlZGVudGlhbHMpOiBQcm9taXNlPEVudmVsb3BlUmVzcG9uc2U8VG9rZW5SZXNwb25zZT4+ID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5zaWduSW5XaXRoUGFzc3dvcmQoe1xuICAgICAgICBlbWFpbDogY3JlZGVudGlhbHMuZW1haWwsXG4gICAgICAgIHBhc3N3b3JkOiBjcmVkZW50aWFscy5wYXNzd29yZCxcbiAgICAgIH0pO1xuXG4gICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgICBtZXNzYWdlOiBlcnJvci5tZXNzYWdlLFxuICAgICAgICAgIGRhdGE6IG51bGwgYXMgYW55LFxuICAgICAgICAgIGVycm9yczogeyBtZXNzYWdlOiBbZXJyb3IubWVzc2FnZV0gfSxcbiAgICAgICAgfTtcbiAgICAgIH1cblxuICAgICAgaWYgKCFkYXRhLnVzZXIgfHwgIWRhdGEuc2Vzc2lvbikge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGVzdGFibGlzaCBhIHNlc3Npb24uXCIsXG4gICAgICAgICAgZGF0YTogbnVsbCBhcyBhbnksXG4gICAgICAgIH07XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHsgZGF0YTogcHJvZmlsZSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oXCJ1c2Vyc1wiKVxuICAgICAgICAuc2VsZWN0KFwiZmlyc3RfbmFtZSwgbGFzdF9uYW1lLCBpc192ZXJpZmllZFwiKVxuICAgICAgICAuZXEoXCJpZFwiLCBkYXRhLnVzZXIuaWQpXG4gICAgICAgIC5zaW5nbGUoKTtcblxuICAgICAgaWYgKCFwcm9maWxlIHx8ICFwcm9maWxlLmlzX3ZlcmlmaWVkKSB7XG4gICAgICAgIGF3YWl0IHN1cGFiYXNlLmF1dGguc2lnbk91dCgpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICAgIG1lc3NhZ2U6IFwiWW91ciBhY2NvdW50IGlzIHBlbmRpbmcgYWRtaW5pc3RyYXRvciBhcHByb3ZhbC5cIixcbiAgICAgICAgICBkYXRhOiBudWxsIGFzIGFueSxcbiAgICAgICAgICBlcnJvcnM6IHsgbWVzc2FnZTogW1wiWW91ciBhY2NvdW50IGlzIHBlbmRpbmcgYWRtaW5pc3RyYXRvciBhcHByb3ZhbC5cIl0gfSxcbiAgICAgICAgfTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgbWVzc2FnZTogXCJMb2dpbiBzdWNjZXNzZnVsXCIsXG4gICAgICAgIGRhdGE6IHtcbiAgICAgICAgICBhY2Nlc3NfdG9rZW46IGRhdGEuc2Vzc2lvbi5hY2Nlc3NfdG9rZW4sXG4gICAgICAgICAgdG9rZW5fdHlwZTogXCJiZWFyZXJcIixcbiAgICAgICAgICB1c2VyOiB7XG4gICAgICAgICAgICBpZDogZGF0YS51c2VyLmlkLFxuICAgICAgICAgICAgZW1haWw6IGRhdGEudXNlci5lbWFpbCB8fCBcIlwiLFxuICAgICAgICAgICAgZmlyc3RfbmFtZTogcHJvZmlsZS5maXJzdF9uYW1lLFxuICAgICAgICAgICAgbGFzdF9uYW1lOiBwcm9maWxlLmxhc3RfbmFtZSxcbiAgICAgICAgICAgIGVtYWlsX2NvbmZpcm1lZDogISFkYXRhLnVzZXIuZW1haWxfY29uZmlybWVkX2F0LFxuICAgICAgICAgICAgaXNfdmVyaWZpZWQ6IHByb2ZpbGUuaXNfdmVyaWZpZWQsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH07XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICBtZXNzYWdlOiBlcnIubWVzc2FnZSB8fCBcIkFuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWRcIixcbiAgICAgICAgZGF0YTogbnVsbCBhcyBhbnksXG4gICAgICB9O1xuICAgIH1cbiAgfSxcblxuICBnZXRNZTogYXN5bmMgKCk6IFByb21pc2U8RW52ZWxvcGVSZXNwb25zZTxVc2VyUmVzcG9uc2U+PiA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgZGF0YSwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0U2Vzc2lvbigpO1xuICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgICAgbWVzc2FnZTogZXJyb3IubWVzc2FnZSxcbiAgICAgICAgICBkYXRhOiBudWxsIGFzIGFueSxcbiAgICAgICAgfTtcbiAgICAgIH1cblxuICAgICAgaWYgKCFkYXRhLnNlc3Npb24gfHwgIWRhdGEuc2Vzc2lvbi51c2VyKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgICAgbWVzc2FnZTogXCJObyBhY3RpdmUgc2Vzc2lvbiBmb3VuZC5cIixcbiAgICAgICAgICBkYXRhOiBudWxsIGFzIGFueSxcbiAgICAgICAgfTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgdXNlciA9IGRhdGEuc2Vzc2lvbi51c2VyO1xuICAgICAgXG4gICAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKFwidXNlcnNcIilcbiAgICAgICAgLnNlbGVjdChcImZpcnN0X25hbWUsIGxhc3RfbmFtZSwgaXNfdmVyaWZpZWRcIilcbiAgICAgICAgLmVxKFwiaWRcIiwgdXNlci5pZClcbiAgICAgICAgLnNpbmdsZSgpO1xuXG4gICAgICBpZiAoIXByb2ZpbGUgfHwgIXByb2ZpbGUuaXNfdmVyaWZpZWQpIHtcbiAgICAgICAgYXdhaXQgc3VwYWJhc2UuYXV0aC5zaWduT3V0KCk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgICAgbWVzc2FnZTogXCJZb3VyIGFjY291bnQgaXMgcGVuZGluZyBhZG1pbmlzdHJhdG9yIGFwcHJvdmFsLlwiLFxuICAgICAgICAgIGRhdGE6IG51bGwgYXMgYW55LFxuICAgICAgICB9O1xuICAgICAgfVxuXG4gICAgICByZXR1cm4ge1xuICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICBtZXNzYWdlOiBcIlNlc3Npb24gcmV0cmlldmVkIHN1Y2Nlc3NmdWxseVwiLFxuICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgaWQ6IHVzZXIuaWQsXG4gICAgICAgICAgZW1haWw6IHVzZXIuZW1haWwgfHwgXCJcIixcbiAgICAgICAgICBmaXJzdF9uYW1lOiBwcm9maWxlLmZpcnN0X25hbWUsXG4gICAgICAgICAgbGFzdF9uYW1lOiBwcm9maWxlLmxhc3RfbmFtZSxcbiAgICAgICAgICBlbWFpbF9jb25maXJtZWQ6ICEhdXNlci5lbWFpbF9jb25maXJtZWRfYXQsXG4gICAgICAgICAgaXNfdmVyaWZpZWQ6IHByb2ZpbGUuaXNfdmVyaWZpZWQsXG4gICAgICAgIH0sXG4gICAgICB9O1xuICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgbWVzc2FnZTogZXJyLm1lc3NhZ2UgfHwgXCJBbiB1bmV4cGVjdGVkIGVycm9yIG9jY3VycmVkXCIsXG4gICAgICAgIGRhdGE6IG51bGwgYXMgYW55LFxuICAgICAgfTtcbiAgICB9XG4gIH0sXG5cbiAgbG9nb3V0OiBhc3luYyAoKTogUHJvbWlzZTx2b2lkPiA9PiB7XG4gICAgYXdhaXQgc3VwYWJhc2UuYXV0aC5zaWduT3V0KCk7XG4gIH1cbn07XG4iXX0=