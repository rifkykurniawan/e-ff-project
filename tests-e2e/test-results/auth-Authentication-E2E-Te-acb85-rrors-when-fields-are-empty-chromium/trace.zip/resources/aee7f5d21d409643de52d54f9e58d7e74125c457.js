import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/DashboardPage.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=513be775";
import { useAuth } from "/src/hooks/useAuth.ts";
import { useDashboard } from "/src/hooks/useDashboard.ts";
import { useOutletContext } from "/node_modules/.vite/deps/react-router-dom.js?v=63710477";
import { useAccounts } from "/src/hooks/useAccounts.ts";
import { useCategories } from "/src/hooks/useCategories.ts";
import { useTransactions } from "/src/hooks/useTransactions.ts";
import { TransactionForm } from "/src/features/transactions/TransactionForm.tsx";
import { Wallet, ArrowUpRight, ArrowDownRight, ArrowLeftRight, TrendingUp, Target, X, Plus, Minus, Sparkles, PieChart, Activity } from "/node_modules/.vite/deps/lucide-react.js?v=7df35618";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/DashboardPage.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
var _s = $RefreshSig$();
export const DashboardPage = () => {
	_s();
	const { user } = useAuth();
	const { data: dashboardData, isLoading, isError, refetch } = useDashboard();
	const { showBalances } = useOutletContext();
	const { accounts } = useAccounts();
	const { categories } = useCategories();
	const { createTransaction, isCreating } = useTransactions();
	// Quick Action Modal State
	const [activeModal, setActiveModal] = useState(null);
	// Currency Formatter
	const formatCurrency = (val) => {
		return new Intl.NumberFormat("id-ID", {
			style: "currency",
			currency: "IDR",
			minimumFractionDigits: 0
		}).format(val);
	};
	const formatAmount = (val) => {
		return showBalances ? formatCurrency(val) : "Rp ••••••";
	};
	if (isLoading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-screen bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-white flex flex-col justify-center items-center gap-4 transition-colors duration-200",
			children: [/* @__PURE__ */ _jsxDEV("div", { className: "h-10 w-10 animate-spin rounded-full border-4 border-emerald-500 border-t-transparent" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-zinc-500 dark:text-zinc-400 font-medium",
				children: "Loading family dashboard..."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 7
		}, this);
	}
	if (isError || !dashboardData) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-screen bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-white flex flex-col justify-center items-center gap-4 transition-colors duration-200",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-center max-w-md",
				children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-red-400 font-semibold mb-2",
						children: "Failed to Load Dashboard"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm text-zinc-500 dark:text-zinc-400 mb-4",
						children: "Could not fetch dashboard data. Please check if backend service is running."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => refetch(),
						className: "rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold hover:bg-red-500 transition-colors text-white",
						children: "Try Reconnecting"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 7
		}, this);
	}
	// Pie/Donut Chart calculations
	const totalBreakdown = dashboardData.total_balance + dashboardData.income_this_month + dashboardData.expense_this_month;
	const balancePercent = totalBreakdown > 0 ? dashboardData.total_balance / totalBreakdown * 100 : 0;
	const incomePercent = totalBreakdown > 0 ? dashboardData.income_this_month / totalBreakdown * 100 : 0;
	const expensePercent = totalBreakdown > 0 ? dashboardData.expense_this_month / totalBreakdown * 100 : 0;
	const r = 38;
	const circ = 2 * Math.PI * r;
	const balanceStrokeLength = balancePercent * circ / 100;
	const incomeStrokeLength = incomePercent * circ / 100;
	const expenseStrokeLength = expensePercent * circ / 100;
	const balanceOffset = 0;
	const incomeOffset = -balanceStrokeLength;
	const expenseOffset = -(balanceStrokeLength + incomeStrokeLength);
	// Helper to translate Transaction Type visually
	const formatTxType = (type) => {
		switch (type) {
			case "Income": return "Income";
			case "Expense": return "Expense";
			case "Transfer": return "Transfer";
			default: return type;
		}
	};
	const handleTransactionSubmit = async (data) => {
		try {
			await createTransaction(data);
			setActiveModal(null);
		} catch (error) {
			console.error("Failed to save transaction", error);
			alert(error.message || "An error occurred while saving the transaction.");
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800/80 rounded-2xl p-6 shadow-md relative overflow-hidden transition-colors duration-200",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { className: "absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-2xl sm:text-3xl font-extrabold tracking-tight text-zinc-900 dark:text-white",
							children: [
								"Hello, ",
								user?.first_name || "Sign Outga",
								" 👋"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-zinc-500 dark:text-zinc-400 text-sm sm:text-base",
							children: "Here is your financial summary for this month."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveModal("income"),
							className: "flex items-center gap-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 px-4 py-2.5 text-sm font-semibold text-white transition-all shadow-md shadow-emerald-950/20 active:scale-95 cursor-pointer",
							"data-testid": "hero-income-button",
							children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "h-4 w-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 138,
								columnNumber: 15
							}, this), " Income"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveModal("expense"),
							className: "flex items-center gap-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 px-4 py-2.5 text-sm font-semibold text-white transition-all shadow-md shadow-rose-950/20 active:scale-95 cursor-pointer",
							"data-testid": "hero-expense-button",
							children: [/* @__PURE__ */ _jsxDEV(Minus, { className: "h-4 w-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 145,
								columnNumber: 15
							}, this), " Expense"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 132,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 122,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-gradient-to-r from-emerald-500/10 to-teal-500/10 dark:from-emerald-500/5 dark:to-teal-500/5 border border-emerald-550/20 dark:border-emerald-500/10 rounded-2xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm relative overflow-hidden transition-colors duration-200",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3 relative z-10",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-emerald-500/10 p-2.5 rounded-xl text-emerald-600 dark:text-[#3cd395]",
						children: /* @__PURE__ */ _jsxDEV(Activity, { className: "h-5 w-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 154,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 153,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "font-bold text-zinc-900 dark:text-white text-sm sm:text-base",
						children: "Financial Health Indicator"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 157,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-zinc-500 dark:text-zinc-400 text-xs sm:text-sm",
						children: "Analyze your spending habits, debt-to-income ratio, and overall financial safety rating."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 158,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 156,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 152,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "shrink-0 bg-emerald-500/10 dark:bg-emerald-500/20 border border-emerald-500/30 text-emerald-700 dark:text-emerald-400 text-[10px] sm:text-xs font-bold px-3 py-1.5 rounded-full uppercase tracking-wider relative z-10",
					children: "Coming Soon"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 161,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 151,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800/80 rounded-2xl p-5 space-y-3 relative overflow-hidden shadow-sm transition-colors duration-200",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between text-zinc-500 dark:text-zinc-400",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold uppercase tracking-wider",
								children: "Total Balance"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 171,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-blue-500/10 p-2 rounded-lg text-blue-600 dark:text-blue-400",
								children: /* @__PURE__ */ _jsxDEV(Wallet, { className: "h-4 w-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 173,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 172,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 170,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "text-2xl font-bold tracking-tight text-zinc-900 dark:text-white",
								children: formatAmount(dashboardData.total_balance)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 177,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-zinc-450 dark:text-zinc-500",
								children: "Across all accounts"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 176,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 169,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800/80 rounded-2xl p-5 space-y-3 relative overflow-hidden shadow-sm transition-colors duration-200",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between text-zinc-500 dark:text-zinc-400",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold uppercase tracking-wider",
								children: "Income This Month"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-emerald-500/10 p-2 rounded-lg text-emerald-600 dark:text-emerald-400",
								children: /* @__PURE__ */ _jsxDEV(ArrowUpRight, { className: "h-4 w-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 189,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 188,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 186,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "text-2xl font-bold tracking-tight text-emerald-600 dark:text-emerald-400",
								children: formatAmount(dashboardData.income_this_month)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 193,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-zinc-450 dark:text-zinc-500",
								children: "Recorded since start of month"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 196,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 185,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800/80 rounded-2xl p-5 space-y-3 relative overflow-hidden shadow-sm transition-colors duration-200",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between text-zinc-500 dark:text-zinc-400",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold uppercase tracking-wider",
								children: "Expense This Month"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 203,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-rose-500/10 p-2 rounded-lg text-rose-600 dark:text-rose-400",
								children: /* @__PURE__ */ _jsxDEV(ArrowDownRight, { className: "h-4 w-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 205,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 204,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "text-2xl font-bold tracking-tight text-rose-650 dark:text-rose-400",
								children: formatAmount(dashboardData.expense_this_month)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 209,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-zinc-450 dark:text-zinc-500",
								children: "Recorded since start of month"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 212,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 201,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800/80 rounded-2xl p-5 space-y-3 relative overflow-hidden shadow-sm transition-colors duration-200",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between text-zinc-500 dark:text-zinc-400",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-semibold uppercase tracking-wider",
								children: "Net Balance"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 219,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-violet-500/10 p-2 rounded-lg text-violet-600 dark:text-violet-400",
								children: /* @__PURE__ */ _jsxDEV(TrendingUp, { className: "h-4 w-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 221,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 220,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 218,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ _jsxDEV("p", {
								className: `text-2xl font-bold tracking-tight ${dashboardData.net_balance >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400"}`,
								children: formatAmount(dashboardData.net_balance)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 225,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-zinc-450 dark:text-zinc-500",
								children: "Income minus expenses"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 228,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 224,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 217,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 167,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-2 space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800/80 rounded-2xl p-6 shadow-sm space-y-5 transition-colors duration-200",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-zinc-900 dark:text-white",
								children: [/* @__PURE__ */ _jsxDEV(PieChart, { className: "h-5 w-5 text-emerald-600 dark:text-emerald-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 240,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("h2", {
									className: "text-lg font-bold tracking-tight",
									children: "Financial Allocation Breakdown"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 241,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 239,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col sm:flex-row items-center justify-around gap-6 py-2",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "relative w-44 h-44 flex items-center justify-center",
									children: [/* @__PURE__ */ _jsxDEV("svg", {
										viewBox: "0 0 100 100",
										className: "w-full h-full transform -rotate-90",
										children: [
											/* @__PURE__ */ _jsxDEV("circle", {
												cx: "50",
												cy: "50",
												r,
												fill: "transparent",
												stroke: "#e4e4e7",
												className: "dark:stroke-zinc-800",
												strokeWidth: "10"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 247,
												columnNumber: 21
											}, this),
											balancePercent > 0 && /* @__PURE__ */ _jsxDEV("circle", {
												cx: "50",
												cy: "50",
												r,
												fill: "transparent",
												className: "stroke-blue-500",
												strokeWidth: "10",
												strokeDasharray: `${balanceStrokeLength} ${circ}`,
												strokeDashoffset: balanceOffset,
												strokeLinecap: "round"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 257,
												columnNumber: 23
											}, this),
											incomePercent > 0 && /* @__PURE__ */ _jsxDEV("circle", {
												cx: "50",
												cy: "50",
												r,
												fill: "transparent",
												className: "stroke-emerald-500",
												strokeWidth: "10",
												strokeDasharray: `${incomeStrokeLength} ${circ}`,
												strokeDashoffset: incomeOffset,
												strokeLinecap: "round"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 270,
												columnNumber: 23
											}, this),
											expensePercent > 0 && /* @__PURE__ */ _jsxDEV("circle", {
												cx: "50",
												cy: "50",
												r,
												fill: "transparent",
												className: "stroke-rose-500",
												strokeWidth: "10",
												strokeDasharray: `${expenseStrokeLength} ${circ}`,
												strokeDashoffset: expenseOffset,
												strokeLinecap: "round"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 283,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 246,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "absolute flex flex-col items-center justify-center text-center p-4",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-zinc-550 dark:text-zinc-500 font-bold uppercase tracking-widest",
											children: "Net Value"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 297,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-sm font-extrabold text-zinc-900 dark:text-white leading-tight mt-0.5",
											children: formatAmount(dashboardData.net_balance)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 298,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 296,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 245,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex-1 space-y-4 w-full sm:max-w-xs",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex justify-between items-center bg-zinc-50 dark:bg-zinc-950/40 p-2.5 rounded-xl border border-zinc-200/50 dark:border-zinc-800/60 transition-colors duration-200",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2.5",
												children: [/* @__PURE__ */ _jsxDEV("div", { className: "h-3 w-3 rounded-full bg-blue-500" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 308,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-semibold text-zinc-700 dark:text-zinc-300",
													children: "Total Balance"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 309,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 307,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "text-right",
												children: [/* @__PURE__ */ _jsxDEV("p", {
													className: "text-xs font-bold text-zinc-900 dark:text-white",
													children: formatAmount(dashboardData.total_balance)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 312,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-zinc-500",
													children: [balancePercent.toFixed(1), "%"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 313,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 311,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 306,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex justify-between items-center bg-zinc-50 dark:bg-zinc-950/40 p-2.5 rounded-xl border border-zinc-200/50 dark:border-zinc-800/60 transition-colors duration-200",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2.5",
												children: [/* @__PURE__ */ _jsxDEV("div", { className: "h-3 w-3 rounded-full bg-emerald-500" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 319,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-semibold text-zinc-700 dark:text-zinc-300",
													children: "Income"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 320,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 318,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "text-right",
												children: [/* @__PURE__ */ _jsxDEV("p", {
													className: "text-xs font-bold text-emerald-600 dark:text-emerald-400",
													children: formatAmount(dashboardData.income_this_month)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 323,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-zinc-500",
													children: [incomePercent.toFixed(1), "%"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 324,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 322,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 317,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex justify-between items-center bg-zinc-50 dark:bg-zinc-950/40 p-2.5 rounded-xl border border-zinc-200/50 dark:border-zinc-800/60 transition-colors duration-200",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2.5",
												children: [/* @__PURE__ */ _jsxDEV("div", { className: "h-3 w-3 rounded-full bg-rose-500" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 330,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-xs font-semibold text-zinc-700 dark:text-zinc-300",
													children: "Expense"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 331,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 329,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "text-right",
												children: [/* @__PURE__ */ _jsxDEV("p", {
													className: "text-xs font-bold text-rose-600 dark:text-rose-400",
													children: formatAmount(dashboardData.expense_this_month)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 334,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-zinc-550",
													children: [expensePercent.toFixed(1), "%"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 335,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 333,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 328,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 305,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 243,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 238,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800/80 rounded-2xl p-6 shadow-sm space-y-5 transition-colors duration-200",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 text-zinc-900 dark:text-white",
									children: [/* @__PURE__ */ _jsxDEV(PieChart, { className: "h-5 w-5 text-emerald-600 dark:text-emerald-500" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 346,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("h2", {
										className: "text-lg font-bold tracking-tight",
										children: "Budget Summary"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 347,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 345,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-zinc-550 dark:text-zinc-500 bg-zinc-100 dark:bg-zinc-800 px-2.5 py-1 rounded-full font-medium transition-colors duration-200",
									children: "This Month"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 349,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 344,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-4",
								children: dashboardData.budget_summary.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm text-zinc-550 dark:text-zinc-500 text-center py-4",
									children: "No monthly budget configured yet."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 354,
									columnNumber: 19
								}, this) : dashboardData.budget_summary.map((budget, idx) => {
									const percent = Math.min(budget.actual / budget.planned * 100, 100);
									const isOver = budget.remaining < 0;
									return /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-2",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between items-center text-sm",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "font-medium text-zinc-800 dark:text-zinc-200",
													children: budget.category_name
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 362,
													columnNumber: 27
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-zinc-500 dark:text-zinc-400",
													children: [
														formatAmount(budget.actual),
														" ",
														/* @__PURE__ */ _jsxDEV("span", {
															className: "text-zinc-400 dark:text-zinc-650",
															children: ["/ ", formatAmount(budget.planned)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 364,
															columnNumber: 59
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 363,
													columnNumber: 27
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 361,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "h-2 w-full bg-zinc-100 dark:bg-zinc-800 rounded-full overflow-hidden transition-colors duration-200",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: `h-full rounded-full transition-all duration-500 ${isOver ? "bg-rose-500" : "bg-emerald-500"}`,
													style: { width: `${percent}%` }
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 369,
													columnNumber: 27
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 368,
												columnNumber: 25
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between items-center text-xs",
												children: [isOver ? /* @__PURE__ */ _jsxDEV("span", {
													className: "text-rose-600 dark:text-rose-400 font-medium",
													children: ["Over budget by ", formatAmount(Math.abs(budget.remaining))]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 376,
													columnNumber: 29
												}, this) : /* @__PURE__ */ _jsxDEV("span", {
													className: "text-emerald-600 dark:text-emerald-400 font-medium",
													children: ["Remaining ", formatAmount(budget.remaining)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 378,
													columnNumber: 29
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-zinc-500",
													children: [percent.toFixed(0), "% used"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 380,
													columnNumber: 27
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 374,
												columnNumber: 25
											}, this)
										]
									}, idx, true, {
										fileName: _jsxFileName,
										lineNumber: 360,
										columnNumber: 23
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 352,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 343,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800/80 rounded-2xl p-6 shadow-sm space-y-4 transition-colors duration-200",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 text-zinc-900 dark:text-white",
									children: [/* @__PURE__ */ _jsxDEV(ArrowLeftRight, { className: "h-5 w-5 text-emerald-600 dark:text-emerald-500" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 393,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("h2", {
										className: "text-lg font-bold tracking-tight",
										children: "Recent Transactions"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 394,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 392,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 391,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "overflow-x-auto",
								children: /* @__PURE__ */ _jsxDEV("table", {
									className: "w-full text-left border-collapse",
									children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
										className: "border-b border-zinc-200 dark:border-zinc-800 text-xs text-zinc-500 uppercase font-semibold",
										children: [
											/* @__PURE__ */ _jsxDEV("th", {
												className: "py-3 px-1",
												children: "Description"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 402,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "py-3 px-1",
												children: "Type"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 403,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "py-3 px-1",
												children: "Date"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 404,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "py-3 px-1 text-right",
												children: "Amount"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 405,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 401,
										columnNumber: 21
									}, this) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 400,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("tbody", {
										className: "divide-y divide-zinc-200/50 dark:divide-zinc-800/50 text-sm",
										children: dashboardData.recent_transactions.length === 0 ? /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
											colSpan: 4,
											className: "py-6 text-center text-zinc-500",
											children: "No transactions found."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 411,
											columnNumber: 25
										}, this) }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 410,
											columnNumber: 23
										}, this) : dashboardData.recent_transactions.map((tx) => /* @__PURE__ */ _jsxDEV("tr", {
											className: "hover:bg-zinc-100/50 dark:hover:bg-zinc-800/30 transition-colors",
											children: [
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3.5 px-1",
													children: /* @__PURE__ */ _jsxDEV("p", {
														className: "font-semibold text-zinc-800 dark:text-zinc-200",
														children: tx.description
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 419,
														columnNumber: 29
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 418,
													columnNumber: 27
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3.5 px-1",
													children: /* @__PURE__ */ _jsxDEV("span", {
														className: `inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold ${tx.type === "Income" ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" : tx.type === "Expense" ? "bg-rose-500/10 text-rose-605 dark:text-rose-400" : "bg-blue-500/10 text-blue-600 dark:text-blue-400"}`,
														children: formatTxType(tx.type)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 422,
														columnNumber: 29
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 421,
													columnNumber: 27
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "py-3.5 px-1 text-zinc-500 dark:text-zinc-400 text-xs",
													children: new Date(tx.date).toLocaleDateString("id-ID", {
														year: "numeric",
														month: "short",
														day: "numeric"
													})
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 434,
													columnNumber: 27
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: `py-3.5 px-1 text-right font-semibold ${tx.type === "Income" ? "text-emerald-600 dark:text-emerald-400" : tx.type === "Expense" ? "text-rose-600 dark:text-rose-400" : "text-blue-600 dark:text-blue-400"}`,
													children: [tx.type === "Expense" ? "-" : tx.type === "Income" ? "+" : "", formatAmount(tx.amount)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 441,
													columnNumber: 27
												}, this)
											]
										}, tx.id, true, {
											fileName: _jsxFileName,
											lineNumber: 417,
											columnNumber: 25
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 408,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 399,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 398,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 390,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 236,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-6",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800/80 rounded-2xl p-6 shadow-sm space-y-4 transition-colors duration-200",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-zinc-900 dark:text-white",
								children: [/* @__PURE__ */ _jsxDEV(Target, { className: "h-5 w-5 text-emerald-600 dark:text-emerald-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 466,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("h2", {
									className: "text-lg font-bold tracking-tight",
									children: "Saving Goals"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 467,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 465,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "bg-emerald-500/10 dark:bg-emerald-500/20 border border-emerald-500/30 text-emerald-750 dark:text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider",
								children: "Soon"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 469,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 464,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col items-center justify-center text-center p-5 border border-dashed border-zinc-200 dark:border-zinc-800 rounded-xl bg-zinc-50/50 dark:bg-zinc-950/20",
							children: [
								/* @__PURE__ */ _jsxDEV(Activity, { className: "h-7 w-7 text-zinc-400 mb-2 animate-pulse" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 475,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm font-bold text-zinc-700 dark:text-zinc-300",
									children: "Feature Coming Soon"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 476,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-zinc-500 dark:text-zinc-400 mt-1 max-w-[200px]",
									children: "We are fine-tuning saving goal allocations."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 477,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 474,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 463,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800/80 rounded-2xl p-6 shadow-sm space-y-4 transition-colors duration-200",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-zinc-900 dark:text-white",
							children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "h-5 w-5 text-emerald-600 dark:text-emerald-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 484,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("h2", {
								className: "text-lg font-bold tracking-tight",
								children: "Quick Actions"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 485,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 483,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 gap-2.5",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setActiveModal("income"),
									className: "flex items-center gap-3 w-full rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-950 dark:hover:bg-zinc-800 p-3.5 text-sm font-medium transition-all text-left text-zinc-700 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700/80 active:scale-[0.99] cursor-pointer",
									"data-testid": "quick-action-income",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-emerald-500/10 p-2 rounded-lg text-emerald-600 dark:text-emerald-500",
										children: /* @__PURE__ */ _jsxDEV(Plus, { className: "h-4 w-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 495,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 494,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "font-semibold text-zinc-900 dark:text-white",
										children: "Income"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 498,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-zinc-500",
										children: "Add cash income or salary"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 499,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 497,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 489,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setActiveModal("expense"),
									className: "flex items-center gap-3 w-full rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-950 dark:hover:bg-zinc-800 p-3.5 text-sm font-medium transition-all text-left text-zinc-700 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700/80 active:scale-[0.99] cursor-pointer",
									"data-testid": "quick-action-expense",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-rose-500/10 p-2 rounded-lg text-rose-600 dark:text-rose-500",
										children: /* @__PURE__ */ _jsxDEV(Minus, { className: "h-4 w-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 509,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 508,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "font-semibold text-zinc-900 dark:text-white",
										children: "Expense"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 512,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-zinc-500",
										children: "Add expenses or payments"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 513,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 511,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 503,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setActiveModal("transfer"),
									className: "flex items-center gap-3 w-full rounded-xl bg-zinc-50 hover:bg-zinc-100 dark:bg-zinc-950 dark:hover:bg-zinc-800 p-3.5 text-sm font-medium transition-all text-left text-zinc-700 dark:text-zinc-200 border border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700/80 active:scale-[0.99] cursor-pointer",
									"data-testid": "quick-action-transfer",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-blue-500/10 p-2 rounded-lg text-blue-600 dark:text-blue-500",
										children: /* @__PURE__ */ _jsxDEV(ArrowLeftRight, { className: "h-4 w-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 523,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 522,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "font-semibold text-zinc-900 dark:text-white",
										children: "Transfer Money"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 526,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-zinc-500",
										children: "Move funds between accounts"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 527,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 525,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 517,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 488,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 482,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 461,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 234,
				columnNumber: 9
			}, this),
			activeModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/80 backdrop-blur-sm flex items-start justify-center p-4 z-50 animate-fade-in overflow-y-auto",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 w-full max-w-md rounded-2xl overflow-hidden shadow-2xl animate-scale-up transition-colors duration-200 my-8",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-between items-center px-6 py-4 border-b border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-900/50 transition-colors duration-200",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-bold text-zinc-900 dark:text-white capitalize flex items-center gap-2",
							children: [
								activeModal === "income" && /* @__PURE__ */ _jsxDEV(Plus, { className: "h-4 w-4 text-emerald-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 541,
									columnNumber: 46
								}, this),
								activeModal === "expense" && /* @__PURE__ */ _jsxDEV(Minus, { className: "h-4 w-4 text-rose-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 542,
									columnNumber: 47
								}, this),
								activeModal === "transfer" && /* @__PURE__ */ _jsxDEV(ArrowLeftRight, { className: "h-4 w-4 text-blue-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 543,
									columnNumber: 48
								}, this),
								"Log ",
								activeModal === "income" ? "Income" : activeModal === "expense" ? "Expense" : "Transfer"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 540,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveModal(null),
							className: "text-zinc-500 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-white transition-colors cursor-pointer",
							"data-testid": "modal-close-icon",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "h-5 w-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 551,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 546,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 539,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "p-6",
						children: /* @__PURE__ */ _jsxDEV(TransactionForm, {
							accounts,
							categories,
							onSubmit: handleTransactionSubmit,
							isSubmitting: isCreating,
							defaultType: activeModal === "income" ? "Income" : activeModal === "expense" ? "Expense" : "Transfer"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 555,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 554,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 538,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 537,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 120,
		columnNumber: 5
	}, this);
};
_s(DashboardPage, "Fj3G9DeH7CMgpiYc10qh1O0PYe8=", false, function() {
	return [
		useAuth,
		useDashboard,
		useOutletContext,
		useAccounts,
		useCategories,
		useTransactions
	];
});
_c = DashboardPage;
var _c;
$RefreshReg$(_c, "DashboardPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/DashboardPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/DashboardPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/DashboardPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/DashboardPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGVBQWU7QUFDeEIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyx1QkFBdUI7QUFFaEMsU0FDRSxRQUNBLGNBQ0EsZ0JBQ0EsZ0JBQ0EsWUFDQSxRQUNBLEdBQ0EsTUFDQSxPQUNBLFVBQ0EsVUFDQSxnQkFDSzs7OztBQUVQLE9BQU8sTUFBTSxzQkFBZ0M7O0NBQzNDLE1BQU0sRUFBRSxTQUFTLFFBQVE7Q0FDekIsTUFBTSxFQUFFLE1BQU0sZUFBZSxXQUFXLFNBQVMsWUFBWSxhQUFhO0NBQzFFLE1BQU0sRUFBRSxpQkFBaUIsaUJBQTRDO0NBRXJFLE1BQU0sRUFBRSxhQUFhLFlBQVk7Q0FDakMsTUFBTSxFQUFFLGVBQWUsY0FBYztDQUNyQyxNQUFNLEVBQUUsbUJBQW1CLGVBQWUsZ0JBQWdCOztDQUcxRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBbUQsSUFBSTs7Q0FHN0YsTUFBTSxrQkFBa0IsUUFBZ0I7RUFDdEMsT0FBTyxJQUFJLEtBQUssYUFBYSxTQUFTO0dBQ3BDLE9BQU87R0FDUCxVQUFVO0dBQ1YsdUJBQXVCO0VBQ3pCLENBQUMsQ0FBQyxDQUFDLE9BQU8sR0FBRztDQUNmO0NBRUEsTUFBTSxnQkFBZ0IsUUFBZ0I7RUFDcEMsT0FBTyxlQUFlLGVBQWUsR0FBRyxJQUFJO0NBQzlDO0NBRUEsSUFBSSxXQUFXO0VBQ2IsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsdUZBQTRGOzs7O2FBQzNHLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQStDO0dBQThCOzs7O1dBQ3ZGOzs7Ozs7Q0FFVDtDQUVBLElBQUksV0FBVyxDQUFDLGVBQWU7RUFDN0IsT0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNiLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBa0M7S0FBMkI7Ozs7O0tBQzFFLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFnRDtLQUUxRDs7Ozs7S0FDSCx3QkFBQyxVQUFEO01BQ0UsZUFBZSxRQUFRO01BQ3ZCLFdBQVU7Z0JBQ1g7S0FFTzs7Ozs7SUFDTDs7Ozs7O0VBQ0Y7Ozs7O0NBRVQ7O0NBR0EsTUFBTSxpQkFBaUIsY0FBYyxnQkFBZ0IsY0FBYyxvQkFBb0IsY0FBYztDQUNyRyxNQUFNLGlCQUFpQixpQkFBaUIsSUFBSyxjQUFjLGdCQUFnQixpQkFBa0IsTUFBTTtDQUNuRyxNQUFNLGdCQUFnQixpQkFBaUIsSUFBSyxjQUFjLG9CQUFvQixpQkFBa0IsTUFBTTtDQUN0RyxNQUFNLGlCQUFpQixpQkFBaUIsSUFBSyxjQUFjLHFCQUFxQixpQkFBa0IsTUFBTTtDQUV4RyxNQUFNLElBQUk7Q0FDVixNQUFNLE9BQU8sSUFBSSxLQUFLLEtBQUs7Q0FFM0IsTUFBTSxzQkFBdUIsaUJBQWlCLE9BQVE7Q0FDdEQsTUFBTSxxQkFBc0IsZ0JBQWdCLE9BQVE7Q0FDcEQsTUFBTSxzQkFBdUIsaUJBQWlCLE9BQVE7Q0FFdEQsTUFBTSxnQkFBZ0I7Q0FDdEIsTUFBTSxlQUFlLENBQUM7Q0FDdEIsTUFBTSxnQkFBZ0IsRUFBRSxzQkFBc0I7O0NBRzlDLE1BQU0sZ0JBQWdCLFNBQWlCO0VBQ3JDLFFBQVEsTUFBUjtHQUNFLEtBQUssVUFDSCxPQUFPO0dBQ1QsS0FBSyxXQUNILE9BQU87R0FDVCxLQUFLLFlBQ0gsT0FBTztHQUNULFNBQ0UsT0FBTztFQUNYO0NBQ0Y7Q0FFQSxNQUFNLDBCQUEwQixPQUFPLFNBQTJCO0VBQ2hFLElBQUk7R0FDRixNQUFNLGtCQUFrQixJQUFJO0dBQzVCLGVBQWUsSUFBSTtFQUNyQixTQUFTLE9BQVk7R0FDbkIsUUFBUSxNQUFNLDhCQUE4QixLQUFLO0dBQ2pELE1BQU0sTUFBTSxXQUFXLGlEQUFpRDtFQUMxRTtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUksd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDhGQUFtRzs7Ozs7S0FDbEgsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUFpRztRQUN2RixNQUFNLGNBQWM7UUFBYTtPQUN2Qzs7Ozs7Z0JBQ0osd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXdEO01BRWxFOzs7O2NBQ0E7Ozs7OztLQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUNFLGVBQWUsZUFBZSxRQUFRO09BQ3RDLFdBQVU7T0FDVixlQUFZO2lCQUhkLENBS0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7OztpQkFBQyxTQUN0Qjs7Ozs7Z0JBQ1Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsZUFBZSxTQUFTO09BQ3ZDLFdBQVU7T0FDVixlQUFZO2lCQUhkLENBS0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsVUFBVzs7OztpQkFBQyxVQUN2Qjs7Ozs7Y0FDTDs7Ozs7O0lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7Ozs7S0FDNUI7Ozs7ZUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQStEO0tBQThCOzs7O2VBQzNHLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFzRDtLQUEyRjs7OzthQUMzSjs7OzthQUNGOzs7OztjQUNMLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQXlOO0lBRW5POzs7O1lBQ0g7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FFRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWlEO09BQW1COzs7O2lCQUNwRix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztPQUMxQjs7OztlQUNGOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNWLGFBQWEsY0FBYyxhQUFhO09BQ3hDOzs7O2lCQUNILHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUEyQztPQUFzQjs7OztlQUMzRTs7Ozs7Y0FDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFpRDtPQUF1Qjs7OztpQkFDeEYsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsY0FBRCxFQUFjLFdBQVUsVUFBVzs7Ozs7T0FDaEM7Ozs7ZUFDRjs7Ozs7Z0JBQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFDVixhQUFhLGNBQWMsaUJBQWlCO09BQzVDOzs7O2lCQUNILHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUEyQztPQUFnQzs7OztlQUNyRjs7Ozs7Y0FDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFpRDtPQUF3Qjs7OztpQkFDekYsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsZ0JBQUQsRUFBZ0IsV0FBVSxVQUFXOzs7OztPQUNsQzs7OztlQUNGOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNWLGFBQWEsY0FBYyxrQkFBa0I7T0FDN0M7Ozs7aUJBQ0gsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQTJDO09BQWdDOzs7O2VBQ3JGOzs7OztjQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWlEO09BQWlCOzs7O2lCQUNsRix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxZQUFELEVBQVksV0FBVSxVQUFXOzs7OztPQUM5Qjs7OztlQUNGOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLEtBQUQ7UUFBRyxXQUFXLHFDQUFxQyxjQUFjLGVBQWUsSUFBSSwyQ0FBMkM7a0JBQzVILGFBQWEsY0FBYyxXQUFXO09BQ3RDOzs7O2lCQUNILHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUEyQztPQUF3Qjs7OztlQUM3RTs7Ozs7Y0FDRjs7Ozs7O0lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGlEQUFrRDs7OztrQkFDdEUsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQW1DO1FBQWtDOzs7O2dCQUNoRjs7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FFRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxTQUFRO1VBQWMsV0FBVTtvQkFBckM7V0FDRSx3QkFBQyxVQUFEO1lBQ0UsSUFBRztZQUNILElBQUc7WUFDQTtZQUNILE1BQUs7WUFDTCxRQUFPO1lBQ1AsV0FBVTtZQUNWLGFBQVk7V0FDYjs7Ozs7V0FDQSxpQkFBaUIsS0FDaEIsd0JBQUMsVUFBRDtZQUNFLElBQUc7WUFDSCxJQUFHO1lBQ0E7WUFDSCxNQUFLO1lBQ0wsV0FBVTtZQUNWLGFBQVk7WUFDWixpQkFBaUIsR0FBRyxvQkFBb0IsR0FBRztZQUMzQyxrQkFBa0I7WUFDbEIsZUFBYztXQUNmOzs7OztXQUVGLGdCQUFnQixLQUNmLHdCQUFDLFVBQUQ7WUFDRSxJQUFHO1lBQ0gsSUFBRztZQUNBO1lBQ0gsTUFBSztZQUNMLFdBQVU7WUFDVixhQUFZO1lBQ1osaUJBQWlCLEdBQUcsbUJBQW1CLEdBQUc7WUFDMUMsa0JBQWtCO1lBQ2xCLGVBQWM7V0FDZjs7Ozs7V0FFRixpQkFBaUIsS0FDaEIsd0JBQUMsVUFBRDtZQUNFLElBQUc7WUFDSCxJQUFHO1lBQ0E7WUFDSCxNQUFLO1lBQ0wsV0FBVTtZQUNWLGFBQVk7WUFDWixpQkFBaUIsR0FBRyxvQkFBb0IsR0FBRztZQUMzQyxrQkFBa0I7WUFDbEIsZUFBYztXQUNmOzs7OztVQUVBOzs7OzttQkFDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFtRjtVQUFlOzs7O29CQUNsSCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFDYixhQUFhLGNBQWMsV0FBVztVQUNuQzs7OztrQkFDSDs7Ozs7aUJBQ0Y7Ozs7O2tCQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLG1DQUF3Qzs7OztzQkFDdkQsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQXlEO1lBQW1COzs7O29CQUN6Rjs7Ozs7cUJBQ0wsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBbUQsYUFBYSxjQUFjLGFBQWE7WUFBSzs7OztzQkFDN0csd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQWIsQ0FBMEMsZUFBZSxRQUFRLENBQUMsR0FBRSxHQUFJOzs7OztvQkFDckU7Ozs7O21CQUNGOzs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsc0NBQTJDOzs7O3NCQUMxRCx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBeUQ7WUFBWTs7OztvQkFDbEY7Ozs7O3FCQUNMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQTRELGFBQWEsY0FBYyxpQkFBaUI7WUFBSzs7OztzQkFDMUgsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQWIsQ0FBMEMsY0FBYyxRQUFRLENBQUMsR0FBRSxHQUFJOzs7OztvQkFDcEU7Ozs7O21CQUNGOzs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsbUNBQXdDOzs7O3NCQUN2RCx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBeUQ7WUFBYTs7OztvQkFDbkY7Ozs7O3FCQUNMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQXNELGFBQWEsY0FBYyxrQkFBa0I7WUFBSzs7OztzQkFDckgsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQWIsQ0FBMEMsZUFBZSxRQUFRLENBQUMsR0FBRSxHQUFJOzs7OztvQkFDckU7Ozs7O21CQUNGOzs7Ozs7U0FDRjs7Ozs7Z0JBQ0Y7Ozs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGlEQUFrRDs7OzttQkFDdEUsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQW1DO1NBQWtCOzs7O2lCQUNoRTs7Ozs7a0JBQ0wsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQTRJO1FBQWdCOzs7O2dCQUN6Szs7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osY0FBYyxlQUFlLFdBQVcsSUFDdkMsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQTREO1FBQW9DOzs7O21CQUU3RyxjQUFjLGVBQWUsS0FBSyxRQUFRLFFBQVE7U0FDaEQsTUFBTSxVQUFVLEtBQUssSUFBSyxPQUFPLFNBQVMsT0FBTyxVQUFXLEtBQUssR0FBRztTQUNwRSxNQUFNLFNBQVMsT0FBTyxZQUFZO1NBQ2xDLE9BQ0Usd0JBQUMsT0FBRDtVQUFlLFdBQVU7b0JBQXpCO1dBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBZ0QsT0FBTztZQUFvQjs7OztzQkFDM0Ysd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCO2NBQ0csYUFBYSxPQUFPLE1BQU07Y0FBRTtjQUFDLHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUFoQixDQUFtRCxNQUFHLGFBQWEsT0FBTyxPQUFPLENBQVE7Ozs7OzthQUNuSDs7Ozs7b0JBQ0g7Ozs7OztXQUVMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNiLHdCQUFDLE9BQUQ7YUFDRSxXQUFXLG1EQUFtRCxTQUFTLGdCQUFnQjthQUN2RixPQUFPLEVBQUUsT0FBTyxHQUFHLFFBQVEsR0FBRztZQUMxQjs7Ozs7V0FDSDs7Ozs7V0FDTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNHLFNBQ0Msd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCLENBQStELG1CQUFnQixhQUFhLEtBQUssSUFBSSxPQUFPLFNBQVMsQ0FBQyxDQUFROzs7Ozt1QkFFOUgsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCLENBQXFFLGNBQVcsYUFBYSxPQUFPLFNBQVMsQ0FBUTs7Ozs7c0JBRXZILHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQixDQUFpQyxRQUFRLFFBQVEsQ0FBQyxHQUFFLFFBQVk7Ozs7O29CQUM3RDs7Ozs7O1VBQ0Y7WUF0Qks7Ozs7Z0JBc0JMO1FBRVQsQ0FBQztPQUVBOzs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxnQkFBRCxFQUFnQixXQUFVLGlEQUFrRDs7OzttQkFDNUUsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQW1DO1NBQXVCOzs7O2lCQUNyRTs7Ozs7O09BQ0Y7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQWpCLENBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkO1dBQ0Usd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQVk7V0FBZTs7Ozs7V0FDekMsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQVk7V0FBUTs7Ozs7V0FDbEMsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQVk7V0FBUTs7Ozs7V0FDbEMsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQXVCO1dBQVU7Ozs7O1VBQzdDOzs7OztrQkFDQzs7OzttQkFDUCx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFDZCxjQUFjLG9CQUFvQixXQUFXLElBQzVDLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO1dBQUksU0FBUztXQUFHLFdBQVU7cUJBQWlDO1VBRXZEOzs7O21CQUNGOzs7O3FCQUVKLGNBQWMsb0JBQW9CLEtBQUssT0FDckMsd0JBQUMsTUFBRDtXQUFnQixXQUFVO3FCQUExQjtZQUNFLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNaLHdCQUFDLEtBQUQ7Y0FBRyxXQUFVO3dCQUFrRCxHQUFHO2FBQWU7Ozs7O1lBQy9FOzs7OztZQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNaLHdCQUFDLFFBQUQ7Y0FDRSxXQUFXLHNFQUNULEdBQUcsU0FBUyxXQUNSLDZEQUNBLEdBQUcsU0FBUyxZQUNaLG9EQUNBO3dCQUdMLGFBQWEsR0FBRyxJQUFJO2FBQ2pCOzs7OztZQUNKOzs7OztZQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNYLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxDQUFDLG1CQUFtQixTQUFTO2NBQzdDLE1BQU07Y0FDTixPQUFPO2NBQ1AsS0FBSzthQUNQLENBQUM7WUFDQzs7Ozs7WUFDSix3QkFBQyxNQUFEO2FBQUksV0FBVyx3Q0FDYixHQUFHLFNBQVMsV0FDUiwyQ0FDQSxHQUFHLFNBQVMsWUFDWixxQ0FDQTt1QkFMTixDQU9HLEdBQUcsU0FBUyxZQUFZLE1BQU0sR0FBRyxTQUFTLFdBQVcsTUFBTSxJQUMzRCxhQUFhLEdBQUcsTUFBTSxDQUNyQjs7Ozs7O1dBQ0Y7YUFsQ0ssR0FBRzs7OztpQkFrQ1IsQ0FDTDtTQUVFOzs7O2lCQUNGOzs7Ozs7T0FDSjs7OztlQUNGOzs7Ozs7S0FDRjs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsaURBQWtEOzs7O2tCQUNwRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBbUM7UUFBZ0I7Ozs7Z0JBQzlEOzs7OztpQkFDTCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBdUw7T0FFak07Ozs7ZUFDSDs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSwyQ0FBNEM7Ozs7O1FBQ2hFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFxRDtRQUFzQjs7Ozs7UUFDeEYsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWtFO1FBQThDOzs7OztPQUMxSDs7Ozs7Y0FDRjs7Ozs7ZUFHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsaURBQWtEOzs7O2lCQUN0RSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBbUM7T0FBaUI7Ozs7ZUFDL0Q7Ozs7O2dCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsVUFBRDtTQUNFLGVBQWUsZUFBZSxRQUFRO1NBQ3RDLFdBQVU7U0FDVixlQUFZO21CQUhkLENBS0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ2Isd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7Ozs7U0FDeEI7Ozs7bUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUE4QztTQUFTOzs7O21CQUNwRSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBd0I7U0FBNEI7Ozs7aUJBQzlEOzs7O2lCQUNDOzs7Ozs7UUFFUix3QkFBQyxVQUFEO1NBQ0UsZUFBZSxlQUFlLFNBQVM7U0FDdkMsV0FBVTtTQUNWLGVBQVk7bUJBSGQsQ0FLRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7OztTQUN6Qjs7OzttQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQThDO1NBQVU7Ozs7bUJBQ3JFLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUF3QjtTQUEyQjs7OztpQkFDN0Q7Ozs7aUJBQ0M7Ozs7OztRQUVSLHdCQUFDLFVBQUQ7U0FDRSxlQUFlLGVBQWUsVUFBVTtTQUN4QyxXQUFVO1NBQ1YsZUFBWTttQkFIZCxDQUtFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLGdCQUFELEVBQWdCLFdBQVUsVUFBVzs7Ozs7U0FDbEM7Ozs7bUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUE4QztTQUFpQjs7OzttQkFDNUUsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQXdCO1NBQThCOzs7O2lCQUNoRTs7OztpQkFDQzs7Ozs7O09BQ0w7Ozs7O2NBQ0Y7Ozs7O2FBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUdOLGVBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZDtRQUNHLGdCQUFnQixZQUFZLHdCQUFDLE1BQUQsRUFBTSxXQUFVLDJCQUE0Qjs7Ozs7UUFDeEUsZ0JBQWdCLGFBQWEsd0JBQUMsT0FBRCxFQUFPLFdBQVUsd0JBQXlCOzs7OztRQUN2RSxnQkFBZ0IsY0FBYyx3QkFBQyxnQkFBRCxFQUFnQixXQUFVLHdCQUF5Qjs7Ozs7UUFBRTtRQUMvRSxnQkFBZ0IsV0FBVyxXQUFXLGdCQUFnQixZQUFZLFlBQVk7T0FDakY7Ozs7O2dCQUNKLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGVBQWUsSUFBSTtPQUNsQyxXQUFVO09BQ1YsZUFBWTtpQkFFWix3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztNQUNsQjs7OztjQUNMOzs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLGlCQUFEO09BQ1k7T0FDRTtPQUNaLFVBQVU7T0FDVixjQUFjO09BQ2QsYUFBYSxnQkFBZ0IsV0FBVyxXQUFXLGdCQUFnQixZQUFZLFlBQVk7TUFDNUY7Ozs7O0tBQ0U7Ozs7YUFDRjs7Ozs7O0dBQ0Y7Ozs7O0VBRUo7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkRhc2hib2FyZFBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuLi9ob29rcy91c2VBdXRoXCI7XG5pbXBvcnQgeyB1c2VEYXNoYm9hcmQgfSBmcm9tIFwiLi4vaG9va3MvdXNlRGFzaGJvYXJkXCI7XG5pbXBvcnQgeyB1c2VPdXRsZXRDb250ZXh0IH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcbmltcG9ydCB7IHVzZUFjY291bnRzIH0gZnJvbSBcIi4uL2hvb2tzL3VzZUFjY291bnRzXCI7XG5pbXBvcnQgeyB1c2VDYXRlZ29yaWVzIH0gZnJvbSBcIi4uL2hvb2tzL3VzZUNhdGVnb3JpZXNcIjtcbmltcG9ydCB7IHVzZVRyYW5zYWN0aW9ucyB9IGZyb20gXCIuLi9ob29rcy91c2VUcmFuc2FjdGlvbnNcIjtcbmltcG9ydCB7IFRyYW5zYWN0aW9uRm9ybSB9IGZyb20gXCIuLi9mZWF0dXJlcy90cmFuc2FjdGlvbnMvVHJhbnNhY3Rpb25Gb3JtXCI7XG5pbXBvcnQgdHlwZSB7IFRyYW5zYWN0aW9uSW5wdXQgfSBmcm9tIFwiLi4vdHlwZXMvdHJhbnNhY3Rpb25zXCI7XG5pbXBvcnQge1xuICBXYWxsZXQsXG4gIEFycm93VXBSaWdodCxcbiAgQXJyb3dEb3duUmlnaHQsXG4gIEFycm93TGVmdFJpZ2h0LFxuICBUcmVuZGluZ1VwLFxuICBUYXJnZXQsXG4gIFgsXG4gIFBsdXMsXG4gIE1pbnVzLFxuICBTcGFya2xlcyxcbiAgUGllQ2hhcnQsXG4gIEFjdGl2aXR5XG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcblxuZXhwb3J0IGNvbnN0IERhc2hib2FyZFBhZ2U6IFJlYWN0LkZDID0gKCkgPT4ge1xuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgeyBkYXRhOiBkYXNoYm9hcmREYXRhLCBpc0xvYWRpbmcsIGlzRXJyb3IsIHJlZmV0Y2ggfSA9IHVzZURhc2hib2FyZCgpO1xuICBjb25zdCB7IHNob3dCYWxhbmNlcyB9ID0gdXNlT3V0bGV0Q29udGV4dDx7IHNob3dCYWxhbmNlczogYm9vbGVhbiB9PigpO1xuXG4gIGNvbnN0IHsgYWNjb3VudHMgfSA9IHVzZUFjY291bnRzKCk7XG4gIGNvbnN0IHsgY2F0ZWdvcmllcyB9ID0gdXNlQ2F0ZWdvcmllcygpO1xuICBjb25zdCB7IGNyZWF0ZVRyYW5zYWN0aW9uLCBpc0NyZWF0aW5nIH0gPSB1c2VUcmFuc2FjdGlvbnMoKTtcblxuICAvLyBRdWljayBBY3Rpb24gTW9kYWwgU3RhdGVcbiAgY29uc3QgW2FjdGl2ZU1vZGFsLCBzZXRBY3RpdmVNb2RhbF0gPSB1c2VTdGF0ZTxcImluY29tZVwiIHwgXCJleHBlbnNlXCIgfCBcInRyYW5zZmVyXCIgfCBudWxsPihudWxsKTtcblxuICAvLyBDdXJyZW5jeSBGb3JtYXR0ZXJcbiAgY29uc3QgZm9ybWF0Q3VycmVuY3kgPSAodmFsOiBudW1iZXIpID0+IHtcbiAgICByZXR1cm4gbmV3IEludGwuTnVtYmVyRm9ybWF0KFwiaWQtSURcIiwge1xuICAgICAgc3R5bGU6IFwiY3VycmVuY3lcIixcbiAgICAgIGN1cnJlbmN5OiBcIklEUlwiLFxuICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAwXG4gICAgfSkuZm9ybWF0KHZhbCk7XG4gIH07XG5cbiAgY29uc3QgZm9ybWF0QW1vdW50ID0gKHZhbDogbnVtYmVyKSA9PiB7XG4gICAgcmV0dXJuIHNob3dCYWxhbmNlcyA/IGZvcm1hdEN1cnJlbmN5KHZhbCkgOiBcIlJwIOKAouKAouKAouKAouKAouKAolwiO1xuICB9O1xuXG4gIGlmIChpc0xvYWRpbmcpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctemluYy01MCBkYXJrOmJnLXppbmMtOTUwIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIGZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGdhcC00IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMTAgdy0xMCBhbmltYXRlLXNwaW4gcm91bmRlZC1mdWxsIGJvcmRlci00IGJvcmRlci1lbWVyYWxkLTUwMCBib3JkZXItdC10cmFuc3BhcmVudFwiPjwvZGl2PlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMCBmb250LW1lZGl1bVwiPkxvYWRpbmcgZmFtaWx5IGRhc2hib2FyZC4uLjwvcD5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICBpZiAoaXNFcnJvciB8fCAhZGFzaGJvYXJkRGF0YSkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy16aW5jLTUwIGRhcms6YmctemluYy05NTAgdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgZ2FwLTQgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXJlZC01MDAvMzAgYmctcmVkLTUwMC8xMCBwLTQgdGV4dC1jZW50ZXIgbWF4LXctbWRcIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC00MDAgZm9udC1zZW1pYm9sZCBtYi0yXCI+RmFpbGVkIHRvIExvYWQgRGFzaGJvYXJkPC9wPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00MDAgbWItNFwiPlxuICAgICAgICAgICAgQ291bGQgbm90IGZldGNoIGRhc2hib2FyZCBkYXRhLiBQbGVhc2UgY2hlY2sgaWYgYmFja2VuZCBzZXJ2aWNlIGlzIHJ1bm5pbmcuXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlZmV0Y2goKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYmctcmVkLTYwMCBweC00IHB5LTIgdGV4dC1zbSBmb250LXNlbWlib2xkIGhvdmVyOmJnLXJlZC01MDAgdHJhbnNpdGlvbi1jb2xvcnMgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgVHJ5IFJlY29ubmVjdGluZ1xuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICAvLyBQaWUvRG9udXQgQ2hhcnQgY2FsY3VsYXRpb25zXG4gIGNvbnN0IHRvdGFsQnJlYWtkb3duID0gZGFzaGJvYXJkRGF0YS50b3RhbF9iYWxhbmNlICsgZGFzaGJvYXJkRGF0YS5pbmNvbWVfdGhpc19tb250aCArIGRhc2hib2FyZERhdGEuZXhwZW5zZV90aGlzX21vbnRoO1xuICBjb25zdCBiYWxhbmNlUGVyY2VudCA9IHRvdGFsQnJlYWtkb3duID4gMCA/IChkYXNoYm9hcmREYXRhLnRvdGFsX2JhbGFuY2UgLyB0b3RhbEJyZWFrZG93bikgKiAxMDAgOiAwO1xuICBjb25zdCBpbmNvbWVQZXJjZW50ID0gdG90YWxCcmVha2Rvd24gPiAwID8gKGRhc2hib2FyZERhdGEuaW5jb21lX3RoaXNfbW9udGggLyB0b3RhbEJyZWFrZG93bikgKiAxMDAgOiAwO1xuICBjb25zdCBleHBlbnNlUGVyY2VudCA9IHRvdGFsQnJlYWtkb3duID4gMCA/IChkYXNoYm9hcmREYXRhLmV4cGVuc2VfdGhpc19tb250aCAvIHRvdGFsQnJlYWtkb3duKSAqIDEwMCA6IDA7XG5cbiAgY29uc3QgciA9IDM4O1xuICBjb25zdCBjaXJjID0gMiAqIE1hdGguUEkgKiByOyAvLyB+MjM4Ljc2XG5cbiAgY29uc3QgYmFsYW5jZVN0cm9rZUxlbmd0aCA9IChiYWxhbmNlUGVyY2VudCAqIGNpcmMpIC8gMTAwO1xuICBjb25zdCBpbmNvbWVTdHJva2VMZW5ndGggPSAoaW5jb21lUGVyY2VudCAqIGNpcmMpIC8gMTAwO1xuICBjb25zdCBleHBlbnNlU3Ryb2tlTGVuZ3RoID0gKGV4cGVuc2VQZXJjZW50ICogY2lyYykgLyAxMDA7XG5cbiAgY29uc3QgYmFsYW5jZU9mZnNldCA9IDA7XG4gIGNvbnN0IGluY29tZU9mZnNldCA9IC1iYWxhbmNlU3Ryb2tlTGVuZ3RoO1xuICBjb25zdCBleHBlbnNlT2Zmc2V0ID0gLShiYWxhbmNlU3Ryb2tlTGVuZ3RoICsgaW5jb21lU3Ryb2tlTGVuZ3RoKTtcblxuICAvLyBIZWxwZXIgdG8gdHJhbnNsYXRlIFRyYW5zYWN0aW9uIFR5cGUgdmlzdWFsbHlcbiAgY29uc3QgZm9ybWF0VHhUeXBlID0gKHR5cGU6IHN0cmluZykgPT4ge1xuICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgY2FzZSBcIkluY29tZVwiOlxuICAgICAgICByZXR1cm4gXCJJbmNvbWVcIjtcbiAgICAgIGNhc2UgXCJFeHBlbnNlXCI6XG4gICAgICAgIHJldHVybiBcIkV4cGVuc2VcIjtcbiAgICAgIGNhc2UgXCJUcmFuc2ZlclwiOlxuICAgICAgICByZXR1cm4gXCJUcmFuc2ZlclwiO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIHR5cGU7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVRyYW5zYWN0aW9uU3VibWl0ID0gYXN5bmMgKGRhdGE6IFRyYW5zYWN0aW9uSW5wdXQpID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgY3JlYXRlVHJhbnNhY3Rpb24oZGF0YSk7XG4gICAgICBzZXRBY3RpdmVNb2RhbChudWxsKTtcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHNhdmUgdHJhbnNhY3Rpb25cIiwgZXJyb3IpO1xuICAgICAgYWxlcnQoZXJyb3IubWVzc2FnZSB8fCBcIkFuIGVycm9yIG9jY3VycmVkIHdoaWxlIHNhdmluZyB0aGUgdHJhbnNhY3Rpb24uXCIpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgIHsvKiBXZWxjb21lIFNlY3Rpb24gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgc206aXRlbXMtY2VudGVyIGdhcC00IGJnLXdoaXRlIGRhcms6YmctemluYy05MDAgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMC84MCByb3VuZGVkLTJ4bCBwLTYgc2hhZG93LW1kIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIHJpZ2h0LTAgdy02NCBoLTY0IGJnLWVtZXJhbGQtNTAwLzUgcm91bmRlZC1mdWxsIGJsdXItM3hsIHBvaW50ZXItZXZlbnRzLW5vbmVcIj48L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIHNtOnRleHQtM3hsIGZvbnQtZXh0cmFib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgIEhlbGxvLCB7dXNlcj8uZmlyc3RfbmFtZSB8fCBcIlNpZ24gT3V0Z2FcIn0g8J+Ri1xuICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtemluYy01MDAgZGFyazp0ZXh0LXppbmMtNDAwIHRleHQtc20gc206dGV4dC1iYXNlXCI+XG4gICAgICAgICAgICAgIEhlcmUgaXMgeW91ciBmaW5hbmNpYWwgc3VtbWFyeSBmb3IgdGhpcyBtb250aC5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlTW9kYWwoXCJpbmNvbWVcIil9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC14bCBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTUwMCBweC00IHB5LTIuNSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSB0cmFuc2l0aW9uLWFsbCBzaGFkb3ctbWQgc2hhZG93LWVtZXJhbGQtOTUwLzIwIGFjdGl2ZTpzY2FsZS05NSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwiaGVyby1pbmNvbWUtYnV0dG9uXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFBsdXMgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+IEluY29tZVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZU1vZGFsKFwiZXhwZW5zZVwiKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLXhsIGJnLXJvc2UtNjAwIGhvdmVyOmJnLXJvc2UtNTAwIHB4LTQgcHktMi41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1tZCBzaGFkb3ctcm9zZS05NTAvMjAgYWN0aXZlOnNjYWxlLTk1IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJoZXJvLWV4cGVuc2UtYnV0dG9uXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPE1pbnVzIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPiBFeHBlbnNlXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEZpbmFuY2UgSGVhbHRoIChDb21pbmcgU29vbikgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWVtZXJhbGQtNTAwLzEwIHRvLXRlYWwtNTAwLzEwIGRhcms6ZnJvbS1lbWVyYWxkLTUwMC81IGRhcms6dG8tdGVhbC01MDAvNSBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTUwLzIwIGRhcms6Ym9yZGVyLWVtZXJhbGQtNTAwLzEwIHJvdW5kZWQtMnhsIHAtNSBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLXN0YXJ0IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgc2hhZG93LXNtIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHJlbGF0aXZlIHotMTBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZW1lcmFsZC01MDAvMTAgcC0yLjUgcm91bmRlZC14bCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1bIzNjZDM5NV1cIj5cbiAgICAgICAgICAgICAgPEFjdGl2aXR5IGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIHRleHQtc20gc206dGV4dC1iYXNlXCI+RmluYW5jaWFsIEhlYWx0aCBJbmRpY2F0b3I8L2gzPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMCB0ZXh0LXhzIHNtOnRleHQtc21cIj5BbmFseXplIHlvdXIgc3BlbmRpbmcgaGFiaXRzLCBkZWJ0LXRvLWluY29tZSByYXRpbywgYW5kIG92ZXJhbGwgZmluYW5jaWFsIHNhZmV0eSByYXRpbmcuPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2hyaW5rLTAgYmctZW1lcmFsZC01MDAvMTAgZGFyazpiZy1lbWVyYWxkLTUwMC8yMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIHRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIHRleHQtWzEwcHhdIHNtOnRleHQteHMgZm9udC1ib2xkIHB4LTMgcHktMS41IHJvdW5kZWQtZnVsbCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgcmVsYXRpdmUgei0xMFwiPlxuICAgICAgICAgICAgQ29taW5nIFNvb25cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBNZXRyaWNzIEdyaWQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNFwiPlxuICAgICAgICAgIHsvKiBUb3RhbCBCYWxhbmNlICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwLzgwIHJvdW5kZWQtMnhsIHAtNSBzcGFjZS15LTMgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy1zbSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtemluYy01MDAgZGFyazp0ZXh0LXppbmMtNDAwXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5Ub3RhbCBCYWxhbmNlPC9zcGFuPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtNTAwLzEwIHAtMiByb3VuZGVkLWxnIHRleHQtYmx1ZS02MDAgZGFyazp0ZXh0LWJsdWUtNDAwXCI+XG4gICAgICAgICAgICAgICAgPFdhbGxldCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgIHtmb3JtYXRBbW91bnQoZGFzaGJvYXJkRGF0YS50b3RhbF9iYWxhbmNlKX1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtemluYy00NTAgZGFyazp0ZXh0LXppbmMtNTAwXCI+QWNyb3NzIGFsbCBhY2NvdW50czwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEluY29tZSBUaGlzIE1vbnRoICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwLzgwIHJvdW5kZWQtMnhsIHAtNSBzcGFjZS15LTMgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy1zbSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtemluYy01MDAgZGFyazp0ZXh0LXppbmMtNDAwXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5JbmNvbWUgVGhpcyBNb250aDwvc3Bhbj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTUwMC8xMCBwLTIgcm91bmRlZC1sZyB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgIDxBcnJvd1VwUmlnaHQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIj5cbiAgICAgICAgICAgICAgICB7Zm9ybWF0QW1vdW50KGRhc2hib2FyZERhdGEuaW5jb21lX3RoaXNfbW9udGgpfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC16aW5jLTQ1MCBkYXJrOnRleHQtemluYy01MDBcIj5SZWNvcmRlZCBzaW5jZSBzdGFydCBvZiBtb250aDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEV4cGVuc2UgVGhpcyBNb250aCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctemluYy05MDAgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMC84MCByb3VuZGVkLTJ4bCBwLTUgc3BhY2UteS0zIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctc20gdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMFwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+RXhwZW5zZSBUaGlzIE1vbnRoPC9zcGFuPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXJvc2UtNTAwLzEwIHAtMiByb3VuZGVkLWxnIHRleHQtcm9zZS02MDAgZGFyazp0ZXh0LXJvc2UtNDAwXCI+XG4gICAgICAgICAgICAgICAgPEFycm93RG93blJpZ2h0IGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtcm9zZS02NTAgZGFyazp0ZXh0LXJvc2UtNDAwXCI+XG4gICAgICAgICAgICAgICAge2Zvcm1hdEFtb3VudChkYXNoYm9hcmREYXRhLmV4cGVuc2VfdGhpc19tb250aCl9XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXppbmMtNDUwIGRhcms6dGV4dC16aW5jLTUwMFwiPlJlY29yZGVkIHNpbmNlIHN0YXJ0IG9mIG1vbnRoPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogTmV0IEJhbGFuY2UgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIGJvcmRlciBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAvODAgcm91bmRlZC0yeGwgcC01IHNwYWNlLXktMyByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXNtIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00MDBcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPk5ldCBCYWxhbmNlPC9zcGFuPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXZpb2xldC01MDAvMTAgcC0yIHJvdW5kZWQtbGcgdGV4dC12aW9sZXQtNjAwIGRhcms6dGV4dC12aW9sZXQtNDAwXCI+XG4gICAgICAgICAgICAgICAgPFRyZW5kaW5nVXAgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9e2B0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgJHtkYXNoYm9hcmREYXRhLm5ldF9iYWxhbmNlID49IDAgPyBcInRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCIgOiBcInRleHQtcm9zZS02MDAgZGFyazp0ZXh0LXJvc2UtNDAwXCJ9YH0+XG4gICAgICAgICAgICAgICAge2Zvcm1hdEFtb3VudChkYXNoYm9hcmREYXRhLm5ldF9iYWxhbmNlKX1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtemluYy00NTAgZGFyazp0ZXh0LXppbmMtNTAwXCI+SW5jb21lIG1pbnVzIGV4cGVuc2VzPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBEYXNoYm9hcmQgU2VjdGlvbnMgR3JpZCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0zIGdhcC02XCI+XG4gICAgICAgICAgey8qIExlZnQgQXJlYSAoQnVkZ2V0ICYgVHJhbnNhY3Rpb25zKSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTIgc3BhY2UteS02XCI+XG4gICAgICAgICAgICB7LyogRmluYW5jaWFsIEFsbG9jYXRpb24gQ2hhcnQgQ2FyZCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwLzgwIHJvdW5kZWQtMnhsIHAtNiBzaGFkb3ctc20gc3BhY2UteS01IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgPFBpZUNoYXJ0IGNsYXNzTmFtZT1cImgtNSB3LTUgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC01MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0cmFja2luZy10aWdodFwiPkZpbmFuY2lhbCBBbGxvY2F0aW9uIEJyZWFrZG93bjwvaDI+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYXJvdW5kIGdhcC02IHB5LTJcIj5cbiAgICAgICAgICAgICAgICB7LyogU1ZHIERvbnV0ICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy00NCBoLTQ0IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICA8c3ZnIHZpZXdCb3g9XCIwIDAgMTAwIDEwMFwiIGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgdHJhbnNmb3JtIC1yb3RhdGUtOTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGNpcmNsZVxuICAgICAgICAgICAgICAgICAgICAgIGN4PVwiNTBcIlxuICAgICAgICAgICAgICAgICAgICAgIGN5PVwiNTBcIlxuICAgICAgICAgICAgICAgICAgICAgIHI9e3J9XG4gICAgICAgICAgICAgICAgICAgICAgZmlsbD1cInRyYW5zcGFyZW50XCJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCIjZTRlNGU3XCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJkYXJrOnN0cm9rZS16aW5jLTgwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIxMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIHtiYWxhbmNlUGVyY2VudCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxjaXJjbGVcbiAgICAgICAgICAgICAgICAgICAgICAgIGN4PVwiNTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY3k9XCI1MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICByPXtyfVxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsbD1cInRyYW5zcGFyZW50XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInN0cm9rZS1ibHVlLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjEwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZURhc2hhcnJheT17YCR7YmFsYW5jZVN0cm9rZUxlbmd0aH0gJHtjaXJjfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VEYXNob2Zmc2V0PXtiYWxhbmNlT2Zmc2V0fVxuICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICB7aW5jb21lUGVyY2VudCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxjaXJjbGVcbiAgICAgICAgICAgICAgICAgICAgICAgIGN4PVwiNTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY3k9XCI1MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICByPXtyfVxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsbD1cInRyYW5zcGFyZW50XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInN0cm9rZS1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjEwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZURhc2hhcnJheT17YCR7aW5jb21lU3Ryb2tlTGVuZ3RofSAke2NpcmN9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZURhc2hvZmZzZXQ9e2luY29tZU9mZnNldH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAge2V4cGVuc2VQZXJjZW50ID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGNpcmNsZVxuICAgICAgICAgICAgICAgICAgICAgICAgY3g9XCI1MFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBjeT1cIjUwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHI9e3J9XG4gICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwidHJhbnNwYXJlbnRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Ryb2tlLXJvc2UtNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMTBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlRGFzaGFycmF5PXtgJHtleHBlbnNlU3Ryb2tlTGVuZ3RofSAke2NpcmN9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZURhc2hvZmZzZXQ9e2V4cGVuc2VPZmZzZXR9XG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1jZW50ZXIgcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtemluYy01NTAgZGFyazp0ZXh0LXppbmMtNTAwIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0XCI+TmV0IFZhbHVlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtZXh0cmFib2xkIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIGxlYWRpbmctdGlnaHQgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEFtb3VudChkYXNoYm9hcmREYXRhLm5ldF9iYWxhbmNlKX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogTGVnZW5kcyAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBzcGFjZS15LTQgdy1mdWxsIHNtOm1heC13LXhzXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBiZy16aW5jLTUwIGRhcms6YmctemluYy05NTAvNDAgcC0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXppbmMtMjAwLzUwIGRhcms6Ym9yZGVyLXppbmMtODAwLzYwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMyB3LTMgcm91bmRlZC1mdWxsIGJnLWJsdWUtNTAwXCI+PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtemluYy03MDAgZGFyazp0ZXh0LXppbmMtMzAwXCI+VG90YWwgQmFsYW5jZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e2Zvcm1hdEFtb3VudChkYXNoYm9hcmREYXRhLnRvdGFsX2JhbGFuY2UpfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXppbmMtNTAwXCI+e2JhbGFuY2VQZXJjZW50LnRvRml4ZWQoMSl9JTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgYmctemluYy01MCBkYXJrOmJnLXppbmMtOTUwLzQwIHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci16aW5jLTIwMC81MCBkYXJrOmJvcmRlci16aW5jLTgwMC82MCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTMgdy0zIHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTUwMFwiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXppbmMtNzAwIGRhcms6dGV4dC16aW5jLTMwMFwiPkluY29tZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+e2Zvcm1hdEFtb3VudChkYXNoYm9hcmREYXRhLmluY29tZV90aGlzX21vbnRoKX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC16aW5jLTUwMFwiPntpbmNvbWVQZXJjZW50LnRvRml4ZWQoMSl9JTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgYmctemluYy01MCBkYXJrOmJnLXppbmMtOTUwLzQwIHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci16aW5jLTIwMC81MCBkYXJrOmJvcmRlci16aW5jLTgwMC82MCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTMgdy0zIHJvdW5kZWQtZnVsbCBiZy1yb3NlLTUwMFwiPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXppbmMtNzAwIGRhcms6dGV4dC16aW5jLTMwMFwiPkV4cGVuc2U8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXJvc2UtNjAwIGRhcms6dGV4dC1yb3NlLTQwMFwiPntmb3JtYXRBbW91bnQoZGFzaGJvYXJkRGF0YS5leHBlbnNlX3RoaXNfbW9udGgpfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXppbmMtNTUwXCI+e2V4cGVuc2VQZXJjZW50LnRvRml4ZWQoMSl9JTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEJ1ZGdldCBTdW1tYXJ5IENhcmQgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctemluYy05MDAgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMC84MCByb3VuZGVkLTJ4bCBwLTYgc2hhZG93LXNtIHNwYWNlLXktNSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICA8UGllQ2hhcnQgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdHJhY2tpbmctdGlnaHRcIj5CdWRnZXQgU3VtbWFyeTwvaDI+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXppbmMtNTUwIGRhcms6dGV4dC16aW5jLTUwMCBiZy16aW5jLTEwMCBkYXJrOmJnLXppbmMtODAwIHB4LTIuNSBweS0xIHJvdW5kZWQtZnVsbCBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDBcIj5UaGlzIE1vbnRoPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIHtkYXNoYm9hcmREYXRhLmJ1ZGdldF9zdW1tYXJ5Lmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC16aW5jLTU1MCBkYXJrOnRleHQtemluYy01MDAgdGV4dC1jZW50ZXIgcHktNFwiPk5vIG1vbnRobHkgYnVkZ2V0IGNvbmZpZ3VyZWQgeWV0LjwvcD5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgZGFzaGJvYXJkRGF0YS5idWRnZXRfc3VtbWFyeS5tYXAoKGJ1ZGdldCwgaWR4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHBlcmNlbnQgPSBNYXRoLm1pbigoYnVkZ2V0LmFjdHVhbCAvIGJ1ZGdldC5wbGFubmVkKSAqIDEwMCwgMTAwKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNPdmVyID0gYnVkZ2V0LnJlbWFpbmluZyA8IDA7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2lkeH0gY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtemluYy04MDAgZGFyazp0ZXh0LXppbmMtMjAwXCI+e2J1ZGdldC5jYXRlZ29yeV9uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0QW1vdW50KGJ1ZGdldC5hY3R1YWwpfSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtNDAwIGRhcms6dGV4dC16aW5jLTY1MFwiPi8ge2Zvcm1hdEFtb3VudChidWRnZXQucGxhbm5lZCl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBQcm9ncmVzcyBCYXIgQ29udGFpbmVyICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTIgdy1mdWxsIGJnLXppbmMtMTAwIGRhcms6YmctemluYy04MDAgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlbiB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGgtZnVsbCByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNTAwICR7aXNPdmVyID8gXCJiZy1yb3NlLTUwMFwiIDogXCJiZy1lbWVyYWxkLTUwMFwifWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAke3BlcmNlbnR9JWAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpc092ZXIgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yb3NlLTYwMCBkYXJrOnRleHQtcm9zZS00MDAgZm9udC1tZWRpdW1cIj5PdmVyIGJ1ZGdldCBieSB7Zm9ybWF0QW1vdW50KE1hdGguYWJzKGJ1ZGdldC5yZW1haW5pbmcpKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1tZWRpdW1cIj5SZW1haW5pbmcge2Zvcm1hdEFtb3VudChidWRnZXQucmVtYWluaW5nKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtemluYy01MDBcIj57cGVyY2VudC50b0ZpeGVkKDApfSUgdXNlZDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogUmVjZW50IFRyYW5zYWN0aW9ucyBDYXJkICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIGJvcmRlciBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAvODAgcm91bmRlZC0yeGwgcC02IHNoYWRvdy1zbSBzcGFjZS15LTQgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgPEFycm93TGVmdFJpZ2h0IGNsYXNzTmFtZT1cImgtNSB3LTUgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0XCI+UmVjZW50IFRyYW5zYWN0aW9uczwvaDI+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgYm9yZGVyLWNvbGxhcHNlXCI+XG4gICAgICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAgdGV4dC14cyB0ZXh0LXppbmMtNTAwIHVwcGVyY2FzZSBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtMVwiPkRlc2NyaXB0aW9uPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC0xXCI+VHlwZTwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtMVwiPkRhdGU8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTEgdGV4dC1yaWdodFwiPkFtb3VudDwvdGg+XG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS16aW5jLTIwMC81MCBkYXJrOmRpdmlkZS16aW5jLTgwMC81MCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgIHtkYXNoYm9hcmREYXRhLnJlY2VudF90cmFuc2FjdGlvbnMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPXs0fSBjbGFzc05hbWU9XCJweS02IHRleHQtY2VudGVyIHRleHQtemluYy01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgTm8gdHJhbnNhY3Rpb25zIGZvdW5kLlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIGRhc2hib2FyZERhdGEucmVjZW50X3RyYW5zYWN0aW9ucy5tYXAoKHR4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXt0eC5pZH0gY2xhc3NOYW1lPVwiaG92ZXI6YmctemluYy0xMDAvNTAgZGFyazpob3ZlcjpiZy16aW5jLTgwMC8zMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMy41IHB4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtemluYy04MDAgZGFyazp0ZXh0LXppbmMtMjAwXCI+e3R4LmRlc2NyaXB0aW9ufTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMuNSBweC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTAuNSByb3VuZGVkIHRleHQteHMgZm9udC1zZW1pYm9sZCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eC50eXBlID09PSBcIkluY29tZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWVtZXJhbGQtNTAwLzEwIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHR4LnR5cGUgPT09IFwiRXhwZW5zZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXJvc2UtNTAwLzEwIHRleHQtcm9zZS02MDUgZGFyazp0ZXh0LXJvc2UtNDAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctYmx1ZS01MDAvMTAgdGV4dC1ibHVlLTYwMCBkYXJrOnRleHQtYmx1ZS00MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFR4VHlwZSh0eC50eXBlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zLjUgcHgtMSB0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKHR4LmRhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImlkLUlEXCIsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHllYXI6IFwibnVtZXJpY1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9udGg6IFwic2hvcnRcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRheTogXCJudW1lcmljXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT17YHB5LTMuNSBweC0xIHRleHQtcmlnaHQgZm9udC1zZW1pYm9sZCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR4LnR5cGUgPT09IFwiSW5jb21lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJ0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHR4LnR5cGUgPT09IFwiRXhwZW5zZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwidGV4dC1yb3NlLTYwMCBkYXJrOnRleHQtcm9zZS00MDBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtYmx1ZS02MDAgZGFyazp0ZXh0LWJsdWUtNDAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0eC50eXBlID09PSBcIkV4cGVuc2VcIiA/IFwiLVwiIDogdHgudHlwZSA9PT0gXCJJbmNvbWVcIiA/IFwiK1wiIDogXCJcIn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0QW1vdW50KHR4LmFtb3VudCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgICAgICkpXG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUmlnaHQgQXJlYSAoR29hbHMgJiBRdWljayBBY3Rpb25zKSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICAgICAgey8qIFNhdmluZyBHb2FscyBTdW1tYXJ5IENhcmQgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctemluYy05MDAgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMC84MCByb3VuZGVkLTJ4bCBwLTYgc2hhZG93LXNtIHNwYWNlLXktNCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICA8VGFyZ2V0IGNsYXNzTmFtZT1cImgtNSB3LTUgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0XCI+U2F2aW5nIEdvYWxzPC9oMj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTUwMC8xMCBkYXJrOmJnLWVtZXJhbGQtNTAwLzIwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgdGV4dC1lbWVyYWxkLTc1MCBkYXJrOnRleHQtZW1lcmFsZC00MDAgdGV4dC1bMTBweF0gZm9udC1ib2xkIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgICAgIFNvb25cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1jZW50ZXIgcC01IGJvcmRlciBib3JkZXItZGFzaGVkIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMCByb3VuZGVkLXhsIGJnLXppbmMtNTAvNTAgZGFyazpiZy16aW5jLTk1MC8yMFwiPlxuICAgICAgICAgICAgICAgIDxBY3Rpdml0eSBjbGFzc05hbWU9XCJoLTcgdy03IHRleHQtemluYy00MDAgbWItMiBhbmltYXRlLXB1bHNlXCIgLz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXppbmMtNzAwIGRhcms6dGV4dC16aW5jLTMwMFwiPkZlYXR1cmUgQ29taW5nIFNvb248L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00MDAgbXQtMSBtYXgtdy1bMjAwcHhdXCI+V2UgYXJlIGZpbmUtdHVuaW5nIHNhdmluZyBnb2FsIGFsbG9jYXRpb25zLjwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFF1aWNrIEFjdGlvbnMgQ2FyZCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwLzgwIHJvdW5kZWQtMnhsIHAtNiBzaGFkb3ctc20gc3BhY2UteS00IHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cImgtNSB3LTUgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC01MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0cmFja2luZy10aWdodFwiPlF1aWNrIEFjdGlvbnM8L2gyPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZU1vZGFsKFwiaW5jb21lXCIpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgdy1mdWxsIHJvdW5kZWQteGwgYmctemluYy01MCBob3ZlcjpiZy16aW5jLTEwMCBkYXJrOmJnLXppbmMtOTUwIGRhcms6aG92ZXI6YmctemluYy04MDAgcC0zLjUgdGV4dC1zbSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWFsbCB0ZXh0LWxlZnQgdGV4dC16aW5jLTcwMCBkYXJrOnRleHQtemluYy0yMDAgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMCBob3Zlcjpib3JkZXItemluYy0zMDAgZGFyazpob3Zlcjpib3JkZXItemluYy03MDAvODAgYWN0aXZlOnNjYWxlLVswLjk5XSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cInF1aWNrLWFjdGlvbi1pbmNvbWVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZW1lcmFsZC01MDAvMTAgcC0yIHJvdW5kZWQtbGcgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPFBsdXMgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5JbmNvbWU8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC16aW5jLTUwMFwiPkFkZCBjYXNoIGluY29tZSBvciBzYWxhcnk8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZU1vZGFsKFwiZXhwZW5zZVwiKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHctZnVsbCByb3VuZGVkLXhsIGJnLXppbmMtNTAgaG92ZXI6YmctemluYy0xMDAgZGFyazpiZy16aW5jLTk1MCBkYXJrOmhvdmVyOmJnLXppbmMtODAwIHAtMy41IHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgdGV4dC1sZWZ0IHRleHQtemluYy03MDAgZGFyazp0ZXh0LXppbmMtMjAwIGJvcmRlciBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAgaG92ZXI6Ym9yZGVyLXppbmMtMzAwIGRhcms6aG92ZXI6Ym9yZGVyLXppbmMtNzAwLzgwIGFjdGl2ZTpzY2FsZS1bMC45OV0gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJxdWljay1hY3Rpb24tZXhwZW5zZVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1yb3NlLTUwMC8xMCBwLTIgcm91bmRlZC1sZyB0ZXh0LXJvc2UtNjAwIGRhcms6dGV4dC1yb3NlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8TWludXMgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5FeHBlbnNlPC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtemluYy01MDBcIj5BZGQgZXhwZW5zZXMgb3IgcGF5bWVudHM8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZU1vZGFsKFwidHJhbnNmZXJcIil9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB3LWZ1bGwgcm91bmRlZC14bCBiZy16aW5jLTUwIGhvdmVyOmJnLXppbmMtMTAwIGRhcms6YmctemluYy05NTAgZGFyazpob3ZlcjpiZy16aW5jLTgwMCBwLTMuNSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIHRleHQtbGVmdCB0ZXh0LXppbmMtNzAwIGRhcms6dGV4dC16aW5jLTIwMCBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwIGhvdmVyOmJvcmRlci16aW5jLTMwMCBkYXJrOmhvdmVyOmJvcmRlci16aW5jLTcwMC84MCBhY3RpdmU6c2NhbGUtWzAuOTldIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwicXVpY2stYWN0aW9uLXRyYW5zZmVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtNTAwLzEwIHAtMiByb3VuZGVkLWxnIHRleHQtYmx1ZS02MDAgZGFyazp0ZXh0LWJsdWUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxBcnJvd0xlZnRSaWdodCBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlRyYW5zZmVyIE1vbmV5PC9wPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtemluYy01MDBcIj5Nb3ZlIGZ1bmRzIGJldHdlZW4gYWNjb3VudHM8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBRdWljayBBY3Rpb24gTW9kYWwgUGxhY2Vob2xkZXIgKi99XG4gICAgICB7YWN0aXZlTW9kYWwgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svODAgYmFja2Ryb3AtYmx1ci1zbSBmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktY2VudGVyIHAtNCB6LTUwIGFuaW1hdGUtZmFkZS1pbiBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctemluYy05MDAgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMCB3LWZ1bGwgbWF4LXctbWQgcm91bmRlZC0yeGwgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy0yeGwgYW5pbWF0ZS1zY2FsZS11cCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDAgbXktOFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHgtNiBweS00IGJvcmRlci1iIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMCBiZy16aW5jLTUwLzUwIGRhcms6YmctemluYy05MDAvNTAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgY2FwaXRhbGl6ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIHthY3RpdmVNb2RhbCA9PT0gXCJpbmNvbWVcIiAmJiA8UGx1cyBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtZW1lcmFsZC01MDBcIiAvPn1cbiAgICAgICAgICAgICAgICB7YWN0aXZlTW9kYWwgPT09IFwiZXhwZW5zZVwiICYmIDxNaW51cyBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtcm9zZS01MDBcIiAvPn1cbiAgICAgICAgICAgICAgICB7YWN0aXZlTW9kYWwgPT09IFwidHJhbnNmZXJcIiAmJiA8QXJyb3dMZWZ0UmlnaHQgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LWJsdWUtNTAwXCIgLz59XG4gICAgICAgICAgICAgICAgTG9nIHthY3RpdmVNb2RhbCA9PT0gXCJpbmNvbWVcIiA/IFwiSW5jb21lXCIgOiBhY3RpdmVNb2RhbCA9PT0gXCJleHBlbnNlXCIgPyBcIkV4cGVuc2VcIiA6IFwiVHJhbnNmZXJcIn1cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZU1vZGFsKG51bGwpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtemluYy01MDAgaG92ZXI6dGV4dC16aW5jLTkwMCBkYXJrOnRleHQtemluYy00MDAgZGFyazpob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cIm1vZGFsLWNsb3NlLWljb25cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxuICAgICAgICAgICAgICA8VHJhbnNhY3Rpb25Gb3JtXG4gICAgICAgICAgICAgICAgYWNjb3VudHM9e2FjY291bnRzfVxuICAgICAgICAgICAgICAgIGNhdGVnb3JpZXM9e2NhdGVnb3JpZXN9XG4gICAgICAgICAgICAgICAgb25TdWJtaXQ9e2hhbmRsZVRyYW5zYWN0aW9uU3VibWl0fVxuICAgICAgICAgICAgICAgIGlzU3VibWl0dGluZz17aXNDcmVhdGluZ31cbiAgICAgICAgICAgICAgICBkZWZhdWx0VHlwZT17YWN0aXZlTW9kYWwgPT09IFwiaW5jb21lXCIgPyBcIkluY29tZVwiIDogYWN0aXZlTW9kYWwgPT09IFwiZXhwZW5zZVwiID8gXCJFeHBlbnNlXCIgOiBcIlRyYW5zZmVyXCJ9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==