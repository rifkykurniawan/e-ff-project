import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/categories/CategoryForm.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=0a9b0578";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=9dd4f110";
import { categorySchema, categoryTypes } from "/src/types/categories.ts";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/features/categories/CategoryForm.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
var _s = $RefreshSig$();
export function CategoryForm({ initialData, onSubmit, isSubmitting }) {
	_s();
	const { register, handleSubmit, formState: { errors } } = useForm({
		resolver: zodResolver(categorySchema),
		defaultValues: initialData ? {
			name: initialData.name,
			type: initialData.type
		} : {
			name: "",
			type: "Expense"
		}
	});
	return /* @__PURE__ */ _jsxDEV("form", {
		onSubmit: handleSubmit(onSubmit),
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("label", {
					className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
					children: "Category Name"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					type: "text",
					...register("name"),
					"data-testid": "category-name-input",
					placeholder: "e.g., Groceries",
					className: `w-full rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.name ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 9
				}, this),
				errors.name && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-xs text-red-500",
					children: errors.name.message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 25
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("label", {
					className: "block text-sm font-medium text-zinc-700 dark:text-zinc-300 mb-1",
					children: "Category Type"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "relative",
					children: [/* @__PURE__ */ _jsxDEV("select", {
						...register("type"),
						"data-testid": "category-type-select",
						className: `w-full appearance-none rounded-lg border bg-white dark:bg-zinc-900 px-3 py-2 pr-10 text-sm text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 ${errors.type ? "border-red-500 focus:border-red-500" : "border-zinc-300 dark:border-zinc-700 focus:border-emerald-500"}`,
						children: categoryTypes.map((type) => /* @__PURE__ */ _jsxDEV("option", {
							value: type,
							children: type
						}, type, false, {
							fileName: _jsxFileName,
							lineNumber: 58,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-zinc-500",
						children: /* @__PURE__ */ _jsxDEV("svg", {
							className: "h-4 w-4",
							fill: "none",
							stroke: "currentColor",
							viewBox: "0 0 24 24",
							xmlns: "http://www.w3.org/2000/svg",
							children: /* @__PURE__ */ _jsxDEV("path", {
								strokeLinecap: "round",
								strokeLinejoin: "round",
								strokeWidth: "2",
								d: "M19 9l-7 7-7-7"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 63,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 9
				}, this),
				errors.type && /* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-xs text-red-500",
					children: errors.type.message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 25
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 45,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "pt-4 flex justify-end",
				children: /* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: isSubmitting,
					"data-testid": "category-submit-button",
					className: "rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 disabled:opacity-50 transition-colors",
					children: isSubmitting ? "Saving..." : "Save Category"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 5
	}, this);
}
_s(CategoryForm, "HLC1IFclXfL/K+q6lxeDS/Po7Wk=", false, function() {
	return [useForm];
});
_c = CategoryForm;
var _c;
$RefreshReg$(_c, "CategoryForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/categories/CategoryForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/features/categories/CategoryForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/features/categories/CategoryForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/features/categories/CategoryForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsZ0JBQWdCLHFCQUF3RDs7OztBQVFqRixPQUFPLFNBQVMsYUFBYSxFQUFFLGFBQWEsVUFBVSxnQkFBbUM7O0NBQ3ZGLE1BQU0sRUFDSixVQUNBLGNBQ0EsV0FBVyxFQUFFLGFBQ1gsUUFBdUI7RUFDekIsVUFBVSxZQUFZLGNBQWM7RUFDcEMsZUFBZSxjQUFjO0dBQzNCLE1BQU0sWUFBWTtHQUNsQixNQUFNLFlBQVk7RUFDcEIsSUFBSTtHQUNGLE1BQU07R0FDTixNQUFNO0VBQ1I7Q0FDRixDQUFDO0NBRUQsT0FDRSx3QkFBQyxRQUFEO0VBQU0sVUFBVSxhQUFhLFFBQVE7RUFBRyxXQUFVO1lBQWxEO0dBQ0Usd0JBQUMsT0FBRDtJQUNFLHdCQUFDLFNBQUQ7S0FBTyxXQUFVO2VBQWtFO0lBRTVFOzs7OztJQUNQLHdCQUFDLFNBQUQ7S0FDRSxNQUFLO0tBQ0wsR0FBSSxTQUFTLE1BQU07S0FDbkIsZUFBWTtLQUNaLGFBQVk7S0FDWixXQUFXLHFMQUNULE9BQU8sT0FBTyx3Q0FBd0M7SUFFekQ7Ozs7O0lBQ0EsT0FBTyxRQUFRLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQTZCLE9BQU8sS0FBSztJQUFXOzs7OztHQUM5RTs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQ0Usd0JBQUMsU0FBRDtLQUFPLFdBQVU7ZUFBa0U7SUFFNUU7Ozs7O0lBQ1Asd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQ7TUFDRSxHQUFJLFNBQVMsTUFBTTtNQUNuQixlQUFZO01BQ1osV0FBVyxzTEFDVCxPQUFPLE9BQU8sd0NBQXdDO2dCQUd2RCxjQUFjLEtBQUksU0FDakIsd0JBQUMsVUFBRDtPQUFtQixPQUFPO2lCQUFPO01BQWEsR0FBakM7Ozs7YUFBaUMsQ0FDL0M7S0FDSzs7OztlQUNSLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO09BQVUsTUFBSztPQUFPLFFBQU87T0FBZSxTQUFRO09BQVksT0FBTTtpQkFDbkYsd0JBQUMsUUFBRDtRQUFNLGVBQWM7UUFBUSxnQkFBZTtRQUFRLGFBQVk7UUFBSSxHQUFFO09BQXVCOzs7OztNQUN6Rjs7Ozs7S0FDRjs7OzthQUNGOzs7Ozs7SUFDSixPQUFPLFFBQVEsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBNkIsT0FBTyxLQUFLO0lBQVc7Ozs7O0dBQzlFOzs7OztHQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxVQUFVO0tBQ1YsZUFBWTtLQUNaLFdBQVU7ZUFFVCxlQUFlLGNBQWM7SUFDeEI7Ozs7O0dBQ0w7Ozs7O0VBQ0Q7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNhdGVnb3J5Rm9ybS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gXCJyZWFjdC1ob29rLWZvcm1cIjtcbmltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSBcIkBob29rZm9ybS9yZXNvbHZlcnMvem9kXCI7XG5pbXBvcnQgeyBjYXRlZ29yeVNjaGVtYSwgY2F0ZWdvcnlUeXBlcywgdHlwZSBDYXRlZ29yeUlucHV0LCB0eXBlIENhdGVnb3J5IH0gZnJvbSBcIi4uLy4uL3R5cGVzL2NhdGVnb3JpZXNcIjtcblxuaW50ZXJmYWNlIENhdGVnb3J5Rm9ybVByb3BzIHtcbiAgaW5pdGlhbERhdGE/OiBDYXRlZ29yeTtcbiAgb25TdWJtaXQ6IChkYXRhOiBDYXRlZ29yeUlucHV0KSA9PiBQcm9taXNlPHZvaWQ+O1xuICBpc1N1Ym1pdHRpbmc/OiBib29sZWFuO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gQ2F0ZWdvcnlGb3JtKHsgaW5pdGlhbERhdGEsIG9uU3VibWl0LCBpc1N1Ym1pdHRpbmcgfTogQ2F0ZWdvcnlGb3JtUHJvcHMpIHtcbiAgY29uc3Qge1xuICAgIHJlZ2lzdGVyLFxuICAgIGhhbmRsZVN1Ym1pdCxcbiAgICBmb3JtU3RhdGU6IHsgZXJyb3JzIH0sXG4gIH0gPSB1c2VGb3JtPENhdGVnb3J5SW5wdXQ+KHtcbiAgICByZXNvbHZlcjogem9kUmVzb2x2ZXIoY2F0ZWdvcnlTY2hlbWEpLFxuICAgIGRlZmF1bHRWYWx1ZXM6IGluaXRpYWxEYXRhID8ge1xuICAgICAgbmFtZTogaW5pdGlhbERhdGEubmFtZSxcbiAgICAgIHR5cGU6IGluaXRpYWxEYXRhLnR5cGUsXG4gICAgfSA6IHtcbiAgICAgIG5hbWU6IFwiXCIsXG4gICAgICB0eXBlOiBcIkV4cGVuc2VcIixcbiAgICB9LFxuICB9KTtcblxuICByZXR1cm4gKFxuICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXQob25TdWJtaXQpfSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtemluYy03MDAgZGFyazp0ZXh0LXppbmMtMzAwIG1iLTFcIj5cbiAgICAgICAgICBDYXRlZ29yeSBOYW1lXG4gICAgICAgIDwvbGFiZWw+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICB7Li4ucmVnaXN0ZXIoXCJuYW1lXCIpfVxuICAgICAgICAgIGRhdGEtdGVzdGlkPVwiY2F0ZWdvcnktbmFtZS1pbnB1dFwiXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuLCBHcm9jZXJpZXNcIlxuICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHB4LTMgcHktMiB0ZXh0LXNtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXppbmMtNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMC8yMCAke1xuICAgICAgICAgICAgZXJyb3JzLm5hbWUgPyBcImJvcmRlci1yZWQtNTAwIGZvY3VzOmJvcmRlci1yZWQtNTAwXCIgOiBcImJvcmRlci16aW5jLTMwMCBkYXJrOmJvcmRlci16aW5jLTcwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgIH1gfVxuICAgICAgICAvPlxuICAgICAgICB7ZXJyb3JzLm5hbWUgJiYgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTUwMFwiPntlcnJvcnMubmFtZS5tZXNzYWdlfTwvcD59XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdj5cbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC16aW5jLTcwMCBkYXJrOnRleHQtemluYy0zMDAgbWItMVwiPlxuICAgICAgICAgIENhdGVnb3J5IFR5cGVcbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcInR5cGVcIil9XG4gICAgICAgICAgICBkYXRhLXRlc3RpZD1cImNhdGVnb3J5LXR5cGUtc2VsZWN0XCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBhcHBlYXJhbmNlLW5vbmUgcm91bmRlZC1sZyBib3JkZXIgYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCBweC0zIHB5LTIgcHItMTAgdGV4dC1zbSB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZW1lcmFsZC01MDAvMjAgJHtcbiAgICAgICAgICAgICAgZXJyb3JzLnR5cGUgPyBcImJvcmRlci1yZWQtNTAwIGZvY3VzOmJvcmRlci1yZWQtNTAwXCIgOiBcImJvcmRlci16aW5jLTMwMCBkYXJrOmJvcmRlci16aW5jLTcwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge2NhdGVnb3J5VHlwZXMubWFwKHR5cGUgPT4gKFxuICAgICAgICAgICAgICA8b3B0aW9uIGtleT17dHlwZX0gdmFsdWU9e3R5cGV9Pnt0eXBlfTwvb3B0aW9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIGluc2V0LXktMCByaWdodC0wIGZsZXggaXRlbXMtY2VudGVyIHB4LTMgdGV4dC16aW5jLTUwMFwiPlxuICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJoLTQgdy00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiPlxuICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xOSA5bC03IDctNy03XCI+PC9wYXRoPlxuICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICB7ZXJyb3JzLnR5cGUgJiYgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTUwMFwiPntlcnJvcnMudHlwZS5tZXNzYWdlfTwvcD59XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGZsZXgganVzdGlmeS1lbmRcIj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XG4gICAgICAgICAgZGF0YS10ZXN0aWQ9XCJjYXRlZ29yeS1zdWJtaXQtYnV0dG9uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJnLWVtZXJhbGQtNjAwIHB4LTQgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgaG92ZXI6YmctZW1lcmFsZC03MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNTAwIGZvY3VzOnJpbmctb2Zmc2V0LTIgZGlzYWJsZWQ6b3BhY2l0eS01MCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgID5cbiAgICAgICAgICB7aXNTdWJtaXR0aW5nID8gXCJTYXZpbmcuLi5cIiA6IFwiU2F2ZSBDYXRlZ29yeVwifVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZm9ybT5cbiAgKTtcbn1cbiJdfQ==