import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ThemeContext.tsx");const React = __vite__cjsImport0_react; const createContext = __vite__cjsImport0_react["createContext"]; const useContext = __vite__cjsImport0_react["useContext"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=513be775";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/components/ThemeContext.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const ThemeContext = createContext(undefined);
_c = ThemeContext;
export const ThemeProvider = ({ children }) => {
	_s();
	const [theme, setTheme] = useState(() => {
		const saved = localStorage.getItem("theme");
		if (saved === "light" || saved === "dark") return saved;
		// Default to dark mode since it's the premium layout theme
		return "dark";
	});
	useEffect(() => {
		const root = window.document.documentElement;
		if (theme === "dark") {
			root.classList.add("dark");
		} else {
			root.classList.remove("dark");
		}
		localStorage.setItem("theme", theme);
	}, [theme]);
	const toggleTheme = () => {
		setTheme((prev) => prev === "dark" ? "light" : "dark");
	};
	return /* @__PURE__ */ _jsxDEV(ThemeContext.Provider, {
		value: {
			theme,
			toggleTheme
		},
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 35,
		columnNumber: 5
	}, this);
};
_s(ThemeProvider, "UTcEjPriy4WV5fWkzTsgs0aQaIE=");
_c2 = ThemeProvider;
export const useTheme = () => {
	_s2();
	const context = useContext(ThemeContext);
	if (!context) {
		throw new Error("useTheme must be used within a ThemeProvider");
	}
	return context;
};
_s2(useTheme, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c, _c2;
$RefreshReg$(_c, "ThemeContext");
$RefreshReg$(_c2, "ThemeProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ThemeContext.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/components/ThemeContext.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/components/ThemeContext.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/components/ThemeContext.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGVBQWUsWUFBWSxXQUFXLGdCQUFnQjs7OztBQVN0RSxNQUFNLGVBQWUsY0FBNEMsU0FBUzs7QUFFMUUsT0FBTyxNQUFNLGlCQUEwRCxFQUFFLGVBQWU7O0NBQ3RGLE1BQU0sQ0FBQyxPQUFPLFlBQVksZUFBc0I7RUFDOUMsTUFBTSxRQUFRLGFBQWEsUUFBUSxPQUFPO0VBQzFDLElBQUksVUFBVSxXQUFXLFVBQVUsUUFBUSxPQUFPOztFQUVsRCxPQUFPO0NBQ1QsQ0FBQztDQUVELGdCQUFnQjtFQUNkLE1BQU0sT0FBTyxPQUFPLFNBQVM7RUFDN0IsSUFBSSxVQUFVLFFBQVE7R0FDcEIsS0FBSyxVQUFVLElBQUksTUFBTTtFQUMzQixPQUFPO0dBQ0wsS0FBSyxVQUFVLE9BQU8sTUFBTTtFQUM5QjtFQUNBLGFBQWEsUUFBUSxTQUFTLEtBQUs7Q0FDckMsR0FBRyxDQUFDLEtBQUssQ0FBQztDQUVWLE1BQU0sb0JBQW9CO0VBQ3hCLFVBQVUsU0FBVSxTQUFTLFNBQVMsVUFBVSxNQUFPO0NBQ3pEO0NBRUEsT0FDRSx3QkFBQyxhQUFhLFVBQWQ7RUFBdUIsT0FBTztHQUFFO0dBQU87RUFBWTtFQUNoRDtDQUNvQjs7Ozs7QUFFM0I7OztBQUVBLE9BQU8sTUFBTSxpQkFBaUI7O0NBQzVCLE1BQU0sVUFBVSxXQUFXLFlBQVk7Q0FDdkMsSUFBSSxDQUFDLFNBQVM7RUFDWixNQUFNLElBQUksTUFBTSw4Q0FBOEM7Q0FDaEU7Q0FDQSxPQUFPO0FBQ1QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVGhlbWVDb250ZXh0LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuXG50eXBlIFRoZW1lID0gXCJsaWdodFwiIHwgXCJkYXJrXCI7XG5cbmludGVyZmFjZSBUaGVtZUNvbnRleHRUeXBlIHtcbiAgdGhlbWU6IFRoZW1lO1xuICB0b2dnbGVUaGVtZTogKCkgPT4gdm9pZDtcbn1cblxuY29uc3QgVGhlbWVDb250ZXh0ID0gY3JlYXRlQ29udGV4dDxUaGVtZUNvbnRleHRUeXBlIHwgdW5kZWZpbmVkPih1bmRlZmluZWQpO1xuXG5leHBvcnQgY29uc3QgVGhlbWVQcm92aWRlcjogUmVhY3QuRkM8eyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlIH0+ID0gKHsgY2hpbGRyZW4gfSkgPT4ge1xuICBjb25zdCBbdGhlbWUsIHNldFRoZW1lXSA9IHVzZVN0YXRlPFRoZW1lPigoKSA9PiB7XG4gICAgY29uc3Qgc2F2ZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInRoZW1lXCIpO1xuICAgIGlmIChzYXZlZCA9PT0gXCJsaWdodFwiIHx8IHNhdmVkID09PSBcImRhcmtcIikgcmV0dXJuIHNhdmVkO1xuICAgIC8vIERlZmF1bHQgdG8gZGFyayBtb2RlIHNpbmNlIGl0J3MgdGhlIHByZW1pdW0gbGF5b3V0IHRoZW1lXG4gICAgcmV0dXJuIFwiZGFya1wiO1xuICB9KTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHJvb3QgPSB3aW5kb3cuZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50O1xuICAgIGlmICh0aGVtZSA9PT0gXCJkYXJrXCIpIHtcbiAgICAgIHJvb3QuY2xhc3NMaXN0LmFkZChcImRhcmtcIik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJvb3QuY2xhc3NMaXN0LnJlbW92ZShcImRhcmtcIik7XG4gICAgfVxuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwidGhlbWVcIiwgdGhlbWUpO1xuICB9LCBbdGhlbWVdKTtcblxuICBjb25zdCB0b2dnbGVUaGVtZSA9ICgpID0+IHtcbiAgICBzZXRUaGVtZSgocHJldikgPT4gKHByZXYgPT09IFwiZGFya1wiID8gXCJsaWdodFwiIDogXCJkYXJrXCIpKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxUaGVtZUNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3sgdGhlbWUsIHRvZ2dsZVRoZW1lIH19PlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvVGhlbWVDb250ZXh0LlByb3ZpZGVyPlxuICApO1xufTtcblxuZXhwb3J0IGNvbnN0IHVzZVRoZW1lID0gKCkgPT4ge1xuICBjb25zdCBjb250ZXh0ID0gdXNlQ29udGV4dChUaGVtZUNvbnRleHQpO1xuICBpZiAoIWNvbnRleHQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJ1c2VUaGVtZSBtdXN0IGJlIHVzZWQgd2l0aGluIGEgVGhlbWVQcm92aWRlclwiKTtcbiAgfVxuICByZXR1cm4gY29udGV4dDtcbn07XG4iXX0=