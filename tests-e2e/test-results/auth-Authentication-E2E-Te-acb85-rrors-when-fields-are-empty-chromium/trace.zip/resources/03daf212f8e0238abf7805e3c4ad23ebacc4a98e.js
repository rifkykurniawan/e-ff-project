import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Modal.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=513be775";
import { X } from "/node_modules/.vite/deps/lucide-react.js?v=7df35618";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/components/Modal.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
var _s = $RefreshSig$();
export function Modal({ isOpen, onClose, title, children }) {
	_s();
	const overlayRef = useRef(null);
	useEffect(() => {
		const handleEscape = (e) => {
			if (e.key === "Escape") onClose();
		};
		if (isOpen) {
			document.addEventListener("keydown", handleEscape);
			document.body.style.overflow = "hidden";
		}
		return () => {
			document.removeEventListener("keydown", handleEscape);
			document.body.style.overflow = "unset";
		};
	}, [isOpen, onClose]);
	if (!isOpen) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 overflow-y-auto",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			ref: overlayRef,
			className: "fixed inset-0 bg-black/50 backdrop-blur-sm transition-opacity",
			onClick: onClose
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 35,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex min-h-full items-center justify-center p-4",
			children: /* @__PURE__ */ _jsxDEV("div", {
				"data-testid": "modal-container",
				className: "relative w-full max-w-md transform overflow-hidden rounded-2xl bg-white dark:bg-zinc-900 p-6 text-left align-middle shadow-xl transition-all border border-zinc-200 dark:border-zinc-800 my-8",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between mb-5",
					children: [/* @__PURE__ */ _jsxDEV("h3", {
						"data-testid": "modal-title",
						className: "text-lg font-bold leading-6 text-zinc-900 dark:text-white",
						children: title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						"data-testid": "modal-close-button",
						className: "rounded-full p-1 text-zinc-400 hover:bg-zinc-100 hover:text-zinc-500 dark:hover:bg-zinc-800 dark:hover:text-zinc-300 transition-colors",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "h-5 w-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "mt-2",
					children
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 5
	}, this);
}
_s(Modal, "Dcc1XOIs2J7RNGv5z0uyGCrvqqk=");
_c = Modal;
var _c;
$RefreshReg$(_c, "Modal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Modal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/components/Modal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/components/Modal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/components/Modal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGNBQWM7QUFDbEMsU0FBUyxTQUFTOzs7O0FBU2xCLE9BQU8sU0FBUyxNQUFNLEVBQUUsUUFBUSxTQUFTLE9BQU8sWUFBd0I7O0NBQ3RFLE1BQU0sYUFBYSxPQUF1QixJQUFJO0NBRTlDLGdCQUFnQjtFQUNkLE1BQU0sZ0JBQWdCLE1BQXFCO0dBQ3pDLElBQUksRUFBRSxRQUFRLFVBQVUsUUFBUTtFQUNsQztFQUVBLElBQUksUUFBUTtHQUNWLFNBQVMsaUJBQWlCLFdBQVcsWUFBWTtHQUNqRCxTQUFTLEtBQUssTUFBTSxXQUFXO0VBQ2pDO0VBRUEsYUFBYTtHQUNYLFNBQVMsb0JBQW9CLFdBQVcsWUFBWTtHQUNwRCxTQUFTLEtBQUssTUFBTSxXQUFXO0VBQ2pDO0NBQ0YsR0FBRyxDQUFDLFFBQVEsT0FBTyxDQUFDO0NBRXBCLElBQUksQ0FBQyxRQUFRLE9BQU87Q0FFcEIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBRUUsd0JBQUMsT0FBRDtHQUNFLEtBQUs7R0FDTCxXQUFVO0dBQ1YsU0FBUztFQUNWOzs7O1lBR0Qsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFFYix3QkFBQyxPQUFEO0lBQ0UsZUFBWTtJQUNaLFdBQVU7Y0FGWixDQUlFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQ0UsZUFBWTtNQUNaLFdBQVU7Z0JBRVQ7S0FDQzs7OztlQUNKLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsZUFBWTtNQUNaLFdBQVU7Z0JBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7S0FDbEI7Ozs7YUFDTDs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUNaO0lBQ0U7Ozs7WUFDRjs7Ozs7O0VBQ0Y7Ozs7VUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTW9kYWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBYIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuXG5pbnRlcmZhY2UgTW9kYWxQcm9wcyB7XG4gIGlzT3BlbjogYm9vbGVhbjtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbiAgdGl0bGU6IHN0cmluZztcbiAgY2hpbGRyZW46IFJlYWN0LlJlYWN0Tm9kZTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIE1vZGFsKHsgaXNPcGVuLCBvbkNsb3NlLCB0aXRsZSwgY2hpbGRyZW4gfTogTW9kYWxQcm9wcykge1xuICBjb25zdCBvdmVybGF5UmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGhhbmRsZUVzY2FwZSA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBpZiAoZS5rZXkgPT09IFwiRXNjYXBlXCIpIG9uQ2xvc2UoKTtcbiAgICB9O1xuXG4gICAgaWYgKGlzT3Blbikge1xuICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgaGFuZGxlRXNjYXBlKTtcbiAgICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSBcImhpZGRlblwiO1xuICAgIH1cblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBoYW5kbGVFc2NhcGUpO1xuICAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdyA9IFwidW5zZXRcIjtcbiAgICB9O1xuICB9LCBbaXNPcGVuLCBvbkNsb3NlXSk7XG5cbiAgaWYgKCFpc09wZW4pIHJldHVybiBudWxsO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICB7LyogQmFja2Ryb3AgKi99XG4gICAgICA8ZGl2IFxuICAgICAgICByZWY9e292ZXJsYXlSZWZ9XG4gICAgICAgIGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svNTAgYmFja2Ryb3AtYmx1ci1zbSB0cmFuc2l0aW9uLW9wYWNpdHlcIlxuICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgLz5cbiAgICAgIFxuICAgICAgey8qIFNjcm9sbGFibGUgY29udGFpbmVyIGVsZW1lbnQgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtZnVsbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICAgIHsvKiBNb2RhbCBDb250ZW50ICovfVxuICAgICAgICA8ZGl2IFxuICAgICAgICAgIGRhdGEtdGVzdGlkPVwibW9kYWwtY29udGFpbmVyXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctbWQgdHJhbnNmb3JtIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLTJ4bCBiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHAtNiB0ZXh0LWxlZnQgYWxpZ24tbWlkZGxlIHNoYWRvdy14bCB0cmFuc2l0aW9uLWFsbCBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwIG15LThcIlxuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNVwiPlxuICAgICAgICAgICAgPGgzIFxuICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cIm1vZGFsLXRpdGxlXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgbGVhZGluZy02IHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3RpdGxlfVxuICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJtb2RhbC1jbG9zZS1idXR0b25cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgcC0xIHRleHQtemluYy00MDAgaG92ZXI6YmctemluYy0xMDAgaG92ZXI6dGV4dC16aW5jLTUwMCBkYXJrOmhvdmVyOmJnLXppbmMtODAwIGRhcms6aG92ZXI6dGV4dC16aW5jLTMwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yXCI+XG4gICAgICAgICAgICB7Y2hpbGRyZW59XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXX0=