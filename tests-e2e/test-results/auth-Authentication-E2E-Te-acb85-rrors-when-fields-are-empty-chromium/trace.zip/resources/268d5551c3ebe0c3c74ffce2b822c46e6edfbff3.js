import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/layouts/MainLayout.tsx");const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { ArrowLeftRight, BarChart3, Eye, EyeOff, LayoutDashboard, LogOut, Menu, Moon, PieChart, PiggyBank, Sun, Tags, Wallet, X } from "/node_modules/.vite/deps/lucide-react.js?v=7df35618";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=513be775";
import { Link, Outlet, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=63710477";
import { useAuth } from "/src/components/AuthContext.tsx";
import { useTheme } from "/src/components/ThemeContext.tsx";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/layouts/MainLayout.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
var _s = $RefreshSig$();
export function MainLayout() {
	_s();
	const location = useLocation();
	const navigate = useNavigate();
	const { user, logout } = useAuth();
	const { theme, toggleTheme } = useTheme();
	const [showBalances, setShowBalances] = useState(() => {
		const saved = localStorage.getItem("show_balances");
		return saved !== "false";
	});
	const [isSidebarOpen, setIsSidebarOpen] = useState(false);
	const toggleShowBalances = () => {
		setShowBalances((prev) => {
			const next = !prev;
			localStorage.setItem("show_balances", String(next));
			return next;
		});
	};
	const handleLogout = () => {
		setIsSidebarOpen(false);
		logout();
		navigate("/login");
	};
	const navItems = [
		{
			name: "Dashboard",
			path: "/",
			icon: LayoutDashboard
		},
		{
			name: "Accounts",
			path: "/accounts",
			icon: Wallet
		},
		{
			name: "Categories",
			path: "/categories",
			icon: Tags
		},
		{
			name: "Transactions",
			path: "/transactions",
			icon: ArrowLeftRight
		},
		{
			name: "Budgets",
			path: "/budgets",
			icon: PieChart
		},
		{
			name: "Saving Goals",
			path: "/saving-goals",
			icon: PiggyBank
		},
		{
			name: "Reports",
			path: "/reports",
			icon: BarChart3
		}
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-zinc-50 dark:bg-zinc-950 flex flex-col sm:flex-row",
		children: [
			isSidebarOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/50 z-40 sm:hidden",
				onClick: () => setIsSidebarOpen(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("nav", {
				className: `fixed inset-y-0 left-0 z-50 w-64 bg-white dark:bg-zinc-900 border-r border-zinc-200 dark:border-zinc-800 flex flex-col justify-between transform transition-transform duration-200 ease-in-out sm:translate-x-0 sm:static sm:z-0 ${isSidebarOpen ? "translate-x-0" : "-translate-x-full"}`,
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "p-6 flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-bold text-zinc-900 dark:text-white tracking-tight flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-emerald-500/10 p-2 rounded-lg text-emerald-500",
							children: /* @__PURE__ */ _jsxDEV(Wallet, { className: "h-5 w-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 15
						}, this), "Finance"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 76,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setIsSidebarOpen(false),
						className: "p-2 -mr-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-300 sm:hidden cursor-pointer",
						title: "Close Menu",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "h-5 w-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("ul", {
					className: "px-3 space-y-1 mt-4",
					children: navItems.map((item) => {
						const isActive = location.pathname === item.path;
						return /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV(Link, {
							to: item.path,
							onClick: () => setIsSidebarOpen(false),
							className: `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${isActive ? "bg-emerald-550/10 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400" : "text-zinc-600 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-zinc-800"}`,
							children: [/* @__PURE__ */ _jsxDEV(item.icon, { className: "h-5 w-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 21
							}, this), item.name]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 19
						}, this) }, item.path, false, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 17
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "p-4 border-t border-zinc-200 dark:border-zinc-800",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleLogout,
						className: "flex w-full items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-500/10 transition-colors",
						children: [/* @__PURE__ */ _jsxDEV(LogOut, { className: "h-5 w-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 13
						}, this), "Sign Out"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 114,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 flex flex-col min-h-screen",
				children: [/* @__PURE__ */ _jsxDEV("header", {
					className: "border-b border-zinc-200 dark:border-zinc-800 bg-white/80 dark:bg-zinc-900/50 backdrop-blur px-6 py-4 flex items-center justify-between sticky top-0 z-10 transition-colors duration-200",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-emerald-600 dark:text-emerald-500 sm:hidden",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setIsSidebarOpen(true),
									className: "p-2 -ml-2 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-300 cursor-pointer",
									title: "Open Menu",
									children: /* @__PURE__ */ _jsxDEV(Menu, { className: "h-5 w-5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 136,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 131,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-emerald-500/10 p-2 rounded-lg",
									children: /* @__PURE__ */ _jsxDEV(Wallet, { className: "h-5 w-5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 139,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 138,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-bold text-lg text-zinc-900 dark:text-white tracking-tight",
									children: "Finance"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 141,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 130,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { className: "hidden sm:block" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 11
						}, this),
						" ",
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "hidden sm:flex flex-col text-right",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-sm font-medium text-zinc-800 dark:text-zinc-200",
										children: [
											user?.first_name,
											" ",
											user?.last_name
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 148,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-zinc-500",
										children: user?.email
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 151,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 147,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: toggleShowBalances,
									className: "p-2 rounded-lg bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700/80 text-zinc-600 dark:text-zinc-300 transition-colors border border-zinc-200 dark:border-zinc-700 cursor-pointer",
									title: showBalances ? "Hide Balances" : "Show Balances",
									"data-testid": "balance-visibility-toggle",
									children: showBalances ? /* @__PURE__ */ _jsxDEV(EyeOff, { className: "h-4 w-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 162,
										columnNumber: 17
									}, this) : /* @__PURE__ */ _jsxDEV(Eye, { className: "h-4 w-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 164,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 155,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: toggleTheme,
									className: "p-2 rounded-lg bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700/80 text-zinc-600 dark:text-zinc-300 transition-colors border border-zinc-200 dark:border-zinc-700 cursor-pointer",
									title: "Change Theme",
									"data-testid": "theme-toggle-button",
									children: theme === "dark" ? /* @__PURE__ */ _jsxDEV(Sun, { className: "h-4 w-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 176,
										columnNumber: 17
									}, this) : /* @__PURE__ */ _jsxDEV(Moon, { className: "h-4 w-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 178,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 169,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleLogout,
									className: "flex items-center gap-1.5 rounded-lg bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700/80 px-3 py-1.5 text-sm font-medium transition-colors text-zinc-600 dark:text-zinc-300 hover:text-zinc-900 dark:hover:text-white border border-zinc-200 dark:border-zinc-700 cursor-pointer",
									"data-testid": "logout-button",
									children: [/* @__PURE__ */ _jsxDEV(LogOut, { className: "h-4 w-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 187,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "hidden sm:inline",
										children: "Sign Out"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 188,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 182,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 146,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 128,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("main", {
					className: "flex-1 p-6 sm:p-10 overflow-y-auto",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "max-w-6xl mx-auto",
						children: /* @__PURE__ */ _jsxDEV(Outlet, { context: { showBalances } }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 195,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 194,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 193,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 126,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 5
	}, this);
}
_s(MainLayout, "BBUqRwBloO8zPIdJz2a4r1wXOEo=", false, function() {
	return [
		useLocation,
		useNavigate,
		useAuth,
		useTheme
	];
});
_c = MainLayout;
var _c;
$RefreshReg$(_c, "MainLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/layouts/MainLayout.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/layouts/MainLayout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/layouts/MainLayout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/layouts/MainLayout.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FDRSxnQkFDQSxXQUNBLEtBQ0EsUUFDQSxpQkFDQSxRQUNBLE1BQ0EsTUFDQSxVQUNBLFdBQ0EsS0FDQSxNQUNBLFFBQ0EsU0FDSztBQUNQLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsTUFBTSxRQUFRLGFBQWEsbUJBQW1CO0FBQ3ZELFNBQVMsZUFBZTtBQUN4QixTQUFTLGdCQUFnQjs7OztBQUV6QixPQUFPLFNBQVMsYUFBYTs7Q0FDM0IsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxFQUFFLE1BQU0sV0FBVyxRQUFRO0NBQ2pDLE1BQU0sRUFBRSxPQUFPLGdCQUFnQixTQUFTO0NBRXhDLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixlQUF3QjtFQUM5RCxNQUFNLFFBQVEsYUFBYSxRQUFRLGVBQWU7RUFDbEQsT0FBTyxVQUFVO0NBQ25CLENBQUM7Q0FDRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBa0IsS0FBSztDQUVqRSxNQUFNLDJCQUEyQjtFQUMvQixpQkFBaUIsU0FBUztHQUN4QixNQUFNLE9BQU8sQ0FBQztHQUNkLGFBQWEsUUFBUSxpQkFBaUIsT0FBTyxJQUFJLENBQUM7R0FDbEQsT0FBTztFQUNULENBQUM7Q0FDSDtDQUVBLE1BQU0scUJBQXFCO0VBQ3pCLGlCQUFpQixLQUFLO0VBQ3RCLE9BQU87RUFDUCxTQUFTLFFBQVE7Q0FDbkI7Q0FFQSxNQUFNLFdBQVc7RUFDZjtHQUFFLE1BQU07R0FBYSxNQUFNO0dBQUssTUFBTTtFQUFnQjtFQUN0RDtHQUFFLE1BQU07R0FBWSxNQUFNO0dBQWEsTUFBTTtFQUFPO0VBQ3BEO0dBQUUsTUFBTTtHQUFjLE1BQU07R0FBZSxNQUFNO0VBQUs7RUFDdEQ7R0FBRSxNQUFNO0dBQWdCLE1BQU07R0FBaUIsTUFBTTtFQUFlO0VBQ3BFO0dBQUUsTUFBTTtHQUFXLE1BQU07R0FBWSxNQUFNO0VBQVM7RUFDcEQ7R0FBRSxNQUFNO0dBQWdCLE1BQU07R0FBaUIsTUFBTTtFQUFVO0VBQy9EO0dBQUUsTUFBTTtHQUFXLE1BQU07R0FBWSxNQUFNO0VBQVU7Q0FDdkQ7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRyxpQkFDQyx3QkFBQyxPQUFEO0lBQ0UsV0FBVTtJQUNWLGVBQWUsaUJBQWlCLEtBQUs7R0FDdEM7Ozs7O0dBSUgsd0JBQUMsT0FBRDtJQUNFLFdBQVcsb09BQ1QsZ0JBQWdCLGtCQUFrQjtjQUZ0QyxDQUtFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztNQUMxQjs7OztnQkFBQyxTQUVKOzs7OztlQUVKLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLGlCQUFpQixLQUFLO01BQ3JDLFdBQVU7TUFDVixPQUFNO2dCQUVOLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O0tBQ2xCOzs7O2FBQ0w7Ozs7O2NBQ0wsd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFDWCxTQUFTLEtBQUssU0FBUztNQUN0QixNQUFNLFdBQVcsU0FBUyxhQUFhLEtBQUs7TUFDNUMsT0FDRSx3QkFBQyxNQUFELFlBQ0Usd0JBQUMsTUFBRDtPQUNFLElBQUksS0FBSztPQUNULGVBQWUsaUJBQWlCLEtBQUs7T0FDckMsV0FBVyx3RkFDVCxXQUNJLG9GQUNBO2lCQU5SLENBU0Usd0JBQUMsS0FBSyxNQUFOLEVBQVcsV0FBVSxVQUFXOzs7O2lCQUMvQixLQUFLLElBQ0Y7Ozs7O2VBQ0osR0FiSyxLQUFLOzs7O2FBYVY7S0FFUixDQUFDO0lBQ0M7Ozs7WUFDRDs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUZaLENBSUUsd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7OztnQkFBQyxVQUV4Qjs7Ozs7O0lBQ0w7Ozs7WUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUVFLHdCQUFDLFVBQUQ7S0FBUSxXQUFVO2VBQWxCO01BRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxVQUFEO1NBQ0UsZUFBZSxpQkFBaUIsSUFBSTtTQUNwQyxXQUFVO1NBQ1YsT0FBTTttQkFFTix3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztRQUNyQjs7Ozs7UUFDUix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztRQUMxQjs7Ozs7UUFDTCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaUU7UUFFM0U7Ozs7O09BQ0g7Ozs7OztNQUNMLHdCQUFDLE9BQUQsRUFBSyxXQUFVLGtCQUF1Qjs7Ozs7TUFBQztNQUN2Qyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCO1dBQ0csTUFBTTtXQUFXO1dBQUUsTUFBTTtVQUN0Qjs7Ozs7bUJBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXlCLE1BQU07U0FBWTs7OztpQkFDeEQ7Ozs7OztRQUdMLHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsV0FBVTtTQUNWLE9BQU8sZUFBZSxrQkFBa0I7U0FDeEMsZUFBWTttQkFFWCxlQUNDLHdCQUFDLFFBQUQsRUFBUSxXQUFVLFVBQVc7Ozs7b0JBRTdCLHdCQUFDLEtBQUQsRUFBSyxXQUFVLFVBQVc7Ozs7O1FBRXRCOzs7OztRQUdSLHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsV0FBVTtTQUNWLE9BQU07U0FDTixlQUFZO21CQUVYLFVBQVUsU0FDVCx3QkFBQyxLQUFELEVBQUssV0FBVSxVQUFXOzs7O29CQUUxQix3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztRQUV2Qjs7Ozs7UUFFUix3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFdBQVU7U0FDVixlQUFZO21CQUhkLENBS0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7OzttQkFDN0Isd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQW1CO1NBQWM7Ozs7aUJBQzNDOzs7Ozs7T0FDTDs7Ozs7O0tBQ0M7Ozs7O2NBRVIsd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFDZCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxRQUFELEVBQVEsU0FBUyxFQUFFLGFBQWEsRUFBSTs7Ozs7S0FDakM7Ozs7O0lBQ0Q7Ozs7WUFDSDs7Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk1haW5MYXlvdXQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFycm93TGVmdFJpZ2h0LFxuICBCYXJDaGFydDMsXG4gIEV5ZSxcbiAgRXllT2ZmLFxuICBMYXlvdXREYXNoYm9hcmQsXG4gIExvZ091dCxcbiAgTWVudSxcbiAgTW9vbixcbiAgUGllQ2hhcnQsXG4gIFBpZ2d5QmFuayxcbiAgU3VuLFxuICBUYWdzLFxuICBXYWxsZXQsXG4gIFgsXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBMaW5rLCBPdXRsZXQsIHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvQXV0aENvbnRleHRcIjtcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvVGhlbWVDb250ZXh0XCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBNYWluTGF5b3V0KCkge1xuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgeyB1c2VyLCBsb2dvdXQgfSA9IHVzZUF1dGgoKTtcbiAgY29uc3QgeyB0aGVtZSwgdG9nZ2xlVGhlbWUgfSA9IHVzZVRoZW1lKCk7XG5cbiAgY29uc3QgW3Nob3dCYWxhbmNlcywgc2V0U2hvd0JhbGFuY2VzXSA9IHVzZVN0YXRlPGJvb2xlYW4+KCgpID0+IHtcbiAgICBjb25zdCBzYXZlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwic2hvd19iYWxhbmNlc1wiKTtcbiAgICByZXR1cm4gc2F2ZWQgIT09IFwiZmFsc2VcIjtcbiAgfSk7XG4gIGNvbnN0IFtpc1NpZGViYXJPcGVuLCBzZXRJc1NpZGViYXJPcGVuXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcblxuICBjb25zdCB0b2dnbGVTaG93QmFsYW5jZXMgPSAoKSA9PiB7XG4gICAgc2V0U2hvd0JhbGFuY2VzKChwcmV2KSA9PiB7XG4gICAgICBjb25zdCBuZXh0ID0gIXByZXY7XG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInNob3dfYmFsYW5jZXNcIiwgU3RyaW5nKG5leHQpKTtcbiAgICAgIHJldHVybiBuZXh0O1xuICAgIH0pO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUxvZ291dCA9ICgpID0+IHtcbiAgICBzZXRJc1NpZGViYXJPcGVuKGZhbHNlKTtcbiAgICBsb2dvdXQoKTtcbiAgICBuYXZpZ2F0ZShcIi9sb2dpblwiKTtcbiAgfTtcblxuICBjb25zdCBuYXZJdGVtcyA9IFtcbiAgICB7IG5hbWU6IFwiRGFzaGJvYXJkXCIsIHBhdGg6IFwiL1wiLCBpY29uOiBMYXlvdXREYXNoYm9hcmQgfSxcbiAgICB7IG5hbWU6IFwiQWNjb3VudHNcIiwgcGF0aDogXCIvYWNjb3VudHNcIiwgaWNvbjogV2FsbGV0IH0sXG4gICAgeyBuYW1lOiBcIkNhdGVnb3JpZXNcIiwgcGF0aDogXCIvY2F0ZWdvcmllc1wiLCBpY29uOiBUYWdzIH0sXG4gICAgeyBuYW1lOiBcIlRyYW5zYWN0aW9uc1wiLCBwYXRoOiBcIi90cmFuc2FjdGlvbnNcIiwgaWNvbjogQXJyb3dMZWZ0UmlnaHQgfSxcbiAgICB7IG5hbWU6IFwiQnVkZ2V0c1wiLCBwYXRoOiBcIi9idWRnZXRzXCIsIGljb246IFBpZUNoYXJ0IH0sXG4gICAgeyBuYW1lOiBcIlNhdmluZyBHb2Fsc1wiLCBwYXRoOiBcIi9zYXZpbmctZ29hbHNcIiwgaWNvbjogUGlnZ3lCYW5rIH0sXG4gICAgeyBuYW1lOiBcIlJlcG9ydHNcIiwgcGF0aDogXCIvcmVwb3J0c1wiLCBpY29uOiBCYXJDaGFydDMgfSxcbiAgXTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXppbmMtNTAgZGFyazpiZy16aW5jLTk1MCBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93XCI+XG4gICAgICB7LyogQmFja2Ryb3Agb3ZlcmxheSBmb3IgbW9iaWxlICovfVxuICAgICAge2lzU2lkZWJhck9wZW4gJiYgKFxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjay81MCB6LTQwIHNtOmhpZGRlblwiXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNTaWRlYmFyT3BlbihmYWxzZSl9XG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7LyogU2lkZWJhciBOYXZpZ2F0aW9uICovfVxuICAgICAgPG5hdlxuICAgICAgICBjbGFzc05hbWU9e2BmaXhlZCBpbnNldC15LTAgbGVmdC0wIHotNTAgdy02NCBiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIGJvcmRlci1yIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMCBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiB0cmFuc2Zvcm0gdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMjAwIGVhc2UtaW4tb3V0IHNtOnRyYW5zbGF0ZS14LTAgc206c3RhdGljIHNtOnotMCAke1xuICAgICAgICAgIGlzU2lkZWJhck9wZW4gPyBcInRyYW5zbGF0ZS14LTBcIiA6IFwiLXRyYW5zbGF0ZS14LWZ1bGxcIlxuICAgICAgICB9YH1cbiAgICAgID5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXppbmMtOTAwIGRhcms6dGV4dC13aGl0ZSB0cmFja2luZy10aWdodCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWVtZXJhbGQtNTAwLzEwIHAtMiByb3VuZGVkLWxnIHRleHQtZW1lcmFsZC01MDBcIj5cbiAgICAgICAgICAgICAgICA8V2FsbGV0IGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgRmluYW5jZVxuICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgIHsvKiBDbG9zZSBidXR0b24gaW5zaWRlIHNpZGViYXIgb24gbW9iaWxlICovfVxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc1NpZGViYXJPcGVuKGZhbHNlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIC1tci0yIHJvdW5kZWQtbGcgaG92ZXI6YmctemluYy0xMDAgZGFyazpob3ZlcjpiZy16aW5jLTgwMCB0ZXh0LXppbmMtNjAwIGRhcms6dGV4dC16aW5jLTMwMCBzbTpoaWRkZW4gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICB0aXRsZT1cIkNsb3NlIE1lbnVcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJweC0zIHNwYWNlLXktMSBtdC00XCI+XG4gICAgICAgICAgICB7bmF2SXRlbXMubWFwKChpdGVtKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gbG9jYXRpb24ucGF0aG5hbWUgPT09IGl0ZW0ucGF0aDtcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8bGkga2V5PXtpdGVtLnBhdGh9PlxuICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgdG89e2l0ZW0ucGF0aH1cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNTaWRlYmFyT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHB4LTMgcHktMi41IHJvdW5kZWQtbGcgdGV4dC1zbSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctZW1lcmFsZC01NTAvMTAgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOmJnLWVtZXJhbGQtNTAwLzEwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC16aW5jLTYwMCBob3ZlcjpiZy16aW5jLTEwMCBkYXJrOnRleHQtemluYy00MDAgZGFyazpob3ZlcjpiZy16aW5jLTgwMFwiXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8aXRlbS5pY29uIGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgICAgICAgICAgICB7aXRlbS5uYW1lfVxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICk7XG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L3VsPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBib3JkZXItdCBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDBcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHctZnVsbCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtMyBweS0yLjUgcm91bmRlZC1sZyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtcmVkLTYwMCBob3ZlcjpiZy1yZWQtNTAgZGFyazp0ZXh0LXJlZC00MDAgZGFyazpob3ZlcjpiZy1yZWQtNTAwLzEwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8TG9nT3V0IGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgICAgU2lnbiBPdXRcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L25hdj5cblxuICAgICAgey8qIE1haW4gQ29udGVudCBBcmVhICsgSGVhZGVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBmbGV4LWNvbCBtaW4taC1zY3JlZW5cIj5cbiAgICAgICAgey8qIENvbnNpc3RlbnQgVG9wIEJhciBIZWFkZXIgKi99XG4gICAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtODAwIGJnLXdoaXRlLzgwIGRhcms6YmctemluYy05MDAvNTAgYmFja2Ryb3AtYmx1ciBweC02IHB5LTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHN0aWNreSB0b3AtMCB6LTEwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICAgIHsvKiBMb2dvICYgTW9iaWxlIE1lbnUgVG9nZ2xlICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC01MDAgc206aGlkZGVuXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzU2lkZWJhck9wZW4odHJ1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiAtbWwtMiByb3VuZGVkLWxnIGhvdmVyOmJnLXppbmMtMTAwIGRhcms6aG92ZXI6YmctemluYy04MDAgdGV4dC16aW5jLTYwMCBkYXJrOnRleHQtemluYy0zMDAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICB0aXRsZT1cIk9wZW4gTWVudVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxNZW51IGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWVtZXJhbGQtNTAwLzEwIHAtMiByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgIDxXYWxsZXQgY2xhc3NOYW1lPVwiaC01IHctNVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWxnIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgIEZpbmFuY2VcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBzbTpibG9ja1wiPjwvZGl2PiB7LyogU3BhY2VyIG9uIGRlc2t0b3AgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gc206ZmxleCBmbGV4LWNvbCB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC16aW5jLTgwMCBkYXJrOnRleHQtemluYy0yMDBcIj5cbiAgICAgICAgICAgICAgICB7dXNlcj8uZmlyc3RfbmFtZX0ge3VzZXI/Lmxhc3RfbmFtZX1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtemluYy01MDBcIj57dXNlcj8uZW1haWx9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBIaWRlL1Nob3cgQmFsYW5jZXMgVG9nZ2xlICovfVxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVTaG93QmFsYW5jZXN9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLWxnIGJnLXppbmMtMTAwIGhvdmVyOmJnLXppbmMtMjAwIGRhcms6YmctemluYy04MDAgZGFyazpob3ZlcjpiZy16aW5jLTcwMC84MCB0ZXh0LXppbmMtNjAwIGRhcms6dGV4dC16aW5jLTMwMCB0cmFuc2l0aW9uLWNvbG9ycyBib3JkZXIgYm9yZGVyLXppbmMtMjAwIGRhcms6Ym9yZGVyLXppbmMtNzAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgdGl0bGU9e3Nob3dCYWxhbmNlcyA/IFwiSGlkZSBCYWxhbmNlc1wiIDogXCJTaG93IEJhbGFuY2VzXCJ9XG4gICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwiYmFsYW5jZS12aXNpYmlsaXR5LXRvZ2dsZVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtzaG93QmFsYW5jZXMgPyAoXG4gICAgICAgICAgICAgICAgPEV5ZU9mZiBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8RXllIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIHsvKiBUaGVtZSBTd2l0Y2hlciBCdXR0b24gKi99XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZVRoZW1lfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgcm91bmRlZC1sZyBiZy16aW5jLTEwMCBob3ZlcjpiZy16aW5jLTIwMCBkYXJrOmJnLXppbmMtODAwIGRhcms6aG92ZXI6YmctemluYy03MDAvODAgdGV4dC16aW5jLTYwMCBkYXJrOnRleHQtemluYy0zMDAgdHJhbnNpdGlvbi1jb2xvcnMgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTcwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgIHRpdGxlPVwiQ2hhbmdlIFRoZW1lXCJcbiAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJ0aGVtZS10b2dnbGUtYnV0dG9uXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3RoZW1lID09PSBcImRhcmtcIiA/IChcbiAgICAgICAgICAgICAgICA8U3VuIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxNb29uIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlTG9nb3V0fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHJvdW5kZWQtbGcgYmctemluYy0xMDAgaG92ZXI6YmctemluYy0yMDAgZGFyazpiZy16aW5jLTgwMCBkYXJrOmhvdmVyOmJnLXppbmMtNzAwLzgwIHB4LTMgcHktMS41IHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgdGV4dC16aW5jLTYwMCBkYXJrOnRleHQtemluYy0zMDAgaG92ZXI6dGV4dC16aW5jLTkwMCBkYXJrOmhvdmVyOnRleHQtd2hpdGUgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTcwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwibG9nb3V0LWJ1dHRvblwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxMb2dPdXQgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmVcIj5TaWduIE91dDwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2hlYWRlcj5cblxuICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4LTEgcC02IHNtOnAtMTAgb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy02eGwgbXgtYXV0b1wiPlxuICAgICAgICAgICAgPE91dGxldCBjb250ZXh0PXt7IHNob3dCYWxhbmNlcyB9fSAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L21haW4+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==