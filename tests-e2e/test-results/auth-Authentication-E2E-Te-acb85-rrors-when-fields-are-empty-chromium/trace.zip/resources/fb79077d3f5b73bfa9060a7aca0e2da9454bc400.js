import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AccountsPage.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=513be775";
import { Plus, Edit2, Trash2, Wallet } from "/node_modules/.vite/deps/lucide-react.js?v=7df35618";
import { useAccounts } from "/src/hooks/useAccounts.ts";
import { Modal } from "/src/components/Modal.tsx";
import { AccountForm } from "/src/features/accounts/AccountForm.tsx";
import { useOutletContext } from "/node_modules/.vite/deps/react-router-dom.js?v=63710477";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/AccountsPage.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
var _s = $RefreshSig$();
export function AccountsPage() {
	_s();
	const { accounts, isLoading, createAccount, updateAccount, deleteAccount } = useAccounts();
	const [isModalOpen, setIsModalOpen] = useState(false);
	const [editingAccount, setEditingAccount] = useState();
	const { showBalances } = useOutletContext();
	const handleOpenModal = (account) => {
		setEditingAccount(account);
		setIsModalOpen(true);
	};
	const handleCloseModal = () => {
		setIsModalOpen(false);
		setEditingAccount(undefined);
	};
	const handleSubmit = async (data) => {
		try {
			if (editingAccount) {
				await updateAccount({
					id: editingAccount.id,
					input: data
				});
			} else {
				await createAccount(data);
			}
			handleCloseModal();
		} catch (error) {
			console.error("Failed to save account", error);
			alert("An error occurred while saving the account.");
		}
	};
	const handleDelete = async (id) => {
		if (confirm("Are you sure you want to delete this account?")) {
			try {
				await deleteAccount(id);
			} catch (error) {
				console.error("Failed to delete account", error);
				alert("Failed to delete account. It might be used in transactions.");
			}
		}
	};
	const formatRupiah = (amount) => {
		const formatted = new Intl.NumberFormat("id-ID", {
			style: "currency",
			currency: "IDR"
		}).format(amount);
		return showBalances ? formatted : "Rp ••••••";
	};
	if (isLoading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "flex h-64 items-center justify-center text-zinc-500",
			children: "Loading accounts..."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 56,
			columnNumber: 12
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-2xl font-bold text-zinc-900 dark:text-white tracking-tight",
				children: "Accounts"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-zinc-500 dark:text-zinc-400 mt-1",
				children: "Manage your family's bank accounts, e-wallets, and cash."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				onClick: () => handleOpenModal(),
				"data-testid": "add-account-button",
				className: "flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-lg text-sm font-medium transition-colors shadow-sm",
				children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "h-4 w-4" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 11
				}, this), "Add Account"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 7
		}, this),
		accounts.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 p-12 text-center",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-zinc-100 dark:bg-zinc-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4",
					children: /* @__PURE__ */ _jsxDEV(Wallet, { className: "h-8 w-8 text-zinc-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 78,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-lg font-semibold text-zinc-900 dark:text-white mb-2",
					children: "No accounts found"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-zinc-500 dark:text-zinc-400 mb-6 max-w-sm mx-auto",
					children: "You haven't added any accounts yet. Create one to start tracking your balances and transactions."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 82,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => handleOpenModal(),
					"data-testid": "add-first-account-button",
					className: "text-emerald-600 hover:text-emerald-700 font-medium text-sm",
					children: "+ Add your first account"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 77,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
			children: accounts.map((account) => /* @__PURE__ */ _jsxDEV("div", {
				"data-testid": `account-card-${account.name.toLowerCase().replace(/\s+/g, "-")}`,
				className: "bg-white dark:bg-zinc-900 rounded-xl border border-zinc-200 dark:border-zinc-800 p-5 shadow-sm hover:shadow-md transition-shadow group relative overflow-hidden",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => handleOpenModal(account),
							"data-testid": "edit-account-button",
							className: "p-1.5 text-zinc-400 hover:text-emerald-600 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-md transition-colors",
							children: /* @__PURE__ */ _jsxDEV(Edit2, { className: "h-4 w-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 107,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => handleDelete(account.id),
							"data-testid": "delete-account-button",
							className: "p-1.5 text-zinc-400 hover:text-red-600 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-md transition-colors",
							children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "h-4 w-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3 mb-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-emerald-50 dark:bg-emerald-500/10 p-2.5 rounded-lg text-emerald-650 dark:text-emerald-400",
							children: /* @__PURE__ */ _jsxDEV(Wallet, { className: "h-5 w-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-semibold text-zinc-900 dark:text-white",
							children: account.name
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-medium px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400",
							children: account.type
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-zinc-500 dark:text-zinc-400 mb-1",
						children: "Current Balance"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						"data-testid": `account-balance-${account.name.toLowerCase().replace(/\s+/g, "-")}`,
						className: "text-xl font-bold text-zinc-900 dark:text-white tracking-tight",
						children: formatRupiah(account.balance)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 132,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 15
					}, this)
				]
			}, account.id, true, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 13
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 94,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(Modal, {
			isOpen: isModalOpen,
			onClose: handleCloseModal,
			title: editingAccount ? "Edit Account" : "Add New Account",
			children: /* @__PURE__ */ _jsxDEV(AccountForm, {
				initialData: editingAccount,
				onSubmit: handleSubmit
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 149,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 144,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 60,
		columnNumber: 5
	}, this);
}
_s(AccountsPage, "99XCdkGU7j/dXpVNHPDIhttN190=", false, function() {
	return [useAccounts, useOutletContext];
});
_c = AccountsPage;
var _c;
$RefreshReg$(_c, "AccountsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/AccountsPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/AccountsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/AccountsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/AccountsPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLE9BQU8sUUFBUSxjQUFjO0FBQzVDLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsYUFBYTtBQUN0QixTQUFTLG1CQUFtQjtBQUU1QixTQUFTLHdCQUF3Qjs7OztBQUVqQyxPQUFPLFNBQVMsZUFBZTs7Q0FDN0IsTUFBTSxFQUFFLFVBQVUsV0FBVyxlQUFlLGVBQWUsa0JBQWtCLFlBQVk7Q0FDekYsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsS0FBSztDQUNwRCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUE4QjtDQUMxRSxNQUFNLEVBQUUsaUJBQWlCLGlCQUE0QztDQUVyRSxNQUFNLG1CQUFtQixZQUFzQjtFQUM3QyxrQkFBa0IsT0FBTztFQUN6QixlQUFlLElBQUk7Q0FDckI7Q0FFQSxNQUFNLHlCQUF5QjtFQUM3QixlQUFlLEtBQUs7RUFDcEIsa0JBQWtCLFNBQVM7Q0FDN0I7Q0FFQSxNQUFNLGVBQWUsT0FBTyxTQUF1QjtFQUNqRCxJQUFJO0dBQ0YsSUFBSSxnQkFBZ0I7SUFDbEIsTUFBTSxjQUFjO0tBQUUsSUFBSSxlQUFlO0tBQUksT0FBTztJQUFLLENBQUM7R0FDNUQsT0FBTztJQUNMLE1BQU0sY0FBYyxJQUFJO0dBQzFCO0dBQ0EsaUJBQWlCO0VBQ25CLFNBQVMsT0FBTztHQUNkLFFBQVEsTUFBTSwwQkFBMEIsS0FBSztHQUM3QyxNQUFNLDZDQUE2QztFQUNyRDtDQUNGO0NBRUEsTUFBTSxlQUFlLE9BQU8sT0FBZTtFQUN6QyxJQUFJLFFBQVEsK0NBQStDLEdBQUc7R0FDNUQsSUFBSTtJQUNGLE1BQU0sY0FBYyxFQUFFO0dBQ3hCLFNBQVMsT0FBTztJQUNkLFFBQVEsTUFBTSw0QkFBNEIsS0FBSztJQUMvQyxNQUFNLDZEQUE2RDtHQUNyRTtFQUNGO0NBQ0Y7Q0FFQSxNQUFNLGdCQUFnQixXQUFtQjtFQUN2QyxNQUFNLFlBQVksSUFBSSxLQUFLLGFBQWEsU0FBUztHQUFFLE9BQU87R0FBWSxVQUFVO0VBQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxNQUFNO0VBQ3RHLE9BQU8sZUFBZSxZQUFZO0NBQ3BDO0NBRUEsSUFBSSxXQUFXO0VBQ2IsT0FBTyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFzRDtFQUF3Qjs7Ozs7Q0FDdEc7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQWtFO0dBQVk7Ozs7YUFDNUYsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBd0M7R0FBMkQ7Ozs7V0FDN0c7Ozs7YUFDTCx3QkFBQyxVQUFEO0lBQ0UsZUFBZSxnQkFBZ0I7SUFDL0IsZUFBWTtJQUNaLFdBQVU7Y0FIWixDQUtFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7Y0FBQyxhQUV0Qjs7Ozs7V0FDTDs7Ozs7O0VBRUosU0FBUyxXQUFXLElBQ25CLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHdCQUF5Qjs7Ozs7SUFDeEM7Ozs7O0lBQ0wsd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBMkQ7SUFBcUI7Ozs7O0lBQzlGLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQXlEO0lBRW5FOzs7OztJQUNILHdCQUFDLFVBQUQ7S0FDRSxlQUFlLGdCQUFnQjtLQUMvQixlQUFZO0tBQ1osV0FBVTtlQUNYO0lBRU87Ozs7O0dBQ0w7Ozs7O2FBRUwsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDWixTQUFTLEtBQUksWUFDWix3QkFBQyxPQUFEO0lBRUUsZUFBYSxnQkFBZ0IsUUFBUSxLQUFLLFlBQVksQ0FBQyxDQUFDLFFBQVEsUUFBUSxHQUFHO0lBQzNFLFdBQVU7Y0FIWjtLQUtFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUNFLGVBQWUsZ0JBQWdCLE9BQU87T0FDdEMsZUFBWTtPQUNaLFdBQVU7aUJBRVYsd0JBQUMsT0FBRCxFQUFPLFdBQVUsVUFBVzs7Ozs7TUFDdEI7Ozs7Z0JBQ1Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsYUFBYSxRQUFRLEVBQUU7T0FDdEMsZUFBWTtPQUNaLFdBQVU7aUJBRVYsd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7Ozs7TUFDdkI7Ozs7Y0FDTDs7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztNQUMxQjs7OztnQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQStDLFFBQVE7TUFBUzs7OztnQkFDOUUsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQ2IsUUFBUTtNQUNMOzs7O2NBQ0g7Ozs7Y0FDRjs7Ozs7O0tBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFnRDtLQUFrQjs7OztlQUMvRSx3QkFBQyxLQUFEO01BQ0UsZUFBYSxtQkFBbUIsUUFBUSxLQUFLLFlBQVksQ0FBQyxDQUFDLFFBQVEsUUFBUSxHQUFHO01BQzlFLFdBQVU7Z0JBRVQsYUFBYSxRQUFRLE9BQU87S0FDNUI7Ozs7YUFDQTs7Ozs7SUFDRjtNQTFDRSxRQUFROzs7O1VBMENWLENBQ047RUFDRTs7Ozs7RUFHUCx3QkFBQyxPQUFEO0dBQ0UsUUFBUTtHQUNSLFNBQVM7R0FDVCxPQUFPLGlCQUFpQixpQkFBaUI7YUFFekMsd0JBQUMsYUFBRDtJQUNFLGFBQWE7SUFDYixVQUFVO0dBQ1g7Ozs7O0VBQ0k7Ozs7O0NBQ0o7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQWNjb3VudHNQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgUGx1cywgRWRpdDIsIFRyYXNoMiwgV2FsbGV0IH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xuaW1wb3J0IHsgdXNlQWNjb3VudHMgfSBmcm9tIFwiLi4vaG9va3MvdXNlQWNjb3VudHNcIjtcbmltcG9ydCB7IE1vZGFsIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvTW9kYWxcIjtcbmltcG9ydCB7IEFjY291bnRGb3JtIH0gZnJvbSBcIi4uL2ZlYXR1cmVzL2FjY291bnRzL0FjY291bnRGb3JtXCI7XG5pbXBvcnQgdHlwZSB7IEFjY291bnQsIEFjY291bnRJbnB1dCB9IGZyb20gXCIuLi90eXBlcy9hY2NvdW50c1wiO1xuaW1wb3J0IHsgdXNlT3V0bGV0Q29udGV4dCB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBBY2NvdW50c1BhZ2UoKSB7XG4gIGNvbnN0IHsgYWNjb3VudHMsIGlzTG9hZGluZywgY3JlYXRlQWNjb3VudCwgdXBkYXRlQWNjb3VudCwgZGVsZXRlQWNjb3VudCB9ID0gdXNlQWNjb3VudHMoKTtcbiAgY29uc3QgW2lzTW9kYWxPcGVuLCBzZXRJc01vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlZGl0aW5nQWNjb3VudCwgc2V0RWRpdGluZ0FjY291bnRdID0gdXNlU3RhdGU8QWNjb3VudCB8IHVuZGVmaW5lZD4oKTtcbiAgY29uc3QgeyBzaG93QmFsYW5jZXMgfSA9IHVzZU91dGxldENvbnRleHQ8eyBzaG93QmFsYW5jZXM6IGJvb2xlYW4gfT4oKTtcblxuICBjb25zdCBoYW5kbGVPcGVuTW9kYWwgPSAoYWNjb3VudD86IEFjY291bnQpID0+IHtcbiAgICBzZXRFZGl0aW5nQWNjb3VudChhY2NvdW50KTtcbiAgICBzZXRJc01vZGFsT3Blbih0cnVlKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVDbG9zZU1vZGFsID0gKCkgPT4ge1xuICAgIHNldElzTW9kYWxPcGVuKGZhbHNlKTtcbiAgICBzZXRFZGl0aW5nQWNjb3VudCh1bmRlZmluZWQpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChkYXRhOiBBY2NvdW50SW5wdXQpID0+IHtcbiAgICB0cnkge1xuICAgICAgaWYgKGVkaXRpbmdBY2NvdW50KSB7XG4gICAgICAgIGF3YWl0IHVwZGF0ZUFjY291bnQoeyBpZDogZWRpdGluZ0FjY291bnQuaWQsIGlucHV0OiBkYXRhIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXdhaXQgY3JlYXRlQWNjb3VudChkYXRhKTtcbiAgICAgIH1cbiAgICAgIGhhbmRsZUNsb3NlTW9kYWwoKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBzYXZlIGFjY291bnRcIiwgZXJyb3IpO1xuICAgICAgYWxlcnQoXCJBbiBlcnJvciBvY2N1cnJlZCB3aGlsZSBzYXZpbmcgdGhlIGFjY291bnQuXCIpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVEZWxldGUgPSBhc3luYyAoaWQ6IHN0cmluZykgPT4ge1xuICAgIGlmIChjb25maXJtKFwiQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSB0aGlzIGFjY291bnQ/XCIpKSB7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBkZWxldGVBY2NvdW50KGlkKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZGVsZXRlIGFjY291bnRcIiwgZXJyb3IpO1xuICAgICAgICBhbGVydChcIkZhaWxlZCB0byBkZWxldGUgYWNjb3VudC4gSXQgbWlnaHQgYmUgdXNlZCBpbiB0cmFuc2FjdGlvbnMuXCIpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICBjb25zdCBmb3JtYXRSdXBpYWggPSAoYW1vdW50OiBudW1iZXIpID0+IHtcbiAgICBjb25zdCBmb3JtYXR0ZWQgPSBuZXcgSW50bC5OdW1iZXJGb3JtYXQoXCJpZC1JRFwiLCB7IHN0eWxlOiBcImN1cnJlbmN5XCIsIGN1cnJlbmN5OiBcIklEUlwiIH0pLmZvcm1hdChhbW91bnQpO1xuICAgIHJldHVybiBzaG93QmFsYW5jZXMgPyBmb3JtYXR0ZWQgOiBcIlJwIOKAouKAouKAouKAouKAouKAolwiO1xuICB9O1xuXG4gIGlmIChpc0xvYWRpbmcpIHtcbiAgICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtNjQgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtemluYy01MDBcIj5Mb2FkaW5nIGFjY291bnRzLi4uPC9kaXY+O1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBzbTppdGVtcy1jZW50ZXIgbWItOCBnYXAtNFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj5BY2NvdW50czwvaDI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC16aW5jLTUwMCBkYXJrOnRleHQtemluYy00MDAgbXQtMVwiPk1hbmFnZSB5b3VyIGZhbWlseSdzIGJhbmsgYWNjb3VudHMsIGUtd2FsbGV0cywgYW5kIGNhc2guPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU9wZW5Nb2RhbCgpfVxuICAgICAgICAgIGRhdGEtdGVzdGlkPVwiYWRkLWFjY291bnQtYnV0dG9uXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTcwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMi41IHJvdW5kZWQtbGcgdGV4dC1zbSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9ycyBzaGFkb3ctc21cIlxuICAgICAgICA+XG4gICAgICAgICAgPFBsdXMgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgQWRkIEFjY291bnRcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAge2FjY291bnRzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAgcC0xMiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctemluYy0xMDAgZGFyazpiZy16aW5jLTgwMCB3LTE2IGgtMTYgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG14LWF1dG8gbWItNFwiPlxuICAgICAgICAgICAgPFdhbGxldCBjbGFzc05hbWU9XCJoLTggdy04IHRleHQtemluYy00MDBcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgbWItMlwiPk5vIGFjY291bnRzIGZvdW5kPC9oMz5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMCBtYi02IG1heC13LXNtIG14LWF1dG9cIj5cbiAgICAgICAgICAgIFlvdSBoYXZlbid0IGFkZGVkIGFueSBhY2NvdW50cyB5ZXQuIENyZWF0ZSBvbmUgdG8gc3RhcnQgdHJhY2tpbmcgeW91ciBiYWxhbmNlcyBhbmQgdHJhbnNhY3Rpb25zLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVPcGVuTW9kYWwoKX1cbiAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwiYWRkLWZpcnN0LWFjY291bnQtYnV0dG9uXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC02MDAgaG92ZXI6dGV4dC1lbWVyYWxkLTcwMCBmb250LW1lZGl1bSB0ZXh0LXNtXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICArIEFkZCB5b3VyIGZpcnN0IGFjY291bnRcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cbiAgICAgICAgICB7YWNjb3VudHMubWFwKGFjY291bnQgPT4gKFxuICAgICAgICAgICAgPGRpdiBcbiAgICAgICAgICAgICAga2V5PXthY2NvdW50LmlkfSBcbiAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9e2BhY2NvdW50LWNhcmQtJHthY2NvdW50Lm5hbWUudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9cXHMrL2csICctJyl9YH1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy16aW5jLTkwMCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAgcC01IHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1zaGFkb3cgZ3JvdXAgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCByaWdodC0wIHAtNCBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5IGZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlT3Blbk1vZGFsKGFjY291bnQpfSBcbiAgICAgICAgICAgICAgICAgIGRhdGEtdGVzdGlkPVwiZWRpdC1hY2NvdW50LWJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXppbmMtNDAwIGhvdmVyOnRleHQtZW1lcmFsZC02MDAgaG92ZXI6YmctemluYy0xMDAgZGFyazpob3ZlcjpiZy16aW5jLTgwMCByb3VuZGVkLW1kIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8RWRpdDIgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZShhY2NvdW50LmlkKX0gXG4gICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cImRlbGV0ZS1hY2NvdW50LWJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXppbmMtNDAwIGhvdmVyOnRleHQtcmVkLTYwMCBob3ZlcjpiZy16aW5jLTEwMCBkYXJrOmhvdmVyOmJnLXppbmMtODAwIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtYi00XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC01MDAvMTAgcC0yLjUgcm91bmRlZC1sZyB0ZXh0LWVtZXJhbGQtNjUwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgPFdhbGxldCBjbGFzc05hbWU9XCJoLTUgdy01XCIgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGVcIj57YWNjb3VudC5uYW1lfTwvaDM+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBiZy16aW5jLTEwMCBkYXJrOmJnLXppbmMtODAwIHRleHQtemluYy02MDAgZGFyazp0ZXh0LXppbmMtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHthY2NvdW50LnR5cGV9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtemluYy01MDAgZGFyazp0ZXh0LXppbmMtNDAwIG1iLTFcIj5DdXJyZW50IEJhbGFuY2U8L3A+XG4gICAgICAgICAgICAgICAgPHAgXG4gICAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD17YGFjY291bnQtYmFsYW5jZS0ke2FjY291bnQubmFtZS50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL1xccysvZywgJy0nKX1gfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtmb3JtYXRSdXBpYWgoYWNjb3VudC5iYWxhbmNlKX1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgPE1vZGFsXG4gICAgICAgIGlzT3Blbj17aXNNb2RhbE9wZW59XG4gICAgICAgIG9uQ2xvc2U9e2hhbmRsZUNsb3NlTW9kYWx9XG4gICAgICAgIHRpdGxlPXtlZGl0aW5nQWNjb3VudCA/IFwiRWRpdCBBY2NvdW50XCIgOiBcIkFkZCBOZXcgQWNjb3VudFwifVxuICAgICAgPlxuICAgICAgICA8QWNjb3VudEZvcm0gXG4gICAgICAgICAgaW5pdGlhbERhdGE9e2VkaXRpbmdBY2NvdW50fSBcbiAgICAgICAgICBvblN1Ym1pdD17aGFuZGxlU3VibWl0fVxuICAgICAgICAvPlxuICAgICAgPC9Nb2RhbD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==