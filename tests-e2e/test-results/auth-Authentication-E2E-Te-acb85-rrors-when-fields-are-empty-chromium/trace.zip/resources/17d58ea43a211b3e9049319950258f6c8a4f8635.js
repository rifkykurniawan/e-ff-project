import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CategoriesPage.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=513be775";
import { Plus, Edit2, Trash2, Tags, ArrowDownCircle, ArrowUpCircle } from "/node_modules/.vite/deps/lucide-react.js?v=7df35618";
import { useCategories } from "/src/hooks/useCategories.ts";
import { Modal } from "/src/components/Modal.tsx";
import { CategoryForm } from "/src/features/categories/CategoryForm.tsx";
var _jsxFileName = "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/CategoriesPage.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=513be775";
var _s = $RefreshSig$();
export function CategoriesPage() {
	_s();
	const { categories, isLoading, createCategory, updateCategory, deleteCategory } = useCategories();
	const [isModalOpen, setIsModalOpen] = useState(false);
	const [editingCategory, setEditingCategory] = useState();
	const handleOpenModal = (category) => {
		setEditingCategory(category);
		setIsModalOpen(true);
	};
	const handleCloseModal = () => {
		setIsModalOpen(false);
		setEditingCategory(undefined);
	};
	const handleSubmit = async (data) => {
		try {
			if (editingCategory) {
				await updateCategory({
					id: editingCategory.id,
					input: data
				});
			} else {
				await createCategory(data);
			}
			handleCloseModal();
		} catch (error) {
			console.error("Failed to save category", error);
			if (error.code === "23505") {
				alert("A category with this name already exists for this type.");
			} else {
				alert("An error occurred while saving the category.");
			}
		}
	};
	const handleDelete = async (id) => {
		if (confirm("Are you sure you want to delete this category?")) {
			try {
				await deleteCategory(id);
			} catch (error) {
				console.error("Failed to delete category", error);
				alert("Failed to delete category. It might be used in transactions.");
			}
		}
	};
	if (isLoading) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "flex h-64 items-center justify-center text-zinc-500",
			children: "Loading categories..."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 53,
			columnNumber: 12
		}, this);
	}
	const incomeCategories = categories.filter((c) => c.type === "Income");
	const expenseCategories = categories.filter((c) => c.type === "Expense");
	const renderCategoryList = (list, title, icon, emptyMessage) => /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "p-5 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-3",
			children: [
				icon,
				/* @__PURE__ */ _jsxDEV("h3", {
					className: "font-semibold text-lg text-zinc-900 dark:text-white",
					children: title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "ml-auto bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 text-xs font-medium px-2.5 py-0.5 rounded-full",
					children: list.length
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 7
		}, this), list.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
			className: "p-8 text-center text-zinc-500 dark:text-zinc-400 text-sm",
			children: emptyMessage
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 70,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("ul", {
			className: "divide-y divide-zinc-100 dark:divide-zinc-800",
			children: list.map((category) => /* @__PURE__ */ _jsxDEV("li", {
				"data-testid": `category-item-${category.name.toLowerCase().replace(/\s+/g, "-")}`,
				className: "flex items-center justify-between p-4 hover:bg-zinc-50 dark:hover:bg-zinc-800/50 transition-colors group",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "font-medium text-zinc-900 dark:text-white",
					children: category.name
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 15
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => handleOpenModal(category),
						"data-testid": "edit-category-button",
						className: "p-2 text-zinc-400 hover:text-emerald-600 hover:bg-zinc-100 dark:hover:bg-zinc-700 rounded-md transition-colors",
						children: /* @__PURE__ */ _jsxDEV(Edit2, { className: "h-4 w-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 19
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => handleDelete(category.id),
						"data-testid": "delete-category-button",
						className: "p-2 text-zinc-400 hover:text-red-600 hover:bg-zinc-100 dark:hover:bg-zinc-700 rounded-md transition-colors",
						children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "h-4 w-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 19
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 82,
					columnNumber: 15
				}, this)]
			}, category.id, true, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 13
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 74,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 60,
		columnNumber: 5
	}, this);
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-2xl font-bold text-zinc-900 dark:text-white tracking-tight",
				children: "Categories"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 109,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-zinc-500 dark:text-zinc-400 mt-1",
				children: "Organize your income and expenses."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 110,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 108,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				onClick: () => handleOpenModal(),
				"data-testid": "add-category-button",
				className: "flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-lg text-sm font-medium transition-colors shadow-sm",
				children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "h-4 w-4" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 117,
					columnNumber: 11
				}, this), "Add Category"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 112,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 107,
			columnNumber: 7
		}, this),
		categories.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-zinc-900 rounded-2xl border border-zinc-200 dark:border-zinc-800 p-12 text-center",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-zinc-100 dark:bg-zinc-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4",
					children: /* @__PURE__ */ _jsxDEV(Tags, { className: "h-8 w-8 text-zinc-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-lg font-semibold text-zinc-900 dark:text-white mb-2",
					children: "No categories found"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 127,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-zinc-500 dark:text-zinc-400 mb-6 max-w-sm mx-auto",
					children: "You haven't added any categories yet. Create categories like \"Salary\", \"Groceries\", or \"Rent\"."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 128,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => handleOpenModal(),
					className: "text-emerald-600 hover:text-emerald-700 font-medium text-sm",
					children: "+ Add your first category"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 131,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 123,
			columnNumber: 9
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-1 lg:grid-cols-2 gap-6",
			children: [renderCategoryList(expenseCategories, "Expense Categories", /* @__PURE__ */ _jsxDEV(ArrowDownCircle, { className: "h-5 w-5 text-red-500" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 143,
				columnNumber: 13
			}, this), "No expense categories yet."), renderCategoryList(incomeCategories, "Income Categories", /* @__PURE__ */ _jsxDEV(ArrowUpCircle, { className: "h-5 w-5 text-emerald-500" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 149,
				columnNumber: 13
			}, this), "No income categories yet.")]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 139,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(Modal, {
			isOpen: isModalOpen,
			onClose: handleCloseModal,
			title: editingCategory ? "Edit Category" : "Add New Category",
			children: /* @__PURE__ */ _jsxDEV(CategoryForm, {
				initialData: editingCategory,
				onSubmit: handleSubmit
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 160,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 155,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 106,
		columnNumber: 5
	}, this);
}
_s(CategoriesPage, "PuqCBuYWC3AgmerKPcEgvX7kLe0=", false, function() {
	return [useCategories];
});
_c = CategoriesPage;
var _c;
$RefreshReg$(_c, "CategoriesPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/CategoriesPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/CategoriesPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/CategoriesPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/rifkykurniawan/Documents/WORK!!/Project/E-FF/frontend/src/pages/CategoriesPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLE9BQU8sUUFBUSxNQUFNLGlCQUFpQixxQkFBcUI7QUFDMUUsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsb0JBQW9COzs7O0FBRzdCLE9BQU8sU0FBUyxpQkFBaUI7O0NBQy9CLE1BQU0sRUFBRSxZQUFZLFdBQVcsZ0JBQWdCLGdCQUFnQixtQkFBbUIsY0FBYztDQUNoRyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBQ3BELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQStCO0NBRTdFLE1BQU0sbUJBQW1CLGFBQXdCO0VBQy9DLG1CQUFtQixRQUFRO0VBQzNCLGVBQWUsSUFBSTtDQUNyQjtDQUVBLE1BQU0seUJBQXlCO0VBQzdCLGVBQWUsS0FBSztFQUNwQixtQkFBbUIsU0FBUztDQUM5QjtDQUVBLE1BQU0sZUFBZSxPQUFPLFNBQXdCO0VBQ2xELElBQUk7R0FDRixJQUFJLGlCQUFpQjtJQUNuQixNQUFNLGVBQWU7S0FBRSxJQUFJLGdCQUFnQjtLQUFJLE9BQU87SUFBSyxDQUFDO0dBQzlELE9BQU87SUFDTCxNQUFNLGVBQWUsSUFBSTtHQUMzQjtHQUNBLGlCQUFpQjtFQUNuQixTQUFTLE9BQVk7R0FDbkIsUUFBUSxNQUFNLDJCQUEyQixLQUFLO0dBQzlDLElBQUksTUFBTSxTQUFTLFNBQVM7SUFDMUIsTUFBTSx5REFBeUQ7R0FDakUsT0FBTztJQUNMLE1BQU0sOENBQThDO0dBQ3REO0VBQ0Y7Q0FDRjtDQUVBLE1BQU0sZUFBZSxPQUFPLE9BQWU7RUFDekMsSUFBSSxRQUFRLGdEQUFnRCxHQUFHO0dBQzdELElBQUk7SUFDRixNQUFNLGVBQWUsRUFBRTtHQUN6QixTQUFTLE9BQU87SUFDZCxRQUFRLE1BQU0sNkJBQTZCLEtBQUs7SUFDaEQsTUFBTSw4REFBOEQ7R0FDdEU7RUFDRjtDQUNGO0NBRUEsSUFBSSxXQUFXO0VBQ2IsT0FBTyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFzRDtFQUEwQjs7Ozs7Q0FDeEc7Q0FFQSxNQUFNLG1CQUFtQixXQUFXLFFBQU8sTUFBSyxFQUFFLFNBQVMsUUFBUTtDQUNuRSxNQUFNLG9CQUFvQixXQUFXLFFBQU8sTUFBSyxFQUFFLFNBQVMsU0FBUztDQUVyRSxNQUFNLHNCQUFzQixNQUFrQixPQUFlLE1BQXVCLGlCQUNsRix3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNHO0lBQ0Qsd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBdUQ7SUFBVTs7Ozs7SUFDL0Usd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFDYixLQUFLO0lBQ0Y7Ozs7O0dBQ0g7Ozs7O1lBRUosS0FBSyxXQUFXLElBQ2Ysd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDWjtFQUNFOzs7O2FBRUwsd0JBQUMsTUFBRDtHQUFJLFdBQVU7YUFDWCxLQUFLLEtBQUksYUFDUix3QkFBQyxNQUFEO0lBRUUsZUFBYSxpQkFBaUIsU0FBUyxLQUFLLFlBQVksQ0FBQyxDQUFDLFFBQVEsUUFBUSxHQUFHO0lBQzdFLFdBQVU7Y0FIWixDQUtFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQTZDLFNBQVM7SUFBVzs7OztjQUNqRix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLGVBQWUsZ0JBQWdCLFFBQVE7TUFDdkMsZUFBWTtNQUNaLFdBQVU7Z0JBRVYsd0JBQUMsT0FBRCxFQUFPLFdBQVUsVUFBVzs7Ozs7S0FDdEI7Ozs7ZUFDUix3QkFBQyxVQUFEO01BQ0UsZUFBZSxhQUFhLFNBQVMsRUFBRTtNQUN2QyxlQUFZO01BQ1osV0FBVTtnQkFFVix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztLQUN2Qjs7OzthQUNMOzs7OztZQUNIO01BckJHLFNBQVM7Ozs7VUFxQlosQ0FDTDtFQUNDOzs7O1VBRUg7Ozs7OztDQUdQLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBa0U7R0FBYzs7OzthQUM5Rix3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUF3QztHQUFxQzs7OztXQUN2Rjs7OzthQUNMLHdCQUFDLFVBQUQ7SUFDRSxlQUFlLGdCQUFnQjtJQUMvQixlQUFZO0lBQ1osV0FBVTtjQUhaLENBS0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7OztjQUFDLGNBRXRCOzs7OztXQUNMOzs7Ozs7RUFFSixXQUFXLFdBQVcsSUFDckIsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsTUFBRCxFQUFNLFdBQVUsd0JBQXlCOzs7OztJQUN0Qzs7Ozs7SUFDTCx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUEyRDtJQUF1Qjs7Ozs7SUFDaEcsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBeUQ7SUFFbkU7Ozs7O0lBQ0gsd0JBQUMsVUFBRDtLQUNFLGVBQWUsZ0JBQWdCO0tBQy9CLFdBQVU7ZUFDWDtJQUVPOzs7OztHQUNMOzs7OzthQUVMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRyxtQkFDQyxtQkFDQSxzQkFDQSx3QkFBQyxpQkFBRCxFQUFpQixXQUFVLHVCQUF3Qjs7OzthQUNuRCw0QkFDRixHQUNDLG1CQUNDLGtCQUNBLHFCQUNBLHdCQUFDLGVBQUQsRUFBZSxXQUFVLDJCQUE0Qjs7OzthQUNyRCwyQkFDRixDQUNHOzs7Ozs7RUFHUCx3QkFBQyxPQUFEO0dBQ0UsUUFBUTtHQUNSLFNBQVM7R0FDVCxPQUFPLGtCQUFrQixrQkFBa0I7YUFFM0Msd0JBQUMsY0FBRDtJQUNFLGFBQWE7SUFDYixVQUFVO0dBQ1g7Ozs7O0VBQ0k7Ozs7O0NBQ0o7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2F0ZWdvcmllc1BhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBQbHVzLCBFZGl0MiwgVHJhc2gyLCBUYWdzLCBBcnJvd0Rvd25DaXJjbGUsIEFycm93VXBDaXJjbGUgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XG5pbXBvcnQgeyB1c2VDYXRlZ29yaWVzIH0gZnJvbSBcIi4uL2hvb2tzL3VzZUNhdGVnb3JpZXNcIjtcbmltcG9ydCB7IE1vZGFsIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvTW9kYWxcIjtcbmltcG9ydCB7IENhdGVnb3J5Rm9ybSB9IGZyb20gXCIuLi9mZWF0dXJlcy9jYXRlZ29yaWVzL0NhdGVnb3J5Rm9ybVwiO1xuaW1wb3J0IHR5cGUgeyBDYXRlZ29yeSwgQ2F0ZWdvcnlJbnB1dCB9IGZyb20gXCIuLi90eXBlcy9jYXRlZ29yaWVzXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBDYXRlZ29yaWVzUGFnZSgpIHtcbiAgY29uc3QgeyBjYXRlZ29yaWVzLCBpc0xvYWRpbmcsIGNyZWF0ZUNhdGVnb3J5LCB1cGRhdGVDYXRlZ29yeSwgZGVsZXRlQ2F0ZWdvcnkgfSA9IHVzZUNhdGVnb3JpZXMoKTtcbiAgY29uc3QgW2lzTW9kYWxPcGVuLCBzZXRJc01vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlZGl0aW5nQ2F0ZWdvcnksIHNldEVkaXRpbmdDYXRlZ29yeV0gPSB1c2VTdGF0ZTxDYXRlZ29yeSB8IHVuZGVmaW5lZD4oKTtcblxuICBjb25zdCBoYW5kbGVPcGVuTW9kYWwgPSAoY2F0ZWdvcnk/OiBDYXRlZ29yeSkgPT4ge1xuICAgIHNldEVkaXRpbmdDYXRlZ29yeShjYXRlZ29yeSk7XG4gICAgc2V0SXNNb2RhbE9wZW4odHJ1ZSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ2xvc2VNb2RhbCA9ICgpID0+IHtcbiAgICBzZXRJc01vZGFsT3BlbihmYWxzZSk7XG4gICAgc2V0RWRpdGluZ0NhdGVnb3J5KHVuZGVmaW5lZCk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGRhdGE6IENhdGVnb3J5SW5wdXQpID0+IHtcbiAgICB0cnkge1xuICAgICAgaWYgKGVkaXRpbmdDYXRlZ29yeSkge1xuICAgICAgICBhd2FpdCB1cGRhdGVDYXRlZ29yeSh7IGlkOiBlZGl0aW5nQ2F0ZWdvcnkuaWQsIGlucHV0OiBkYXRhIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXdhaXQgY3JlYXRlQ2F0ZWdvcnkoZGF0YSk7XG4gICAgICB9XG4gICAgICBoYW5kbGVDbG9zZU1vZGFsKCk7XG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBzYXZlIGNhdGVnb3J5XCIsIGVycm9yKTtcbiAgICAgIGlmIChlcnJvci5jb2RlID09PSAnMjM1MDUnKSB7XG4gICAgICAgIGFsZXJ0KFwiQSBjYXRlZ29yeSB3aXRoIHRoaXMgbmFtZSBhbHJlYWR5IGV4aXN0cyBmb3IgdGhpcyB0eXBlLlwiKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGFsZXJ0KFwiQW4gZXJyb3Igb2NjdXJyZWQgd2hpbGUgc2F2aW5nIHRoZSBjYXRlZ29yeS5cIik7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jIChpZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKGNvbmZpcm0oXCJBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVsZXRlIHRoaXMgY2F0ZWdvcnk/XCIpKSB7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBkZWxldGVDYXRlZ29yeShpZCk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGRlbGV0ZSBjYXRlZ29yeVwiLCBlcnJvcik7XG4gICAgICAgIGFsZXJ0KFwiRmFpbGVkIHRvIGRlbGV0ZSBjYXRlZ29yeS4gSXQgbWlnaHQgYmUgdXNlZCBpbiB0cmFuc2FjdGlvbnMuXCIpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICBpZiAoaXNMb2FkaW5nKSB7XG4gICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLTY0IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXppbmMtNTAwXCI+TG9hZGluZyBjYXRlZ29yaWVzLi4uPC9kaXY+O1xuICB9XG5cbiAgY29uc3QgaW5jb21lQ2F0ZWdvcmllcyA9IGNhdGVnb3JpZXMuZmlsdGVyKGMgPT4gYy50eXBlID09PSBcIkluY29tZVwiKTtcbiAgY29uc3QgZXhwZW5zZUNhdGVnb3JpZXMgPSBjYXRlZ29yaWVzLmZpbHRlcihjID0+IGMudHlwZSA9PT0gXCJFeHBlbnNlXCIpO1xuXG4gIGNvbnN0IHJlbmRlckNhdGVnb3J5TGlzdCA9IChsaXN0OiBDYXRlZ29yeVtdLCB0aXRsZTogc3RyaW5nLCBpY29uOiBSZWFjdC5SZWFjdE5vZGUsIGVtcHR5TWVzc2FnZTogc3RyaW5nKSA9PiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXppbmMtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSBib3JkZXItYiBib3JkZXItemluYy0yMDAgZGFyazpib3JkZXItemluYy04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAge2ljb259XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtbGcgdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGVcIj57dGl0bGV9PC9oMz5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtYXV0byBiZy16aW5jLTEwMCBkYXJrOmJnLXppbmMtODAwIHRleHQtemluYy02MDAgZGFyazp0ZXh0LXppbmMtNDAwIHRleHQteHMgZm9udC1tZWRpdW0gcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGxcIj5cbiAgICAgICAgICB7bGlzdC5sZW5ndGh9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuICAgICAgXG4gICAgICB7bGlzdC5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyIHRleHQtemluYy01MDAgZGFyazp0ZXh0LXppbmMtNDAwIHRleHQtc21cIj5cbiAgICAgICAgICB7ZW1wdHlNZXNzYWdlfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgIDx1bCBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtemluYy0xMDAgZGFyazpkaXZpZGUtemluYy04MDBcIj5cbiAgICAgICAgICB7bGlzdC5tYXAoY2F0ZWdvcnkgPT4gKFxuICAgICAgICAgICAgPGxpIFxuICAgICAgICAgICAgICBrZXk9e2NhdGVnb3J5LmlkfSBcbiAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9e2BjYXRlZ29yeS1pdGVtLSR7Y2F0ZWdvcnkubmFtZS50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL1xccysvZywgJy0nKX1gfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcC00IGhvdmVyOmJnLXppbmMtNTAgZGFyazpob3ZlcjpiZy16aW5jLTgwMC81MCB0cmFuc2l0aW9uLWNvbG9ycyBncm91cFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtemluYy05MDAgZGFyazp0ZXh0LXdoaXRlXCI+e2NhdGVnb3J5Lm5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTEgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eVwiPlxuICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVPcGVuTW9kYWwoY2F0ZWdvcnkpfVxuICAgICAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJlZGl0LWNhdGVnb3J5LWJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgdGV4dC16aW5jLTQwMCBob3Zlcjp0ZXh0LWVtZXJhbGQtNjAwIGhvdmVyOmJnLXppbmMtMTAwIGRhcms6aG92ZXI6YmctemluYy03MDAgcm91bmRlZC1tZCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPEVkaXQyIGNsYXNzTmFtZT1cImgtNCB3LTRcIiAvPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGUoY2F0ZWdvcnkuaWQpfVxuICAgICAgICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJkZWxldGUtY2F0ZWdvcnktYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXppbmMtNDAwIGhvdmVyOnRleHQtcmVkLTYwMCBob3ZlcjpiZy16aW5jLTEwMCBkYXJrOmhvdmVyOmJnLXppbmMtNzAwIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwiaC00IHctNFwiIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC91bD5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBzbTppdGVtcy1jZW50ZXIgbWItOCBnYXAtNFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj5DYXRlZ29yaWVzPC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtNTAwIGRhcms6dGV4dC16aW5jLTQwMCBtdC0xXCI+T3JnYW5pemUgeW91ciBpbmNvbWUgYW5kIGV4cGVuc2VzLjwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVPcGVuTW9kYWwoKX1cbiAgICAgICAgICBkYXRhLXRlc3RpZD1cImFkZC1jYXRlZ29yeS1idXR0b25cIlxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLWVtZXJhbGQtNjAwIGhvdmVyOmJnLWVtZXJhbGQtNzAwIHRleHQtd2hpdGUgcHgtNCBweS0yLjUgcm91bmRlZC1sZyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tY29sb3JzIHNoYWRvdy1zbVwiXG4gICAgICAgID5cbiAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJoLTQgdy00XCIgLz5cbiAgICAgICAgICBBZGQgQ2F0ZWdvcnlcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAge2NhdGVnb3JpZXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6YmctemluYy05MDAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci16aW5jLTIwMCBkYXJrOmJvcmRlci16aW5jLTgwMCBwLTEyIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy16aW5jLTEwMCBkYXJrOmJnLXppbmMtODAwIHctMTYgaC0xNiByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0byBtYi00XCI+XG4gICAgICAgICAgICA8VGFncyBjbGFzc05hbWU9XCJoLTggdy04IHRleHQtemluYy00MDBcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTkwMCBkYXJrOnRleHQtd2hpdGUgbWItMlwiPk5vIGNhdGVnb3JpZXMgZm91bmQ8L2gzPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtemluYy01MDAgZGFyazp0ZXh0LXppbmMtNDAwIG1iLTYgbWF4LXctc20gbXgtYXV0b1wiPlxuICAgICAgICAgICAgWW91IGhhdmVuJ3QgYWRkZWQgYW55IGNhdGVnb3JpZXMgeWV0LiBDcmVhdGUgY2F0ZWdvcmllcyBsaWtlIFwiU2FsYXJ5XCIsIFwiR3JvY2VyaWVzXCIsIG9yIFwiUmVudFwiLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVPcGVuTW9kYWwoKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC02MDAgaG92ZXI6dGV4dC1lbWVyYWxkLTcwMCBmb250LW1lZGl1bSB0ZXh0LXNtXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICArIEFkZCB5b3VyIGZpcnN0IGNhdGVnb3J5XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0yIGdhcC02XCI+XG4gICAgICAgICAge3JlbmRlckNhdGVnb3J5TGlzdChcbiAgICAgICAgICAgIGV4cGVuc2VDYXRlZ29yaWVzLCBcbiAgICAgICAgICAgIFwiRXhwZW5zZSBDYXRlZ29yaWVzXCIsIFxuICAgICAgICAgICAgPEFycm93RG93bkNpcmNsZSBjbGFzc05hbWU9XCJoLTUgdy01IHRleHQtcmVkLTUwMFwiIC8+LFxuICAgICAgICAgICAgXCJObyBleHBlbnNlIGNhdGVnb3JpZXMgeWV0LlwiXG4gICAgICAgICAgKX1cbiAgICAgICAgICB7cmVuZGVyQ2F0ZWdvcnlMaXN0KFxuICAgICAgICAgICAgaW5jb21lQ2F0ZWdvcmllcywgXG4gICAgICAgICAgICBcIkluY29tZSBDYXRlZ29yaWVzXCIsIFxuICAgICAgICAgICAgPEFycm93VXBDaXJjbGUgY2xhc3NOYW1lPVwiaC01IHctNSB0ZXh0LWVtZXJhbGQtNTAwXCIgLz4sXG4gICAgICAgICAgICBcIk5vIGluY29tZSBjYXRlZ29yaWVzIHlldC5cIlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgPE1vZGFsXG4gICAgICAgIGlzT3Blbj17aXNNb2RhbE9wZW59XG4gICAgICAgIG9uQ2xvc2U9e2hhbmRsZUNsb3NlTW9kYWx9XG4gICAgICAgIHRpdGxlPXtlZGl0aW5nQ2F0ZWdvcnkgPyBcIkVkaXQgQ2F0ZWdvcnlcIiA6IFwiQWRkIE5ldyBDYXRlZ29yeVwifVxuICAgICAgPlxuICAgICAgICA8Q2F0ZWdvcnlGb3JtIFxuICAgICAgICAgIGluaXRpYWxEYXRhPXtlZGl0aW5nQ2F0ZWdvcnl9IFxuICAgICAgICAgIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9XG4gICAgICAgIC8+XG4gICAgICA8L01vZGFsPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl19